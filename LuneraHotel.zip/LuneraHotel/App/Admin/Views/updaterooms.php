<?php
ob_start();
require_once __DIR__ . '/header.php';
require_once __DIR__ . '/../../config/Helpers/amenityicon.php';
?>

<div class="p-10">
    <a href="/LuneraHotel/App/Public/managerooms">
        <h1 class="p-2 w-[200px] bg-white shadow-2xl border rounded-2xl hover:bg-amber-600 hover:text-white border-[#b4adad] hover:scale-105 ">
            <i class="fa-solid fa-arrow-left"></i> Back to All Rooms
        </h1>
    </a>

    <div class="w-full flex flex-col justify-center items-center p-10">

        <?php if (!$room): ?>
            <p>Room information is not available.</p>
        <?php else: ?>
            <?php if (isset($successMessage)) echo "<p class='text-green-600 text-2xl p-5'>$successMessage</p>"; ?>
            <?php if (isset($errorMessage)) echo "<p class='text-red-600 text-2xl p-5'>$errorMessage</p>"; ?>

            <form method="POST" enctype="multipart/form-data" class="w-full md:w-[60vw] bg-white shadow-2xl border border-[#dddddd] p-6 md:p-10 rounded-2xl flex flex-col gap-6 ">

                <div>
                    <h1 class="text-3xl font-semibold">Edit Room Details</h1>
                    <p class="text-xl">Update the information for <?= htmlspecialchars($room['room_type']) ?></p>
                </div>

                <!-- Room Number + Room Name -->
                <div class="flex flex-col md:flex-row gap-4 w-full">
                    <div class="flex flex-col w-full">
                        <label class="font-semibold text-xl">Room Number</label>
                        <input type="text" name="room_number" value="<?= htmlspecialchars($room['room_number']) ?>" class="outline-0 bg-[#ebebeb] p-3 rounded-xl border border-[#dcdcdc] ">
                    </div>

                    <div class="flex flex-col w-full">
                        <label class="font-semibold text-xl">Room Name</label>
                        <input type="text" name="room_type" value="<?= htmlspecialchars($room['room_type']) ?>" class="outline-0 bg-[#ebebeb] p-3 rounded-xl border border-[#dcdcdc] ">
                    </div>
                </div>

                <!-- Room Type Dropdown -->
                <select name="type_name" class="border border-[#dcdcdc] p-3 rounded-xl bg-[#ebebeb] w-full md:w-[250px]">
                    <?php foreach ($roomTypes as $type): ?>
                        <option value="<?= htmlspecialchars($type['type_name']) ?>"
                            <?= ($room['type_name'] ?? '') === $type['type_name'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($type['type_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <!-- Description -->
                <div class="flex flex-col w-full">
                    <label class="font-semibold text-xl">Description</label>
                    <input type="text" name="description" value="<?= htmlspecialchars($room['description']) ?>" class="outline-0 bg-[#ebebeb] p-3 rounded-xl border border-[#dcdcdc] ">
                </div>

                <!-- Image Upload -->
                <div class="flex flex-col w-full">
                    <label class="font-semibold text-xl">Image</label>
                    <input type="file" name="img" class="outline-0 bg-[#ebebeb] p-3 rounded-xl w-full md:w-[250px] border border-[#dcdcdc] ">
                </div>

                <!-- Status Radio Buttons -->
                <div class="flex flex-col md:flex-row gap-6 items-start md:items-center text-xl">
                    <?php $isDirty = $room['status'] === 'Dirty'; ?>

                    <label class="flex items-center gap-3 font-semibold">
                        <i class="fa-solid fa-screwdriver-wrench text-[#800000] "></i> Under Maintenance
                        <input type="radio" name="status" value="Under Maintenance"
                            <?= $room['status'] === 'Under Maintenance' ? 'checked' : '' ?>
                            <?= $isDirty ? 'disabled' : '' ?>
                            class="w-6 h-6">
                    </label>

                    <label class="flex items-center gap-3 font-semibold">
                        <i class="fa-solid fa-bed text-green-800"></i> Available
                        <input type="radio" name="status" value="Available"
                            <?= $room['status'] === 'Available' ? 'checked' : '' ?>
                            <?= $isDirty ? 'disabled' : '' ?>
                            class="w-6 h-6">
                    </label>

                    <label class="flex items-center gap-3 font-semibold">
                        <i class="fa-solid fa-book text-blue-800"></i> Booked
                        <input type="radio" name="status" value="Booked"
                            <?= $room['status'] === 'Booked' ? 'checked' : '' ?>
                            <?= $isDirty ? 'disabled' : '' ?>
                            class="w-6 h-6">
                    </label>

                    <label class="flex items-center gap-3 font-semibold">
                        <i class="fa-solid fa-broom text-orange-600"></i> Needs Cleaning
                        <input type="radio" name="status" value="Dirty"
                            <?= $isDirty ? 'checked disabled' : '' ?>
                            class="w-6 h-6">
                    </label>
                </div>

                <!-- Floor + Capacity -->
                <div class="flex flex-col md:flex-row gap-4 w-full">
                    <div class="flex flex-col w-full">
                        <label class="font-semibold text-xl">Floor</label>
                        <input type="number" name="floor" value="<?= htmlspecialchars($room['floor']) ?>" min="1" max="4" class="border border-[#dcdcdc] p-3 rounded-xl bg-[#ebebeb] outline-0">
                    </div>

                    <div class="flex flex-col w-full">
                        <label class="font-semibold text-xl">Capacity</label>
                        <input type="number" name="people" value="<?= htmlspecialchars($room['people']) ?>" min="1" max="6" class="border border-[#dcdcdc] p-3 rounded-xl bg-[#ebebeb] outline-0">
                    </div>
                </div>

                <!-- Amenities -->
                <label class="font-semibold text-xl">Amenities</label>
                <div class="grid grid-cols-2 md:grid-cols-3 gap-4 ">
                    <?php foreach ($allAmenities as $amenity): ?>
                        <label class="flex items-center gap-3">
                            <input type="checkbox" name="amenities[]" value="<?= htmlspecialchars($amenity) ?>" <?= in_array($amenity, $roomAmenities) ? 'checked' : '' ?> class="w-6 h-6">
                            <i class="<?= htmlspecialchars(getAmenityIcon($amenity)) ?> text-[#800000]"></i>
                            <?= htmlspecialchars($amenity) ?>
                        </label>
                    <?php endforeach; ?>
                </div>

                <!-- Bedsheet sets per room -->
                <div class="mt-6 bg-[#fafafa] p-4 rounded-lg">
                    <h3 class="font-semibold text-xl mb-2">Bedsheet Sets (per room)</h3>
                    <?php
                    $bedsheetsModel = new \InventoryModel($pdo);
                    // ensure sets exist
                    $bedsheetsModel->initializeBedsheetSets($room['id']);
                    $sets = $bedsheetsModel->getBedsheetsForRoom($room['id']);
                    if (empty($sets)) {
                        echo "<p class='text-sm text-gray-600'>No bedsheet sets configured. Use the composer below to create sets.</p>";
                    } else {
                        // map item display names based on room type
                        $rtype = strtolower($room['room_type'] ?? $room['type_name'] ?? '');
                        $sheetLabel = 'Bed Sheet';
                        if (strpos($rtype, 'king') !== false) $sheetLabel = 'King Bed Sheet';
                        elseif (strpos($rtype, 'family') !== false || strpos($rtype, 'family') !== false) $sheetLabel = 'Family Bed Sheet';
                        elseif (strpos($rtype, 'twin') !== false) $sheetLabel = 'Twin Bed Sheet';
                        elseif (strpos($rtype, 'single') !== false) $sheetLabel = 'Single Bed Sheet';

                        // standard items we show in each set (order matters)
                        $standardItems = [
                            'Pillow Sheet' => 'Pillow Sheet',
                            'BED SHEET' => $sheetLabel,
                            'TOWEL' => 'Towel',
                            'BLANKET' => 'Blanket'
                        ];

                        // wrapper for sets (one set per row)
                        echo '<div class="space-y-4">';
                        foreach ($sets as $set):
                            $status = strtoupper($set['status']);
                            $badgeClass = 'bg-green-500 text-white';
                            if ($status === 'UNAVAILABLE') $badgeClass = 'bg-gray-400 text-white';
                            elseif ($status === 'USING') $badgeClass = 'bg-blue-600 text-white';
                            $restockInfo = $bedsheetsModel->canRestockSet($set['set_id']);
                            $canRestock = $restockInfo['ok'];
                        ?>
                            <div class="mb-3 border rounded-lg p-3">
                                <div class="flex items-start justify-between">
                                    <div class="font-semibold flex items-center gap-3">
                                        <div class="text-lg">SET <?= (int)$set['set_no'] ?></div>
                                    </div>
                                    <div class="flex items-center gap-2">
                                        <button type="button" class="px-2 py-1 rounded <?= $badgeClass ?> text-sm use-set-btn" data-set-no="<?= (int)$set['set_no'] ?>"><?= htmlspecialchars($set['status']) ?></button>
                                    </div>
                                </div>

                                <div class="mt-3">
                                    <table class="w-full md:w-[840px] table-fixed text-sm border-collapse border">
                                        <colgroup>
                                            <col style="width:18%">
                                            <col style="width:42%">
                                            <col style="width:20%">
                                            <col style="width:20%">
                                        </colgroup>
                                        <thead>
                                            <tr class="bg-white text-left">
                                                <th class="p-2 border">ACTION</th>
                                                <th class="p-2 border">ITEM NAME</th>
                                                <th class="p-2 border text-center">NUMBER OF USE</th>
                                                <th class="p-2 border">CONDITION</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            // build quick lookup of set items by item name (upper)
                                            $lookup = [];
                                            foreach ($set['items'] as $it) {
                                                $lookup[strtoupper($it['name'])] = $it;
                                            }
                                            foreach ($standardItems as $key => $display):
                                                $it = $lookup[strtoupper($key)] ?? null;
                                                $used = $it ? (int)$it['used_count'] : 0;
                                                $maxu = $it ? (int)$it['max_use'] : 30;
                                            ?>
                                            <tr>
                                                <td class="p-2 border text-center">
                                                    <?php
                                                    $rowItemName = $it['name'] ?? $display;
                                                    $rowQty = isset($it['quantity']) ? (int)$it['quantity'] : 1;
                                                    $needsRestock = ($used >= $maxu);
                                                    $btnClass = $needsRestock ? 'row-restock-btn px-2 py-1 bg-red-600 text-white rounded text-sm font-semibold' : 'px-2 py-1 bg-gray-100 text-gray-500 rounded text-sm';
                                                    $disabledAttr = $needsRestock ? '' : 'disabled';
                                                    ?>
                                                    <button type="button" class="<?= $btnClass ?>" <?= $disabledAttr ?> data-set-no="<?= (int)$set['set_no'] ?>" data-item-name="<?= htmlspecialchars($rowItemName, ENT_QUOTES) ?>" data-qty="<?= $rowQty ?>">RE-STOCK</button>
                                                </td>
                                                <td class="p-2 border"><?= htmlspecialchars($display) ?></td>
                                                <td class="p-2 border text-center"><?= $used ?>/<?= $maxu ?></td>
                                                <td class="p-2 border"><?php if ($used >= $maxu) echo 'need to restock'; else echo 'good'; ?></td>
                                            </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        <?php endforeach; 
                        echo '</div>';
                    }
                    // lightweight composer: if DB has bedsheet-related items, show quick reference
                    
                    ?>
                </div>

                <div>
                    <div class="flex gap-4">
                        <button type="submit" name="update_room" class="px-6 py-3 bg-[#800000] text-white rounded-2xl text-xl w-full md:w-[200px] cursor-pointer">Save changes</button>
                        <!-- Mark Room Used removed: booking now automatically adjusts usage counts when status changes to Booked -->
                    </div>
                </div>
            </form>
        <?php endif; ?>
    </div>

<?php
$content = ob_get_clean();
include __DIR__ . '/../../../App/layout.php';
?>

<!-- Confirmation dialog for restock buttons and per-set Use buttons -->
<script>
document.addEventListener('DOMContentLoaded', function(){
    const form = document.querySelector('form');
    if (!form) return;

    // Restock confirmation (per-set) and Use (per-set) handlers
    document.querySelectorAll('.restock-btn').forEach(function(btn){
        btn.addEventListener('click', function(ev){
            ev.preventDefault();
            const comp = btn.getAttribute('data-composition');
            let items = [];
            try { items = JSON.parse(comp); } catch(e){ items = []; }
            let msg = 'You are about to restock set ' + btn.dataset.setNo + '. This will deduct from global inventory:\n\n';
            items.forEach(function(it){ msg += '- ' + it.name + ': ' + it.qty + '\n'; });
            msg += '\nContinue?';
            if (confirm(msg)) {
                let f = form.querySelector('input[name="confirm_restock"]');
                if (!f) {
                    f = document.createElement('input');
                    f.type = 'hidden'; f.name = 'confirm_restock'; f.value = '1';
                    form.appendChild(f);
                }
                // create a hidden input the controller expects
                let hb = document.createElement('input'); hb.type='hidden'; hb.name='restock_bedsheet_set'; hb.value=btn.dataset.setNo; form.appendChild(hb);
                form.submit();
            }
        });
    });

    // Per-set Use buttons submit a specific `use_set` (target that set). Optimistic UI applied.
    document.querySelectorAll('.use-set-btn').forEach(function(b){
        b.addEventListener('click', function(ev){
            ev.preventDefault();
            // make other use buttons revert to normal 'Use' state (only one USING at a time)
            document.querySelectorAll('.use-set-btn').forEach(function(other){
                if (other === b) return;
                other.textContent = 'Use';
                other.classList.remove('bg-blue-600');
                other.classList.add('bg-green-500');
                other.disabled = false;
            });
            // optimistic UI: set clicked button to USING and disable while submitting
            b.textContent = 'USING';
            b.classList.remove('bg-green-500');
            b.classList.add('bg-blue-600');
            b.disabled = true;
            // remove any existing use_set input
            let existing = form.querySelector('input[name="use_set"]');
            if (existing) existing.remove();
            // create use_set hidden input (controller will consume this specific set)
            let hb = document.createElement('input'); hb.type='hidden'; hb.name='use_set'; hb.value=b.dataset.setNo; form.appendChild(hb);
            form.submit();
        });
    });

    // Per-row restock buttons inside each set table
    document.querySelectorAll('.row-restock-btn').forEach(function(btn){
        btn.addEventListener('click', function(ev){
            ev.preventDefault();
            const setNo = btn.dataset.setNo;
            const item = btn.dataset.itemName;
            const qty = btn.dataset.qty || 1;
            const msg = 'You are about to restock:\n\nSet ' + setNo + '\n' + item + ': ' + qty + '\n\nThis will deduct from global inventory. Continue?';
            if (confirm(msg)){
                let f = form.querySelector('input[name="confirm_restock"]');
                if (!f){ f = document.createElement('input'); f.type='hidden'; f.name='confirm_restock'; f.value='1'; form.appendChild(f); }
                // indicate which set and which item to restock
                let hs = document.createElement('input'); hs.type='hidden'; hs.name='restock_bedsheet_set'; hs.value=setNo; form.appendChild(hs);
                let hi = document.createElement('input'); hi.type='hidden'; hi.name='restock_item'; hi.value=item; form.appendChild(hi);
                form.submit();
            }
        });
    });
});
</script>
