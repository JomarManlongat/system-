<?php

ob_start();
require_once 'header.php';
require_once __DIR__ . '/../../config/Helpers/amenityicon.php';

if (!isset($_SESSION['user'])) {
    header('Location: index.php?page=login');
    exit;
}
// If there's a DB error from controller, show it
if (isset($dbError) && $dbError) {
    echo '<div class="mb-6 p-4 rounded bg-red-50 text-red-700">' . htmlspecialchars($dbError) . '</div>';
}
?>

<div class="max-w-7xl mx-auto px-6 py-10">
    <h1 class="text-4xl font-extrabold text-gray-800 mb-6">Inventory</h1>

    <p class="mb-6 text-gray-600">All inventory is shown below, including bedsheets. Bedsheets have both a global stock and per-room sets: use the room management page to assign or edit per-room sets and to mark sets used. Toiletries are tracked globally and will be deducted when rooms are used.</p>

    <?php if (!empty($perRoomTemplates)): ?>
        <div class="mb-6 grid grid-cols-1 md:grid-cols-4 gap-4">
            <?php foreach ($perRoomTemplates as $type => $req): ?>
                <div class="p-4 border rounded-lg bg-white shadow-sm">
                    <div class="font-semibold mb-2"><?= htmlspecialchars($type) ?> room needs</div>
                    <ul class="text-sm text-gray-700">
                        <?php foreach ($req as $label => $qty): ?>
                            <li><?= htmlspecialchars($label) ?>: <strong><?= (int)$qty ?></strong></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <?php if (isset($debugInfo)): ?>
        <div class="mb-4 p-3 bg-yellow-50 border rounded text-sm text-gray-700">
            <strong>Debug:</strong>
            All items: <?= (int)$debugInfo['allItemsCount'] ?>, Filtered items: <?= (int)$debugInfo['filteredItemsCount'] ?>;
            All summary: <?= (int)$debugInfo['allSummaryCount'] ?>, Filtered summary: <?= (int)$debugInfo['filteredSummaryCount'] ?>
            <details class="mt-2"><summary>Sample</summary><pre class="text-xs"><?= htmlspecialchars(var_export($debugInfo['allSummarySample'], true)) ?></pre></details>
        </div>
    <?php endif; ?>

    <!-- Summary Table -->
    <div class="bg-white rounded-2xl shadow-lg overflow-hidden">
        <table class="min-w-full text-sm text-left">
            <thead class="bg-gray-100 text-gray-600 uppercase tracking-wider">
                <tr>
                    <th class="px-6 py-4">Item Name</th>
                    <th class="px-6 py-4">Category</th>
                    <th class="px-6 py-4 text-center">Stock</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
                <?php foreach ($summary as $s): ?>
                    <tr class="hover:bg-gray-50 transition">
                        <td class="px-6 py-4 font-semibold"><?= htmlspecialchars($s['name']) ?></td>
                        <td class="px-6 py-4"><?= $s['location'] ?></td>
                        <td class="px-6 py-4 text-center"><?= $s['stock'] ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php
$content = ob_get_clean();
include __DIR__ . '/../../../App/layout.php';
