<?php
class InventoryModel {
    private $pdo;
    private $max_use = 30;

    public function __construct($pdo){
        $this->pdo = $pdo;
    }

    // Increment inventory when a room is booked
    public function bookRoom($roomId, $people) {
        // Update room's people count directly to the value submitted
        $stmt = $this->pdo->prepare("UPDATE rooms SET people = ? WHERE id = ?");
        $stmt->execute([$people, $roomId]);

        // Get all items
        $stmt = $this->pdo->query("SELECT id FROM items");
        $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($items as $item) {
            $check = $this->pdo->prepare("SELECT used_count FROM room_item_usage WHERE room_id = ? AND item_id = ?");
            $check->execute([$roomId, $item['id']]);
            $row = $check->fetch(PDO::FETCH_ASSOC);

            if ($row) {
                $newUsed = min($row['used_count'] + $people, $this->max_use);
                $update = $this->pdo->prepare("
                    UPDATE room_item_usage 
                    SET used_count = ?, condition_status = CASE WHEN ? >= ? THEN 'need to restock' ELSE 'good' END
                    WHERE room_id = ? AND item_id = ?
                ");
                $update->execute([$newUsed, $newUsed, $this->max_use, $roomId, $item['id']]);
            } else {
                $status = ($people >= $this->max_use) ? 'need to restock' : 'good';
                $insert = $this->pdo->prepare("
                    INSERT INTO room_item_usage (room_id, item_id, used_count, max_use, condition_status) 
                    VALUES (?, ?, ?, 30, ?)
                ");
                $insert->execute([$roomId, $item['id'], $people, $status]);
            }
        }
    }

    // Reset usage for an item
    public function restockItem($itemId) {
        // Reset room usage counters for this item
        $stmt = $this->pdo->prepare("
            UPDATE room_item_usage 
            SET used_count = 0, condition_status = 'good' 
            WHERE item_id = ?
        ");
        $stmt->execute([$itemId]);
        
        // Sync to central inventory: record replenishment
        $this->syncRestockToCentralInventory($itemId);
    }
    
    private function syncRestockToCentralInventory($itemId) {
        // Get item details from hotel DB
        $stmt = $this->pdo->prepare("SELECT name, Stock, location FROM items WHERE id = ?");
        $stmt->execute([$itemId]);
        $item = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$item) return;
        
        // Connect to central inventory DB
        require_once __DIR__ . '/../../../../shared/dual_connection.php';
        if (!isset($conn_inventory)) return;
        
        // Find matching item in central inventory (case/space insensitive)
        $normalizedName = strtolower(preg_replace('/\s+/', '', $item['name']));
        $centralItemId = null;
        
        $result = $conn_inventory->query("SELECT ItemID, ItemName FROM items");
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $centralNormalized = strtolower(preg_replace('/\s+/', '', $row['ItemName']));
                if ($centralNormalized === $normalizedName || 
                    (strpos($centralNormalized, 'bed') !== false && $item['location'] === 'BEDSHEETS') ||
                    (strpos($centralNormalized, 'sheet') !== false && $item['location'] === 'BEDSHEETS')) {
                    $centralItemId = intval($row['ItemID']);
                    break;
                }
            }
        }
        
        if (!$centralItemId) return; // No matching item in central inventory
        
        // Record usage in central inventory (mode=replenish will add to central stock)
        $quantity = intval($item['Stock']); // Use current stock as quantity
        $userId = $_SESSION['user_id'] ?? 1;
        $notes = "Hotel inventory restock for: " . $item['name'];
        
        $stmt = $conn_inventory->prepare("INSERT INTO item_usage (ItemID, Quantity, UserID, Notes, CreatedAt) VALUES (?, ?, ?, ?, NOW())");
        if ($stmt) {
            $stmt->bind_param('iiis', $centralItemId, $quantity, $userId, $notes);
            $stmt->execute();
            $stmt->close();
        }
    }

    // Get inventory status
    public function getInventoryStatus() {
        // Compute used_count per item and return max_use = items.Stock (if present)
        $sql = "SELECT i.id, i.name, i.location,
                COALESCE(SUM(riu.used_count),0) AS used_count,
                COALESCE(i.Stock, :default_max) AS max_use
            FROM items i
            LEFT JOIN room_item_usage riu ON i.id = riu.item_id
            GROUP BY i.id
            ORDER BY i.name";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':default_max', $this->max_use, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Get inventory summary
    public function getSummaryStock() {
        // Compute available stock as items.Stock - SUM(used_count) where possible
        $sql = "SELECT i.id, i.name, i.location,
                COALESCE(i.Stock, :default_stock) AS total_stock,
                COALESCE(SUM(riu.used_count),0) AS used_sum,
                GREATEST(COALESCE(i.Stock, :default_stock) - COALESCE(SUM(riu.used_count),0), 0) AS stock
            FROM items i
            LEFT JOIN room_item_usage riu ON i.id = riu.item_id
            GROUP BY i.id
            ORDER BY i.name";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':default_stock', $this->max_use, PDO::PARAM_INT);
        $stmt->execute();
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        // Normalize output
        return array_map(function($r){
            return [
                'id' => $r['id'],
                'name' => $r['name'],
                'location' => $r['location'],
                'stock' => max(0, (int)$r['stock'])
            ];
        }, $rows);
    }

    // Get bedsheet sets for a specific room (per-room data)
    public function getBedsheetsForRoom($roomId) {
        // Return per-room sets and items (if migration not run, fall back to previous per-item rows)
        $sets = [];
        try {
            $stmt = $this->pdo->prepare("SELECT s.id AS set_id, s.set_no FROM room_bedsheet_sets s WHERE s.room_id = ? ORDER BY s.set_no");
            $stmt->execute([$roomId]);
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            if (!$rows) return [];
            foreach ($rows as $r) {
                $setId = $r['set_id'];
                $stmt2 = $this->pdo->prepare("SELECT rbs.id AS row_id, rbs.item_id, rbs.quantity, rbs.used_count, rbs.max_use, i.name FROM room_bedsheet_set_items rbs JOIN items i ON i.id = rbs.item_id WHERE rbs.set_id = ?");
                $stmt2->execute([$setId]);
                $items = $stmt2->fetchAll(PDO::FETCH_ASSOC);
                // compute set status: if any item used_count >= max_use => Unavailable; else if any used_count>0 => Using; else Use
                $status = 'Use';
                foreach ($items as $it) {
                    if ((int)$it['used_count'] >= (int)$it['max_use']) { $status = 'Unavailable'; break; }
                    if ((int)$it['used_count'] > 0) $status = 'Using';
                }
                $sets[] = [
                    'set_no' => (int)$r['set_no'],
                    'set_id' => $setId,
                    'status' => $status,
                    'items' => $items
                ];
            }
        } catch (Exception $e) {
            // If tables don't exist, fall back to old per-item representation
            $sql = "SELECT i.id, i.name, i.location, COALESCE(riu.used_count,0) AS used_count, COALESCE(riu.max_use,0) AS max_use, COALESCE(riu.condition_status,'good') AS condition_status
                FROM items i
                LEFT JOIN room_item_usage riu ON i.id = riu.item_id AND riu.room_id = :roomId
                WHERE i.location = 'BEDSHEETS'
                ORDER BY i.name";
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindValue(':roomId', $roomId, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
        return $sets;
    }

    // Initialize (ensure) 3 bedsheet sets exist for a room
    public function initializeBedsheetSets($roomId) {
        for ($i = 1; $i <= 3; $i++) {
            $stmt = $this->pdo->prepare("SELECT id FROM room_bedsheet_sets WHERE room_id = ? AND set_no = ?");
            $stmt->execute([$roomId, $i]);
            if (!$stmt->fetch()) {
                $ins = $this->pdo->prepare("INSERT INTO room_bedsheet_sets (room_id, set_no) VALUES (?, ?)");
                $ins->execute([$roomId, $i]);
            }
        }
        // Ensure each set has items; if a set has no items, seed it from global items where location='BEDSHEETS'
        try {
            $stmtSets = $this->pdo->prepare("SELECT id AS set_id FROM room_bedsheet_sets WHERE room_id = ? ORDER BY set_no");
            $stmtSets->execute([$roomId]);
            $sets = $stmtSets->fetchAll(PDO::FETCH_ASSOC);
            // fetch available bedsheet items
            $stmtItems = $this->pdo->query("SELECT id AS item_id, name FROM items WHERE location = 'BEDSHEETS'");
            $bedsheetItems = $stmtItems->fetchAll(PDO::FETCH_ASSOC);
            foreach ($sets as $s) {
                $setId = $s['set_id'];
                $chk = $this->pdo->prepare("SELECT id FROM room_bedsheet_set_items WHERE set_id = ? LIMIT 1");
                $chk->execute([$setId]);
                if ($chk->fetch()) continue; // already populated
                if (empty($bedsheetItems)) continue;
                $ins = $this->pdo->prepare("INSERT INTO room_bedsheet_set_items (set_id, item_id, quantity, used_count, max_use) VALUES (?, ?, ?, 0, ?)");
                foreach ($bedsheetItems as $bi) {
                    // default quantity per set: 1
                    $ins->execute([$setId, (int)$bi['item_id'], 1, $this->max_use]);
                }
            }
        } catch (Exception $e) {
            // ignore seeding errors
        }

        return true;
    }

    // Set composition for a specific set (composition = [item_id => quantity, ...])
    public function setSetComposition($roomId, $setNo, array $composition) {
        // ensure set exists
        $stmt = $this->pdo->prepare("SELECT id FROM room_bedsheet_sets WHERE room_id = ? AND set_no = ?");
        $stmt->execute([$roomId, $setNo]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            $setId = $row['id'];
        } else {
            $ins = $this->pdo->prepare("INSERT INTO room_bedsheet_sets (room_id, set_no) VALUES (?, ?)");
            $ins->execute([$roomId, $setNo]);
            $setId = $this->pdo->lastInsertId();
        }

        // remove existing items for set
        $del = $this->pdo->prepare("DELETE FROM room_bedsheet_set_items WHERE set_id = ?");
        $del->execute([$setId]);

        // insert new composition
        $insItem = $this->pdo->prepare("INSERT INTO room_bedsheet_set_items (set_id, item_id, quantity, used_count, max_use) VALUES (?, ?, ?, 0, ?)");
        foreach ($composition as $itemId => $qty) {
            $qty = max(0, (int)$qty);
            $insItem->execute([$setId, (int)$itemId, $qty, $this->max_use]);
        }

        return true;
    }

    // Reset a particular set to zero usage (by set_id)
    public function resetBedsheetSet($roomId, $setNo) {
        $stmt = $this->pdo->prepare("SELECT id FROM room_bedsheet_sets WHERE room_id = ? AND set_no = ?");
        $stmt->execute([$roomId, $setNo]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            $setId = $row['id'];
            $upd = $this->pdo->prepare("UPDATE room_bedsheet_set_items SET used_count = 0 WHERE set_id = ?");
            $upd->execute([$setId]);
        }
        return true;
    }

    // Restock a bedsheet set: deduct global stock by set quantities and reset per-set usage
    public function restockBedsheetSet($roomId, $setNo) {
        try {
            $logFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'inventory_debug.log';
            $this->pdo->beginTransaction();
            $stmt = $this->pdo->prepare("SELECT id FROM room_bedsheet_sets WHERE room_id = ? AND set_no = ? FOR UPDATE");
            $stmt->execute([$roomId, $setNo]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$row) {
                $this->pdo->commit();
                return false;
            }
            $setId = $row['id'];

            // fetch set items and check availability
            $stmtItems = $this->pdo->prepare("SELECT rbs.id AS rbs_id, rbs.item_id, rbs.quantity, i.name, COALESCE(i.Stock,0) AS stock FROM room_bedsheet_set_items rbs JOIN items i ON i.id = rbs.item_id WHERE rbs.set_id = ? FOR UPDATE");
            $stmtItems->execute([$setId]);
            $items = $stmtItems->fetchAll(PDO::FETCH_ASSOC);

            $shortages = [];
            foreach ($items as $it) {
                $need = max(0, (int)$it['quantity']);
                $have = max(0, (int)$it['stock']);
                if ($have < $need) {
                    $shortages[] = ['item_id'=>$it['item_id'],'name'=>$it['name'],'need'=>$need,'have'=>$have];
                }
            }
            if (!empty($shortages)) {
                $this->pdo->rollBack();
                $msgs = array_map(function($s){ return $s['name'] . " (need: " . $s['need'] . ", have: " . $s['have'] . ")"; }, $shortages);
                throw new Exception("Insufficient stock for: " . implode(', ', $msgs));
            }

            // For each item: deduct items.Stock by quantity, reset used_count in set items, and reset room_item_usage
            $updStock = $this->pdo->prepare("UPDATE items SET Stock = GREATEST(Stock - ?, 0) WHERE id = ?");
            $updSetItem = $this->pdo->prepare("UPDATE room_bedsheet_set_items SET used_count = 0 WHERE id = ?");
            $updRoomUsage = $this->pdo->prepare("UPDATE room_item_usage SET used_count = 0, condition_status = 'good' WHERE room_id = ? AND item_id = ?");

            foreach ($items as $it) {
                $qty = max(0, (int)$it['quantity']);
                if ($qty > 0) {
                    $updStock->execute([$qty, $it['item_id']]);
                }
                $updSetItem->execute([$it['rbs_id']]);
                // reset room_item_usage for visibility
                $updRoomUsage->execute([$roomId, $it['item_id']]);
            }

            $this->pdo->commit();

            // post-commit debug snapshot
            try {
                $postStmtDbg = $this->pdo->prepare("SELECT s.set_no, rbs.id AS rbs_id, rbs.item_id, rbs.used_count FROM room_bedsheet_set_items rbs JOIN room_bedsheet_sets s ON s.id = rbs.set_id WHERE s.room_id = ? AND s.set_no = ?");
                $postStmtDbg->execute([$roomId, $setNo]);
                $postDbg = $postStmtDbg->fetchAll(PDO::FETCH_ASSOC);
                @file_put_contents($logFile, "POST:\n" . json_encode($postDbg) . "\n", FILE_APPEND);
                // also dump aggregate room_item_usage for affected items (use local $items list)
                if (!empty($items)) {
                    $ri = $this->pdo->prepare("SELECT item_id, used_count FROM room_item_usage WHERE room_id = ? AND item_id = ?");
                    foreach ($items as $itm) {
                        $iid = isset($itm['item_id']) ? (int)$itm['item_id'] : null;
                        if ($iid === null) continue;
                        $ri->execute([$roomId, $iid]);
                        $rval = $ri->fetch(PDO::FETCH_ASSOC);
                        @file_put_contents($logFile, "ROOM_ITEM_USAGE item:$iid -> " . json_encode($rval) . "\n", FILE_APPEND);
                    }
                }
            } catch (Exception $_) {}

            // Attempt to sync the restock deduction to the central inventory DB (record transaction and deduct stock)
            $dualPath = __DIR__ . '/../../../../shared/dual_connection.php';
            if (file_exists($dualPath)) {
                try {
                    require_once $dualPath; // provides $conn_inventory (mysqli)
                    global $conn_inventory;
                    if (isset($conn_inventory) && ($conn_inventory instanceof mysqli)) {
                        // prepare statements
                        $updCentral = $conn_inventory->prepare("UPDATE items SET Stock = GREATEST(Stock - ?, 0) WHERE ItemID = ? OR ItemName = ? OR ItemName = ?");
                        // try to pick a user to attribute transaction
                        $logUserId = null;
                        $resu = $conn_inventory->query("SELECT UserID FROM users LIMIT 1");
                        if ($resu && $r = $resu->fetch_assoc()) $logUserId = (int)$r['UserID'];
                        $insTrans = $logUserId !== null ? $conn_inventory->prepare("INSERT INTO transactions (ItemID, Quantity, Type, UserID) VALUES (?, ?, ?, ?)") : null;

                        foreach ($items as $it) {
                            $qty = max(0, (int)$it['quantity']);
                            if ($qty <= 0) continue;
                            // attempt find by name
                            $iname = null;
                            if (isset($it['name'])) $iname = $it['name'];
                            $itemId = $this->ensureCentralCanonicalItem($conn_inventory, $iname);
                            if ($itemId !== null && $updCentral) {
                                // update by id
                                $updById = $conn_inventory->prepare("UPDATE items SET Stock = GREATEST(Stock - ?, 0) WHERE ItemID = ?");
                                $updById->bind_param('ii', $qty, $itemId);
                                $updById->execute();
                            } elseif ($iname !== null && $updCentral) {
                                // best-effort: update by name
                                $updByName = $conn_inventory->prepare("UPDATE items SET Stock = GREATEST(Stock - ?, 0) WHERE ItemName = ?");
                                $updByName->bind_param('is', $qty, $iname);
                                $updByName->execute();
                            }

                                if ($itemId !== null && $insTrans) {
                                    $transType = 'Restock (room:' . intval($roomId) . ')';
                                    $insTrans->bind_param('iisi', $itemId, $qty, $transType, $logUserId);
                                    $insTrans->execute();
                                }
                        }
                    }
                } catch (Exception $e) {
                    // non-fatal: local restock succeeded, central sync failed
                }
            }

            return true;
        } catch (Exception $e) {
            $this->pdo->rollBack();
            throw $e;
        }
    }

    // Set number of bedsheet sets for a room for a specific item
    public function setBedsheetSetsForRoom($roomId, $itemId, $sets) {
        $sets = max(0, (int)$sets);
        $check = $this->pdo->prepare("SELECT id FROM room_item_usage WHERE room_id = ? AND item_id = ?");
        $check->execute([$roomId, $itemId]);
        if ($check->fetch()) {
            $stmt = $this->pdo->prepare("UPDATE room_item_usage SET max_use = ?, used_count = LEAST(used_count, ?) WHERE room_id = ? AND item_id = ?");
            $stmt->execute([$sets, $sets, $roomId, $itemId]);
        } else {
            $stmt = $this->pdo->prepare("INSERT INTO room_item_usage (room_id, item_id, used_count, max_use, condition_status) VALUES (?, ?, 0, ?, 'good')");
            $stmt->execute([$roomId, $itemId, $sets]);
        }
        return true;
    }

    // Reset used_count for a room/item (Change Set)
    public function resetBedsheetSetForRoom($roomId, $itemId) {
        $stmt = $this->pdo->prepare("UPDATE room_item_usage SET used_count = 0, condition_status = 'good' WHERE room_id = ? AND item_id = ?");
        $stmt->execute([$roomId, $itemId]);
        return true;
    }

    // Check whether a specific set (by set_id) can be restocked from global stock
    public function canRestockSet($setId) {
        $stmt = $this->pdo->prepare("SELECT rbs.item_id, rbs.quantity, i.name, COALESCE(i.Stock,0) AS stock FROM room_bedsheet_set_items rbs JOIN items i ON i.id = rbs.item_id WHERE rbs.set_id = ?");
        $stmt->execute([$setId]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $missing = [];
        foreach ($rows as $r) {
            $need = max(0, (int)$r['quantity']);
            $have = max(0, (int)$r['stock']);
            if ($have < $need) $missing[] = ['item_id'=>$r['item_id'],'name'=>$r['name'],'need'=>$need,'have'=>$have];
        }
        return ['ok' => empty($missing), 'missing' => $missing];
    }

    // Return room-type requirement templates from DB if present
    public function getRoomTypeRequirements() {
        try {
            $stmt = $this->pdo->query("SHOW TABLES LIKE 'room_type_item_requirements'");
            if ($stmt->fetchColumn() === false) return [];
            $stmt = $this->pdo->query("SELECT r.room_type, r.item_id, r.quantity, i.ItemName AS name FROM room_type_item_requirements r JOIN items i ON i.ItemID = r.item_id");
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $out = [];
            foreach ($rows as $r) {
                $rt = $r['room_type'];
                if (!isset($out[$rt])) $out[$rt] = [];
                $out[$rt][$r['name']] = (int)$r['quantity'];
            }
            return $out;
        } catch (Exception $e) {
            return [];
        }
    }

    // Ensure a canonical central ItemID for a given item name in the central inventory.
    // If multiple rows exist with the same name, sum their Stocks into the first record and remove duplicates.
    // Returns canonical ItemID or null on failure.
    private function ensureCentralCanonicalItem($conn_inventory, $itemName) {
        if (!($conn_inventory instanceof mysqli)) return null;
        // find all matching items by name
        $stmt = $conn_inventory->prepare("SELECT ItemID, Stock FROM items WHERE ItemName = ?");
        if (!$stmt) return null;
        $stmt->bind_param('s', $itemName);
        $stmt->execute();
        $res = $stmt->get_result();
        $rows = [];
        if ($res) $rows = $res->fetch_all(MYSQLI_ASSOC);
        if (empty($rows)) return null;
        // first becomes canonical
        $first = array_shift($rows);
        $canonicalId = (int)$first['ItemID'];
        $sumStock = isset($first['Stock']) ? (int)$first['Stock'] : 0;
        $toDelete = [];
        foreach ($rows as $r) {
            $sumStock += isset($r['Stock']) ? (int)$r['Stock'] : 0;
            $toDelete[] = (int)$r['ItemID'];
        }
        // update canonical with summed stock
        $upd = $conn_inventory->prepare("UPDATE items SET Stock = ? WHERE ItemID = ?");
        if ($upd) { $upd->bind_param('ii', $sumStock, $canonicalId); $upd->execute(); }
        // remove duplicates (best-effort)
        if (!empty($toDelete)) {
            $ids = implode(',', array_map('intval', $toDelete));
            $conn_inventory->query("DELETE FROM items WHERE ItemID IN ($ids)");
        }
        return $canonicalId;
    }

    // Consume bedsheets and toiletries when a room is used (one unit each)
    public function consumeRoomUse($roomId) {
        // Find items that belong to BEDSHEETS or TOILETRIES
        $stmt = $this->pdo->prepare("SELECT id, name, location, COALESCE(Stock, 0) AS Stock FROM items WHERE location IN ('BEDSHEETS','TOILETRIES')");
        $stmt->execute();
        $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // toiletries: consume 1 unit of each toiletries item when a room is used
        foreach ($items as $item) {
            if ($item['location'] === 'TOILETRIES') {
                $qty = 1;
                $updateStock = $this->pdo->prepare("UPDATE items SET Stock = GREATEST(Stock - ?, 0) WHERE id = ?");
                $updateStock->execute([$qty, $item['id']]);

                // record per-room usage in room_item_usage
                $check = $this->pdo->prepare("SELECT used_count FROM room_item_usage WHERE room_id = ? AND item_id = ?");
                $check->execute([$roomId, $item['id']]);
                $row = $check->fetch(PDO::FETCH_ASSOC);
                if ($row) {
                    $newUsed = min($row['used_count'] + $qty, $this->max_use);
                    $update = $this->pdo->prepare("UPDATE room_item_usage SET used_count = ?, condition_status = CASE WHEN ? >= ? THEN 'need to restock' ELSE 'good' END WHERE room_id = ? AND item_id = ?");
                    $update->execute([$newUsed, $newUsed, $this->max_use, $roomId, $item['id']]);
                } else {
                    $status = ($qty >= $this->max_use) ? 'need to restock' : 'good';
                    $insert = $this->pdo->prepare("INSERT INTO room_item_usage (room_id, item_id, used_count, max_use, condition_status) VALUES (?, ?, ?, ?, ?)");
                    $insert->execute([$roomId, $item['id'], $qty, $this->max_use, $status]);
                }
            }
        }

        // BEDSHEETS: use the first available set (set_no 1..3) and increment set-item used_count
        try {
            // ensure sets exist
            $this->initializeBedsheetSets($roomId);
            $stmtSets = $this->pdo->prepare("SELECT id, set_no FROM room_bedsheet_sets WHERE room_id = ? ORDER BY set_no");
            $stmtSets->execute([$roomId]);
            $setsRows = $stmtSets->fetchAll(PDO::FETCH_ASSOC);
            foreach ($setsRows as $srow) {
                $setId = $srow['id'];
                // fetch items for set
                $stmtItems = $this->pdo->prepare("SELECT id, item_id, quantity, used_count, max_use FROM room_bedsheet_set_items WHERE set_id = ?");
                $stmtItems->execute([$setId]);
                $setItems = $stmtItems->fetchAll(PDO::FETCH_ASSOC);
                if (!$setItems) continue; // empty set
                // determine set status
                $unavailable = false;
                foreach ($setItems as $si) {
                    if ((int)$si['used_count'] >= (int)$si['max_use']) { $unavailable = true; break; }
                }
                if ($unavailable) continue; // try next set
                // consume this set: increment used_count for each item by 1 (one use)
                $upd = $this->pdo->prepare("UPDATE room_bedsheet_set_items SET used_count = LEAST(used_count + 1, max_use) WHERE id = ?");
                foreach ($setItems as $si) {
                    $upd->execute([$si['id']]);
                }
                // Also update aggregate room_item_usage table for visibility
                foreach ($setItems as $si) {
                    $itemId = $si['item_id'];
                    $check = $this->pdo->prepare("SELECT used_count FROM room_item_usage WHERE room_id = ? AND item_id = ?");
                    $check->execute([$roomId, $itemId]);
                    $r = $check->fetch(PDO::FETCH_ASSOC);
                    if ($r) {
                        $newUsed = min($r['used_count'] + 1, $this->max_use);
                        $update = $this->pdo->prepare("UPDATE room_item_usage SET used_count = ?, condition_status = CASE WHEN ? >= ? THEN 'need to restock' ELSE 'good' END WHERE room_id = ? AND item_id = ?");
                        $update->execute([$newUsed, $newUsed, $this->max_use, $roomId, $itemId]);
                    } else {
                        $status = (1 >= $this->max_use) ? 'need to restock' : 'good';
                        $insert = $this->pdo->prepare("INSERT INTO room_item_usage (room_id, item_id, used_count, max_use, condition_status) VALUES (?, ?, ?, ?, ?)");
                        $insert->execute([$roomId, $itemId, 1, $this->max_use, $status]);
                    }
                }
                // consumed one set, stop
                break;
            }
        } catch (Exception $e) {
            // if sets tables don't exist, fallback to previous behavior (no-op)
        }

        return true;
    }

    /**
     * Record room usage and synchronize relevant usage to the central inventory_managementdb.
     * - Calls consumeRoomUse() to update LuneraHotel local tables
     * - For toiletries consumed (per-person), decrements stock in inventory_managementdb.items
     * - Adds a transactions row in inventory_managementdb when possible
     * 
     * @param int $roomId
     * @param int|null $performedBy optional user id (inventory system user) to log transaction
     * @return array ['ok'=>bool, 'synced'=>array, 'errors'=>array]
     */
    public function recordRoomUsageAndSync($roomId, $performedBy = null) {
        $results = ['ok' => false, 'synced' => [], 'errors' => []];

        // 1) determine toiletries consumption per room (people count)
        $people = 1;
        try {
            $stmtRoom = $this->pdo->prepare("SELECT people FROM rooms WHERE id = ? LIMIT 1");
            $stmtRoom->execute([$roomId]);
            $r = $stmtRoom->fetch(PDO::FETCH_ASSOC);
            if ($r && isset($r['people'])) $people = max(1, (int)$r['people']);
        } catch (Exception $e) {
            $people = 1;
        }

        // Build list of toiletries to sync: name => qty (1 per item per room use)
        $toSync = [];
        try {
            $stmt = $this->pdo->prepare("SELECT id, name FROM items WHERE location = 'TOILETRIES'");
            $stmt->execute();
            $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($items as $it) {
                $toSync[$it['name']] = 1; // consume 1 unit of each toiletries item per room use
            }
        } catch (Exception $e) {
            $results['errors'][] = 'Failed to enumerate toiletries: ' . $e->getMessage();
        }

        // 2) perform local consume (updates LuneraHotel local DB)
        try {
            $this->consumeRoomUse($roomId);
        } catch (Exception $e) {
            $results['errors'][] = 'Local consumeRoomUse failed: ' . $e->getMessage();
            return $results;
        }

        // 3) attempt to sync to central inventory_managementdb using shared/dual_connection.php
        $dualPath = __DIR__ . '/../../../../shared/dual_connection.php';
        if (!file_exists($dualPath)) {
            $results['errors'][] = 'Dual connection helper not found: ' . $dualPath;
            // still return success of local consume
            $results['ok'] = true;
            return $results;
        }

        try {
            require_once $dualPath; // provides $conn_inventory (mysqli)
            global $conn_inventory;
            if (!isset($conn_inventory) || !($conn_inventory instanceof mysqli)) {
                $results['errors'][] = 'Inventory mysqli connection not available (shared/dual_connection.php)';
                $results['ok'] = true;
                return $results;
            }

            // find a valid user id in inventory DB for transaction logging
            $logUserId = null;
            if ($performedBy !== null) $logUserId = (int)$performedBy;
            if ($logUserId === null) {
                $res = $conn_inventory->query("SELECT UserID FROM users LIMIT 1");
                if ($res && $row = $res->fetch_assoc()) $logUserId = (int)$row['UserID'];
            }

            // prepare update and insert statements
            $updStmt = $conn_inventory->prepare("UPDATE items SET Stock = GREATEST(Stock - ?, 0) WHERE ItemName = ?");
            $insTrans = null;
            // note: we'll canonicalize duplicate-named items when determining ItemID
            if ($logUserId !== null) {
                $insTrans = $conn_inventory->prepare("INSERT INTO transactions (ItemID, Quantity, Type, UserID) VALUES (?, ?, ?, ?)");
            }

            foreach ($toSync as $iname => $qty) {
                // update central stock by qty
                if ($updStmt) {
                    $updStmt->bind_param('is', $qty, $iname);
                    $updStmt->execute();
                }

                // determine canonical central ItemID for this name (merge duplicates if present)
                $itemId = null;
                if ($iname !== null) {
                    $itemId = $this->ensureCentralCanonicalItem($conn_inventory, $iname);
                }

                if ($itemId !== null && $insTrans) {
                    $transType = 'Usage Stock (room:' . intval($roomId) . ')';
                    $insTrans->bind_param('iisi', $itemId, $qty, $transType, $logUserId);
                    $insTrans->execute();
                }

                $results['synced'][] = ['name' => $iname, 'qty' => $qty, 'itemId' => $itemId];
            }

            $results['ok'] = true;
            return $results;
        } catch (Exception $e) {
            $results['errors'][] = 'Sync exception: ' . $e->getMessage();
            $results['ok'] = true; // local operation succeeded
            return $results;
        }
    }

    /**
     * Consume a specific bedsheet set for a room (set_no 1..3)
     * Updates per-set used_count and the aggregate room_item_usage rows.
     * Also attempts to sync toiletries consumption to the central inventory DB.
     * @param int $roomId
     * @param int $setNo
     * @param int|null $performedBy
     * @return array ['ok'=>bool,'errors'=>array]
     */
    public function consumeBedsheetSet($roomId, $setNo, $performedBy = null) {
        $result = ['ok' => false, 'errors' => []];
        // prepare debug logging
        $logFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'inventory_debug.log';
        $timeNow = date('c');
        try { file_put_contents($logFile, "\n--- consumeBedsheetSet start ($timeNow) room:$roomId set:$setNo ---\n", FILE_APPEND); } catch (Exception $_) {}
        try {
            $preStmtDbg = $this->pdo->prepare("SELECT s.set_no, rbs.id AS rbs_id, rbs.item_id, rbs.used_count FROM room_bedsheet_set_items rbs JOIN room_bedsheet_sets s ON s.id = rbs.set_id WHERE s.room_id = ? AND s.set_no = ?");
            $preStmtDbg->execute([$roomId, $setNo]);
            $preDbg = $preStmtDbg->fetchAll(PDO::FETCH_ASSOC);
            @file_put_contents($logFile, "PRE:\n" . json_encode($preDbg) . "\n", FILE_APPEND);
        } catch (Exception $_) {}
        try {
        
        
        
        
        
        
        
        
        
        
        
        
        } catch (Exception $_) {}
        try {
        
        
        
        
        
        
        
        
        
        } catch (Exception $_) {}
        try {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        } catch (Exception $_) {}
        try {
        
        
        
        
        
        
        
        
        
        
        
        
        } catch (Exception $_) {}
        
        try {
            // start transaction to ensure consistency across sets and aggregate usage
            $this->pdo->beginTransaction();

            $stmt = $this->pdo->prepare("SELECT id FROM room_bedsheet_sets WHERE room_id = ? AND set_no = ? LIMIT 1");
            $stmt->execute([$roomId, $setNo]);
            $s = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$s) {
                $this->pdo->rollBack();
                $result['errors'][] = 'Set not found';
                return $result;
            }
            $setId = $s['id'];

            // NOTE: Do NOT reset other sets here — each set's used_count should accumulate independently.
            // The UI may show a single "USING" indicator, but server-side we preserve usage counts
            // so switching which set is actively used does not zero previous counts.

            // fetch items for chosen set
            $stmtItems = $this->pdo->prepare("SELECT id, item_id, quantity, used_count, max_use FROM room_bedsheet_set_items WHERE set_id = ?");
            $stmtItems->execute([$setId]);
            $items = $stmtItems->fetchAll(PDO::FETCH_ASSOC);
            if (empty($items)) {
                $this->pdo->rollBack();
                $result['errors'][] = 'Set is empty';
                return $result;
            }

            // check availability (no item at max)
            foreach ($items as $it) {
                if ((int)$it['used_count'] >= (int)$it['max_use']) {
                    $this->pdo->rollBack();
                    $result['errors'][] = 'Set is unavailable (items exhausted)';
                    return $result;
                }
            }

            // consume: increment used_count for each set item in chosen set (atomic DB increment)
            $upd = $this->pdo->prepare("UPDATE room_bedsheet_set_items SET used_count = used_count + 1 WHERE id = ? AND used_count < max_use");
            foreach ($items as $it) {
                $upd->execute([$it['id']]);
                $affected = $upd->rowCount();
                if ($affected === 0) {
                    // if no row updated, either at max_use or concurrency issue
                    // fetch current values for debug and continue
                    try { @file_put_contents($logFile, "WARN: item id {$it['id']} not incremented (used_count >= max or no change)\n", FILE_APPEND); } catch (Exception $_) {}
                }
            }

            // Recompute aggregate room_item_usage for affected items by summing across all sets for this room
            $itemIds = array_unique(array_map(function($i){ return (int)$i['item_id']; }, $items));
            $sumStmt = $this->pdo->prepare("SELECT SUM(rbs.used_count) AS ssum FROM room_bedsheet_set_items rbs JOIN room_bedsheet_sets s ON s.id = rbs.set_id WHERE s.room_id = ? AND rbs.item_id = ?");
            $updRoomUsage = $this->pdo->prepare("UPDATE room_item_usage SET used_count = ?, condition_status = CASE WHEN ? >= ? THEN 'need to restock' ELSE 'good' END WHERE room_id = ? AND item_id = ?");
            $insRoomUsage = $this->pdo->prepare("INSERT INTO room_item_usage (room_id, item_id, used_count, max_use, condition_status) VALUES (?, ?, ?, ?, ?)");
            foreach ($itemIds as $itemId) {
                $sumStmt->execute([$roomId, $itemId]);
                $r = $sumStmt->fetch(PDO::FETCH_ASSOC);
                $usedSum = (int)($r['ssum'] ?? 0);
                if ($usedSum > 0) {
                    // update or insert
                    $check = $this->pdo->prepare("SELECT 1 FROM room_item_usage WHERE room_id = ? AND item_id = ?");
                    $check->execute([$roomId, $itemId]);
                    if ($check->fetch()) {
                        $updRoomUsage->execute([$usedSum, $usedSum, $this->max_use, $roomId, $itemId]);
                    } else {
                        $status = ($usedSum >= $this->max_use) ? 'need to restock' : 'good';
                        $insRoomUsage->execute([$roomId, $itemId, $usedSum, $this->max_use, $status]);
                    }
                } else {
                    // no usage across sets -> ensure room_item_usage exists and is zeroed
                    $check = $this->pdo->prepare("SELECT 1 FROM room_item_usage WHERE room_id = ? AND item_id = ?");
                    $check->execute([$roomId, $itemId]);
                    if ($check->fetch()) {
                        $updRoomUsage->execute([0, 0, $this->max_use, $roomId, $itemId]);
                    } else {
                        $insRoomUsage->execute([$roomId, $itemId, 0, $this->max_use, 'good']);
                    }
                }
            }

            $this->pdo->commit();

            // toiletries: sync to central inventory (same logic as recordRoomUsageAndSync but without consuming additional bedsheet sets)
            $people = 1;
            try {
                $stmtRoom = $this->pdo->prepare("SELECT people FROM rooms WHERE id = ? LIMIT 1");
                $stmtRoom->execute([$roomId]);
                $rr = $stmtRoom->fetch(PDO::FETCH_ASSOC);
                if ($rr && isset($rr['people'])) $people = max(1, (int)$rr['people']);
            } catch (Exception $e) { $people = 1; }

            $toSync = [];
            $stmtT = $this->pdo->prepare("SELECT id, name FROM items WHERE location = 'TOILETRIES'");
            $stmtT->execute();
            $titems = $stmtT->fetchAll(PDO::FETCH_ASSOC);
            foreach ($titems as $ti) $toSync[$ti['name']] = 1;

            // attempt central sync
            $dualPath = __DIR__ . '/../../../../shared/dual_connection.php';
            if (file_exists($dualPath)) {
                require_once $dualPath;
                global $conn_inventory;
                if (isset($conn_inventory) && ($conn_inventory instanceof mysqli)) {
                    $logUserId = $performedBy !== null ? (int)$performedBy : null;
                    if ($logUserId === null) {
                        $res = $conn_inventory->query("SELECT UserID FROM users LIMIT 1");
                        if ($res && $row = $res->fetch_assoc()) $logUserId = (int)$row['UserID'];
                    }
                    $updStmt = $conn_inventory->prepare("UPDATE items SET Stock = GREATEST(Stock - ?, 0) WHERE ItemName = ?");
                    $insTrans = $logUserId !== null ? $conn_inventory->prepare("INSERT INTO transactions (ItemID, Quantity, Type, UserID) VALUES (?, ?, ?, ?)") : null;
                    foreach ($toSync as $iname => $qty) {
                        if ($updStmt) { $updStmt->bind_param('is',$qty,$iname); $updStmt->execute(); }
                        $itemId = null;
                        if ($iname !== null) { $itemId = $this->ensureCentralCanonicalItem($conn_inventory, $iname); }
                        if ($itemId !== null && $insTrans) { $transType = 'Usage Stock (room:' . intval($roomId) . ')'; $insTrans->bind_param('iisi',$itemId,$qty,$transType,$logUserId); $insTrans->execute(); }
                    }
                }
            }

            $result['ok'] = true;
            return $result;
        } catch (Exception $e) {
            try { $this->pdo->rollBack(); } catch (Exception $_) {}
            // log exception
            try { @file_put_contents($logFile, "ERROR: " . $e->getMessage() . "\n", FILE_APPEND); } catch (Exception $_) {}
            $result['errors'][] = $e->getMessage();
            return $result;
        }
    }
}
?>
