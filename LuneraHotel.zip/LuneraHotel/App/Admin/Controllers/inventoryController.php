<?php
require_once __DIR__.'/../../config/db.php';
require_once __DIR__.'/../Models/InventoryModel.php';

class InventoryController {
    private $model;

    public function __construct($pdo) {
        $this->model = new InventoryModel($pdo);
    }

    public function index() {
        // Handle restock button
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['item_id'])) {
            $this->model->restockItem($_POST['item_id']);
        }

        // Handle room booking increment
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['book_room_people'], $_POST['room_id'])) {
            $people = intval($_POST['book_room_people']); 
            $roomId = intval($_POST['room_id']);
            $this->model->bookRoom($roomId, $people);
        }

        $dbError = null;
        try {
            $allItems = $this->model->getInventoryStatus();
            $allSummary = $this->model->getSummaryStock();

            // Remove bedsheets and toiletries from global inventory summary (managed per-room).
            // Use trimmed, case-insensitive comparison to avoid accidental mismatches.
            // Do not exclude any locations from the global inventory list by default
            // Bedsheets will also appear in the global inventory. Per-room sets remain managed in the room editor.
            $exclude = [];
            $items = array_filter($allItems, function($i) use ($exclude) {
                $loc = isset($i['location']) ? strtoupper(trim($i['location'])) : '';
                return !in_array($loc, $exclude, true);
            });

            $summary = array_filter($allSummary, function($s) use ($exclude) {
                $loc = isset($s['location']) ? strtoupper(trim($s['location'])) : '';
                return !in_array($loc, $exclude, true);
            });
            // debug info for troubleshooting empty lists
            $debugInfo = [
                'allItemsCount' => is_array($allItems) ? count($allItems) : 0,
                'filteredItemsCount' => is_array($items) ? count($items) : 0,
                'allSummaryCount' => is_array($allSummary) ? count($allSummary) : 0,
                'filteredSummaryCount' => is_array($summary) ? count($summary) : 0,
                'allSummarySample' => is_array($allSummary) ? array_slice($allSummary, 0, 6) : []
            ];

            // Prefer DB-driven per-room requirement templates if available
            $perRoomTemplates = $this->model->getRoomTypeRequirements();
            if (empty($perRoomTemplates)) {
                // Fallback defaults
                $perRoomTemplates = [
                    'King' => [ 'Bedsheet' => 1, 'Pillow Sheet' => 2, 'Towel' => 2, 'Blanket' => 1, 'Shampoo (pcs)' => 1, 'Soap (pcs)' => 1 ],
                    'Queen' => [ 'Bedsheet' => 1, 'Pillow Sheet' => 2, 'Towel' => 2, 'Blanket' => 1, 'Shampoo (pcs)' => 1, 'Soap (pcs)' => 1 ],
                    'Twin' => [ 'Bedsheet' => 2, 'Pillow Sheet' => 2, 'Towel' => 2, 'Blanket' => 2, 'Shampoo (pcs)' => 1, 'Soap (pcs)' => 1 ],
                    'Single' => [ 'Bedsheet' => 1, 'Pillow Sheet' => 1, 'Towel' => 1, 'Blanket' => 1, 'Shampoo (pcs)' => 1, 'Soap (pcs)' => 1 ]
                ];
            }
        } catch (Exception $e) {
            $dbError = 'Database error: ' . $e->getMessage();
            $items = [];
            $summary = [];
        }

        // If the view needs raw bedsheet/toiletry lists, compute from the full set ($allItems)
        $bedsheets = isset($allItems) ? array_filter($allItems, function($i){ return isset($i['location']) && strtoupper(trim($i['location'])) === 'BEDSHEETS'; }) : [];
        $toiletries = isset($allItems) ? array_filter($allItems, function($i){ return isset($i['location']) && strtoupper(trim($i['location'])) === 'TOILETRIES'; }) : [];

        require __DIR__.'/../Views/inventory.php';
    }
}
?>
