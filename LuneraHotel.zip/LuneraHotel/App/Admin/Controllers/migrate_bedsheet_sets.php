<?php
require_once __DIR__ . '/../../config/db.php';

// This script runs the SQL in database/add_room_bedsheet_sets.sql to create needed tables.
// Use in browser once: http://localhost/systemfor4/LuneraHotel/App/Admin/Controllers/migrate_bedsheet_sets.php

try {
    // Prefer a robust path resolution: walk up 4 levels to reach workspace root then /database
    $sqlPath = dirname(__DIR__, 4) . DIRECTORY_SEPARATOR . 'database' . DIRECTORY_SEPARATOR . 'add_room_bedsheet_sets.sql';
    if (!file_exists($sqlPath)) {
        // fallback: try relative locations that may exist in different contexts
        $candidates = [
            __DIR__ . '/../../../database/add_room_bedsheet_sets.sql',
            __DIR__ . '/../../../../database/add_room_bedsheet_sets.sql',
            __DIR__ . '/../../database/add_room_bedsheet_sets.sql'
        ];
        foreach ($candidates as $c) if (file_exists($c)) { $sqlPath = $c; break; }
    }

    if (!file_exists($sqlPath)) throw new Exception('Migration SQL file not found at expected locations. Tried: ' . htmlspecialchars($sqlPath));

    $sql = file_get_contents($sqlPath);
    if ($sql === false) throw new Exception('Failed to read migration SQL.');
    $pdo->exec($sql);
    echo "Migration applied successfully. Tables created (if not existed).";
} catch (Exception $e) {
    http_response_code(500);
    echo "Migration failed: " . htmlspecialchars($e->getMessage());
}

?>
