<?php
require_once __DIR__ . '/../../config/db.php';

try {
    $sqlPath = dirname(__DIR__, 4) . DIRECTORY_SEPARATOR . 'database' . DIRECTORY_SEPARATOR . 'remodel_items_table.sql';
    if (!file_exists($sqlPath)) {
        throw new Exception('Migration SQL file not found at ' . $sqlPath);
    }
    $sql = file_get_contents($sqlPath);
    if ($sql === false) throw new Exception('Failed to read SQL file.');
    $pdo->exec($sql);
    echo "Remodel migration applied successfully.";
} catch (Exception $e) {
    http_response_code(500);
    echo "Migration failed: " . htmlspecialchars($e->getMessage());
}

?>
