<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../Models/updateRoomsModel.php';
require_once __DIR__ . '/../Models/InventoryModel.php';
require_once __DIR__ . '/../../config/Helpers/amenityicon.php';

if (!isset($_SESSION['user'])) {
    header("Location: /LuneraHotel/App/Public");
    exit;
}

$roomId = $_GET['id'] ?? null;
if (!$roomId) die("Invalid room ID");

// Fetch data
$room = getRoomById($pdo, $roomId);
$roomAmenities = getRoomAmenities($pdo, $roomId);
$allAmenities = getAllAmenities($pdo);
$roomTypes = getAllRoomTypes($pdo);

$errorMessage = null;
$successMessage = null;

// Quick handlers for POST actions that don't come from the Update form
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['use_set'])) {
    $inventoryModel = new InventoryModel($pdo);
    $setNo = (int)$_POST['use_set'];
    try {
        $performedBy = $_SESSION['user']['id'] ?? null;
        $res = $inventoryModel->consumeBedsheetSet($roomId, $setNo, $performedBy);
        // redirect back to same page to show updated state
        header('Location: ' . $_SERVER['REQUEST_URI']);
        exit;
    } catch (Exception $e) {
        $errorMessage = "Failed to use set: " . $e->getMessage();
    }
}

// Early handler for restock actions (row or set level)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['restock_bedsheet_set'])) {
    $inventoryModel = new InventoryModel($pdo);
    $setNo = (int)$_POST['restock_bedsheet_set'];
    try {
        $inventoryModel->restockBedsheetSet($roomId, $setNo);
        header('Location: ' . $_SERVER['REQUEST_URI']);
        exit;
    } catch (Exception $e) {
        $errorMessage = 'Failed to restock set: ' . $e->getMessage();
    }
}

// Early handler for reset per-item inside set
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reset_bedsheet_item']) && is_numeric($_POST['reset_bedsheet_item'])) {
    $inventoryModel = new InventoryModel($pdo);
    $itemId = (int)$_POST['reset_bedsheet_item'];
    $inventoryModel->resetBedsheetSetForRoom($roomId, $itemId);
    header('Location: ' . $_SERVER['REQUEST_URI']);
    exit;
}


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_room'])) {

    $status = $_POST['status'] ?? 'Booked';
    $people = intval($_POST['people']); // Direct user input
    $room_number = trim($_POST['room_number']);
    $floor = intval($_POST['floor']);

    // Validations
    if (!is_numeric($room_number) || intval($room_number) < 0) {
        $errorMessage = "Invalid room number!";
    } elseif ($people > 6) {
        $errorMessage = "Maximum capacity is 6 people only!";
    } elseif ($floor > 4) {
        $errorMessage = "Maximum floor allowed is 4!";
    } else {
        $stmt = $pdo->prepare("SELECT id FROM rooms WHERE room_number = ? AND id != ?");
        $stmt->execute([$room_number, $roomId]);
        if ($stmt->fetch()) $errorMessage = "Room number $room_number is already in use!";
    }

    if (!$errorMessage) {
        // Image upload
        $imgPath = null;
        if (!empty($_FILES['img']['name'])) {
            $targetDir = __DIR__ . '/../../Public/images/';
            $imgPath = $targetDir . basename($_FILES['img']['name']);
            move_uploaded_file($_FILES['img']['tmp_name'], $imgPath);
            $imgPath = 'images/' . basename($_FILES['img']['name']);
        }

        // remember previous status to detect change to 'Booked'
        $previousStatus = $room['status'];

        // Update room
        updateRoom($pdo, $roomId, [
            'room_number' => $room_number,
            'room_type'   => $_POST['room_type'],
            'description' => $_POST['description'],
            'status'      => $status,
            'floor'       => $floor,
            'people'      => $people,
            'img'         => $imgPath,
            'type_name'   => $_POST['type_name']
        ]);

        // If the status changed to 'Booked' (i.e. newly booked), auto-consume a set and deduct toiletries
        if ($previousStatus !== 'Booked' && $status === 'Booked') {
            $inventoryModel = new InventoryModel($pdo);
            try {
                $performedBy = $_SESSION['user']['id'] ?? null;
                $res = $inventoryModel->recordRoomUsageAndSync($roomId, $performedBy);
                if (!empty($res['errors'])) {
                    $errorMessage = "Booking recorded locally, but sync issues: " . implode('; ', $res['errors']);
                } else {
                    $successMessage = "Booking recorded; bedsheet set consumed and toiletries deducted.";
                }
            } catch (Exception $e) {
                $errorMessage = "Failed to auto-consume on booking: " . $e->getMessage();
            }
        }

        // Mark completed bookings if available
        if ($status === 'Available') {
            $stmt = $pdo->prepare("
                UPDATE bookings
                SET status = 'Completed'
                WHERE room_id = ? AND status = 'Booked'
            ");
            $stmt->execute([$roomId]);
        }

        // Update amenities
        $selectedAmenities = $_POST['amenities'] ?? [];
        updateAmenities($pdo, $roomId, $selectedAmenities);

        // Handle bedsheet set assignments per-room
        $inventoryModel = new InventoryModel($pdo);
        if (!empty($_POST['bedsheet_sets']) && is_array($_POST['bedsheet_sets'])) {
            foreach ($_POST['bedsheet_sets'] as $itemId => $sets) {
                $inventoryModel->setBedsheetSetsForRoom($roomId, (int)$itemId, (int)$sets);
            }
            $successMessage = "Bedsheet set assignments updated.";
        }

        // Handle detailed bedsheet set composition (JSON expected): {'1': {itemId:qty,...}, '2': {...}, '3': {...}}
        if (!empty($_POST['bedsheet_sets_composition'])) {
            $posted = $_POST['bedsheet_sets_composition'];
            // Accept either JSON string or an array of sets
            if (!is_array($posted)) {
                $comp = json_decode($posted, true);
            } else {
                $comp = $posted;
            }
            if (is_array($comp)) {
                foreach ($comp as $setNo => $composition) {
                    $setNoInt = intval($setNo);
                    if ($setNoInt < 1 || $setNoInt > 3) continue;
                    if (!is_array($composition)) continue;
                    $inventoryModel->setSetComposition($roomId, $setNoInt, $composition);
                }
                $successMessage = "Bedsheet set compositions updated.";
            }
        }

        // 'use_room' (mark room used) removed - per-user set consumption is manual via per-set Use buttons

        // Per-set Use (submit with name use_set => set number)
        if (isset($_POST['use_set'])) {
            $setNo = (int)$_POST['use_set'];
            try {
                $performedBy = $_SESSION['user']['id'] ?? null;
                $res = $inventoryModel->consumeBedsheetSet($roomId, $setNo, $performedBy);
                if (!empty($res['errors'])) {
                    $errorMessage = "Failed to use set #$setNo: " . implode('; ', $res['errors']);
                } else {
                    $successMessage = "Set #$setNo consumed and inventory updated.";
                }
            } catch (Exception $e) {
                $errorMessage = "Failed to use set: " . $e->getMessage();
            }
            // After consuming a set, re-evaluate sets: if all unavailable, mark room Unavailable
            try {
                $setsCheck = $inventoryModel->getBedsheetsForRoom($roomId);
                $allUnavailable = true;
                foreach ($setsCheck as $s) {
                    if (strtoupper($s['status']) !== 'UNAVAILABLE') { $allUnavailable = false; break; }
                }
                if ($allUnavailable) {
                    $upd = $pdo->prepare("UPDATE rooms SET status = 'Unavailable' WHERE id = ?");
                    $upd->execute([$roomId]);
                }
            } catch (Exception $e) {}
        }

        // If a bedsheet reset/change was requested
        if (isset($_POST['reset_bedsheet_item']) && is_numeric($_POST['reset_bedsheet_item'])) {
            $itemId = (int)$_POST['reset_bedsheet_item'];
            $inventoryModel->resetBedsheetSetForRoom($roomId, $itemId);
            $successMessage = "Bedsheet set reset for the room.";
        }

        // Restock a whole set by set number (deduct global stock and reset usage)
        if (isset($_POST['restock_bedsheet_set']) && is_numeric($_POST['restock_bedsheet_set'])) {
            $setNo = (int)$_POST['restock_bedsheet_set'];
            try {
                $inventoryModel->restockBedsheetSet($roomId, $setNo);
                $successMessage = "Bedsheet set #$setNo restocked and inventory updated.";
            } catch (Exception $e) {
                $errorMessage = "Failed to restock set: " . $e->getMessage();
            }
            // After restock, if any set is available, mark room as Available
            try {
                $setsCheck = $inventoryModel->getBedsheetsForRoom($roomId);
                $anyAvailable = false;
                foreach ($setsCheck as $s) {
                    if (strtoupper($s['status']) !== 'UNAVAILABLE') { $anyAvailable = true; break; }
                }
                if ($anyAvailable) {
                    $upd = $pdo->prepare("UPDATE rooms SET status = 'Available' WHERE id = ?");
                    $upd->execute([$roomId]);
                }
            } catch (Exception $e) {}
        }

        $room = getRoomById($pdo, $roomId);
        $roomAmenities = getRoomAmenities($pdo, $roomId);
        $successMessage = "Room updated successfully!";
    }
}

include __DIR__ . '/../Views/updaterooms.php';
?>
