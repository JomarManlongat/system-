<?php
require __DIR__.'/../Models/config.php';
require __DIR__.'/../Models/authenticatemodel.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    $user = getUser($pdo, $email);

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user'] = $user;

        if ($user['role'] === 'admin') {
            header('Location: index.php?page=admin');
        } else {
            header('Location: index.php?page=rooms');
        }
        exit;
    } else {
        $_SESSION['error'] = "Invalid email or password";
        header('Location: index.php?page=login');
        exit;
    }
}
