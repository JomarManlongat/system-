<?php
// Debug endpoint: returns bedsheet sets, per-set items/used_count, room_item_usage, and toiletries stock for a room
// Usage: debug_room_sets.php?room_id=5

header('Content-Type: application/json; charset=utf-8');

// correct path to LuneraHotel App config
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../Admin/Models/InventoryModel.php';

$roomId = isset($_GET['room_id']) ? (int)$_GET['room_id'] : null;
if (!$roomId) {
    echo json_encode(['ok'=>false,'error'=>'room_id required']);
    exit;
}

try {
    $inv = new InventoryModel($pdo);
    $sets = $inv->getBedsheetsForRoom($roomId);

    // aggregate room_item_usage for this room
    $stmt = $pdo->prepare("SELECT riu.item_id, i.name, riu.used_count, riu.max_use, riu.condition_status FROM room_item_usage riu JOIN items i ON i.id = riu.item_id WHERE riu.room_id = ?");
    $stmt->execute([$roomId]);
    $roomUsage = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // toiletries stock
    $stmt2 = $pdo->prepare("SELECT id, name, COALESCE(Stock,0) AS stock FROM items WHERE location = 'TOILETRIES'");
    $stmt2->execute();
    $toiletries = $stmt2->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['ok'=>true,'room_id'=>$roomId,'sets'=>$sets,'room_item_usage'=>$roomUsage,'toiletries'=>$toiletries], JSON_PRETTY_PRINT);
} catch (Exception $e) {
    echo json_encode(['ok'=>false,'error'=>$e->getMessage()]);
}

?>
