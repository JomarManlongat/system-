<?php
// Debug page to inspect inventory tables
// Usage: http://localhost/systemfor4/LuneraHotel/App/Public/debug_inventory.php

// Try several possible paths for the DB config (different include contexts)
$candidates = [
    __DIR__ . '/../../config/db.php',
    __DIR__ . '/../config/db.php',
    __DIR__ . '/../../Auth/Models/config.php',
    __DIR__ . '/../../../config/db.php'
];
$loaded = false;
foreach ($candidates as $c) {
    if (file_exists($c)) {
        require_once $c;
        $loaded = true;
        break;
    }
}
if (!$loaded) {
    header('Content-Type: text/plain; charset=utf-8', true, 500);
    echo "DB config not found. Tried:\n" . implode("\n", $candidates);
    exit;
}

header('Content-Type: text/html; charset=utf-8');
echo "<h2>LuneraHotel DB (roomslunera_hotel) - items</h2>\n<pre>";
try {
    $stmt = $pdo->query('SELECT id, name, location, IFNULL(Stock, "(no Stock column)") AS Stock FROM items LIMIT 100');
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo htmlspecialchars(var_export($rows, true));
} catch (PDOException $e) {
    echo 'Error querying items: ' . htmlspecialchars($e->getMessage());
}
echo "</pre>\n";

echo "<h2>room_item_usage (roomslunera_hotel)</h2>\n<pre>";
try {
    $stmt = $pdo->query('SELECT room_id, item_id, used_count, max_use, condition_status FROM room_item_usage LIMIT 100');
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo htmlspecialchars(var_export($rows, true));
} catch (PDOException $e) {
    echo 'Error querying room_item_usage: ' . htmlspecialchars($e->getMessage());
}
echo "</pre>\n";

// Attempt to also connect to central inventory DB if config exists
$centralConfig = __DIR__ . '/../../../config/database.php';
if (file_exists($centralConfig)) {
    echo "<h2>Central inventory DB (if configured) - items</h2>\n<pre>";
    require_once $centralConfig; // defines DB_HOST, DB_USER, DB_PASS, INVENTORY_DB
    try {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . INVENTORY_DB . ';charset=utf8';
        $pdoInv = new PDO($dsn, DB_USER, DB_PASS, [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
        $stmt = $pdoInv->query('SELECT ItemID AS id, ItemName AS name, Location AS location, Stock FROM items LIMIT 100');
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo htmlspecialchars(var_export($rows, true));
    } catch (Exception $e) {
        echo 'Error connecting/querying central inventory DB: ' . htmlspecialchars($e->getMessage());
    }
    echo "</pre>\n";
} else {
    echo "<p>No central config/database.php found at expected path.</p>\n";
}

?>