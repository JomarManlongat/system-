<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?? 'Room Management' ?></title>
    <link rel="stylesheet" href="/systemfor4/LuneraHotel/App/src/output.css">
    <link rel="stylesheet" href="/systemfor4/LuneraHotel/App/Public/CSS/fontawesome.min.css">
    <link rel="stylesheet" href="/systemfor4/LuneraHotel/App/Public/CSS/all.min.css">
    <link rel="stylesheet" href="/systemfor4/LuneraHotel/App/Public/CSS/login.css">
    <link rel="stylesheet" href="/systemfor4/LuneraHotel/App/Public/CSS/dashboard.css">
    <link rel="icon" type="image/jpg" href="/systemfor4/LuneraHotel/App/Public/images/logo.jpg">
    <!--npx @tailwindcss/cli -i ./src/input.css -o ./src/output.css --watch
    cd C:\ngrok
    ngrok http 80
    -->
</head>
<body class=" bg-[#f8f8f8] font-mono overflow-x-hidden">
    <?= $content  ?>
</body>

</html>

<script>
// Fix absolute links that point to /LuneraHotel when app is served from /systemfor4
(function(){
    const from = '/LuneraHotel';
    const to = '/systemfor4/LuneraHotel';

    // Fix anchors
    document.querySelectorAll('a[href^="'+from+'"]').forEach(a=>{
        a.href = a.href.replace(from, to);
    });

    // Fix resource links (images, css, scripts)
    document.querySelectorAll('link[href^="'+from+'"], script[src^="'+from+'"], img[src^="'+from+'"]').forEach(el=>{
        if(el.href) el.href = el.href.replace(from, to);
        if(el.src) el.src = el.src.replace(from, to);
    });
})();
</script>

