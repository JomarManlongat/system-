<?php
session_name('INVENTORY_SESSION');
session_start();

echo "<pre>";
echo "=== SESSION DATA ===\n";
echo "UserID: " . ($_SESSION['UserID'] ?? 'NOT SET') . "\n";
echo "Role: " . ($_SESSION['Role'] ?? 'NOT SET') . "\n";
echo "roles: " . ($_SESSION['roles'] ?? 'NOT SET') . "\n";
echo "\n";

echo "=== TESTING SUPPLIERS DATABASE ===\n";
echo "Calling: main_inventory_system/admin-page/suppliers/suppliers_database.php\n";
$suppliers_url = __DIR__ . '/main_inventory_system/admin-page/suppliers/suppliers_database.php';
echo "File exists: " . (file_exists($suppliers_url) ? 'YES' : 'NO') . "\n";

echo "\n=== TESTING ORDERS DATABASE ===\n";
echo "Calling: main_inventory_system/admin-page/orders/orders_database.php\n";
$orders_url = __DIR__ . '/main_inventory_system/admin-page/orders/orders_database.php';
echo "File exists: " . (file_exists($orders_url) ? 'YES' : 'NO') . "\n";

echo "\n=== TESTING STAFF PAGE SUPPLIERS DATABASE ===\n";
echo "Calling: main_inventory_system/staff-page/suppliers/suppliers_database.php\n";
$staff_suppliers_url = __DIR__ . '/main_inventory_system/staff-page/suppliers/suppliers_database.php';
echo "File exists: " . (file_exists($staff_suppliers_url) ? 'YES' : 'NO') . "\n";

echo "</pre>";
?>
