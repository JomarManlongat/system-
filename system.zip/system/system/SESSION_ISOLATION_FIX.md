# Session Isolation Fix - Complete Documentation

## Problem Summary
**Issue:** Username changing from "admin" to "ryan" when switching between Inventory and Restaurant systems.

**Root Cause:** Both systems were using the default PHP session with same session variable names (`$_SESSION['username']`, `$_SESSION['role']`). Since they run on the same domain, they shared the same session storage, causing session data to overwrite each other.

## Solution Implemented
**Session Name Separation:** Each system now uses a unique session name to maintain isolated session storage.

### Session Names:
- **Inventory System:** `INVENTORY_SESSION`
- **Restaurant System:** `RESTAURANT_SESSION`

## Files Modified

### Total Files Updated: 47
- **Inventory System:** 18 files
- **Restaurant System:** 29 files

### Key Changes Made:

#### 1. Login Files (Initial Implementation)
```php
// Before
session_start();

// After (Inventory)
session_name('INVENTORY_SESSION');
session_start();

// After (Restaurant)
session_name('RESTAURANT_SESSION');
session_start();
```

**Files:**
- `main_inventory_system/login/login-function.php`
- `HotelLuneraRestaurant/login.php`

#### 2. All Session Files (Bulk Update)
Applied `session_name()` before **every** `session_start()` call in:

**Inventory System (18 files):**
- `main_inventory_system/nocache.php`
- `main_inventory_system/login/index.php`
- `main_inventory_system/login/database-account.php`
- `main_inventory_system/admin-page/*.php` (multiple files)
- `main_inventory_system/staff-page/*.php` (multiple files)
- `main_inventory_system/admin-page/inventory/*.php`
- `main_inventory_system/admin-page/orders/*.php`
- `main_inventory_system/admin-page/suppliers/*.php`
- `main_inventory_system/admin-page/users/*.php`

**Restaurant System (29 files):**
- `HotelLuneraRestaurant/*.php` (root level files)
- `HotelLuneraRestaurant/admin/*.php`
- All restaurant PHP files with session usage

#### 3. SSO Bridge (Critical Update)
**File:** `shared/sso_bridge.php`

**Changes:**
- Start with RESTAURANT session to read credentials
- Switch to INVENTORY session after authentication
- Use `session_write_close()` before switching sessions
- Properly handle both session contexts

**Before:**
```php
session_start(); // Uses default session (caused collision)
// ... authentication ...
$_SESSION['username'] = $user['username']; // Overwrites!
```

**After:**
```php
session_name('RESTAURANT_SESSION');
session_start();
// Read restaurant credentials...

// Switch to inventory session
session_write_close();
session_name('INVENTORY_SESSION');
session_start();
// Set inventory session data (now isolated)
$_SESSION['username'] = $user['username'];
```

#### 4. Inventory Gateway (Updated)
**File:** `HotelLuneraRestaurant/inventory_gateway.php`

**Changes:**
- Start with RESTAURANT session
- Call `authenticate_restaurant_user()` which handles session switching
- After authentication, session is already switched to INVENTORY
- Redirect to inventory system

## How It Works

### Scenario 1: Direct Login to Each System
1. **Login to Inventory as "admin"**
   - Sets `INVENTORY_SESSION` with username="admin"
   
2. **Login to Restaurant as "ryan"** (separate tab)
   - Sets `RESTAURANT_SESSION` with username="ryan"
   
3. **Result:** ✅ Both sessions remain isolated
   - Inventory shows "admin"
   - Restaurant shows "ryan"
   - No conflicts!

### Scenario 2: SSO from Restaurant to Inventory
1. **Login to Restaurant as "ryan"**
   - Creates `RESTAURANT_SESSION` with username="ryan"
   
2. **Click "Go to Inventory" button**
   - `inventory_gateway.php` reads RESTAURANT session
   - `sso_bridge.php` switches to INVENTORY session
   - Creates/updates INVENTORY session with restaurant credentials
   - Redirects to inventory system
   
3. **Result:** ✅ Session properly transferred
   - Restaurant still has "ryan" in RESTAURANT_SESSION
   - Inventory now has "ryan" in INVENTORY_SESSION
   - No overwrite of existing admin session if it exists

### Scenario 3: Return from Inventory to Restaurant
1. **Click "Back to Restaurant" button in inventory**
   - JavaScript redirects to restaurant admin page
   - Restaurant page starts with `RESTAURANT_SESSION`
   
2. **Result:** ✅ Returns to original restaurant session
   - Restaurant session preserved during inventory visit

## Testing Guide

### Test Page Created
**URL:** `http://localhost/system/test_sessions.php`

**Features:**
- Shows both INVENTORY and RESTAURANT session data side-by-side
- Live status indicators (Logged In / Not Logged In)
- Quick login links for both systems
- Logout buttons for each session independently
- Session ID display for verification

### Manual Testing Steps

#### Test 1: Verify Session Isolation
1. Open `test_sessions.php` - both should show "Not Logged In"
2. Open new tab → Login to Inventory as "admin"
3. Open new tab → Login to Restaurant as "ryan"
4. Refresh `test_sessions.php`
5. ✅ **Expected:** Both sessions active with different usernames

#### Test 2: Verify SSO Transfer
1. Login to Restaurant as "ryan"
2. Go to Restaurant admin → Click "Go to Inventory"
3. Verify inventory shows "ryan" username
4. Open `test_sessions.php` in new tab
5. ✅ **Expected:** Both INVENTORY and RESTAURANT show "ryan"

#### Test 3: Verify Independent Logouts
1. Login to both systems (use Test 1)
2. Logout from Inventory only
3. Refresh `test_sessions.php`
4. ✅ **Expected:** INVENTORY="Not Logged In", RESTAURANT="Logged In"

#### Test 4: Verify No Admin Overwrite
1. Login to Inventory as "admin"
2. Open new tab → Login to Restaurant as "ryan"
3. Return to Inventory tab → Refresh page
4. ✅ **Expected:** Inventory still shows "admin" (NOT "ryan")

## Technical Details

### Session Configuration
```php
// Inventory system
session_name('INVENTORY_SESSION');  // Sets cookie name
session_start();                     // Starts/resumes session

// Creates separate session file:
// sess_INVENTORY_SESSION_<random_id>
```

```php
// Restaurant system  
session_name('RESTAURANT_SESSION'); // Sets different cookie name
session_start();                     // Starts/resumes session

// Creates separate session file:
// sess_RESTAURANT_SESSION_<random_id>
```

### Session Switching (SSO Bridge)
```php
// 1. Read from source session
session_name('RESTAURANT_SESSION');
session_start();
$username = $_SESSION['username'];

// 2. Close source session
session_write_close();

// 3. Switch to target session
session_name('INVENTORY_SESSION');
session_start();

// 4. Write to target session
$_SESSION['username'] = $username;
```

### Browser Cookie Behavior
**Before Fix:**
- Cookie: `PHPSESSID=abc123` (shared between both systems)

**After Fix:**
- Cookie 1: `INVENTORY_SESSION=inv456` (only for inventory)
- Cookie 2: `RESTAURANT_SESSION=rest789` (only for restaurant)

## Potential Issues & Solutions

### Issue 1: Session Not Found After SSO
**Symptom:** Redirected to login after SSO transfer

**Solution:** Check that `sso_bridge.php` is properly closing RESTAURANT session before opening INVENTORY session.

**Debug Code:**
```php
// Add to sso_bridge.php
error_log("Restaurant session: " . print_r($_SESSION, true));
session_write_close();
session_name('INVENTORY_SESSION');
session_start();
error_log("Inventory session: " . print_r($_SESSION, true));
```

### Issue 2: Old Sessions Still Active
**Symptom:** Getting mixed session data after update

**Solution:** Clear all sessions:
```php
// Clear inventory session
session_name('INVENTORY_SESSION');
session_start();
session_destroy();

// Clear restaurant session  
session_name('RESTAURANT_SESSION');
session_start();
session_destroy();
```

Or manually delete session files:
- Windows: `C:\xampp\tmp\sess_*`
- Linux: `/tmp/sess_*`

### Issue 3: SSO Not Working
**Symptom:** Can't access inventory from restaurant

**Solution:** Verify database connection in `sso_bridge.php` and check that user exists in inventory `users` table.

## Rollback Instructions

If you need to revert to the old single-session behavior:

1. **Remove all session_name() calls:**
```bash
# PowerShell command to find all instances
Get-ChildItem -Path "C:\xampp\htdocs\system" -Recurse -Filter "*.php" | 
Select-String -Pattern "session_name\('(INVENTORY|RESTAURANT)_SESSION'\);"
```

2. **Restore original session_start() calls:**
```php
// Remove
session_name('INVENTORY_SESSION');
session_start();

// Replace with
session_start();
```

3. **Restore original sso_bridge.php** (remove session switching logic)

## Maintenance Notes

### Adding New PHP Files
When creating new PHP files that use sessions:

**Inventory System:**
```php
<?php
session_name('INVENTORY_SESSION');
session_start();
// ... rest of code
```

**Restaurant System:**
```php
<?php
session_name('RESTAURANT_SESSION');
session_start();
// ... rest of code
```

### Session Variable Names (Unchanged)
The fix does NOT change variable names, only session isolation:

**Inventory:**
- `$_SESSION['username']`
- `$_SESSION['Role']` (capital R)
- `$_SESSION['UserID']`

**Restaurant:**
- `$_SESSION['username']`
- `$_SESSION['role']` (lowercase r)
- `$_SESSION['user_id']`

These can remain the same because they're now in different session namespaces.

## Summary

✅ **Fixed:** Session collision between Inventory and Restaurant systems
✅ **Method:** Separate session names (INVENTORY_SESSION / RESTAURANT_SESSION)
✅ **Files:** 47 files updated
✅ **SSO:** Still works, properly switches between sessions
✅ **Testing:** Test page created at `test_sessions.php`

**No more username changes!** Each system maintains its own isolated session data.

---
**Last Updated:** November 2024
**Issue:** Username changing from "admin" to "ryan"
**Status:** ✅ RESOLVED
