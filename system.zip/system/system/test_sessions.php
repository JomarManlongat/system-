<?php
// Handle logout requests FIRST (before any output)
if (isset($_GET['logout_inv'])) {
    session_name('INVENTORY_SESSION');
    session_start();
    session_destroy();
    header("Location: test_sessions.php");
    exit;
}
if (isset($_GET['logout_rest'])) {
    session_name('RESTAURANT_SESSION');
    session_start();
    session_destroy();
    header("Location: test_sessions.php");
    exit;
}

// Read both sessions BEFORE any HTML output
session_name('INVENTORY_SESSION');
session_start();
$inventory_session = $_SESSION ?? [];
$inventory_logged_in = isset($inventory_session['username']);
$inventory_session_name = session_name();
$inventory_session_id = session_id();
session_write_close();

session_name('RESTAURANT_SESSION');
session_start();
$restaurant_session = $_SESSION ?? [];
$restaurant_logged_in = isset($restaurant_session['username']);
$restaurant_session_name = session_name();
$restaurant_session_id = session_id();
session_write_close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Session Test - Inventory & Restaurant</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px;
            margin: 0;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        h1 {
            color: white;
            text-align: center;
            margin-bottom: 30px;
        }
        .session-boxes {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 20px;
        }
        .session-box {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        .session-box h2 {
            margin-top: 0;
            color: #667eea;
            border-bottom: 2px solid #667eea;
            padding-bottom: 10px;
        }
        .session-data {
            background: #f5f5f5;
            padding: 15px;
            border-radius: 5px;
            font-family: 'Courier New', monospace;
            font-size: 14px;
            overflow-x: auto;
        }
        .status {
            display: inline-block;
            padding: 5px 15px;
            border-radius: 20px;
            font-weight: bold;
            margin-bottom: 10px;
        }
        .status.logged-in {
            background: #4caf50;
            color: white;
        }
        .status.not-logged-in {
            background: #f44336;
            color: white;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            margin: 5px;
            background: #667eea;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: all 0.3s;
        }
        .btn:hover {
            background: #5568d3;
            transform: translateY(-2px);
        }
        .btn-danger {
            background: #f44336;
        }
        .btn-danger:hover {
            background: #da190b;
        }
        .actions {
            text-align: center;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        .key {
            color: #e91e63;
            font-weight: bold;
        }
        .value {
            color: #2196f3;
        }
        .info-box {
            background: #fff3cd;
            border: 1px solid #ffc107;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            color: #856404;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔒 Session Isolation Test</h1>
        
        <div class="info-box">
            <strong>✅ Session Isolation Fixed!</strong><br>
            Each system now uses a separate session name:<br>
            • Inventory: <code>INVENTORY_SESSION</code><br>
            • Restaurant: <code>RESTAURANT_SESSION</code><br><br>
            You can now login to both systems simultaneously without session conflicts.
        </div>

        <div class="session-boxes">
            <!-- Inventory Session -->
            <div class="session-box">
                <h2>🏢 Inventory System Session</h2>
                <?php
                if ($inventory_logged_in) {
                    echo '<span class="status logged-in">✓ Logged In</span>';
                    echo '<div class="session-data">';
                    echo '<div><span class="key">Session Name:</span> <span class="value">' . htmlspecialchars($inventory_session_name) . '</span></div>';
                    echo '<div><span class="key">Username:</span> <span class="value">' . htmlspecialchars($inventory_session['username']) . '</span></div>';
                    if (isset($inventory_session['Role'])) {
                        echo '<div><span class="key">Role:</span> <span class="value">' . htmlspecialchars($inventory_session['Role']) . '</span></div>';
                    }
                    if (isset($inventory_session['user_name'])) {
                        echo '<div><span class="key">Full Name:</span> <span class="value">' . htmlspecialchars($inventory_session['user_name']) . '</span></div>';
                    }
                    if (isset($inventory_session['UserID'])) {
                        echo '<div><span class="key">User ID:</span> <span class="value">' . htmlspecialchars($inventory_session['UserID']) . '</span></div>';
                    }
                    echo '<div><span class="key">Session ID:</span> <span class="value">' . substr($inventory_session_id, 0, 20) . '...</span></div>';
                    echo '</div>';
                } else {
                    echo '<span class="status not-logged-in">✗ Not Logged In</span>';
                    echo '<div class="session-data">';
                    echo '<div><span class="key">Session Name:</span> <span class="value">' . htmlspecialchars($inventory_session_name) . '</span></div>';
                    echo '<div>No active session data</div>';
                    echo '</div>';
                }
                ?>
            </div>

            <!-- Restaurant Session -->
            <div class="session-box">
                <h2>🍽️ Restaurant System Session</h2>
                <?php
                if ($restaurant_logged_in) {
                    echo '<span class="status logged-in">✓ Logged In</span>';
                    echo '<div class="session-data">';
                    echo '<div><span class="key">Session Name:</span> <span class="value">' . htmlspecialchars($restaurant_session_name) . '</span></div>';
                    echo '<div><span class="key">Username:</span> <span class="value">' . htmlspecialchars($restaurant_session['username']) . '</span></div>';
                    if (isset($restaurant_session['role'])) {
                        echo '<div><span class="key">Role:</span> <span class="value">' . htmlspecialchars($restaurant_session['role']) . '</span></div>';
                    }
                    if (isset($restaurant_session['user_id'])) {
                        echo '<div><span class="key">User ID:</span> <span class="value">' . htmlspecialchars($restaurant_session['user_id']) . '</span></div>';
                    }
                    echo '<div><span class="key">Session ID:</span> <span class="value">' . substr($restaurant_session_id, 0, 20) . '...</span></div>';
                    echo '</div>';
                } else {
                    echo '<span class="status not-logged-in">✗ Not Logged In</span>';
                    echo '<div class="session-data">';
                    echo '<div><span class="key">Session Name:</span> <span class="value">' . htmlspecialchars($restaurant_session_name) . '</span></div>';
                    echo '<div>No active session data</div>';
                    echo '</div>';
                }
                ?>
            </div>
        </div>

        <div class="actions">
            <h3>Quick Actions</h3>
            <a href="main_inventory_system/login/index.php" class="btn" target="_blank">Login to Inventory</a>
            <a href="HotelLuneraRestaurant/login.php" class="btn" target="_blank">Login to Restaurant</a>
            <br><br>
            <a href="main_inventory_system/admin-page/admin_inv_man.php" class="btn">Inventory Dashboard</a>
            <a href="HotelLuneraRestaurant/admin/admin.php" class="btn">Restaurant Dashboard</a>
            <br><br>
            <a href="?refresh=1" class="btn">🔄 Refresh Page</a>
            <a href="?logout_inv=1" class="btn btn-danger">Logout Inventory</a>
            <a href="?logout_rest=1" class="btn btn-danger">Logout Restaurant</a>
        </div>
    </div>

            <a href="?logout_rest=1" class="btn btn-danger">Logout Restaurant</a>
        </div>
    </div>
</body>
</html>