/*
 Robust record usage script:
 - always exposes window.openUsage(itemId?, itemName?)
 - waits for modal HTML if not yet present
 - initializes event handlers once when modal is present
 - supports selectable (top) and fixed (row) modes
*/
(() => {
  let initialized = false;
  let initAttemptTimer = null;

  // helpers to find elements (look up at call time)
  function el(id) { return document.getElementById(id); }

  // init when modal exists
  function initIfReady() {
    if (initialized) return true;
    const modal = el('recordUsageModal');
    if (!modal) return false;

    // element refs
    const searchInput = el('usage_search');
    const dropdown = el('usage_dropdown');
    const hiddenItem = el('usage_item');
    const qtyInput = el('usage_quantity');
    const userSelect = el('usage_user');
    const hiddenUser = el('usage_user_hidden');
    const notesInput = el('usage_notes');
    const msg = el('usage_message');
    const saveBtn = el('usage_save_btn');
    const searchBlock = el('usage_search_block');
    const form = el('recordUsageForm');

    let debounceTimer = null;
    let selectedItem = null;
    let fixedMode = false;

    function showMessage(txt) {
      if (msg) { msg.style.display = 'block'; msg.textContent = txt; }
      else if (typeof window.showNotification === 'function') window.showNotification(txt, 'error');
      else alert(txt);
    }
    function clearMessage() { if (msg) { msg.style.display = 'none'; msg.textContent = ''; } }

    // Centered notification for success messages
    function showCenteredNotification(text) {
      // Create notification element
      const notif = document.createElement('div');
      notif.textContent = text;
      notif.style.cssText = `
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: #28a745;
        color: white;
        padding: 20px 40px;
        border-radius: 8px;
        font-size: 16px;
        font-weight: 600;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        z-index: 10000;
        animation: fadeInOut 2s ease-in-out;
      `;
      
      // Add animation style
      const style = document.createElement('style');
      style.textContent = `
        @keyframes fadeInOut {
          0% { opacity: 0; transform: translate(-50%, -60%); }
          15% { opacity: 1; transform: translate(-50%, -50%); }
          85% { opacity: 1; transform: translate(-50%, -50%); }
          100% { opacity: 0; transform: translate(-50%, -40%); }
        }
      `;
      document.head.appendChild(style);
      
      document.body.appendChild(notif);
      
      // Remove after animation completes
      setTimeout(() => {
        notif.remove();
        style.remove();
      }, 2000);
    }

    function performSearch(q) {
      if (!dropdown || !searchInput) return;
      if (!q || q.trim().length === 0) {
        dropdown.style.display = 'none';
        dropdown.innerHTML = '';
        return;
      }
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        fetch(`inventory/search_items.php?q=${encodeURIComponent(q)}`, { cache: 'no-store' })
          .then(r => r.json())
          .then(data => renderDropdown(Array.isArray(data) ? data : []))
          .catch(() => { dropdown.style.display = 'none'; dropdown.innerHTML = ''; });
      }, 200);
    }

    function renderDropdown(items) {
      if (!dropdown) return;
      dropdown.innerHTML = '';
      if (!items.length) { dropdown.style.display = 'none'; return; }
      items.forEach(it => {
        const div = document.createElement('div');
        div.className = 'usage-dropdown-item';
        div.style.padding = '8px';
        div.style.cursor = 'pointer';
        div.style.borderBottom = '1px solid #eee';
        const measurement = it.Measurement ? ` ${it.Measurement}` : '';
        div.textContent = `${it.ItemID} — ${it.ItemName} (stock: ${it.Stock}${measurement})`;
        div.dataset.item = JSON.stringify(it);
        div.addEventListener('click', () => {
          const obj = JSON.parse(div.dataset.item);
          selectedItem = obj;
          // Update search input with selected item
          if (searchInput) searchInput.value = `${obj.ItemID} — ${obj.ItemName}`;
          if (hiddenItem) hiddenItem.value = obj.ItemID;
          if (dropdown) dropdown.style.display = 'none';
        });
        dropdown.appendChild(div);
      });
      dropdown.style.display = 'block';
    }

    // attach listeners
    if (searchInput) {
      searchInput.addEventListener('input', (e) => performSearch(e.target.value));
    }

    // keep hidden user input in sync with the select (helps disabled-select submission)
    if (userSelect && hiddenUser) {
      // initialize
      try { hiddenUser.value = userSelect.value || hiddenUser.value || ''; } catch (e) {}
      userSelect.addEventListener('change', () => { hiddenUser.value = userSelect.value || ''; });
    }

    document.addEventListener('click', (ev) => {
      if (!ev.target.closest('#usage_search') && !ev.target.closest('#usage_dropdown')) {
        if (dropdown) dropdown.style.display = 'none';
      }
    });

    // form submit
    if (form) {
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        clearMessage();

        const itemVal = hiddenItem ? hiddenItem.value.trim() : '';
        const qty = qtyInput ? parseInt(qtyInput.value, 10) || 0 : 0;
        const user = userSelect ? userSelect.value : '';
        const notes = notesInput ? notesInput.value : '';

        if (!itemVal) return showMessage('Please select an item.');
        if (qty <= 0) return showMessage('Quantity must be at least 1.');
        if (!user) return showMessage('Please select a user.');

        if (saveBtn) saveBtn.disabled = true;

        const fd = new FormData();
        fd.append('item', itemVal);
        fd.append('quantity', qty);
        fd.append('user', user);
        fd.append('notes', notes);

        fetch('inventory/save_usage.php', { method: 'POST', body: fd })
          .then(r => r.json())
          .then(resp => {
            if (saveBtn) saveBtn.disabled = false;
            if (resp && resp.success) {
              try {
                updateStockInTable(resp.item, resp.updated_stock, resp.measurement);
              } catch (e) { /* ignore */ }
              closeUsageModal();
              showCenteredNotification('Record usage successfully');
            } else {
              showMessage(resp && resp.error ? resp.error : 'Failed to record usage.');
            }
          })
          .catch(() => {
            if (saveBtn) saveBtn.disabled = false;
            // Removed duplicate error notification - only show inline message
          });
      });
    }

    // close modal when clicking outside
    window.addEventListener('click', (e) => {
      const m = el('recordUsageModal');
      if (m && e.target === m) closeUsageModal();
    });

    // helper to update table stock cell
    function updateStockInTable(itemId, newStock, measurement) {
      const tbody = document.getElementById('inventory_table_body');
      if (!tbody) return;
      const rows = tbody.querySelectorAll('tr');
      rows.forEach(row => {
        const firstTd = row.querySelector('td');
        if (!firstTd) return;
        if (firstTd.textContent.trim() === String(itemId)) {
          const stockTd = row.children[2];
          if (stockTd) {
            stockTd.textContent = (newStock !== null && newStock !== undefined)
              ? (newStock + (measurement ? ' ' + measurement : ''))
              : stockTd.textContent;
          }
        }
      });
    }

    // mark initialized
    initialized = true;
    return true;
  }

  // Expose openUsage and closeUsageModal immediately.
  window.openUsage = function(itemId, itemName) {
    // ensure initialization, retry if modal not yet present
    if (!initIfReady()) {
      if (initAttemptTimer) clearTimeout(initAttemptTimer);
      initAttemptTimer = setTimeout(() => {
        if (!initIfReady()) return;
        window.openUsage(itemId, itemName);
      }, 120);
      return;
    }
    // now modal and elements are ready
    const modal = el('recordUsageModal');
    const searchInput = el('usage_search');
    const hiddenItem = el('usage_item');
    const msg = el('usage_message');
    if (msg) { msg.style.display = 'none'; msg.textContent = ''; }
    const qtyInput = el('usage_quantity');
    if (qtyInput) qtyInput.value = 1;
    const notes = el('usage_notes');
    if (notes) notes.value = '';
    // If opened from a specific row with itemId, lock the item field (fixed mode)
    if (itemId) {
      if (searchInput) {
        const label = itemName ? String(itemName) : '';
        searchInput.value = `${itemId} — ${label}`.trim();
        searchInput.setAttribute('readonly', 'true');
        searchInput.style.background = '#f5f5f5';
        searchInput.style.cursor = 'not-allowed';
        searchInput.setAttribute('aria-readonly', 'true');
      }
      if (hiddenItem) hiddenItem.value = String(itemId);
      const dropdown = el('usage_dropdown');
      if (dropdown) { dropdown.style.display = 'none'; dropdown.innerHTML = ''; }
    } else {
      // No preselected item: allow searching normally
      if (searchInput) {
        searchInput.value = '';
        searchInput.removeAttribute('readonly');
        searchInput.style.background = '';
        searchInput.style.cursor = '';
        searchInput.removeAttribute('aria-readonly');
        searchInput.focus();
      }
      if (hiddenItem) hiddenItem.value = '';
      const dropdown = el('usage_dropdown');
      if (dropdown) { dropdown.style.display = 'none'; dropdown.innerHTML = ''; }
    }
    if (modal) {
      modal.style.display = 'flex';
      modal.setAttribute('aria-hidden', 'false');
    }
  };

  window.closeUsageModal = function() {
    const modal = el('recordUsageModal');
    if (modal) {
      modal.style.display = 'none';
      modal.setAttribute('aria-hidden', 'true');
    }
    // Re-enable search input when modal closes
    const searchInput = el('usage_search');
    if (searchInput) {
      searchInput.removeAttribute('readonly');
      searchInput.style.background = '';
      searchInput.style.cursor = '';
    }
  };

  // ensure we attempt init once immediately in case modal is already present
  setTimeout(initIfReady, 30);
})();
