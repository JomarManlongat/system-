<?php
session_name('INVENTORY_SESSION');
session_start();
require(__DIR__ . "/../../login/database-account.php"); // adjust path

$search = $_POST['search'] ?? '';
$location = $_POST['location'] ?? 'All'; // Supplier-specific location
$generalLocation = $_POST['general_location'] ?? 'All'; // General location filter
$top = $_POST['top'] ?? '';

// Get user's assigned location from session. If null/empty => they may access both locations.
$user_location = (isset($_SESSION) && isset($_SESSION['user_location']) && $_SESSION['user_location'] !== '') ? $_SESSION['user_location'] : null;

$query = "SELECT i.ItemID, si.ItemName,
                 CONCAT(i.Stock, ' ', si.Measurement) AS StockMeasurement,
                 i.Stock AS StockNumeric,
                 s.SupplierName, s.Location,
                 i.ExpiryDate, i.Conditions
          FROM items i
          JOIN supplieritems si ON i.SupplierItemID = si.SupplierItemID
          JOIN suppliers s ON si.SupplierID = s.SupplierID
          WHERE i.Stock > 0
          AND (i.ExpiryDate IS NULL OR i.ExpiryDate >= CURDATE())
          AND (si.ItemName LIKE ? OR i.ItemID LIKE ? OR s.SupplierName LIKE ?)";

$params = ["%$search%", "%$search%", "%$search%"];
$types = "sss";

// Filter by user's assigned location:
// - Admins: can filter or see all
// - Staff: only restrict when a location is explicitly set; if NULL/empty they may access both
$userRole = $_SESSION['Role'] ?? $_SESSION['roles'] ?? '';
if (strtolower($userRole) !== 'admin') {
    // Staff: only restrict when a location is explicitly provided
    if (!empty($user_location)) {
        $query .= " AND s.Location = ?";
        $params[] = $user_location;
        $types .= "s";
    }
} else {
    // Admin can filter by location or see all
    if ($location !== "All") {
        $query .= " AND s.Location = ?";
        $params[] = $location;
        $types .= "s";
    }

    if ($generalLocation !== "All") {
        $query .= " AND s.Location = ?";
        $params[] = $generalLocation;
        $types .= "s";
    }
}

// Sort by highest stock when TOP filter is used
if ($top && is_numeric($top) && intval($top) > 0) {
    $query .= " ORDER BY i.Stock DESC LIMIT " . intval($top);
} else {
    $query .= " ORDER BY i.ItemID ASC";
}

$stmt = $conn->prepare($query);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()):
?>
<tr>
    <td><?= htmlspecialchars($row['ItemID']); ?></td>
    <td><?= htmlspecialchars($row['ItemName']); ?></td>
    <td><?= htmlspecialchars($row['StockMeasurement']); ?></td>
    <td><?= htmlspecialchars($row['SupplierName']); ?></td>
    <td><?= htmlspecialchars($row['Location']); ?></td>
    <td><?= $row['ExpiryDate'] ? htmlspecialchars($row['ExpiryDate']) : "N/A"; ?></td>
    <td>
        <?php if ($row['Conditions'] == "Good"): ?>
            <span class="status good">Good</span>
        <?php else: ?>
            <span class="status low">Low Stock</span>
        <?php endif; ?>
    </td>
    <td>
        <button type="button" class="record-btn" onclick="openUsage('<?= $row['ItemID'] ?>', '<?= htmlspecialchars($row['ItemName']) ?>')">
            Record Usage
        </button>
    </td>

 
</tr>
<?php endwhile; ?>