<?php
header('Content-Type: application/json; charset=utf-8');
session_name('INVENTORY_SESSION');
session_start();
require_once __DIR__ . '/../../login/database-account.php';

$item = isset($_POST['item']) ? trim($_POST['item']) : '';
$quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 0;
$user = isset($_POST['user']) ? trim($_POST['user']) : '';
$notes = isset($_POST['notes']) ? trim($_POST['notes']) : '';

if ($item === '' || $quantity <= 0 || $user === '') {
    echo json_encode(['success' => false, 'error' => 'Invalid input. Please fill all required fields.']);
    exit;
}

// No separate restaurant connection needed - trigger handles cross-database sync
// Ensure item_usage has sync columns before starting a transaction (avoid DDL inside txn)
$colChk = $conn->query("SHOW COLUMNS FROM item_usage LIKE 'synced_to_restaurant'");
if (!$colChk || $colChk->num_rows === 0) {
    // ALTER causes implicit commit; do it before transactional work
    $conn->query("ALTER TABLE item_usage ADD COLUMN synced_to_restaurant TINYINT(1) DEFAULT 0, ADD COLUMN synced_at DATETIME NULL");
}

$conn->begin_transaction();

try {
    // Detect which column names the `items` table uses for stock and condition
    $stockCol = null;
    $condCol = null;
    $expiryCol = null;
    $colsRes = $conn->query("SHOW COLUMNS FROM items");
    if ($colsRes) {
        while ($c = $colsRes->fetch_assoc()) {
            $f = $c['Field'];
            if (in_array($f, ['Stock','CurrentStock','Current_Stock','Quantity','Current'])) {
                if (!$stockCol) $stockCol = $f;
            }
            if (in_array($f, ['Conditions','Condition','status','Status'])) {
                if (!$condCol) $condCol = $f;
            }
            if (in_array($f, ['ExpiryDate','Expiry','expiry_date','expiry'])) {
                if (!$expiryCol) $expiryCol = $f;
            }
        }
    }
    if (!$stockCol) {
        throw new Exception('Could not detect stock column in items table');
    }
    // Only include expiry column if it exists

    // Lock and read current stock (and expiry if available)
    if ($expiryCol) {
        $sql = "SELECT `$stockCol` AS current_stock, `$expiryCol` AS expiry_date FROM items WHERE ItemID = ? FOR UPDATE";
    } else {
        $sql = "SELECT `$stockCol` AS current_stock FROM items WHERE ItemID = ? FOR UPDATE";
    }
    $sel = $conn->prepare($sql);
    if (!$sel) {
        throw new Exception('Database prepare error: ' . $conn->error);
    }
    $sel->bind_param('i', $item);
    $sel->execute();
    $res = $sel->get_result();

    if (!($row = $res->fetch_assoc())) {
        throw new Exception('Item not found');
    }

    $currentStock = (int)$row['current_stock'];
    $currentExpiryDate = $expiryCol ? ($row['expiry_date'] ?? null) : null;
    $newStock = $currentStock - $quantity;
    
    if ($newStock < 0) {
        throw new Exception('Insufficient stock. Current stock: ' . $currentStock . ', requested: ' . $quantity);
    }

    // Update stock in items table and handle condition label
    // Build update SQL using detected column names
    $condCol = $condCol ?: 'Conditions';
    if ($newStock === 0) {
        $updSql = "UPDATE items SET `$stockCol` = ?, `$condCol` = 'Out of Stock' WHERE ItemID = ?";
    } else if ($newStock > 0 && $newStock <= 20) {
        $updSql = "UPDATE items SET `$stockCol` = ?, `$condCol` = 'Low Stock' WHERE ItemID = ?";
    } else {
        $updSql = "UPDATE items SET `$stockCol` = ?, `$condCol` = 'Good' WHERE ItemID = ?";
    }
    $upd = $conn->prepare($updSql);
    if (!$upd) {
        throw new Exception('Database prepare error: ' . $conn->error);
    }
    $upd->bind_param('ii', $newStock, $item);
    if (!$upd->execute()) {
        throw new Exception('Failed to update stock');
    }

    // Insert usage record into item_usage table
    // Check if table exists, if not create it
    $checkTable = $conn->query("SHOW TABLES LIKE 'item_usage'");
    if ($checkTable->num_rows == 0) {
        // Create table if it doesn't exist
        $createTable = "CREATE TABLE item_usage (
            UsageID INT AUTO_INCREMENT PRIMARY KEY,
            ItemID INT NOT NULL,
            Quantity INT NOT NULL,
            UserID INT NOT NULL,
            Notes TEXT,
            CreatedAt DATETIME NOT NULL,
            INDEX idx_item (ItemID),
            INDEX idx_user (UserID),
            INDEX idx_date (CreatedAt)
        )";
        if (!$conn->query($createTable)) {
            throw new Exception('Failed to create usage table: ' . $conn->error);
        }
    }

    $ins = $conn->prepare("INSERT INTO item_usage (ItemID, Quantity, UserID, Notes, CreatedAt) VALUES (?, ?, ?, ?, NOW())");
    if (!$ins) {
        throw new Exception('Database prepare error: ' . $conn->error);
    }
    $ins->bind_param('iiis', $item, $quantity, $user, $notes);
    if (!$ins->execute()) {
        throw new Exception('Failed to record usage');
    }
    $usage_id = $ins->insert_id;

    // ✅ INSERT INTO TRANSACTIONS TABLE
    // For usage records, SupplierID is not applicable
    // Check if SupplierID column allows NULL, otherwise use 0
    $transType = 'Usage Stock';
    
    // Try without SupplierID first (if column is nullable)
    $transSql = $conn->prepare("INSERT INTO `transactions` (`ItemID`, `Type`, `Quantity`, `UserID`, `DateTime`) VALUES (?, ?, ?, ?, NOW())");
    if (!$transSql) {
        throw new Exception('Failed to prepare transaction: ' . $conn->error);
    }
    $transSql->bind_param('isii', $item, $transType, $quantity, $user);
    
    // If insert fails due to SupplierID constraint, try with 0
    if (!$transSql->execute()) {
        $transSql->close();
        // Retry with SupplierID = 0 or NULL
        $transSql = $conn->prepare("INSERT INTO `transactions` (`ItemID`, `Type`, `Quantity`, `UserID`, `SupplierID`, `DateTime`) VALUES (?, ?, ?, ?, 0, NOW())");
        if (!$transSql) {
            throw new Exception('Failed to prepare transaction: ' . $conn->error);
        }
        $transSql->bind_param('isii', $item, $transType, $quantity, $user);
        if (!$transSql->execute()) {
            throw new Exception('Failed to log transaction: ' . $transSql->error);
        }
    }
    $transSql->close();

    // Avoid double-sync: if DB trigger exists, skip PHP sync
    $hasTrigger = false;
    $tcStmt = $conn->prepare("SELECT COUNT(*) AS cnt FROM INFORMATION_SCHEMA.TRIGGERS WHERE TRIGGER_SCHEMA = DATABASE() AND TRIGGER_NAME = 'after_item_usage_sync_restaurant'");
    if ($tcStmt) {
        $tcStmt->execute();
        $tcRes = $tcStmt->get_result();
        if ($tcRes && ($tcRow = $tcRes->fetch_assoc())) {
            $hasTrigger = intval($tcRow['cnt'] ?? 0) > 0;
        }
        $tcStmt->close();
    }

    if (!$hasTrigger) {
        // Run PHP sync based on item location - sync when item is marked as Restaurant
        $locStmt = $conn->prepare("SELECT Location FROM items WHERE ItemID = ? LIMIT 1");
        if ($locStmt) {
            $locStmt->bind_param('i', $item);
            $locStmt->execute();
            $locRes = $locStmt->get_result();
            if ($locRes && ($locRow = $locRes->fetch_assoc())) {
                $itemLocation = strtolower(trim($locRow['Location'] ?? ''));
                if ($itemLocation === 'restaurant') {
                    require_once __DIR__ . '/restaurant_sync.php';
                    if (function_exists('sync_usage_to_restaurant')) {
                        try { sync_usage_to_restaurant($conn, $usage_id); } catch (Exception $e) { /* ignore */ }
                    }
                }
            }
            $locStmt->close();
        }
    }

    // Get measurement for UI update
    $mstmt = $conn->prepare("SELECT si.Measurement FROM supplieritems si JOIN items i ON i.SupplierItemID = si.SupplierItemID WHERE i.ItemID = ?");
    if ($mstmt) {
        $mstmt->bind_param('i', $item);
        $mstmt->execute();
        $mres = $mstmt->get_result();
        $measurement = '';
        if ($mrow = $mres->fetch_assoc()) {
            $measurement = $mrow['Measurement'];
        }
        $mstmt->close();
    } else {
        $measurement = '';
    }

    $conn->commit();
    
    echo json_encode([
        'success' => true, 
        'item' => $item, 
        'updated_stock' => $newStock, 
        'measurement' => $measurement,
        'message' => 'Usage recorded successfully. Stock updated from ' . $currentStock . ' to ' . $newStock . '. Restaurant sync attempted if applicable.'
    ]);
    exit;
    
} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    exit;
}

