<?php
session_name('INVENTORY_SESSION');
session_start();
require_once __DIR__ . '/../../login/database-account.php';

function esc($s){return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8');}

$search = $_GET['search'] ?? '';
$date_from = $_GET['from'] ?? '';
$date_to = $_GET['to'] ?? '';
$location = $_GET['location'] ?? 'all';
$top = (int)($_GET['top'] ?? 0);
$transType = $_GET['type'] ?? 'all'; // Stock Added | Usage Recorded

// Get user's assigned location from session. If NULL/empty => they may access both locations.
$user_location = (isset($_SESSION['user_location']) && $_SESSION['user_location'] !== '') ? $_SESSION['user_location'] : null;
$userRole = $_SESSION['Role'] ?? $_SESSION['roles'] ?? '';

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) { die('DB connection failed'); }

// Check if items has Location column (to avoid SQL errors on some schemas)
$hasLocation = false;
$colRes = $conn->query("SHOW COLUMNS FROM items LIKE 'Location'");
if ($colRes && $colRes->num_rows > 0) { $hasLocation = true; }

$sql = "SELECT t.TransactionID, t.ItemID, i.ItemName, i.Location AS ItemLocation, t.Type, t.Quantity, t.UserID, u.NAME AS UserName, t.DateTime, "
     . "s.SupplierName"
     . " FROM transactions t"
     . " LEFT JOIN items i ON t.ItemID = i.ItemID"
     . " LEFT JOIN users u ON t.UserID = u.UserID"
     . " LEFT JOIN supplieritems si ON i.SupplierItemID = si.SupplierItemID"
     . " LEFT JOIN suppliers s ON si.SupplierID = s.SupplierID"
     . " WHERE 1=1";

$params = [];

// Staff users: restrict to their assigned location only when explicitly set.
// If items table has a Location column use it; otherwise fall back to supplier's Location (s.Location).
if (strtolower($userRole) !== 'admin' && !empty($user_location)) {
    $safe = $conn->real_escape_string($user_location);
    if ($hasLocation) {
        $sql .= " AND i.Location = '$safe'";
    } else {
        // fallback to supplier location when items.Location is absent
        $sql .= " AND s.Location = '$safe'";
    }
}

if ($search !== '') {
    $safe = '%' . $conn->real_escape_string($search) . '%';
    $sql .= " AND (t.TransactionID LIKE '$safe' OR i.ItemName LIKE '$safe' OR u.NAME LIKE '$safe')";
}
if ($date_from !== '') {
    $safe = $conn->real_escape_string($date_from);
    $sql .= " AND DATE(t.DateTime) >= '$safe'";
}
if ($date_to !== '') {
    $safe = $conn->real_escape_string($date_to);
    $sql .= " AND DATE(t.DateTime) <= '$safe'";
}
if ($transType !== 'all') {
    // Normalize known values: transactions.Type may be like 'Added Stock' or 'Usage Stock'
    if ($transType === 'Stock Added') {
        $sql .= " AND (t.Type LIKE '%Add%' OR t.Type='Added Stock')";
    } else if ($transType === 'Usage Recorded') {
        $sql .= " AND (t.Type LIKE '%Usage%' OR t.Type='Usage Stock')";
    }
}
// Only allow explicit location filtering for admins; ignore non-admin requests to change scope.
if ($location !== 'all' && strtolower($userRole) === 'admin') {
    $safe = $conn->real_escape_string($location);
    // prefer items.Location if available, otherwise suppliers.Location
    if ($hasLocation) {
        $sql .= " AND i.Location = '$safe'";
    } else {
        $sql .= " AND s.Location = '$safe'";
    }
}

$sql .= " ORDER BY t.DateTime DESC";
if ($top > 0) { $sql .= " LIMIT " . intval($top); }

$res = $conn->query($sql);

// Build HTML rows
$out = '';
if ($res && $res->num_rows) {
    while ($r = $res->fetch_assoc()) {
        $badge = 'badge-usage';
        $label = 'Usage Recorded';
        $t = strtolower($r['Type'] ?? '');
        if (strpos($t, 'add') !== false) { $badge = 'badge-added'; $label = 'Stock Added'; }
        $out .= '<tr>'
             . '<td>' . esc($r['TransactionID']) . '</td>'
             . '<td>' . esc($r['ItemID']) . '</td>'
             . '<td>' . esc($r['ItemName']) . '</td>'
             . '<td>' . esc($r['Quantity']) . '</td>'
             . '<td><span class="badge ' . $badge . '">' . $label . '</span></td>'
             . '<td>' . esc($r['UserName'] ?: 'N/A') . '</td>'
             . '<td>' . esc($r['SupplierName'] ?: 'N/A') . '</td>'
             . '<td>' . esc($r['ItemLocation'] ?: 'N/A') . '</td>'
             . '<td>' . esc($r['DateTime']) . '</td>'
             . '</tr>';
    }
}

echo $out;
$conn->close();
