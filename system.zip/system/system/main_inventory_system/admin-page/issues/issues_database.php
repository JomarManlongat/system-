<?php
require __DIR__ . '/../../login/database-account.php';
header('Content-Type: text/html; charset=utf-8');

$filter = isset($_POST['filter']) ? strtolower(trim($_POST['filter'])) : 'all';
$top = isset($_POST['top']) ? intval($_POST['top']) : 0;
$location = isset($_POST['location']) ? trim($_POST['location']) : 'All';

function esc($v){ return htmlspecialchars((string)$v ?? '', ENT_QUOTES, 'UTF-8'); }
function fmt_date($d){ if(!$d) return 'N/A'; $t=strtotime($d); return $t? date('n/j/Y', $t): esc($d); }

// Build base query to fetch potential issues
// Sources:
// - Damaged: issues table with Conditions = 'Damaged'
// - Expired: items with ExpiryDate < CURDATE()
// We'll join items -> supplieritems -> suppliers to render columns

// Fetch issues directly from issues table
$sqlIssues = "SELECT IssueID, ItemID, ItemName, Location, Stock, ExpiryDate, Conditions AS IssueCondition, Reason, QuantityAffected FROM issues WHERE 1=1";
if ($location !== 'All') {
  $sqlIssues .= " AND Location = '" . $conn->real_escape_string($location) . "'";
}
if ($filter === 'damaged') {
  $sqlIssues .= " AND Conditions = 'Damaged'";
} else if ($filter === 'expired') {
  $sqlIssues .= " AND Conditions = 'Expired'";
}
$sqlIssues .= " ORDER BY IssueID DESC";
$resIssues = $conn->query($sqlIssues);
$issuesFromTable = [];
if ($resIssues) {
  while ($row = $resIssues->fetch_assoc()) {
    $issuesFromTable[] = $row;
  }
}

// Out of Stock from items table (live data)
$outOfStockRows = [];
if ($filter === 'all' || $filter === 'out of stock') {
  $sqlO = "SELECT i.ItemID, si.ItemName, s.Location, i.Stock, i.ExpiryDate, 'Out of Stock' AS IssueCondition, '' as Reason, 0 as QuantityAffected
           FROM items i
           JOIN supplieritems si ON i.SupplierItemID = si.SupplierItemID
           JOIN suppliers s ON si.SupplierID = s.SupplierID
           WHERE i.Stock = 0";
  if ($location !== 'All') {
    $sqlO .= " AND s.Location = '" . $conn->real_escape_string($location) . "'";
  }
  $resO = $conn->query($sqlO);
  if ($resO) { while ($row = $resO->fetch_assoc()) { $outOfStockRows[] = $row; } }
}

// Merge all issues
$rows = [];
if ($filter === 'damaged') {
  $rows = array_filter($issuesFromTable, function($r) { return strtolower($r['IssueCondition']) === 'damaged'; });
} else if ($filter === 'expired') {
  $rows = array_filter($issuesFromTable, function($r) { return strtolower($r['IssueCondition']) === 'expired'; });
} else if ($filter === 'out of stock') {
  $rows = $outOfStockRows;
} else {
  $rows = array_merge($issuesFromTable, $outOfStockRows);
}

// Apply top limit if specified
if ($top > 0 && count($rows) > $top) {
  $rows = array_slice($rows, 0, $top);
}

// Helper to compute whether return is allowed (last received within 7 days)
function last_received_date($conn, $itemId){
  $sql = "SELECT MAX(o.OrderDate) AS last_date
          FROM orders o
          JOIN orderdetails od ON od.OrderID = o.OrderID
          JOIN supplieritems si ON si.SupplierItemID = od.SupplierItemID
          JOIN items i ON i.SupplierItemID = si.SupplierItemID
          WHERE i.ItemID = ? AND o.Status IN ('Received','Completed')";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param('s', $itemId);
  $stmt->execute(); $res = $stmt->get_result();
  if ($res && ($row = $res->fetch_assoc()) && $row['last_date']) return $row['last_date'];
  return null;
}

if (empty($rows)){
  echo '<tr><td colspan="7" style="text-align:center;color:#666;padding:16px">No issues found.</td></tr>';
  exit;
}

// Render rows
foreach ($rows as $r) {
  $itemId = esc($r['ItemID']);
  $name = esc($r['ItemName']);
  $loc = esc($r['Location']);
  $stock = (int)$r['Stock'];
  $exp = fmt_date($r['ExpiryDate']);
  $cond = strtolower($r['IssueCondition']);
  
  // Different badge colors for different conditions
  $badgeColor = '#ef4444'; // Red for damaged/expired
  if ($cond === 'out of stock') $badgeColor = '#f59e0b'; // Orange for out of stock
  
  $badge = '<span style="display:inline-block;background:'.$badgeColor.';color:#fff;padding:6px 10px;border-radius:14px;font-weight:600;font-size:12px;">'.ucfirst($cond).'</span>';

  // Determine return eligibility
  $actionHtml = '';
  if ($cond === 'out of stock') {
    // Out of stock items cannot be returned
    $actionHtml = '<span style="color:#999;font-size:12px;">Not eligible</span>';
  } else {
    $last = last_received_date($conn, $itemId);
    $eligible = false;
    if ($last) {
      $days = (time() - strtotime($last)) / 86400.0;
      $eligible = ($days <= 7);
    }
    if ($eligible) {
      $actionHtml = '<button class="record-btn return-btn" data-item-id="'.$itemId.'" style="height:32px;padding:4px 8px;display:inline-flex;align-items:center;justify-content:center;gap:4px;white-space:nowrap;font-size:12px;"><span style="font-size:12px;line-height:1;">⟲</span><span style="line-height:1;">Return to Supplier</span></button>';
    } else {
      $actionHtml = '<span style="color:#999;font-size:12px;">Not eligible</span>';
    }
  }

  echo '<tr>'
     . '<td>'.$itemId.'</td>'
     . '<td>'.$name.'</td>'
     . '<td>'.$loc.'</td>'
     . '<td>'.$stock.'</td>'
     . '<td>'.$exp.'</td>'
     . '<td>'.$badge.'</td>'
    . '<td style="text-align:center">'.$actionHtml.'</td>'
     . '</tr>';
}
