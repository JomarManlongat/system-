<?php
require __DIR__ . '/../../login/database-account.php';
header('Content-Type: application/json');

$itemId = isset($_POST['item_id']) ? trim($_POST['item_id']) : '';
if ($itemId === '') { echo json_encode(['ok'=>false,'error'=>'Missing item_id']); exit; }

// Validate last received within 7 days
$sql = "SELECT MAX(o.OrderDate) AS last_date
        FROM orders o
        JOIN orderdetails od ON od.OrderID = o.OrderID
        JOIN supplieritems si ON si.SupplierItemID = od.SupplierItemID
        JOIN items i ON i.SupplierItemID = si.SupplierItemID
        WHERE i.ItemID = ? AND o.Status IN ('Received','Completed')";
$stmt = $conn->prepare($sql);
$stmt->bind_param('s', $itemId);
$stmt->execute(); $res = $stmt->get_result();
$last = null; if ($res && ($row=$res->fetch_assoc())) $last = $row['last_date'];
if (!$last || (time()-strtotime($last)) > 7*86400) {
  echo json_encode(['ok'=>false,'error'=>'Return window expired']);
  exit;
}

// Create a simple returns table if it doesn't exist
$conn->query("CREATE TABLE IF NOT EXISTS returns (
  ReturnID INT AUTO_INCREMENT PRIMARY KEY,
  ItemID VARCHAR(64) NOT NULL,
  CreatedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  Status VARCHAR(20) NOT NULL DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$ins = $conn->prepare("INSERT INTO returns (ItemID, Status) VALUES (?, 'Pending')");
$ins->bind_param('s', $itemId);
$ok = $ins->execute();

if ($ok) echo json_encode(['ok'=>true]); else echo json_encode(['ok'=>false,'error'=>'DB insert failed']);
