<?php
require __DIR__ . '/../../login/database-account.php';
header('Content-Type: text/html; charset=utf-8');

$typeFilter = isset($_POST['type']) ? trim($_POST['type']) : 'all';
$statusFilter = isset($_POST['status']) ? trim($_POST['status']) : 'all';

function esc($v){ return htmlspecialchars((string)$v ?? '', ENT_QUOTES, 'UTF-8'); }

// Query alerts table directly
$sql = "SELECT a.AlertID, a.Type, a.ItemID, a.Details, a.Status
        FROM alerts a";

$where = [];
$params = [];
$types = '';

if ($typeFilter !== 'all') {
  $where[] = 'a.Type = ?';
  $params[] = $typeFilter;
  $types .= 's';
}

if ($statusFilter !== 'all') {
  $where[] = 'a.Status = ?';
  $params[] = $statusFilter;
  $types .= 's';
}

if (!empty($where)) {
  $sql .= ' WHERE ' . implode(' AND ', $where);
}

$sql .= ' ORDER BY a.AlertID DESC LIMIT 200';

$stmt = $conn->prepare($sql);
if ($params) { $stmt->bind_param($types, ...$params); }
$stmt->execute();
$result = $stmt->get_result();

if (!$result || $result->num_rows === 0) {
  echo '<tr><td colspan="6" style="text-align:center;color:#666;padding:16px">No alerts found.</td></tr>';
  exit;
}

function status_badge($status) {
  $s = strtolower(trim((string)$status));
  if ($s === 'pending') {
    return '<span style="display:inline-block;background:#ef4444;color:#fff;padding:6px 10px;border-radius:14px;font-weight:600;font-size:12px;">Pending</span>';
  } else if ($s === 'resolved') {
    return '<span style="display:inline-block;background:#e5e7eb;color:#111;padding:6px 10px;border-radius:14px;font-weight:600;font-size:12px;">Resolved</span>';
  }
  return '<span style="display:inline-block;background:#e5e7eb;color:#111;padding:6px 10px;border-radius:14px;font-weight:600;font-size:12px;">'.esc($status).'</span>';
}

function clamp2($s){ return '<div class="clamp-2">'.esc($s).'</div>'; }

while ($row = $result->fetch_assoc()) {
  $alertId = esc($row['AlertID']);
  $type = $row['Type'] ? esc($row['Type']) : '-';
  $itemId = $row['ItemID'];
  
  // Get ItemName from items table
  $itemNameSql = "SELECT ItemName FROM items WHERE ItemID = ?";
  $itemStmt = $conn->prepare($itemNameSql);
  $itemStmt->bind_param('i', $itemId);
  $itemStmt->execute();
  $itemResult = $itemStmt->get_result();
  $itemRow = $itemResult->fetch_assoc();
  $itemName = $itemRow ? esc($itemRow['ItemName']) : '-';
  $itemStmt->close();
  
  $details = $row['Details'] ? esc($row['Details']) : '-';
  $status = $row['Status'];
  $badge = status_badge($status);

  $actionHtml = '';
  if (strtolower(trim($status)) === 'pending') {
    $actionHtml = '<button class="record-btn resolve-alert-btn" data-alert-id="'.$alertId.'" style="height:32px;line-height:32px;">Mark as Resolved</button>';
  } else {
    $actionHtml = '<span style="color:#999;font-size:12px;">-</span>';
  }

  echo '<tr>'
     . '<td>'.clamp2($alertId).'</td>'
     . '<td>'.clamp2($type).'</td>'
     . '<td>'.clamp2($itemName).'</td>'
     . '<td>'.clamp2($details).'</td>'
     . '<td>'.$badge.'</td>'
     . '<td style="text-align:center">'.$actionHtml.'</td>'
     . '</tr>';
}
