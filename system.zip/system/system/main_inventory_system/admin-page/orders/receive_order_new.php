<?php
error_reporting(0);
ini_set('display_errors', 0);
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../../login/database-account.php';

$orderId = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;
$receivedBy = isset($_POST['received_by']) ? intval($_POST['received_by']) : 0;
$itemsJson = isset($_POST['items']) ? $_POST['items'] : '[]';
$items = json_decode($itemsJson, true);
$issuesJson = isset($_POST['issues']) ? $_POST['issues'] : '[]';
$issues = json_decode($issuesJson, true);

if ($orderId <= 0) {
    echo json_encode(['success' => false, 'error' => 'Invalid order ID']);
    exit;
}

if ($receivedBy <= 0) {
    echo json_encode(['success' => false, 'error' => 'Please select who received the order']);
    exit;
}

if (!is_array($items) || empty($items)) {
    echo json_encode(['success' => false, 'error' => 'No items provided']);
    exit;
}

try {
    // Get supplier ID from order
    $supplierStmt = $conn->prepare("SELECT SupplierID FROM orders WHERE OrderID = ?");
    $supplierStmt->bind_param('i', $orderId);
    $supplierStmt->execute();
    $supplierResult = $supplierStmt->get_result();
    $supplierRow = $supplierResult->fetch_assoc();
    $supplierId = $supplierRow['SupplierID'] ?? 0;
    $supplierStmt->close();
    
    if ($supplierId <= 0) {
        throw new Exception('Supplier not found for this order');
    }
    
    $itemsProcessed = 0;
    $allItemsFullyReceived = true;
    $anyItemAccepted = false;
    
    // First, process issues and update ReceivedQuantity for them
    if (is_array($issues) && count($issues) > 0) {
        foreach ($issues as $issue) {
            $supplierItemId = intval($issue['supplier_item_id'] ?? 0);
            $itemName = isset($issue['item_name']) ? $issue['item_name'] : '';
            $quantity = intval($issue['quantity'] ?? 0);
            $condition = isset($issue['condition']) ? $issue['condition'] : '';
            $reason = isset($issue['reason']) ? $issue['reason'] : '';
            $issueExpiryDate = isset($issue['expiry_date']) && !empty($issue['expiry_date']) ? $issue['expiry_date'] : null;
            $orderDetailId = intval($issue['order_detail_id'] ?? 0);
            
            if ($supplierItemId <= 0 || $quantity <= 0 || empty($condition) || empty($reason)) {
                continue;
            }
            
            // Validate expiry date format if provided
            if ($issueExpiryDate && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $issueExpiryDate)) {
                continue; // Skip invalid dates
            }
            
            // Update ReceivedQuantity for the issue quantity (counts as received, not accepted)
            if ($orderDetailId > 0) {
                $updateOrderDetail = $conn->prepare("UPDATE orderdetails SET ReceivedQuantity = COALESCE(ReceivedQuantity, 0) + ? WHERE OrderDetailID = ?");
                $updateOrderDetail->bind_param('ii', $quantity, $orderDetailId);
                $updateOrderDetail->execute();
                $updateOrderDetail->close();
            }
            
            // Get or create item in inventory for reference
            $itemId = 0;
            $location = 'Restaurant';
            $stock = 0;
            
            $stmt = $conn->prepare("SELECT ItemID, Location, Stock FROM items WHERE SupplierItemID = ? LIMIT 1");
            $stmt->bind_param('i', $supplierItemId);
            $stmt->execute();
            $res = $stmt->get_result();
            if ($row = $res->fetch_assoc()) {
                $itemId = $row['ItemID'];
                $location = $row['Location'];
                $stock = $row['Stock'];
            } else {
                // Create item if doesn't exist (but don't add stock)
                $detailsStmt = $conn->prepare("SELECT ItemName, Measurement FROM supplieritems WHERE SupplierItemID = ?");
                $detailsStmt->bind_param('i', $supplierItemId);
                $detailsStmt->execute();
                $detailsResult = $detailsStmt->get_result();
                if ($detailsRow = $detailsResult->fetch_assoc()) {
                    $insertItem = $conn->prepare("INSERT INTO items (SupplierItemID, ItemName, Location, Stock, Measurement, ExpiryDate, Conditions, MinimumStock) VALUES (?, ?, 'Restaurant', 0, ?, ?, 'Out of Stock', 10)");
                    $insertItem->bind_param('isss', $supplierItemId, $detailsRow['ItemName'], $detailsRow['Measurement'], $issueExpiryDate);
                    $insertItem->execute();
                    $itemId = $conn->insert_id;
                    $insertItem->close();
                }
                $detailsStmt->close();
            }
            $stmt->close();
            
            // If item found or created, insert into issues table
            if ($itemId > 0) {
                $insert = $conn->prepare("INSERT INTO issues (ItemID, ItemName, Location, Stock, ExpiryDate, Conditions, Reason, QuantityAffected) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $insert->bind_param('isssissi', $itemId, $itemName, $location, $stock, $issueExpiryDate, $condition, $reason, $quantity);
                if (!$insert->execute()) {
                    error_log("ERROR inserting issue: " . $insert->error);
                    throw new Exception("Failed to save issue: " . $insert->error);
                }
                $insert->close();
            }
        }
    }
    
    foreach ($items as $item) {
        $orderDetailId = intval($item['orderDetailId'] ?? 0);
        $supplierItemId = intval($item['supplierItemId'] ?? 0);
        $acceptQty = intval($item['accept'] ?? 0);
        $orderedQty = intval($item['ordered'] ?? 0);
        $expiryDate = isset($item['expiryDate']) && !empty($item['expiryDate']) ? trim($item['expiryDate']) : null;
        
        // Validate date format (should be YYYY-MM-DD from HTML5 date input)
        if ($expiryDate && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $expiryDate)) {
            throw new Exception('Invalid date format for expiry date: ' . $expiryDate);
        }
        
        if ($orderDetailId <= 0 || $supplierItemId <= 0) continue;
        
        // Update orderdetails with received quantity using OrderDetailID for specific row
        $updateOrderDetail = $conn->prepare("UPDATE orderdetails SET ReceivedQuantity = COALESCE(ReceivedQuantity, 0) + ? WHERE OrderDetailID = ?");
        $updateOrderDetail->bind_param('ii', $acceptQty, $orderDetailId);
        $updateOrderDetail->execute();
        $updateOrderDetail->close();
        
        // Check total received vs ordered for this specific row
        $checkReceived = $conn->prepare("SELECT Quantity, COALESCE(ReceivedQuantity, 0) as Received FROM orderdetails WHERE OrderDetailID = ?");
        $checkReceived->bind_param('i', $orderDetailId);
        $checkReceived->execute();
        $recResult = $checkReceived->get_result();
        if ($recRow = $recResult->fetch_assoc()) {
            if ($recRow['Received'] < $recRow['Quantity']) {
                $allItemsFullyReceived = false;
            }
        }
        $checkReceived->close();
        
        // Track if any items were accepted
        if ($acceptQty > 0) {
            $anyItemAccepted = true;
            
            // Get item details from supplieritems including Measurement
            $detailsStmt = $conn->prepare("SELECT ItemName, Measurement FROM supplieritems WHERE SupplierItemID = ?");
            $detailsStmt->bind_param('i', $supplierItemId);
            $detailsStmt->execute();
            $detailsResult = $detailsStmt->get_result();
            if (!$detailsRow = $detailsResult->fetch_assoc()) {
                $detailsStmt->close();
                throw new Exception('Supplier item not found: ' . $supplierItemId);
            }
            $itemName = $detailsRow['ItemName'];
            $measurement = $detailsRow['Measurement'];
            $detailsStmt->close();
            
            // Check if item exists in inventory
            $checkStmt = $conn->prepare("SELECT ItemID, Stock FROM items WHERE SupplierItemID = ? LIMIT 1");
            $checkStmt->bind_param('i', $supplierItemId);
            $checkStmt->execute();
            $checkResult = $checkStmt->get_result();
            
            if ($checkRow = $checkResult->fetch_assoc()) {
                // Update existing item
                $itemId = $checkRow['ItemID'];
                $newStock = $checkRow['Stock'] + $acceptQty;
                
                if ($expiryDate) {
                    $updateStmt = $conn->prepare("UPDATE items SET Stock = ?, ExpiryDate = ? WHERE ItemID = ?");
                    $updateStmt->bind_param('isi', $newStock, $expiryDate, $itemId);
                } else {
                    $updateStmt = $conn->prepare("UPDATE items SET Stock = ? WHERE ItemID = ?");
                    $updateStmt->bind_param('ii', $newStock, $itemId);
                }
                $updateStmt->execute();
                $updateStmt->close();
                
                // Update condition based on stock level
                if ($newStock > 0 && $newStock <= 20) {
                    $condStmt = $conn->prepare("UPDATE items SET Conditions = 'Low Stock' WHERE ItemID = ?");
                } else if ($newStock > 20) {
                    $condStmt = $conn->prepare("UPDATE items SET Conditions = 'Good' WHERE ItemID = ?");
                } else {
                    $condStmt = $conn->prepare("UPDATE items SET Conditions = 'Out of Stock' WHERE ItemID = ?");
                }
                $condStmt->bind_param('i', $itemId);
                $condStmt->execute();
                $condStmt->close();
            } else {
                // Insert new item - ALL columns must be provided
                $insertStmt = $conn->prepare("INSERT INTO items (SupplierItemID, ItemName, Location, Stock, Measurement, ExpiryDate, Conditions, MinimumStock) VALUES (?, ?, 'Restaurant', ?, ?, ?, 'Good', 10)");
                $insertStmt->bind_param('isiss', $supplierItemId, $itemName, $acceptQty, $measurement, $expiryDate);
                $insertStmt->execute();
                $itemId = $conn->insert_id;
                $insertStmt->close();
                
                // Update condition if low stock
                if ($acceptQty > 0 && $acceptQty <= 20) {
                    $condStmt = $conn->prepare("UPDATE items SET Conditions = 'Low Stock' WHERE ItemID = ?");
                    $condStmt->bind_param('i', $itemId);
                    $condStmt->execute();
                    $condStmt->close();
                }
            }
            $checkStmt->close();
            
            // Log transaction
            $transStmt = $conn->prepare("INSERT INTO transactions (ItemID, Type, Quantity, UserID, SupplierID, DateTime) VALUES (?, 'Added Stock', ?, ?, ?, NOW())");
            $transStmt->bind_param('iiii', $itemId, $acceptQty, $receivedBy, $supplierId);
            $transStmt->execute();
            $transStmt->close();
            
            $itemsProcessed++;
        }
    }
    
    // Determine order status by checking ALL orderdetails rows
    $checkAllStmt = $conn->prepare("SELECT COUNT(*) as total, SUM(CASE WHEN COALESCE(ReceivedQuantity, 0) >= Quantity THEN 1 ELSE 0 END) as complete FROM orderdetails WHERE OrderID = ?");
    $checkAllStmt->bind_param('i', $orderId);
    $checkAllStmt->execute();
    $checkResult = $checkAllStmt->get_result();
    $checkRow = $checkResult->fetch_assoc();
    $checkAllStmt->close();
    
    $totalItems = $checkRow['total'];
    $completeItems = $checkRow['complete'];
    
    if ($completeItems >= $totalItems && $totalItems > 0) {
        $status = 'Received';
        $message = "Order fully received! All items processed.";
    } else if ($anyItemAccepted || $completeItems > 0) {
        $status = 'Partially Received';
        $message = "Order partially received. $itemsProcessed item(s) processed in this batch.";
    } else {
        $status = 'Pending Approval';
        $message = "No items were accepted.";
    }
    
    $statusStmt = $conn->prepare("UPDATE orders SET Status = ? WHERE OrderID = ?");
    $statusStmt->bind_param('si', $status, $orderId);
    $statusStmt->execute();
    $statusStmt->close();
    
    echo json_encode([
        'success' => true,
        'message' => $message,
        'status' => $status
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>
