<!-- View Order Details Modal -->
<div id="viewOrderModal" class="modal">
  <div class="order-dialog">
    <div class="modal-header">
      <span class="close" onclick="closeViewOrderModal()">&times;</span>
    </div>
    
    <div class="title-group">
      <h2 id="view_order_title" class="dialog-title">Order Details</h2>
      <p id="view_order_info" class="dialog-desc">From Supplier on Date</p>
    </div>
    
    <div class="order-table-wrapper">
      <table class="order-table">
        <thead>
          <tr>
            <th>Item</th>
            <th>Unit</th>
            <th>Ordered</th>
            <th>Received</th>
          </tr>
        </thead>
        <tbody id="view_order_items_body">
          <!-- Items will be loaded here -->
        </tbody>
      </table>
    </div>
  </div>
</div>
<!-- Create New Order Modal -->
<div id="createOrderModal" class="modal">
  <div class="order-dialog">
    <div class="modal-header" style="justify-content: space-between; align-items:center;">
      <h2 class="dialog-title" style="margin:0;">Create New Order</h2>
      <span class="close" onclick="closeCreateOrderModal()">&times;</span>
    </div>

    <div class="title-group" style="margin-top:8px; margin-bottom:16px;">
      <p class="dialog-desc">Select a supplier and add items to order.</p>
    </div>

    <div class="form-group">
      <label for="order_supplier_select" class="dialog-desc" style="display:block; margin-bottom:6px; color:#374151;">Supplier</label>
      <select id="order_supplier_select" class="input-select" style="width:100%;" onchange="onSupplierChanged()">
        <option value="">Select a supplier</option>
      </select>
    </div>

    <div class="form-group" style="margin-top:16px;">
      <label class="dialog-desc" style="display:block; margin-bottom:6px; color:#374151;">Items</label>
      <div id="order_items_container"></div>
      <button class="white-btn" type="button" style="margin-top:10px;" onclick="addOrderItemRow()">Add Item</button>
    </div>

    <div class="actions-row">
      <button class="white-btn" type="button" onclick="closeCreateOrderModal()">Cancel</button>
      <button class="blue_design" id="create_order_btn" type="button" onclick="submitNewOrder()" disabled>Create Order</button>
    </div>
  </div>
</div>

<!-- Receive Order Modal -->
<div id="receiveOrderModal" class="modal" style="display:none;">
  <div class="order-dialog" style="max-width: 900px; width: 90%;">
    <div class="modal-header">
      <span class="close" onclick="closeReceiveOrderModal()">&times;</span>
    </div>
    
    <div class="title-group">
      <h2 id="receive_order_title" class="dialog-title">Receive Order</h2>
    </div>

    <div class="form-group">
      <label class="dialog-desc" style="display: block; margin-bottom: 8px; color: #374151; font-weight: 500;">Received By</label>
      <select id="received_by_select" class="input-select" required style="width: 100%;">
        <option value="">-- Select User --</option>
        <?php
        // Build connection if needed
        if (!isset($conn) || !$conn || $conn->connect_errno) {
          require_once __DIR__ . '/../../login/database-account.php';
        }
        
        // Get current user info
        $currentUserID = $_SESSION['UserID'] ?? '';
        $currentUserRole = strtolower($_SESSION['Role'] ?? $_SESSION['roles'] ?? '');
        $isStaff = ($currentUserRole === 'staff');
        
        // Fetch users, excluding inactive ones if a Status column exists
        $hasStatus = false;
        $chk = $conn->query("SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME='users' AND COLUMN_NAME='Status'");
        if ($chk && $chk->num_rows > 0) {
          $hasStatus = true;
        }

        $sql = "SELECT UserID, Name, Role FROM users WHERE 1=1";
        if ($hasStatus) {
          $sql .= " AND (Status = 'Active' OR Status IS NULL)";
        }
        $sql .= " ORDER BY Name ASC";

        $usersResult = $conn->query($sql);
        if ($usersResult && $usersResult->num_rows > 0) {
          while ($userRow = $usersResult->fetch_assoc()) {
            $userId = $userRow['UserID'];
            $userName = $userRow['Name'];
            $userRole = $userRow['Role'] ?? '';
            
            // If staff, only show and pre-select their own account
            if ($isStaff && $userId != $currentUserID) continue;
            
            $selected = ($isStaff && $userId == $currentUserID) ? ' selected' : '';
            echo '<option value="' . $userId . '"' . $selected . '>' . htmlspecialchars($userName);
            if ($userRole) echo ' (' . htmlspecialchars($userRole) . ')';
            echo '</option>';
          }
        }
        ?>
      </select>
      <?php if ($isStaff): ?>
      <script>
        // Disable the dropdown for staff users
        document.addEventListener('DOMContentLoaded', function() {
          const selectEl = document.getElementById('received_by_select');
          if (selectEl) selectEl.disabled = true;
        });
      </script>
      <?php endif; ?>
    </div>

    <div class="order-table-wrapper" style="margin-top: 24px;">
      <table class="order-table">
        <thead>
          <tr>
            <th>Item</th>
            <th>Measurement</th>
            <th>Ordered</th>
            <th>Accept</th>
            <th>Expiry Date</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody id="receive_order_items_body">
          <!-- Items populated by JavaScript -->
        </tbody>
      </table>
    </div>

    <div class="actions-row" style="margin-top: 32px;">
      <button type="button" class="white-btn" onclick="closeReceiveOrderModal()">Cancel</button>
      <button type="button" class="blue_design" id="confirm_delivery_btn" onclick="confirmDelivery()">Confirm Delivery</button>
    </div>
  </div>
</div>

<!-- Report Issue Modal (for individual items) -->
<div id="reportIssueModal" class="modal" style="display:none;">
  <div class="order-dialog" style="max-width: 500px; width: 90%;">
    <div style="display: flex; justify-content: space-between; align-items: center; padding-bottom: 16px; border-bottom: 1px solid #e5e7eb;">
      <h2 style="margin: 0; font-size: 18px; font-weight: 600; color: #111827;" id="report_issue_title">Report Issue for Sugar</h2>
      <span class="close" onclick="closeReportIssueModal()" style="cursor: pointer; font-size: 28px; color: #6b7280;">&times;</span>
    </div>


    <div style="margin-top: 24px;">
      <label style="display: block; font-size: 14px; font-weight: 500; color: #374151; margin-bottom: 8px;">Quantity to Return</label>
      <input type="number" id="return_quantity" min="1" value="1" style="width: 100%; padding: 10px 12px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 14px;">
    </div>

    <div style="margin-top: 20px;">
      <label style="display: block; font-size: 14px; font-weight: 500; color: #374151; margin-bottom: 8px;">Condition</label>
      <select id="return_condition" style="width: 100%; padding: 10px 12px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 14px;">
        <option value="Damaged">Damaged</option>
        <option value="Expired">Expired</option>
        <option value="Out of Stock">Out of Stock</option>
      </select>
    </div>

    <div style="margin-top: 20px;">
      <label style="display: block; font-size: 14px; font-weight: 500; color: #374151; margin-bottom: 8px;">Description</label>
      <textarea id="return_reason" placeholder="Describe the issue..." style="width: 100%; padding: 10px 12px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 14px; min-height: 80px; resize: vertical;"></textarea>
    </div>

    <div style="margin-top: 32px; display: flex; justify-content: flex-end; gap: 12px; padding-top: 16px; border-top: 1px solid #e5e7eb;">
      <button type="button" onclick="closeReportIssueModal()" style="padding: 10px 24px; background: white; border: 1px solid #d1d5db; border-radius: 6px; font-size: 14px; font-weight: 500; color: #374151; cursor: pointer;">Cancel</button>
      <button type="button" onclick="submitIssueReport()" style="padding: 10px 24px; background: #3b82f6; border: none; border-radius: 6px; font-size: 14px; font-weight: 500; color: white; cursor: pointer;">Submit Report</button>
    </div>
  </div>
</div>
