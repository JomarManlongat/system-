<?php
// Minimal, robust order details fetcher
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_name('INVENTORY_SESSION');
session_start();
require __DIR__ . '/../../login/database-account.php';

header('Content-Type: application/json; charset=utf-8');

if (!$conn) {
  http_response_code(500);
  echo json_encode(['success' => false, 'error' => 'Database connection error']);
  exit;
}

$orderId = isset($_POST['order_id']) ? intval($_POST['order_id']) : (isset($_GET['order_id']) ? intval($_GET['order_id']) : 0);
$viewMode = isset($_POST['view_mode']) ? $_POST['view_mode'] : 'view'; // 'view' or 'receive'

if ($orderId <= 0) {
  echo json_encode(['success' => false, 'error' => 'Invalid order ID']);
  exit;
}

// Get order header info
$sql = "SELECT o.OrderID, s.SupplierName, o.OrderDate, o.Status
        FROM orders o
        JOIN suppliers s ON s.SupplierID = o.SupplierID
        WHERE o.OrderID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $orderId);
$stmt->execute();
$result = $stmt->get_result();
$order = $result->fetch_assoc();
$stmt->close();

if (!$order) {
  echo json_encode(['success' => false, 'error' => 'Order not found']);
  exit;
}

// Get order items with remaining quantities (ordered - already received)
$sql = "SELECT od.OrderDetailID, si.ItemName, si.Measurement, od.Quantity, od.SupplierItemID, od.ReceivedQuantity
        FROM orderdetails od
        LEFT JOIN supplieritems si ON si.SupplierItemID = od.SupplierItemID
        WHERE od.OrderID = ?
        ORDER BY si.ItemName";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $orderId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
  echo json_encode([
    'success' => false,
    'error' => 'No items found for this order. (orderdetails rows missing or SupplierItemID mismatch)'
  ]);
  exit;
}

$items = [];
while ($row = $result->fetch_assoc()) {
  $ordered = (int)$row['Quantity'];
  $received = (int)($row['ReceivedQuantity'] ?? 0);
  $remaining = $ordered - $received;
  
  // For 'view' mode, show all items. For 'receive' mode, only show items with remaining quantity
  if ($viewMode === 'view' || $remaining > 0) {
    $items[] = [
      'order_detail_id' => (int)$row['OrderDetailID'], // Track specific row
      'item' => $row['ItemName'],
      'item_name' => $row['ItemName'],
      'supplier_item_id' => (int)$row['SupplierItemID'],
      'unit' => $row['Measurement'],
      'ordered' => $viewMode === 'view' ? $ordered : $remaining, // Show full qty for view, remaining for receive
      'quantity' => $viewMode === 'view' ? $ordered : $remaining,
      'received' => $received,
      'total_ordered' => $ordered,
      'remaining' => $remaining
    ];
  }
}
$stmt->close();
$conn->close();

$dateObj = new DateTime($order['OrderDate']);
$formattedDate = $dateObj->format('n/j/Y');

echo json_encode([
  'success' => true,
  'order' => [
    'id' => 'ORD' . str_pad($order['OrderID'], 3, '0', STR_PAD_LEFT),
    'supplier' => $order['SupplierName'],
    'date' => $formattedDate,
    'status' => $order['Status'],
    'items' => $items
  ],
  'items' => $items
]);
