<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
session_name('INVENTORY_SESSION');
session_start();
require __DIR__ . '/../../login/database-account.php';
header('Content-Type: application/json; charset=utf-8');

if (!$conn) { echo json_encode(['success'=>false,'error'=>'DB']); exit; }

$supplierId = isset($_POST['supplier_id']) ? intval($_POST['supplier_id']) : 0;
$itemsJson  = $_POST['items'] ?? '[]';
$items = json_decode($itemsJson, true);
if (!is_array($items)) $items = [];

if ($supplierId <= 0 || count($items) === 0) {
  echo json_encode(['success'=>false,'error'=>'Missing supplier or items']);
  exit;
}

$conn->begin_transaction();
try {
  // Insert order header
  $status = 'Pending Approval';
  $today  = date('Y-m-d');
  $stmt = $conn->prepare("INSERT INTO orders (SupplierID, OrderDate, Status) VALUES (?, ?, ?)");
  $stmt->bind_param('iss', $supplierId, $today, $status);
  if (!$stmt->execute()) throw new Exception('Insert order failed');
  $orderId = $stmt->insert_id;
  $stmt->close();

  // Insert details
  $stmtD = $conn->prepare("INSERT INTO orderdetails (OrderID, SupplierItemID, Quantity, Status) VALUES (?, ?, ?, ?)");
  foreach ($items as $it) {
    $sid = intval($it['supplier_item_id'] ?? 0);
    $qty = intval($it['quantity'] ?? 0);
    if ($sid <= 0 || $qty <= 0) continue;
    $dStatus = 'Pending Approval';
    $stmtD->bind_param('iiis', $orderId, $sid, $qty, $dStatus);
    if (!$stmtD->execute()) throw new Exception('Insert detail failed');
  }
  $stmtD->close();

  $conn->commit();
  echo json_encode(['success'=>true,'order_id'=>$orderId]);
} catch (Exception $e) {
  $conn->rollback();
  echo json_encode(['success'=>false,'error'=>$e->getMessage()]);
}

$conn->close();
