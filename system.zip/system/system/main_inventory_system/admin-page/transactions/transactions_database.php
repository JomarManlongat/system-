<?php
require __DIR__ . '/../../login/database-account.php';
header('Content-Type: text/html; charset=utf-8');

$search = isset($_POST['search']) ? trim($_POST['search']) : '';
$top = isset($_POST['top']) ? intval($_POST['top']) : 500;
if ($top <= 0) $top = 500;
$location = isset($_POST['location']) ? trim($_POST['location']) : 'All';
// Date range and transaction type
$dateFrom = isset($_POST['date_from']) ? trim($_POST['date_from']) : '';
$dateTo   = isset($_POST['date_to']) ? trim($_POST['date_to']) : '';
$transType = isset($_POST['transaction_type']) ? trim($_POST['transaction_type']) : '';

// Helper for escaping HTML
function esc($v){ return htmlspecialchars((string)$v ?? '', ENT_QUOTES, 'UTF-8'); }
function fmt_dt($d){ $t=strtotime($d); return $t ? date('n/j/Y, g:i:s A', $t) : esc($d); }
function type_badge($t){
  // Normalize to elegant labels used in UI
  $tt = strtolower(trim((string)$t));
  $label = (strpos($tt,'add') !== false) ? 'Added Stock'
         : ((strpos($tt,'usage') !== false || strpos($tt,'use') !== false) ? 'Usage Stock'
         : (($tt === 'stock added') ? 'Added Stock' : ucfirst(trim((string)$t))));
  $isAdd = ($label === 'Added Stock');
  return $isAdd
    ? '<span style="display:inline-block;background:#16a34a;color:#fff;padding:6px 10px;border-radius:14px;font-weight:600;font-size:12px;">'.$label.'</span>'
    : '<span style="display:inline-block;background:#e5e7eb;color:#111;padding:6px 10px;border-radius:14px;font-weight:600;font-size:12px;">'.$label.'</span>';
}

$rows = [];

// Prefer your dedicated `transactions` table if present
$hasTransactions = $conn->query("SHOW TABLES LIKE 'transactions'");
if ($hasTransactions && $hasTransactions->num_rows > 0) {
  // Detect which datetime column exists in `transactions`
  $txnDateCol = 'DateTime';
  $chkTxnDate = $conn->query("SHOW COLUMNS FROM transactions LIKE 'TransactionDate'");
  if ($chkTxnDate && $chkTxnDate->num_rows > 0) { $txnDateCol = 'TransactionDate'; }

  $sql = "SELECT t.TransactionID, t.ItemID, t.Quantity, t.Type, t.UserID,
       t.".$txnDateCol." AS TxnDate,
       si.ItemName, sup.SupplierName AS SupplierName, sup.Location as SupplierLocation, u.Name AS UserName
          FROM transactions t
          LEFT JOIN items i ON i.ItemID = t.ItemID
          LEFT JOIN supplieritems si ON i.SupplierItemID = si.SupplierItemID
      LEFT JOIN suppliers sup ON si.SupplierID = sup.SupplierID
     LEFT JOIN users u ON u.UserID = t.UserID";
  $params = [];$types='';
  $whereClauses = [];
  
  if ($search !== '') {
    $whereClauses[] = "(t.TransactionID LIKE ? OR t.ItemID LIKE ? OR si.ItemName LIKE ? OR t.Type LIKE ? OR t.UserID LIKE ? OR sup.SupplierName LIKE ? OR u.Name LIKE ?)";
    $like = "%$search%"; $params = array_merge($params, [$like,$like,$like,$like,$like,$like,$like]); $types .= 'sssssss';
  }
  
  if ($location !== 'All') {
    $whereClauses[] = "sup.Location = ?";
    $params[] = $location;
    $types .= 's';
  }
  // Date range (inclusive) uses detected column
  if ($dateFrom !== '') {
    $whereClauses[] = "t.".$txnDateCol." >= ?";
    $params[] = $dateFrom . ' 00:00:00';
    $types .= 's';
  }
  if ($dateTo !== '') {
    $whereClauses[] = "t.".$txnDateCol." <= ?";
    $params[] = $dateTo . ' 23:59:59';
    $types .= 's';
  }
  // Transaction type filter (tolerant to synonyms)
  if ($transType !== '' && strtolower($transType) !== 'all') {
    $needle = strtolower($transType);
    if (strpos($needle, 'stock') !== false || strpos($needle, 'add') !== false) {
      $whereClauses[] = "LOWER(t.Type) LIKE ?";
      $params[] = '%add%';
      $types .= 's';
    } else if (strpos($needle, 'usage') !== false || strpos($needle, 'use') !== false) {
      $whereClauses[] = "LOWER(t.Type) LIKE ?";
      $params[] = '%usage%';
      $types .= 's';
    } else {
      $whereClauses[] = "t.Type = ?";
      $params[] = $transType;
      $types .= 's';
    }
  }
  
  if (!empty($whereClauses)) {
    $sql .= " WHERE " . implode(" AND ", $whereClauses);
  }
  
  $sql .= " ORDER BY TxnDate DESC LIMIT " . $top;
  $stmt = $conn->prepare($sql);
  if ($params) $stmt->bind_param($types, ...$params);
  $stmt->execute(); $res = $stmt->get_result();
  while($r = $res->fetch_assoc()){
    $typeLabel = (string)($r['Type'] ?? '');
    $rows[] = [
      'trans_id' => $r['TransactionID'],
      'item_id'  => $r['ItemID'] ?? '-',
      'item_name'=> $r['ItemName'] ?: '-',
      'qty'      => (int)($r['Quantity'] ?? 0),
      'type'     => $typeLabel,
      'user'     => ($r['UserName'] ?: ($r['UserID'] ?: '-')),
      'supplier' => $r['SupplierName'] ?: 'N/A',
      'location' => $r['SupplierLocation'] ?: 'N/A',
      'dt'       => $r['TxnDate']
    ];
  }
} else {
  // Fallback: derive from usage + orders if `transactions` table not present
  // 1) Usage transactions if table exists
  $hasUsage = $conn->query("SHOW TABLES LIKE 'item_usage'");
  if ($hasUsage && $hasUsage->num_rows > 0) {
  $sqlU = "SELECT iu.UsageID, i.ItemID, si.ItemName, iu.Quantity, iu.UserID, u.Name AS UserName, COALESCE(s.SupplierName,'N/A') AS SupplierName, iu.CreatedAt
             FROM item_usage iu
             JOIN items i ON i.ItemID = iu.ItemID
             LEFT JOIN supplieritems si ON i.SupplierItemID = si.SupplierItemID
       LEFT JOIN suppliers s ON si.SupplierID = s.SupplierID
       LEFT JOIN users u ON u.UserID = iu.UserID";
    $params = [];$types='';
    if ($search !== '') {
      $sqlU .= " WHERE (i.ItemID LIKE ? OR si.ItemName LIKE ? OR iu.UserID LIKE ? OR s.SupplierName LIKE ? OR u.Name LIKE ?)";
      $like = "%$search%"; $params = [$like,$like,$like,$like,$like]; $types = 'sssss';
    }
    $sqlU .= " ORDER BY iu.CreatedAt DESC LIMIT 300";
    $stmt = $conn->prepare($sqlU);
    if ($params) $stmt->bind_param($types, ...$params);
    $stmt->execute(); $res = $stmt->get_result();
    while($r = $res->fetch_assoc()){
      $rows[] = [
        'trans_id' => 'USG' . str_pad((string)$r['UsageID'], 3, '0', STR_PAD_LEFT),
        'item_id'  => $r['ItemID'],
        'item_name'=> $r['ItemName'] ?: '-',
        'qty'      => (int)$r['Quantity'],
        'type'     => 'Usage Stock',
        'user'     => ($r['UserName'] ?: ($r['UserID'] ?: '-')),
        'supplier' => $r['SupplierName'] ?: 'N/A',
        'dt'       => $r['CreatedAt']
      ];
    }
  }

  // 2) Stock added from orders -> orderdetails
  $sqlO = "SELECT o.OrderID, i.ItemID, si.ItemName, od.Quantity, COALESCE(s.SupplierName,'N/A') AS SupplierName, o.OrderDate, o.Status
           FROM orders o
           JOIN orderdetails od ON od.OrderID = o.OrderID
           JOIN supplieritems si ON si.SupplierItemID = od.SupplierItemID
           LEFT JOIN items i ON i.SupplierItemID = si.SupplierItemID
           JOIN suppliers s ON s.SupplierID = si.SupplierID";

  $paramsO = [];$typesO='';
  $statuses = [ 'Approved','Shipped','In Transit','Received','Completed' ];
  $sqlO .= " WHERE o.Status IN (" . implode(',', array_fill(0, count($statuses), '?')) . ")";
  $typesO .= str_repeat('s', count($statuses));
  $paramsO = array_merge($paramsO, $statuses);

  if ($search !== '') {
    $sqlO .= " AND (i.ItemID LIKE ? OR si.ItemName LIKE ? OR s.SupplierName LIKE ? OR o.OrderID LIKE ?)";
    $like = "%$search%"; $paramsO = array_merge($paramsO, [$like,$like,$like,$like]); $typesO .= 'ssss';
  }
  // Date range for derived 'Added Stock' via orders
  if ($dateFrom !== '') {
    $sqlO .= " AND o.OrderDate >= ?";
    $paramsO[] = $dateFrom . ' 00:00:00';
    $typesO .= 's';
  }
  if ($dateTo !== '') {
    $sqlO .= " AND o.OrderDate <= ?";
    $paramsO[] = $dateTo . ' 23:59:59';
    $typesO .= 's';
  }
  $sqlO .= " ORDER BY o.OrderDate DESC LIMIT 300";

  $stmtO = $conn->prepare($sqlO);
  if ($paramsO) $stmtO->bind_param($typesO, ...$paramsO);
  $stmtO->execute(); $resO = $stmtO->get_result();
  while($r = $resO->fetch_assoc()){
    $rows[] = [
      'trans_id' => 'ORD' . str_pad((string)$r['OrderID'], 3, '0', STR_PAD_LEFT),
      'item_id'  => $r['ItemID'] ?: '-',
      'item_name'=> $r['ItemName'] ?: '-',
      'qty'      => (int)$r['Quantity'],
      'type'     => 'Added Stock',
      'user'     => '-',
      'supplier' => $r['SupplierName'] ?: 'N/A',
      'dt'       => $r['OrderDate']
    ];
  }

  // Sort derived rows by date desc
  usort($rows, function($a,$b){ return strtotime($b['dt']) <=> strtotime($a['dt']); });
}

// Apply post-filters for date range and transaction type (covers both main and fallback paths)
if ($dateFrom !== '' || $dateTo !== '' || ($transType !== '' && strtolower($transType) !== 'all')) {
  $rows = array_values(array_filter($rows, function($r) use ($dateFrom, $dateTo, $transType){
    $ok = true;
    $ts = strtotime((string)($r['dt'] ?? ''));
    if ($dateFrom !== '') {
      $fromTs = strtotime($dateFrom . ' 00:00:00');
      if ($ts === false || $ts < $fromTs) $ok = false;
    }
    if ($ok && $dateTo !== '') {
      $toTs = strtotime($dateTo . ' 23:59:59');
      if ($ts === false || $ts > $toTs) $ok = false;
    }
    if ($ok && $transType !== '' && strtolower($transType) !== 'all') {
      $t = strtolower((string)($r['type'] ?? ''));
      if (strpos($t, strtolower($transType)) === false) {
        // try loose match: 'add' vs 'added', 'usage' vs 'recorded'
        if ($transType === 'Stock Added' && strpos($t, 'add') === false) $ok = false;
        if ($transType === 'Usage Recorded' && strpos($t, 'usage') === false) $ok = false;
      }
    }
    return $ok;
  }));
}

if (empty($rows)) {
  echo '<tr><td colspan="7" style="text-align:center;color:#666;padding:16px">No transactions found.</td></tr>';
  exit;
}

// Helper to clamp cell content to two lines for readability
function clamp2($s){ return '<div class="clamp-2">'.$s.'</div>'; }

foreach($rows as $row){
  // Normalize and render badge
  $badge = type_badge($row['type']);

  echo '<tr>';
  echo '<td>'.clamp2(esc($row['trans_id'])).'</td>';
  echo '<td>'.clamp2(esc($row['item_id'])).'</td>';
  echo '<td>'.clamp2(esc($row['item_name'])).'</td>';
  echo '<td>'.clamp2(esc($row['qty'])).'</td>';
  echo '<td>'.$badge.'</td>';
  echo '<td>'.clamp2(esc($row['user'])).'</td>';
  echo '<td>'.clamp2(esc(fmt_dt($row['dt']))).'</td>';
  echo '</tr>';
}
