﻿// Custom notification system to replace browser alerts
window.showNotification = function(message, type = 'info') {
  const notif = document.createElement('div');
  notif.textContent = message;
  notif.style.cssText = `
    position: fixed;
    top: 20px;
    left: 50%;
    transform: translateX(-50%);
    background: ${type === 'error' ? '#ef4444' : type === 'success' ? '#22c55e' : '#3b82f6'};
    color: white;
    padding: 16px 32px;
    border-radius: 8px;
    font-size: 15px;
    font-weight: 500;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    z-index: 10001;
    max-width: 500px;
    animation: slideDown 0.3s ease-out;
  `;
  
  const style = document.createElement('style');
  style.textContent = `
    @keyframes slideDown {
      from { opacity: 0; transform: translate(-50%, -20px); }
      to { opacity: 1; transform: translate(-50%, 0); }
    }
  `;
  document.head.appendChild(style);
  document.body.appendChild(notif);
  
  setTimeout(() => {
    notif.style.animation = 'slideDown 0.3s ease-out reverse';
    setTimeout(() => {
      notif.remove();
      style.remove();
    }, 300);
  }, 3000);
};

document.addEventListener("DOMContentLoaded", () => {
  const unwantedElements = document.querySelectorAll('h1');
  unwantedElements.forEach(el => {
    if (el.textContent.includes('CONTENT AREA IS HERE')) el.remove();
  });

  const links = document.querySelectorAll("[data-page]");
  const pages = document.querySelectorAll(".page");

  function showPage(pageId) {
    pages.forEach(p => p.classList.remove("active-page"));
    document.getElementById(pageId).classList.add("active-page");
    links.forEach(link => link.classList.remove("active"));
    const activeLink = document.querySelector(`[data-page="${pageId}"]`);
    if (activeLink) activeLink.classList.add("active");

    if (pageId === 'transactions') {
      if (typeof loadTransactionsTable === 'function') loadTransactionsTable();
    } else if (pageId === 'issues') {
      if (typeof loadIssuesTable === 'function') loadIssuesTable();
    } else if (pageId === 'alerts') {
      if (typeof loadAlertsTable === 'function') loadAlertsTable();
    } else if (pageId === 'orders') {
      if (typeof reloadOrders === 'function') reloadOrders();
    }
  }

  links.forEach(link => {
    link.addEventListener("click", (e) => {
      e.preventDefault();
      showPage(link.getAttribute("data-page"));
    });
  });

  // Default to dashboard if it exists, otherwise inventory (for staff)
  if (document.getElementById("dashboard")) {
    showPage("dashboard");
  } else {
    showPage("inventory");
  }

  // === DASHBOARD BOX CLICK HANDLERS ===
  const totalItemsBox = document.getElementById('total-items');
  if (totalItemsBox) {
    totalItemsBox.addEventListener('click', (e) => {
      e.preventDefault();
      showPage('inventory');
    });
  }

  const lowStockAlertsBox = document.getElementById('low-stocks-alerts');
  if (lowStockAlertsBox) {
    lowStockAlertsBox.addEventListener('click', (e) => {
      e.preventDefault();
      // Navigate to alerts page and set filter to Low Stock
      const alertsTypeFilter = document.getElementById('alerts_type_filter');
      if (alertsTypeFilter) {
        alertsTypeFilter.value = 'Low Stock';
      }
      showPage('alerts');
    });
  }

  const expiredItemsBox = document.getElementById('expired-items');
  if (expiredItemsBox) {
    expiredItemsBox.addEventListener('click', (e) => {
      e.preventDefault();
      // Navigate to issues page where expired items are tracked
      showPage('issues');
    });
  }

  // === LOGOUT FUNCTIONALITY ===
  const logoutBtn = document.getElementById('logout_btn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', (e) => {
      e.preventDefault();
      // Redirect to login page
      window.location.href = '../login/index.php';
    });
  }

  // Back to Restaurant button (if present) - same-tab navigation
  const backToRestaurantBtn = document.getElementById('backToRestaurantBtn');
  if (backToRestaurantBtn) {
    backToRestaurantBtn.addEventListener('click', function(e) {
      e.preventDefault();
      window.location.href = '../../HotelLuneraRestaurant/admin/admin.php';
    });
  }

  // === REPORTS PAGE ===
  // Helper to resolve API URLs correctly for admin vs staff page contexts
  function getAdminUrl(path) {
    try {
      const p = window.location.pathname.replace(/\\+/g, '/');
      return p.includes('/staff-page/') ? ('../admin-page/' + path) : path;
    } catch (_) {
      return path;
    }
  }
  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  window.loadReportsTable = function() {
    const reportType = document.getElementById('report_type')?.value || 'transactions';
    const tbody = document.getElementById('reports_table_body');
    const thead = document.getElementById('reports_table_head');
    const titleEl = document.getElementById('reports_table_title');
    
    if (!tbody) return;

    // Show/hide dynamic filters based on report type
    const dateRangeFilter = document.getElementById('date_range_filter');
    const locationFilter = document.getElementById('location_filter_wrapper');
    const transactionTypeFilter = document.getElementById('transaction_type_filter');

    // Hide all dynamic filters first
    if (dateRangeFilter) dateRangeFilter.style.display = 'none';
    if (locationFilter) locationFilter.style.display = 'none';
    if (transactionTypeFilter) transactionTypeFilter.style.display = 'none';

    // Show relevant filters based on report type
    if (reportType === 'transactions') {
      if (dateRangeFilter) dateRangeFilter.style.display = 'block';
      if (transactionTypeFilter) transactionTypeFilter.style.display = 'block';
    } else if (reportType === 'inventory') {
      if (locationFilter) locationFilter.style.display = 'block';
    } else if (reportType === 'orders') {
      if (dateRangeFilter) dateRangeFilter.style.display = 'block';
    } else if (reportType === 'issues') {
      if (locationFilter) locationFilter.style.display = 'block';
    }

    // Update title
    const titles = {
      'transactions': 'Transactions',
      'inventory': 'Inventory Stock',
      'orders': 'Purchase Orders',
      'issues': 'Issues (Damaged/Expired)',
      'suppliers': 'Suppliers List',
      'users': 'Users List',
      'alerts': 'Alerts'
    };
    if (titleEl) titleEl.textContent = titles[reportType] || 'Report';

    // Update headers based on type
    const headers = {
      'transactions': ['Trans ID', 'Item ID', 'Item', 'Qty', 'Type', 'User', 'Supplier', 'Location', 'Date/Time'],
      'inventory': ['Item ID', 'Item Name', 'Stock', 'Supplier', 'Location', 'Expiry Date', 'Condition', 'Actions'],
      'orders': ['Order ID', 'Supplier', 'Location', 'Items', 'Total', 'Status', 'Date', 'Actions'],
      'issues': ['Item ID', 'Item Name', 'Location', 'Stock', 'Expiry Date', 'Condition', 'Actions'],
      'suppliers': ['Supplier ID', 'Name', 'Contact', 'Phone', 'Email', 'Location'],
      'users': ['User ID', 'Username', 'Role', 'Name'],
      'alerts': ['Alert ID', 'Type', 'Item', 'Message', 'Date', 'Status']
    };
    if (thead && headers[reportType]) {
      thead.innerHTML = '<tr>' + headers[reportType].map(h => `<th>${h}</th>`).join('') + '</tr>';
    }

  // Get filter values
  const searchVal = document.getElementById('report_search')?.value || '';
  const topVal = document.getElementById('show_top')?.value || '';
  const generalLocation = document.getElementById('general_location_filter')?.value || 'All';
  const dateFrom = document.getElementById('date_from')?.value || '';
  const dateTo = document.getElementById('date_to')?.value || '';
  const transType = document.getElementById('transaction_type')?.value || 'all';

    // Call the appropriate existing function and redirect output to reports table
    
    if (reportType === 'transactions') {
      const params = new URLSearchParams();
      if (searchVal) params.append('search', searchVal);
      if (topVal) params.append('top', topVal);
      if (generalLocation !== 'All') params.append('location', generalLocation);
      if (dateFrom) params.append('from', dateFrom);
      if (dateTo) params.append('to', dateTo);
      if (transType && transType !== 'all') params.append('type', transType);
      fetch(getAdminUrl('reports/reports_database.php') + '?' + params.toString())
        .then(r => r.text())
        .then(html => { tbody.innerHTML = html || '<tr><td colspan="8" style="text-align:center;padding:20px;color:#999;">No data</td></tr>'; })
        .catch(() => { tbody.innerHTML = '<tr><td colspan="8" style="color:#c00;padding:16px;text-align:center;">Error loading</td></tr>'; });
    }
    else if (reportType === 'inventory') {
      const fd = new FormData();
      if (searchVal) fd.append('search', searchVal);
      const loc = document.getElementById('location_filter')?.value || 'All';
      fd.append('location', loc);
      if (topVal) fd.append('top', topVal);
      if (generalLocation !== 'All') fd.append('general_location', generalLocation);
      fetch(getAdminUrl('inventory/inventory_database.php'), { method: 'POST', body: fd })
        .then(r => r.text())
        .then(html => { 
          console.log('Inventory response:', html);
          tbody.innerHTML = html || '<tr><td colspan="8" style="text-align:center;padding:20px;color:#999;">No data</td></tr>'; 
        })
        .catch(err => { 
          console.error('Inventory error:', err);
          tbody.innerHTML = '<tr><td colspan="8" style="color:#c00;padding:16px;text-align:center;">Error loading</td></tr>'; 
        });
    }
    else if (reportType === 'orders') {
      const fd = new FormData();
      if (searchVal) fd.append('search', searchVal);
      if (topVal) fd.append('top', topVal);
      if (generalLocation !== 'All') fd.append('location', generalLocation);
      if (dateFrom) fd.append('date_from', dateFrom);
      if (dateTo) fd.append('date_to', dateTo);
      fetch(getAdminUrl('orders/orders_database.php'), { method: 'POST', body: fd })
        .then(r => r.text())
        .then(html => { tbody.innerHTML = html || '<tr><td colspan="8" style="text-align:center;padding:20px;color:#999;">No data</td></tr>'; })
        .catch(() => { tbody.innerHTML = '<tr><td colspan="8" style="color:#c00;padding:16px;text-align:center;">Error loading</td></tr>'; });
    }
    else if (reportType === 'issues') {
      const fd = new FormData();
      fd.append('filter', 'all');
      if (topVal) fd.append('top', topVal);
      if (generalLocation !== 'All') fd.append('location', generalLocation);
      fetch(getAdminUrl('issues/issues_database.php'), { method: 'POST', body: fd })
        .then(r => r.text())
        .then(html => { tbody.innerHTML = html || '<tr><td colspan="7" style="text-align:center;padding:20px;color:#999;">No data</td></tr>'; })
        .catch(() => { tbody.innerHTML = '<tr><td colspan="7" style="color:#c00;padding:16px;text-align:center;">Error loading</td></tr>'; });
    }
    else if (reportType === 'suppliers') {
      // suppliers_database returns JSON array; render HTML rows here
      const q = searchVal ? `?search=${encodeURIComponent(searchVal)}` : '';
      fetch(getAdminUrl('suppliers/suppliers_database.php') + q)
        .then(r => r.json())
        .then(list => {
          if (!Array.isArray(list) || list.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;padding:20px;color:#999;">No suppliers</td></tr>';
            return;
          }
          // Apply top limit if specified
          let filteredList = list;
          if (topVal && !isNaN(topVal) && parseInt(topVal) > 0) {
            filteredList = list.slice(0, parseInt(topVal));
          }
          const rowsHtml = filteredList.map(s => {
            const id = s.SupplierID || '';
            const name = s.SupplierName || '';
            const contact = s.ContactPerson || '';
            const phone = s.Phone || '';
            const email = s.Email || '';
            const loc = s.Location || '';
            return `<tr>`+
                   `<td>${escapeHtml(String(id))}</td>`+
                   `<td>${escapeHtml(name)}</td>`+
                   `<td>${escapeHtml(contact)}</td>`+
                   `<td>${escapeHtml(phone)}</td>`+
                   `<td>${escapeHtml(email)}</td>`+
                   `<td>${escapeHtml(loc)}</td>`+
                   `</tr>`;
          }).join('');
          tbody.innerHTML = rowsHtml;
        })
        .catch(() => { tbody.innerHTML = '<tr><td colspan="6" style="color:#c00;padding:16px;text-align:center;">Error loading</td></tr>'; });
    }
    else if (reportType === 'users') {
      const fd = new FormData();
      if (searchVal) fd.append('search', searchVal);
      // Note: TOP is passed but sorting is not applied for users (just limits result)
      if (topVal) fd.append('top', topVal);
      fd.append('context', 'report');
      fetch(getAdminUrl('users/users_database.php'), { method: 'POST', body: fd })
        .then(r => r.text())
        .then(html => { tbody.innerHTML = html || '<tr><td colspan="4" style="text-align:center;padding:20px;color:#999;">No users</td></tr>'; })
        .catch(() => { tbody.innerHTML = '<tr><td colspan="4" style="color:#c00;padding:16px;text-align:center;">Error loading</td></tr>'; });
    }
    else if (reportType === 'alerts') {
      const fd = new FormData();
      fd.append('type', 'all');
      fd.append('status', 'all');
      fetch(getAdminUrl('alerts/alerts_database.php'), { method: 'POST', body: fd })
        .then(r => r.text())
        .then(html => { tbody.innerHTML = html || '<tr><td colspan="6" style="text-align:center;padding:20px;color:#999;">No data</td></tr>'; })
        .catch(() => { tbody.innerHTML = '<tr><td colspan="6" style="color:#c00;padding:16px;text-align:center;">Error loading</td></tr>'; });
    }
  };

  // Wire reports page controls
  const reportType = document.getElementById('report_type');
  if (reportType) {
    reportType.addEventListener('change', () => loadReportsTable());
    loadReportsTable(); // Load initial data
  }

  // Date range validation
  const dateFrom = document.getElementById('date_from');
  const dateTo = document.getElementById('date_to');
  
  if (dateFrom && dateTo) {
    // When start date changes, set minimum for end date
    dateFrom.addEventListener('change', function() {
      if (this.value) {
        dateTo.min = this.value;
        // If end date is before start date, reset it
        if (dateTo.value && dateTo.value < this.value) {
          dateTo.value = this.value;
        }
      }
      loadReportsTable();
    });
    
    // When end date changes, set maximum for start date
    dateTo.addEventListener('change', function() {
      if (this.value) {
        dateFrom.max = this.value;
        // If start date is after end date, reset it
        if (dateFrom.value && dateFrom.value > this.value) {
          dateFrom.value = this.value;
        }
      }
      loadReportsTable();
    });
  }

  const generalLocationFilter = document.getElementById('general_location_filter');
  if (generalLocationFilter) {
    generalLocationFilter.addEventListener('change', () => loadReportsTable());
  }

  const reportSearch = document.getElementById('report_search');
  if (reportSearch) {
    let reportSearchTimer;
    reportSearch.addEventListener('input', () => {
      clearTimeout(reportSearchTimer);
      reportSearchTimer = setTimeout(loadReportsTable, 300);
    });
  }

  const showTop = document.getElementById('show_top');
  if (showTop) {
    showTop.addEventListener('input', () => {
      if (showTop.value && parseInt(showTop.value) > 0) {
        loadReportsTable();
      } else if (showTop.value === '') {
        loadReportsTable();
      }
    });
  }

  const transactionType = document.getElementById('transaction_type');
  if (transactionType) {
    transactionType.addEventListener('change', () => loadReportsTable());
  }

  const locationFilter = document.getElementById('location_filter');
  if (locationFilter) {
    locationFilter.addEventListener('change', () => loadReportsTable());
  }

  // Reports printing: hide notes only during print if empty, then restore
  function applyPrintNotesVisibility() {
    const notesSection = document.querySelector('.reports-notes');
    const notesTextarea = document.getElementById('report_notes');
    if (!notesSection || !notesTextarea) return;
    const isEmpty = !notesTextarea.value || notesTextarea.value.trim() === '';
    if (isEmpty) {
      notesSection.classList.add('print-hide');
      notesSection.setAttribute('data-hidden-by-print', '1');
    } else {
      notesSection.classList.remove('print-hide');
      notesSection.removeAttribute('data-hidden-by-print');
    }
  }

  function cleanupPrintNotesVisibility() {
    const notesSection = document.querySelector('.reports-notes');
    if (!notesSection) return;
    // Only remove class if we added it specifically for this print session
    if (notesSection.getAttribute('data-hidden-by-print') === '1') {
      notesSection.classList.remove('print-hide');
      notesSection.removeAttribute('data-hidden-by-print');
    }
    // Ensure section is visible again in UI
    // Do not force display; let CSS control layout
  }

  // Hook into print lifecycle
  window.addEventListener('beforeprint', applyPrintNotesVisibility);
  window.addEventListener('afterprint', cleanupPrintNotesVisibility);
  // Fallback for browsers using matchMedia
  if (window.matchMedia) {
    const mediaQueryList = window.matchMedia('print');
    // Older browsers use addListener
    if (typeof mediaQueryList.addEventListener === 'function') {
      mediaQueryList.addEventListener('change', (mql) => {
        if (mql.matches) applyPrintNotesVisibility();
        else cleanupPrintNotesVisibility();
      });
    } else if (typeof mediaQueryList.addListener === 'function') {
      mediaQueryList.addListener((mql) => {
        if (mql.matches) applyPrintNotesVisibility();
        else cleanupPrintNotesVisibility();
      });
    }
  }

  const reportPrintBtn = document.getElementById('reports_print_btn');
  if (reportPrintBtn) {
    reportPrintBtn.addEventListener('click', () => {
      // Ensure proper state just before printing
      applyPrintNotesVisibility();
      // Print
      window.print();
      // Safety cleanup in case afterprint doesn't fire (some browsers)
      setTimeout(() => cleanupPrintNotesVisibility(), 1500);
    });
  }

  // Notes are for print only - no save functionality needed

  //dashboard functions
  function loadNotifications() {
      fetch(getAdminUrl("dashboard/dashboard_notifications.php"))
          .then(res => res.text())
          .then(html => {
              const target = document.getElementById("notifications_list");
              if (target) {
                  const oldHtml = target.innerHTML;
                  target.innerHTML = html;
                  
                  // Check for new notifications and show browser notification
                  if (html !== oldHtml && html.trim() !== '') {
                    checkAndNotify(html, oldHtml);
                  }
              }
          })
          .catch(err => console.error("Error loading notifications:", err));
  }

  // Notification checker - shows browser notifications for new alerts
  function checkAndNotify(newHtml, oldHtml) {
    const lowStockEnabled = localStorage.getItem('low_stock_alerts') === 'true';
    const expiryEnabled = localStorage.getItem('expiry_alerts') === 'true';
    const orderEnabled = localStorage.getItem('order_updates') === 'true';
    const soundEnabled = localStorage.getItem('sound_notifications') === 'true';
    
    // Parse new notifications
    const parser = new DOMParser();
    const newDoc = parser.parseFromString(newHtml, 'text/html');
    const oldDoc = parser.parseFromString(oldHtml, 'text/html');
    
    const newNotifications = newDoc.querySelectorAll('.notification');
    const oldNotifications = oldDoc.querySelectorAll('.notification');
    
    // Only notify if there are more notifications than before
    if (newNotifications.length > oldNotifications.length) {
      const latestNotification = newNotifications[0];
      if (latestNotification) {
        const titleEl = latestNotification.querySelector('.title');
        const subtitleEl = latestNotification.querySelector('.subtitle');
        const title = titleEl ? titleEl.textContent : '';
        const subtitle = subtitleEl ? subtitleEl.textContent : '';
        
        // Check notification type and user preferences
        let shouldNotify = false;
        if (title.toLowerCase().includes('low stock') && lowStockEnabled) shouldNotify = true;
        if (title.toLowerCase().includes('expired') && expiryEnabled) shouldNotify = true;
        if (title.toLowerCase().includes('expiry') && expiryEnabled) shouldNotify = true;
        if (title.toLowerCase().includes('order') && orderEnabled) shouldNotify = true;
        if (title.toLowerCase().includes('stock added') && orderEnabled) shouldNotify = true;
        
        if (shouldNotify) {
          showNotification(title, subtitle);
          if (soundEnabled) playNotificationSound();
        }
      }
    }
  }

  // Show browser notification
  function showNotification(title, message) {
    if (!("Notification" in window)) return;
    
    if (Notification.permission === "granted") {
      new Notification(title, {
        body: message,
        icon: '../logos/moon.png',
        badge: '../logos/moon.png'
      });
    } else if (Notification.permission !== "denied") {
      Notification.requestPermission().then(permission => {
        if (permission === "granted") {
          new Notification(title, {
            body: message,
            icon: '../logos/moon.png',
            badge: '../logos/moon.png'
          });
        }
      });
    }
  }

  // Play notification sound
  function playNotificationSound() {
    const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBStVbOmyWhQGVa3h77FKHg4PU67j8oNMGQtCp+Xt6pxNFAQ/nN7y0YQtBSh+zPLaizsIGGW1697OgykHKIDN8tyLNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBStVbOmyWhQGVa3h77FKHg4PU67j8oNMGQtCp+Xt6pxNFAQ/nN7y0YQtBSh+zPLaizsIGGW1697OgykHKIDN8tyLNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBStVbOmyWhQGVa3h77FKHg4PU67j8oNMGQtCp+Xt6pxNFAQ/nN7y0YQtBSh+zPLaizsIGGW1697OgykHKIDN8tyLNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBStVbOmyWhQGVa3h77FKHg4PU67j8oNMGQtCp+Xt6pxNFAQ/nN7y0YQtBSh+zPLaizsIGGW1697OgykHKIDN8tyLNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBStVbOmyWhQGVa3h77FKHg4=');
    audio.play().catch(() => {});
  }

  loadNotifications();
  setInterval(loadNotifications, 5000); // Check every 5 seconds

  // inventory functions
  let searchTimeout;

  function loadInventoryTable() {
      const searchEl = document.getElementById("search_bar_inventory");
      const locEl = document.getElementById("location");
      const search = searchEl ? searchEl.value : '';
      const location = locEl ? locEl.value : 'All';

      const formData = new FormData();
      formData.append("search", search);
      formData.append("location", location);

    fetch(getAdminUrl("inventory/inventory_database.php"), {
          method: "POST",
          body: formData
      })
      .then(res => res.text())
      .then(html => {
          const tbody = document.getElementById("inventory_table_body");
          if (tbody) tbody.innerHTML = html;
      })
      .catch(err => console.error("⚠️ Error loading table:", err));
  }

  loadInventoryTable();

  const searchBar = document.getElementById("search_bar_inventory");
  if (searchBar) {
    searchBar.addEventListener("input", () => {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(loadInventoryTable, 150);
    });
  }

  const locationEl = document.getElementById("location");
  if (locationEl) locationEl.addEventListener("change", loadInventoryTable);

  // Record Usage Modal
  const modal = document.getElementById("recordUsageModal");
  if (modal) {
    const closeBtn = modal.querySelector(".close");
    const itemSelect = document.getElementById("itemSelect");
    const form = document.getElementById("recordUsageForm");

    const globalBtn = document.getElementById("record_usage");
    if (globalBtn) {
      globalBtn.addEventListener("click", () => {
        modal.style.display = "block";
        itemSelect.disabled = false;
        itemSelect.value = "";
      });
    }

    document.querySelectorAll(".record-usage-item").forEach(btn => {
      btn.addEventListener("click", () => {
        const itemId = btn.dataset.itemId;
        modal.style.display = "block";
        itemSelect.value = itemId;
        itemSelect.disabled = true;
      });
    });

    if (closeBtn) closeBtn.onclick = () => { modal.style.display = "none"; };
    window.onclick = (e) => { if (e.target == modal) modal.style.display = "none"; };

    if (form) {
      form.addEventListener("submit", (e) => {
        e.preventDefault();
        const formData = new FormData(form);
        fetch("record_usage.php", { method: "POST", body: formData })
        .then(res => res.json())
        .then(data => {
          if (data.status === "success") {
            showNotification(data.message, 'success');
            modal.style.display = "none";
          } else {
            showNotification(data.message, 'error');
          }
        })
        .catch(err => {
          console.error("Error:", err);
          showNotification("Something went wrong!", 'error');
        });
      });
    }
  }

  // Transactions
  let trxSearchTimer;
  window.loadTransactionsTable = function() {
    const tbody = document.getElementById('transactions_table_body');
    if (!tbody) return;
    const searchEl = document.getElementById('search_bar_transactions');
    const fd = new FormData();
    if (searchEl && searchEl.value) fd.append('search', searchEl.value);
    fetch(getAdminUrl('transactions/transactions_database.php'), { method: 'POST', body: fd })
      .then(r => r.text())
      .then(html => { tbody.innerHTML = html; })
      .catch(() => { tbody.innerHTML = '<tr><td colspan="8" style="color:#c00; padding:16px; text-align:center;">Failed to load transactions.</td></tr>'; });
  }

  const trxSearch = document.getElementById('search_bar_transactions');
  if (trxSearch) {
    trxSearch.addEventListener('input', () => {
      clearTimeout(trxSearchTimer); trxSearchTimer = setTimeout(loadTransactionsTable, 200);
    });
  }

  // Issues
  window.loadIssuesTable = function() {
    const tbody = document.getElementById('issues_table_body');
    if (!tbody) return;
    const filterEl = document.getElementById('issues_filter');
    const fd = new FormData();
    if (filterEl) fd.append('filter', filterEl.value || 'all');
    fetch(getAdminUrl('issues/issues_database.php'), { method: 'POST', body: fd })
      .then(r => r.text())
      .then(html => { tbody.innerHTML = html; })
      .catch(() => { tbody.innerHTML = '<tr><td colspan="7" style="color:#c00; padding:16px; text-align:center;">Failed to load issues.</td></tr>'; });
  }

  const issuesFilter = document.getElementById('issues_filter');
  if (issuesFilter) issuesFilter.addEventListener('change', () => loadIssuesTable());

  document.addEventListener('click', (e) => {
    const btn = e.target.closest('.return-btn');
    if (!btn) return;
    const itemId = btn.getAttribute('data-item-id');
    if (!itemId) return;
    
    showConfirmationModal('Return this item to supplier?', 'Confirm Return').then(confirmed => {
      if (!confirmed) return;
      const fd = new FormData(); fd.append('item_id', itemId);
      fetch(getAdminUrl('issues/return_to_supplier.php'), { method: 'POST', body: fd })
        .then(r => r.json())
        .then(resp => {
          if (resp.ok) {
            btn.disabled = true; btn.textContent = 'Return requested';
          } else {
            showNotification(resp.error || 'Return failed', 'error');
          }
        })
        .catch(() => showNotification('Return failed', 'error'));
    });
  });

  // Alerts
  window.loadAlertsTable = function() {
    const tbody = document.getElementById('alerts_table_body');
    if (!tbody) return;
    const typeEl = document.getElementById('alerts_type_filter');
    const statusEl = document.getElementById('alerts_status_filter');
    const fd = new FormData();
    if (typeEl) fd.append('type', typeEl.value || 'all');
    if (statusEl) fd.append('status', statusEl.value || 'all');
    fetch(getAdminUrl('alerts/alerts_database.php'), { method: 'POST', body: fd })
      .then(r => r.text())
      .then(html => { tbody.innerHTML = html; })
      .catch(() => { tbody.innerHTML = '<tr><td colspan="6" style="color:#c00; padding:16px; text-align:center;">Failed to load alerts.</td></tr>'; });
  }

  const alertsTypeFilter = document.getElementById('alerts_type_filter');
  const alertsStatusFilter = document.getElementById('alerts_status_filter');
  if (alertsTypeFilter) alertsTypeFilter.addEventListener('change', () => loadAlertsTable());
  if (alertsStatusFilter) alertsStatusFilter.addEventListener('change', () => loadAlertsTable());

  document.addEventListener('click', (e) => {
    const btn = e.target.closest('.resolve-alert-btn');
    if (!btn) return;
    const alertId = btn.getAttribute('data-alert-id');
    if (!alertId) return;
    showConfirmationModal('Mark this alert as resolved?', 'Confirm Resolution').then(confirmed => {
      if (!confirmed) return;
    const fd = new FormData(); fd.append('alert_id', alertId);
    fetch(getAdminUrl('alerts/mark_resolved.php'), { method: 'POST', body: fd })
      .then(r => r.json())
      .then(resp => {
        if (resp.ok) loadAlertsTable();
        else showNotification(resp.error || 'Failed to resolve alert', 'error');
      })
      .catch(() => showNotification('Failed to resolve alert', 'error'));
    });
  });

  // Settings - Theme Management
  const themeButtons = document.querySelectorAll('.theme-btn');
  const applyTheme = (theme) => {
    const body = document.body;
    body.classList.remove('light-theme', 'dark-theme');
    
    if (theme === 'auto') {
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      if (prefersDark) body.classList.add('dark-theme');
      else body.classList.add('light-theme');
    } else {
      body.classList.add(`${theme}-theme`);
    }
    
    themeButtons.forEach(btn => {
      if (btn.getAttribute('data-theme') === theme) btn.classList.add('active');
      else btn.classList.remove('active');
    });
    
    localStorage.setItem('theme_preference', theme);
  };

  const savedTheme = localStorage.getItem('theme_preference') || 'auto';
  applyTheme(savedTheme);

  themeButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const theme = btn.getAttribute('data-theme');
      applyTheme(theme);
    });
  });

  window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
    const currentTheme = localStorage.getItem('theme_preference');
    if (currentTheme === 'auto') applyTheme('auto');
  });

  function loadSettings() {
    // Define default values for all settings
    const defaults = {
      // Toggles - default states
      compact_mode: false,
      low_stock_alerts: true,
      expiry_alerts: true,
      order_updates: true,
      sound_notifications: false,
      auto_save: false,
      
      // Selects - default values
      export_format: 'csv',
      language_select: 'en',
      date_format: 'MM/DD/YYYY',
      currency_select: 'USD',
      items_per_page: '50',
      session_timeout: '30'
    };

    // Load toggles (checkboxes) - use defaults always (settings auto-save on change)
    const toggles = ['compact_mode', 'low_stock_alerts', 'expiry_alerts', 'order_updates', 'sound_notifications', 'auto_save'];
    toggles.forEach(id => {
      const checkbox = document.getElementById(id);
      if (checkbox) {
        const saved = localStorage.getItem(id);
        checkbox.checked = saved !== null ? (saved === 'true') : (defaults[id] || false);
        
        // Auto-save on change
        checkbox.addEventListener('change', function() {
          localStorage.setItem(id, this.checked.toString());
          
          // Apply compact mode immediately
          if (id === 'compact_mode') {
            applyCompactMode(this.checked);
          }
        });
      }
    });

    // Load selects - use defaults, auto-save on change
    const selects = ['export_format', 'language_select', 'date_format', 'currency_select', 'items_per_page', 'session_timeout'];
    selects.forEach(id => {
      const select = document.getElementById(id);
      if (select) {
        const saved = localStorage.getItem(id);
        select.value = saved !== null ? saved : (defaults[id] || '');
        
        // Auto-save on change
        select.addEventListener('change', function() {
          localStorage.setItem(id, this.value);
        });
      }
    });

    // Apply compact mode on load if enabled
    const compactEnabled = localStorage.getItem('compact_mode') === 'true';
    applyCompactMode(compactEnabled);
  }

  // Compact Mode Implementation
  function applyCompactMode(enabled) {
    if (enabled) {
      document.body.classList.add('compact-mode');
    } else {
      document.body.classList.remove('compact-mode');
    }
  }

  function resetSettings() {
    showConfirmationModal('Reset all settings to default values?', 'Confirm Reset').then(confirmed => {
      if (!confirmed) return;
    
    // Clear all settings from localStorage
    ['compact_mode', 'low_stock_alerts', 'expiry_alerts', 'order_updates', 'sound_notifications', 'auto_save',
     'export_format', 'language_select', 'date_format', 'currency_select', 'items_per_page', 'session_timeout'
    ].forEach(key => localStorage.removeItem(key));
    
    // Reset theme to auto
    applyTheme('auto');
    
    // Remove compact mode
    applyCompactMode(false);
    
    // Reload settings from defaults
    loadSettings();
    
    showNotification('Settings reset to defaults!', 'success');
    });
  }

  function exportData() {
    const format = document.getElementById('export_format')?.value || 'csv';
    window.location.href = getAdminUrl(`settings/export_data.php?format=${format}`);
  }

  function backupDatabase() {
    showConfirmationModal('Generate a backup of the database?', 'Confirm Backup').then(confirmed => {
      if (!confirmed) return;
      window.location.href = getAdminUrl('settings/backup_database.php');
    });
  }

  function clearCache() {
    showConfirmationModal('Clear application cache?', 'Confirm Clear Cache').then(confirmed => {
      if (!confirmed) return;
      fetch(getAdminUrl('settings/clear_cache.php'), { method: 'POST' })
        .then(r => r.json())
        .then(resp => {
          if (resp.ok) showNotification('Cache cleared successfully!', 'success');
          else showNotification(resp.error || 'Failed to clear cache', 'error');
        })
        .catch(() => showNotification('Failed to clear cache', 'error'));
    });
  }

  function checkUpdates() {
    showNotification('Current version: 1.0.0 - No updates available', 'info');
  }

  function openChangePasswordModal() {
    showNotification('Change password feature coming soon!', 'info');
  }

  loadSettings();

  // Confirmation Modal Functions
  let confirmationCallback = null;

  window.showConfirmationModal = function(message, title = 'Confirm Action') {
    return new Promise((resolve) => {
      confirmationCallback = resolve;
      const modal = document.getElementById('confirmationModal');
      const titleEl = document.getElementById('confirmationModalTitle');
      const messageEl = document.getElementById('confirmationModalMessage');
      
      if (titleEl) titleEl.textContent = title;
      if (messageEl) messageEl.textContent = message;
      if (modal) modal.style.display = 'flex';
    });
  };

  window.closeConfirmationModal = function(confirmed) {
    const modal = document.getElementById('confirmationModal');
    if (modal) modal.style.display = 'none';
    if (confirmationCallback) {
      confirmationCallback(confirmed);
      confirmationCallback = null;
    }
  };

  window.resetSettings = resetSettings;
  window.exportData = exportData;
  window.backupDatabase = backupDatabase;
  window.clearCache = clearCache;
  window.checkUpdates = checkUpdates;
  window.openChangePasswordModal = openChangePasswordModal;
});
