<?php
session_name('INVENTORY_SESSION');
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../../login/database-account.php';

$action = $_POST['action'] ?? '';

// Add User
if ($action === 'add') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $confirm_password = trim($_POST['confirm_password'] ?? '');
    $role = trim($_POST['role'] ?? '');
    $name = trim($_POST['name'] ?? '');
    $location = trim($_POST['location'] ?? '');

    if (empty($username) || empty($password) || empty($role) || empty($name)) {
        echo json_encode(['success' => false, 'error' => 'Username, password, role and name are required']);
        exit;
    }

    if ($password !== $confirm_password) {
        echo json_encode(['success' => false, 'error' => 'Passwords do not match']);
        exit;
    }

    if (strlen($password) < 6) {
        echo json_encode(['success' => false, 'error' => 'Password must be at least 6 characters']);
        exit;
    }

    // Check if username already exists
    $check = $conn->prepare("SELECT UserID, Status FROM users WHERE Username = ?");
    $check->bind_param('s', $username);
    $check->execute();
    $result = $check->get_result();
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        // If user is inactive, suggest reactivation
        if (isset($user['Status']) && $user['Status'] === 'Inactive') {
            echo json_encode([
                'success' => false, 
                'error' => 'Username already exists',
                'inactive' => true,
                'user_id' => $user['UserID'],
                'username' => $username
            ]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Username already exists']);
        }
        exit;
    }

    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
    // Check if Location column exists, if not create it
    $chkLoc = $conn->query("SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME='users' AND COLUMN_NAME='Location'");
    if (!$chkLoc || $chkLoc->num_rows === 0) {
        $conn->query("ALTER TABLE users ADD COLUMN Location VARCHAR(50) DEFAULT NULL");
    }
    
    $stmt = $conn->prepare("INSERT INTO users (Username, Password, Role, Name, Location) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param('sssss', $username, $hashed_password, $role, $name, $location);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'User added successfully']);
    } else {
        echo json_encode(['success' => false, 'error' => 'Failed to add user: ' . $conn->error]);
    }
    exit;
}

// Edit User
if ($action === 'edit') {
    $user_id = trim($_POST['user_id'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $role = trim($_POST['role'] ?? '');
    $name = trim($_POST['name'] ?? '');
    $location = trim($_POST['location'] ?? '');
    $new_password = trim($_POST['new_password'] ?? '');
    $confirm_password = trim($_POST['confirm_password'] ?? '');

    if (empty($user_id) || empty($username) || empty($role) || empty($name)) {
        echo json_encode(['success' => false, 'error' => 'User ID, username, role and name are required']);
        exit;
    }

    // Check if username is taken by another user
    $check = $conn->prepare("SELECT UserID FROM users WHERE Username = ? AND UserID != ?");
    $check->bind_param('ss', $username, $user_id);
    $check->execute();
    if ($check->get_result()->num_rows > 0) {
        echo json_encode(['success' => false, 'error' => 'Username already exists']);
        exit;
    }

    // Update user
    if (!empty($new_password)) {
        if ($new_password !== $confirm_password) {
            echo json_encode(['success' => false, 'error' => 'Passwords do not match']);
            exit;
        }
        if (strlen($new_password) < 6) {
            echo json_encode(['success' => false, 'error' => 'Password must be at least 6 characters']);
            exit;
        }
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE users SET Username = ?, Password = ?, Role = ?, Name = ?, Location = ? WHERE UserID = ?");
        $stmt->bind_param('ssssss', $username, $hashed_password, $role, $name, $location, $user_id);
    } else {
        $stmt = $conn->prepare("UPDATE users SET Username = ?, Role = ?, Name = ?, Location = ? WHERE UserID = ?");
        $stmt->bind_param('sssss', $username, $role, $name, $location, $user_id);
    }
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'User updated successfully']);
    } else {
        echo json_encode(['success' => false, 'error' => 'Failed to update user: ' . $conn->error]);
    }
    exit;
}

// Delete User
if ($action === 'delete') {
    $user_id = trim($_POST['user_id'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $current_user_id = $_SESSION['UserID'] ?? '';

    if (empty($user_id)) {
        echo json_encode(['success' => false, 'error' => 'User ID is required']);
        exit;
    }

    if (empty($password)) {
        echo json_encode(['success' => false, 'error' => 'Password is required']);
        exit;
    }

    if (empty($current_user_id)) {
        echo json_encode(['success' => false, 'error' => 'You must be logged in']);
        exit;
    }

    // Verify the current user's password
    $verify_stmt = $conn->prepare("SELECT Password FROM users WHERE UserID = ?");
    $verify_stmt->bind_param('s', $current_user_id);
    $verify_stmt->execute();
    $result = $verify_stmt->get_result();
    
    if ($result->num_rows === 0) {
        echo json_encode(['success' => false, 'error' => 'Current user not found']);
        exit;
    }
    
    $user_data = $result->fetch_assoc();
    $stored_password = $user_data['Password'];
    
    // Support both hashed and plain text passwords
    $password_valid = false;
    if (password_verify($password, $stored_password)) {
        $password_valid = true;
    } elseif ($password === $stored_password) {
        $password_valid = true;
    }
    
    if (!$password_valid) {
        echo json_encode(['success' => false, 'error' => 'Incorrect password']);
        exit;
    }

    // Instead of deleting, mark user as inactive (soft delete)
    // First check if Status column exists
    $check_column = $conn->query("SHOW COLUMNS FROM users LIKE 'Status'");
    $has_status_column = ($check_column && $check_column->num_rows > 0);
    
    if (!$has_status_column) {
        // Add Status column if it doesn't exist
        $conn->query("ALTER TABLE users ADD COLUMN Status VARCHAR(20) DEFAULT 'Active'");
    }
    
    try {
        // Soft delete: Mark user as 'Inactive' instead of deleting
        $stmt = $conn->prepare("UPDATE users SET Status = 'Inactive' WHERE UserID = ?");
        $stmt->bind_param('s', $user_id);
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'User deactivated successfully']);
        } else {
            echo json_encode(['success' => false, 'error' => 'Failed to deactivate user: ' . $conn->error]);
        }
    } catch (mysqli_sql_exception $e) {
        echo json_encode(['success' => false, 'error' => 'Database error: ' . $e->getMessage()]);
    }
    exit;
}

// Reactivate User
if ($action === 'reactivate') {
    $user_id = trim($_POST['user_id'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $new_password = trim($_POST['new_password'] ?? '');
    $confirm_password = trim($_POST['confirm_password'] ?? '');
    $role = trim($_POST['role'] ?? '');
    $name = trim($_POST['name'] ?? '');
    $current_user_id = $_SESSION['UserID'] ?? '';

    if (empty($user_id) || empty($password) || empty($new_password) || empty($role) || empty($name)) {
        echo json_encode(['success' => false, 'error' => 'All fields are required']);
        exit;
    }

    if ($new_password !== $confirm_password) {
        echo json_encode(['success' => false, 'error' => 'Passwords do not match']);
        exit;
    }

    if (strlen($new_password) < 6) {
        echo json_encode(['success' => false, 'error' => 'Password must be at least 6 characters']);
        exit;
    }

    if (empty($current_user_id)) {
        echo json_encode(['success' => false, 'error' => 'You must be logged in']);
        exit;
    }

    // Verify the current admin's password
    $verify_stmt = $conn->prepare("SELECT Password FROM users WHERE UserID = ?");
    $verify_stmt->bind_param('s', $current_user_id);
    $verify_stmt->execute();
    $result = $verify_stmt->get_result();
    
    if ($result->num_rows === 0) {
        echo json_encode(['success' => false, 'error' => 'Current user not found']);
        exit;
    }
    
    $user_data = $result->fetch_assoc();
    $stored_password = $user_data['Password'];
    
    // Support both hashed and plain text passwords
    $password_valid = false;
    if (password_verify($password, $stored_password)) {
        $password_valid = true;
    } elseif ($password === $stored_password) {
        $password_valid = true;
    }
    
    if (!$password_valid) {
        echo json_encode(['success' => false, 'error' => 'Incorrect admin password']);
        exit;
    }

    // Reactivate the user with new details
    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("UPDATE users SET Password = ?, Role = ?, Name = ?, Status = 'Active' WHERE UserID = ?");
    $stmt->bind_param('ssss', $hashed_password, $role, $name, $user_id);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'User reactivated successfully']);
    } else {
        echo json_encode(['success' => false, 'error' => 'Failed to reactivate user: ' . $conn->error]);
    }
    exit;
}

echo json_encode(['success' => false, 'error' => 'Invalid action']);
exit;
