<!-- Add User Modal - Form for creating new user accounts -->
<div id="addUserModal" class="modal" aria-hidden="true" style="display:none;">
  <div class="modal-content">
    <div class="modal-header">
      <h3>Add New User</h3>
      <span class="close" onclick="closeAddUserModal()">&times;</span>
    </div>

    <form id="addUserForm" class="user-form" novalidate>
      <label for="add_username">Username</label>
      <input type="text" id="add_username" name="username" required />

      <label for="add_password">Password</label>
      <input type="password" id="add_password" name="password" required />

      <label for="add_confirm_password">Confirm Password</label>
      <input type="password" id="add_confirm_password" name="confirm_password" required />

      <label for="add_role">Role</label>
      <select id="add_role" name="role" required>
        <option value="">Select a role</option>
        <option value="Admin">Admin</option>
        <option value="Staff">Staff</option>
        <option value="Manager">Manager</option>
      </select>

      <label for="add_name">Full Name</label>
      <input type="text" id="add_name" name="name" required />

      <label for="add_location">Location (optional)</label>
      <select id="add_location" name="location">
        <option value="">Select location</option>
        <option value="Restaurant">Restaurant</option>
        <option value="Room">Room</option>
      </select>

      <div id="add_user_message" class="user_message"></div>

      <div class="modal-actions">
        <button type="button" class="cancel-btn" onclick="closeAddUserModal()">Cancel</button>
        <button type="submit" class="save-btn" id="add_user_btn">Add User</button>
      </div>
    </form>
  </div>
</div>

<!-- Edit User Modal -->
<div id="editUserModal" class="modal" aria-hidden="true" style="display:none;">
  <div class="modal-content">
    <div class="modal-header">
      <h3>Edit User</h3>
      <span class="close" onclick="closeEditUserModal()">&times;</span>
    </div>

    <form id="editUserForm" class="user-form" novalidate>
      <input type="hidden" id="edit_user_id" name="user_id" />

      <label for="edit_username">Username</label>
      <input type="text" id="edit_username" name="username" required />

      <label for="edit_role">Role</label>
      <select id="edit_role" name="role" required>
        <option value="">Select a role</option>
        <option value="Admin">Admin</option>
        <option value="Staff">Staff</option>
        <option value="Manager">Manager</option>
      </select>

      <label for="edit_name">Full Name</label>
      <input type="text" id="edit_name" name="name" required />

      <label for="edit_location">Location (optional)</label>
      <select id="edit_location" name="location">
        <option value="">Select location</option>
        <option value="Restaurant">Restaurant</option>
        <option value="Room">Room</option>
      </select>

      <label for="edit_new_password">New Password (leave blank to keep current)</label>
      <input type="password" id="edit_new_password" name="new_password" />

      <label for="edit_confirm_password">Confirm New Password</label>
      <input type="password" id="edit_confirm_password" name="confirm_password" />

      <div id="edit_user_message" class="user_message"></div>

      <div class="modal-actions">
        <button type="button" class="cancel-btn" onclick="closeEditUserModal()">Cancel</button>
        <button type="submit" class="save-btn" id="edit_user_btn">Update User</button>
      </div>
    </form>
  </div>
</div>

<!-- Delete User Confirmation Modal -->
<div id="deleteUserModal" class="modal" aria-hidden="true" style="display:none;">
  <div class="modal-content">
    <div class="modal-header">
      <h3>Confirm Delete User</h3>
      <span class="close" onclick="closeDeleteUserModal()">&times;</span>
    </div>

    <form id="deleteUserForm" class="user-form" novalidate>
      <input type="hidden" id="delete_user_id" name="user_id" />
      
      <p style="margin: 0 0 16px 0; color: #555; font-size: 14px;">
        You are about to delete user: <strong id="delete_username_display"></strong>
      </p>
      
      <p style="margin: 0 0 16px 0; color: #dc3545; font-size: 13px; font-weight: 600;">
        ⚠️ This action cannot be undone!
      </p>

      <label for="delete_password">Enter your password to confirm</label>
      <input type="password" id="delete_password" name="password" placeholder="Your password" required />

      <div id="delete_user_message" class="user_message"></div>

      <div class="modal-actions">
        <button type="button" class="cancel-btn" onclick="closeDeleteUserModal()">Cancel</button>
        <button type="submit" class="delete-btn" id="delete_user_btn">Delete User</button>
      </div>
    </form>
  </div>
</div>

<!-- Reactivate User Modal -->
<div id="reactivateUserModal" class="modal" aria-hidden="true" style="display:none;">
  <div class="modal-content">
    <div class="modal-header">
      <h3>Reactivate Deactivated User</h3>
      <span class="close" onclick="closeReactivateUserModal()">&times;</span>
    </div>

    <form id="reactivateUserForm" class="user-form" novalidate>
      <input type="hidden" id="reactivate_user_id" name="user_id" />
      
      <p style="margin: 0 0 16px 0; color: #555; font-size: 14px;">
        The username "<strong id="reactivate_username_display"></strong>" exists but is currently deactivated.
      </p>
      
      <p style="margin: 0 0 20px 0; color: #28a745; font-size: 13px; font-weight: 600;">
        ✓ Would you like to reactivate this user?
      </p>

      <label for="reactivate_password">New Password</label>
      <input type="password" id="reactivate_password" name="new_password" placeholder="Enter new password" required />

      <label for="reactivate_confirm_password">Confirm Password</label>
      <input type="password" id="reactivate_confirm_password" name="confirm_password" placeholder="Confirm new password" required />

      <label for="reactivate_role">Role</label>
      <select id="reactivate_role" name="role" required>
        <option value="">Select a role</option>
        <option value="Admin">Admin</option>
        <option value="Staff">Staff</option>
        <option value="Manager">Manager</option>
      </select>

      <label for="reactivate_name">Full Name</label>
      <input type="text" id="reactivate_name" name="name" placeholder="Enter full name" required />

      <hr style="margin: 20px 0; border: none; border-top: 1px solid #ddd;" />

      <label for="reactivate_admin_password">Enter Your Admin Password to Confirm</label>
      <input type="password" id="reactivate_admin_password" name="password" placeholder="Your admin password" required />

      <div id="reactivate_user_message" class="user_message"></div>

      <div class="modal-actions">
        <button type="button" class="cancel-btn" onclick="closeReactivateUserModal()">Cancel</button>
        <button type="submit" class="save-btn" id="reactivate_user_btn">Reactivate User</button>
      </div>
    </form>
  </div>
</div>
