<?php
require(__DIR__ . "/../../login/database-account.php");

$search = $_POST['search'] ?? '';
$top = isset($_POST['top']) ? intval($_POST['top']) : 0;
$context = $_POST['context'] ?? 'manage'; // 'manage' for users page, 'report' for reports page

// Prefer Username/Role naming; fall back to UserName/Position if needed by aliasing via SELECT
$usernameField = 'Username';
$roleField = 'Role';

// Test fields existence and adapt
$chk = $conn->query("SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME='users' AND COLUMN_NAME='Username'");
if (!$chk || $chk->num_rows === 0) { $usernameField = 'UserName'; }
$chk2 = $conn->query("SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME='users' AND COLUMN_NAME='Role'");
if (!$chk2 || $chk2->num_rows === 0) { $roleField = 'Position'; }

// Check if Status column exists
$chk3 = $conn->query("SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME='users' AND COLUMN_NAME='Status'");
$hasStatus = ($chk3 && $chk3->num_rows > 0);

// Check if Location column exists
$chkLoc = $conn->query("SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME='users' AND COLUMN_NAME='Location'");
$hasLocation = ($chkLoc && $chkLoc->num_rows > 0);
$locationField = $hasLocation ? ", Location" : ", '' AS Location";

$query = "SELECT UserID, $usernameField AS Username, $roleField AS Role, Name $locationField
          FROM users 
          WHERE ($usernameField LIKE ? OR Name LIKE ? OR UserID LIKE ?)";

// Filter out inactive users if Status column exists
if ($hasStatus && $context === 'manage') {
    $query .= " AND (Status = 'Active' OR Status IS NULL)";
}

$query .= " ORDER BY UserID ASC";

$params = ["%$search%", "%$search%", "%$search%"];

// Note: TOP filter is ignored for users table (no sorting by quantity/total)
if ($top > 0 && $context === 'report') {
    $query .= " LIMIT " . $top;
}

$stmt = $conn->prepare($query);
$stmt->bind_param("sss", ...$params);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()):
?>
<tr>
    <td><?= htmlspecialchars($row['UserID']); ?></td>
    <td><?= htmlspecialchars($row['Username']); ?></td>
    <td><?= htmlspecialchars($row['Role']); ?></td>
    <td><?= htmlspecialchars($row['Name']); ?></td>
    <td><?= htmlspecialchars($row['Location'] ?? 'N/A'); ?></td>
    <?php if ($context === 'manage'): ?>
    <td>
        <div class="action-menu">
            <button class="action-btn" onclick="toggleActionMenu(event, this)">⋮</button>
            <div class="action-dropdown">
                <a href="#" onclick="openEditUser('<?= $row['UserID'] ?>', '<?= htmlspecialchars($row['Username']) ?>', '<?= htmlspecialchars($row['Role']) ?>', '<?= htmlspecialchars($row['Name']) ?>', '<?= htmlspecialchars($row['Location'] ?? '') ?>')">Edit</a>
                <a href="#" onclick="deleteUser('<?= $row['UserID'] ?>', '<?= htmlspecialchars($row['Username']) ?>')">Delete</a>
            </div>
        </div>
    </td>
    <?php endif; ?>
</tr>
<?php endwhile; ?>
