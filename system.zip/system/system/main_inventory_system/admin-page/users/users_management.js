// User Management Script
document.addEventListener('DOMContentLoaded', () => {
  let searchTimeout;

  function loadUsersTable() {
    const searchEl = document.getElementById("search_bar_users");
    const search = searchEl ? searchEl.value : '';

    const formData = new FormData();
    formData.append("search", search);

    fetch("users/users_database.php", {
      method: "POST",
      body: formData
    })
    .then(res => res.text())
    .then(html => {
      const tbody = document.getElementById("users_table_body");
      if (tbody) tbody.innerHTML = html;
    })
    .catch(err => console.error("Error loading users table:", err));
  }

  // Initial load
  loadUsersTable();

  // Live search
  const searchBar = document.getElementById("search_bar_users");
  if (searchBar) {
    searchBar.addEventListener("input", () => {
      clearTimeout(searchTimeout);
      searchTimeout = setTimeout(loadUsersTable, 150);
    });
  }

  // Toggle action menu
  window.toggleActionMenu = function(event, btn) {
    event.stopPropagation();
    const dropdown = btn.nextElementSibling;
    
    // Close all other dropdowns
    document.querySelectorAll('.action-dropdown').forEach(d => {
      if (d !== dropdown) d.style.display = 'none';
    });
    
    if (dropdown.style.display === 'block') {
      dropdown.style.display = 'none';
    } else {
      // Calculate position relative to button
      const rect = btn.getBoundingClientRect();
      dropdown.style.top = (rect.bottom + 4) + 'px';
      dropdown.style.left = (rect.right - 120) + 'px'; // 120px is min-width of dropdown
      dropdown.style.display = 'block';
    }
  };

  // Close dropdowns when clicking outside
  document.addEventListener('click', () => {
    document.querySelectorAll('.action-dropdown').forEach(d => {
      d.style.display = 'none';
    });
  });

  // Add User Modal
  window.openAddUserModal = function() {
    const modal = document.getElementById('addUserModal');
    if (modal) {
      document.getElementById('addUserForm').reset();
      document.getElementById('add_user_message').style.display = 'none';
      modal.style.display = 'flex';
    }
  };

  window.closeAddUserModal = function() {
    const modal = document.getElementById('addUserModal');
    if (modal) modal.style.display = 'none';
  };

  // Edit User Modal
  window.openEditUser = function(userId, username, role, name, location) {
    const modal = document.getElementById('editUserModal');
    if (modal) {
      document.getElementById('edit_user_id').value = userId;
      document.getElementById('edit_username').value = username;
      document.getElementById('edit_role').value = role;
      document.getElementById('edit_name').value = name;
      document.getElementById('edit_location').value = location || '';
      document.getElementById('edit_new_password').value = '';
      document.getElementById('edit_confirm_password').value = '';
      document.getElementById('edit_user_message').style.display = 'none';
      modal.style.display = 'flex';
    }
    // Close action dropdown
    document.querySelectorAll('.action-dropdown').forEach(d => d.style.display = 'none');
  };

  window.closeEditUserModal = function() {
    const modal = document.getElementById('editUserModal');
    if (modal) modal.style.display = 'none';
  };

  // Delete User Modal
  window.openDeleteUserModal = function(userId, username) {
    const modal = document.getElementById('deleteUserModal');
    if (modal) {
      document.getElementById('delete_user_id').value = userId;
      document.getElementById('delete_username_display').textContent = username;
      document.getElementById('delete_password').value = '';
      document.getElementById('delete_user_message').style.display = 'none';
      modal.style.display = 'flex';
    }
    // Close action dropdown
    document.querySelectorAll('.action-dropdown').forEach(d => d.style.display = 'none');
  };

  window.closeDeleteUserModal = function() {
    const modal = document.getElementById('deleteUserModal');
    if (modal) modal.style.display = 'none';
  };

  // Reactivate User Modal
  window.openReactivateUserModal = function(userId, username) {
    const modal = document.getElementById('reactivateUserModal');
    if (modal) {
      document.getElementById('reactivate_user_id').value = userId;
      document.getElementById('reactivate_username_display').textContent = username;
      document.getElementById('reactivateUserForm').reset();
      document.getElementById('reactivate_user_id').value = userId; // Reset clears hidden fields too
      document.getElementById('reactivate_user_message').style.display = 'none';
      modal.style.display = 'flex';
    }
  };

  window.closeReactivateUserModal = function() {
    const modal = document.getElementById('reactivateUserModal');
    if (modal) modal.style.display = 'none';
  };

  // Delete User (now opens modal instead of direct delete)
  window.deleteUser = function(userId, username) {
    openDeleteUserModal(userId, username);
  };

  // Add User Form Submit
  const addUserForm = document.getElementById('addUserForm');
  if (addUserForm) {
    addUserForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const msg = document.getElementById('add_user_message');
      msg.style.display = 'none';

      const btn = document.getElementById('add_user_btn');
      btn.disabled = true;

      const formData = new FormData(addUserForm);
      formData.append('action', 'add');

      fetch('users/manage_users.php', {
        method: 'POST',
        body: formData
      })
      .then(r => r.json())
      .then(resp => {
        btn.disabled = false;
        if (resp.success) {
          showNotification('User added successfully', 'success');
          closeAddUserModal();
          loadUsersTable();
        } else {
          // Check if user is inactive and offer reactivation
          if (resp.inactive) {
            closeAddUserModal();
            openReactivateUserModal(resp.user_id, resp.username);
          } else {
            msg.textContent = resp.error || 'Failed to add user';
            msg.style.display = 'block';
          }
        }
      })
      .catch(() => {
        btn.disabled = false;
        msg.textContent = 'Request failed';
        msg.style.display = 'block';
      });
    });
  }

  // Edit User Form Submit
  const editUserForm = document.getElementById('editUserForm');
  if (editUserForm) {
    editUserForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const msg = document.getElementById('edit_user_message');
      msg.style.display = 'none';

      const btn = document.getElementById('edit_user_btn');
      btn.disabled = true;

      const formData = new FormData(editUserForm);
      formData.append('action', 'edit');

      fetch('users/manage_users.php', {
        method: 'POST',
        body: formData
      })
      .then(r => r.json())
      .then(resp => {
        btn.disabled = false;
        if (resp.success) {
          showNotification('User updated successfully', 'success');
          closeEditUserModal();
          loadUsersTable();
        } else {
          msg.textContent = resp.error || 'Failed to update user';
          msg.style.display = 'block';
        }
      })
      .catch(() => {
        btn.disabled = false;
        msg.textContent = 'Request failed';
        msg.style.display = 'block';
      });
    });
  }

  // Delete User Form Submit (with password verification)
  const deleteUserForm = document.getElementById('deleteUserForm');
  if (deleteUserForm) {
    deleteUserForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const msg = document.getElementById('delete_user_message');
      msg.style.display = 'none';

      const password = document.getElementById('delete_password').value;
      if (!password) {
        msg.textContent = 'Please enter your password';
        msg.style.display = 'block';
        return;
      }

      const btn = document.getElementById('delete_user_btn');
      btn.disabled = true;

      const formData = new FormData(deleteUserForm);
      formData.append('action', 'delete');

      fetch('users/manage_users.php', {
        method: 'POST',
        body: formData
      })
      .then(r => r.json())
      .then(resp => {
        btn.disabled = false;
        if (resp.success) {
          showNotification('User deleted successfully', 'success');
          closeDeleteUserModal();
          loadUsersTable();
        } else {
          msg.textContent = resp.error || 'Failed to delete user';
          msg.style.display = 'block';
        }
      })
      .catch(() => {
        btn.disabled = false;
        msg.textContent = 'Request failed';
        msg.style.display = 'block';
      });
    });
  }

  // Reactivate User Form Submit
  const reactivateUserForm = document.getElementById('reactivateUserForm');
  if (reactivateUserForm) {
    reactivateUserForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const msg = document.getElementById('reactivate_user_message');
      msg.style.display = 'none';

      const btn = document.getElementById('reactivate_user_btn');
      btn.disabled = true;

      const formData = new FormData(reactivateUserForm);
      formData.append('action', 'reactivate');

      fetch('users/manage_users.php', {
        method: 'POST',
        body: formData
      })
      .then(r => r.json())
      .then(resp => {
        btn.disabled = false;
        if (resp.success) {
          showNotification('User reactivated successfully', 'success');
          closeReactivateUserModal();
          loadUsersTable();
        } else {
          msg.textContent = resp.error || 'Failed to reactivate user';
          msg.style.display = 'block';
        }
      })
      .catch(() => {
        btn.disabled = false;
        msg.textContent = 'Request failed';
        msg.style.display = 'block';
      });
    });
  }

  // Centered notification
  function showNotification(text, type = 'success') {
    const notif = document.createElement('div');
    notif.textContent = text;
    notif.style.cssText = `
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background: ${type === 'success' ? '#28a745' : '#dc3545'};
      color: white;
      padding: 20px 40px;
      border-radius: 8px;
      font-size: 16px;
      font-weight: 600;
      box-shadow: 0 4px 12px rgba(0,0,0,0.3);
      z-index: 10000;
      animation: fadeInOut 2s ease-in-out;
    `;
    
    const style = document.createElement('style');
    style.textContent = `
      @keyframes fadeInOut {
        0% { opacity: 0; transform: translate(-50%, -60%); }
        15% { opacity: 1; transform: translate(-50%, -50%); }
        85% { opacity: 1; transform: translate(-50%, -50%); }
        100% { opacity: 0; transform: translate(-50%, -40%); }
      }
    `;
    document.head.appendChild(style);
    document.body.appendChild(notif);
    
    setTimeout(() => {
      notif.remove();
      style.remove();
    }, 2000);
  }

  // Close modals when clicking outside
  window.addEventListener('click', (e) => {
    const addModal = document.getElementById('addUserModal');
    const editModal = document.getElementById('editUserModal');
    const deleteModal = document.getElementById('deleteUserModal');
    const reactivateModal = document.getElementById('reactivateUserModal');
    if (e.target === addModal) closeAddUserModal();
    if (e.target === editModal) closeEditUserModal();
    if (e.target === deleteModal) closeDeleteUserModal();
    if (e.target === reactivateModal) closeReactivateUserModal();
  });
});
