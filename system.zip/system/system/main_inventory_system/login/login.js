// Login form handler
document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('login');
    const errorMessage = document.getElementById('login_error_message');

    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();

            // Hide previous error
            if (errorMessage) {
                errorMessage.style.display = 'none';
            }

            // Get form data
            const formData = new FormData(loginForm);

            try {
                const response = await fetch('login-function.php', {
                    method: 'POST',
                    body: formData
                });

                const text = await response.text();
                console.log('Response:', text); // Debug log
                
                const data = JSON.parse(text);

                if (data.success) {
                    // Redirect on success
                    window.location.href = data.redirect;
                } else {
                    // Show error message
                    if (errorMessage) {
                        errorMessage.textContent = data.message;
                        errorMessage.style.display = 'block';
                    } else {
                        alert(data.message);
                    }
                }
            } catch (error) {
                console.error('Login error:', error);
                console.error('Full error:', error.message);
                if (errorMessage) {
                    errorMessage.textContent = 'Login system error. Check console.';
                    errorMessage.style.display = 'block';
                } else {
                    alert('An error occurred. Please try again.');
                }
            }
        });
    }
});
