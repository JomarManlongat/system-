<?php 
session_name('INVENTORY_SESSION');
session_start();

// Authentication check
if (!isset($_SESSION['UserID']) || empty($_SESSION['UserID'])) {
    header('Location: ../login/index.php');
    exit;
}

// Staff role check - check both 'Role' and 'roles' session variables
$userRole = $_SESSION['Role'] ?? $_SESSION['roles'] ?? '';
if (strtolower($userRole) !== 'staff') {
    header('Location: ../login/index.php');
    exit;
}

include '../nocache.php'; 
?>
<?php
// Get logged-in user's full name and extract first name only
$full_name = isset($_SESSION['user_name']) && !empty($_SESSION['user_name']) 
    ? $_SESSION['user_name'] 
    : (isset($_SESSION['username']) ? $_SESSION['username'] : 'User');

// Extract first name (everything before the first space)
$logged_username = explode(' ', trim($full_name))[0];
?>
<?php
// Determine session location and whether Orders should be shown to this staff user
$sess_loc = $_SESSION['user_location'] ?? $_SESSION['sso_source'] ?? '';
$show_orders = true;
if (strtolower($userRole) === 'staff') {
    $locLower = strtolower((string)$sess_loc);
    // Hide Orders when staff location is explicitly 'room' (or the legacy 'orders' token)
    if ($locLower === 'room' || $locLower === 'orders') {
        $show_orders = false;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Management - Lunera Hotel</title>
    <link rel="stylesheet" type="text/css" href="../admin-page/admin_inv_man.css">
    <link rel="icon" href="../logos/moon.png" type="image/png">
    <!-- Responsive CSS consolidated into admin_inv_man.css -->
</head>
<body>
    <?php $nav_context='staff'; include __DIR__ . '/../admin-page/includes/nav.php'; ?>
    <div id="content" style="margin-left:300px; padding:20px; flex:1;">
        
        <div id="inventory" class="page">
            <div class="header-page-admin">
                <h2> Inventory</h2>
            </div>
            <div class="whole_box">
                <div class="inventory_functions">
                    <div id="for_form_inventory">
                        <form method="POST" id="form_filters">
                             <input type="search" name="search" id="search_bar_inventory"
                                placeholder=" Search Items by name or ID ...">
                            <select name="location" id="location">
                                <option value="All">All Locations</option>
                                <option value="Restaurant">Restaurant</option>
                                <option value="Room">Room</option>
                            </select>

                        </form>
                    </div>
                    <button class="blue_design" onclick="openUsage()">Record Usage</button>

                </div>

                <div class="inventory_table">
                    <table>
                        <thead>
                            <tr>
                                <th>Item ID</th>
                                <th>Item Name</th>
                                <th>Stock</th>
                                <th>Supplier</th>
                                <th>Location</th>
                                <th>Expiry Date</th>
                                <th>Condition</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="inventory_table_body">
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <?php if ($show_orders): ?>
        <div id="orders" class="page">
            <div class="header-page-admin">
                <h2> Order</h2>
            </div>
            <div class="whole_box">
                <div class="orders_design">
                    <!-- Optional search, keeps design minimal; hidden by default if not styled -->
                    <!-- <input type="search" id="search_bar_orders" class="search_bar" placeholder=" Search orders by ID, supplier or status ..."> -->
                    <!-- New Order button removed - staff cannot create orders -->
                </div>
                <div class="inventory_table">
                    <table>
                        <thead>
                            <tr>
                                <th>Order ID</th>
                                <th>Supplier</th>
                                    <th>Location</th>
                                    <th>Items</th>
                                <th>Total</th>
                                <th>Status</th>
                                <th>Date</th>
                                <th style="text-align:center">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="orders_table_body"></tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <div id="reports" class="page">
            <div class="header-page-admin">
                <h2> Reports</h2>
            </div>
            <div class="whole_box">
                <div class="reports-header">
                    <div>
                        <h1>Comprehensive Report Dashboard</h1>
                        <p class="muted">Select a report type and apply filters to view data.</p>
                    </div>
                    <button id="reports_print_btn" class="btn btn-print" type="button">
                        <span style="margin-right: 4px;">🖨</span> Print
                    </button>
                </div>

                <div class="reports-filters">
                    <!-- First row: Always visible -->
                    <div class="filter-row-primary">
                        <div class="filter-item" style="flex: 0 0 200px;">
                            <label>Report Type</label>
                            <select id="report_type" class="filter-select">
                                <option value="inventory" selected>Inventory Stock</option>
                                <?php if ($show_orders): ?>
                                <option value="orders">Purchase Orders</option>
                                <?php endif; ?>
                            </select>
                        </div>
                        <div class="filter-item" style="flex: 1 1 auto; min-width: 200px;">
                            <label>Search</label>
                            <input id="report_search" class="filter-input" type="search" placeholder="Search..." />
                        </div>
                        <div class="filter-item" style="flex: 0 0 120px;">
                            <label>Top</label>
                            <input id="show_top" type="number" min="1" class="filter-input" placeholder="e.g. 10" />
                        </div>
                    </div>

                    <!-- Second row: Dynamic filters (show/hide based on report type) -->
                    <div class="filter-row-secondary">
                        <div class="filter-item" style="flex: 0 0 200px;">
                            <label>Location</label>
                            <select id="general_location_filter" class="filter-select">
                                <option value="All" selected>All Locations</option>
                                <option value="Restaurant">Restaurant</option>
                                <option value="Room">Room</option>
                            </select>
                        </div>
                        <div class="filter-item" id="date_range_filter" style="display:none; flex: 1 1 auto;">
                            <label>Date Range</label>
                            <div class="date-range">
                                <input id="date_from" type="date" class="filter-input" />
                                <span class="date-sep">–</span>
                                <input id="date_to" type="date" class="filter-input" />
                            </div>
                        </div>
                        <div class="filter-item" id="location_filter_wrapper" style="display:none; flex: 0 0 200px;">
                            <label>Supplier Location</label>
                            <select id="location_filter" class="filter-select">
                                <option value="All" selected>All Locations</option>
                                <option value="Restaurant">Restaurant</option>
                                <option value="Room">Room</option>
                            </select>
                        </div>
                        <div class="filter-item" id="transaction_type_filter" style="display:none; flex: 0 0 200px;">
                            <label>Transaction Type</label>
                            <select id="transaction_type" class="filter-select">
                                <option value="all" selected>All Types</option>
                                <option value="Stock Added">Stock Added</option>
                                <option value="Usage Recorded">Usage Recorded</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="reports-table-title" id="reports_table_title">Transactions <span id="reports_scope_badge" class="scope-badge" style="margin-left:12px; font-size:13px; padding:4px 8px; border-radius:12px; background:#eef; color:#334; display:inline-block;">Scope</span></div>
                <div class="inventory_table reports_table">
                    <table id="reports_table">
                        <thead id="reports_table_head">
                            <tr>
                                <th>ID</th>
                                <th>Item</th>
                                <th>Qty</th>
                                <th>Type</th>
                                <th>User</th>
                                <th>Date/Time</th>
                            </tr>
                        </thead>
                        <tbody id="reports_table_body"></tbody>
                    </table>
                </div>

                <div class="reports-notes">
                    <label for="report_notes">Report Notes</label>
                    <textarea id="report_notes" placeholder="Type your notes for this report here..."></textarea>
                    <button id="save_report_notes" class="btn btn-primary" type="button">Save Notes</button>
                </div>
            </div>
        </div>
    </div>
    <?php include __DIR__ . '/inventory/record_usage_modal.php'; ?>
    <?php include __DIR__ . '/orders/order_modals.php'; ?>
    
    <script src="inventory/record_usage.js"></script>
    <script src="orders/orders_management.js"></script>
    <script src="../admin-page/admin_int_man.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function(){
        // Reports scope badge setup based on server-side session
        try {
            var badge = document.getElementById('reports_scope_badge');
            if (badge) {
                var sessionRole = '<?php echo addslashes(strtolower($_SESSION['Role'] ?? $_SESSION['roles'] ?? '')); ?>';
                var sessionLocation = '<?php echo addslashes($_SESSION['user_location'] ?? ''); ?>';

                var label = 'Scope';
                var bg = '#eef';
                var color = '#334';

                if (sessionRole === 'admin') {
                    label = 'All (admin)';
                    bg = '#6b5cff';
                    color = '#fff';
                } else {
                    if (!sessionLocation || sessionLocation === 'NULL') {
                        label = 'Both Locations';
                        bg = '#cbd5e1';
                        color = '#0f172a';
                    } else if (sessionLocation.toLowerCase() === 'restaurant') {
                        label = 'Restaurant';
                        bg = '#d1fae5';
                        color = '#065f46';
                    } else if (sessionLocation.toLowerCase() === 'room') {
                        label = 'Room';
                        bg = '#e0f2fe';
                        color = '#0369a1';
                    } else {
                        label = sessionLocation;
                        bg = '#f3f4f6';
                        color = '#111827';
                    }
                }

                badge.textContent = label;
                badge.style.background = bg;
                badge.style.color = color;
            }
        } catch (e) {
            console.error('Failed to set scope badge', e);
        }
    });
    </script>
</body>
</html>