<?php
// Staff page receive order - uses admin receive order
require(__DIR__ . "/../../admin-page/orders/receive_order.php");
?>
