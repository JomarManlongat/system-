-- Update existing ingredient system to add cost tracking
-- Run this if you already installed the ingredient system

USE hotel_restaurant;

-- Check if cost_per_unit column exists, if not add it
ALTER TABLE current_ingredients_stock 
ADD COLUMN IF NOT EXISTS cost_per_unit DECIMAL(10,2) NOT NULL DEFAULT 0 COMMENT 'Cost per unit for calculating expenses';

-- Update sample prices for existing ingredients
UPDATE current_ingredients_stock SET cost_per_unit = 45.00 WHERE ingredient_name = 'Rice';
UPDATE current_ingredients_stock SET cost_per_unit = 180.00 WHERE ingredient_name = 'Chicken Breast';
UPDATE current_ingredients_stock SET cost_per_unit = 320.00 WHERE ingredient_name = 'Beef Shank';
UPDATE current_ingredients_stock SET cost_per_unit = 250.00 WHERE ingredient_name = 'Pork Leg';
UPDATE current_ingredients_stock SET cost_per_unit = 450.00 WHERE ingredient_name = 'Shrimp';
UPDATE current_ingredients_stock SET cost_per_unit = 280.00 WHERE ingredient_name = 'Squid';
UPDATE current_ingredients_stock SET cost_per_unit = 380.00 WHERE ingredient_name = 'Tuna';
UPDATE current_ingredients_stock SET cost_per_unit = 220.00 WHERE ingredient_name = 'Mussels';
UPDATE current_ingredients_stock SET cost_per_unit = 35.00 WHERE ingredient_name = 'Flour';
UPDATE current_ingredients_stock SET cost_per_unit = 55.00 WHERE ingredient_name = 'Sugar';
UPDATE current_ingredients_stock SET cost_per_unit = 15.00 WHERE ingredient_name = 'Salt';
UPDATE current_ingredients_stock SET cost_per_unit = 120.00 WHERE ingredient_name = 'Oil';
UPDATE current_ingredients_stock SET cost_per_unit = 85.00 WHERE ingredient_name = 'Milk';
UPDATE current_ingredients_stock SET cost_per_unit = 8.00 WHERE ingredient_name = 'Eggs';
UPDATE current_ingredients_stock SET cost_per_unit = 380.00 WHERE ingredient_name = 'Cheese';
UPDATE current_ingredients_stock SET cost_per_unit = 420.00 WHERE ingredient_name = 'Bacon';
UPDATE current_ingredients_stock SET cost_per_unit = 350.00 WHERE ingredient_name = 'Ham';
UPDATE current_ingredients_stock SET cost_per_unit = 65.00 WHERE ingredient_name = 'Lettuce';
UPDATE current_ingredients_stock SET cost_per_unit = 75.00 WHERE ingredient_name = 'Tomatoes';
UPDATE current_ingredients_stock SET cost_per_unit = 45.00 WHERE ingredient_name = 'Onions';
UPDATE current_ingredients_stock SET cost_per_unit = 95.00 WHERE ingredient_name = 'Garlic';
UPDATE current_ingredients_stock SET cost_per_unit = 150.00 WHERE ingredient_name = 'Peanut Sauce';
UPDATE current_ingredients_stock SET cost_per_unit = 65.00 WHERE ingredient_name = 'Soy Sauce';
UPDATE current_ingredients_stock SET cost_per_unit = 35.00 WHERE ingredient_name = 'Vinegar';
UPDATE current_ingredients_stock SET cost_per_unit = 280.00 WHERE ingredient_name = 'Chocolate';
UPDATE current_ingredients_stock SET cost_per_unit = 850.00 WHERE ingredient_name = 'Matcha Powder';
UPDATE current_ingredients_stock SET cost_per_unit = 420.00 WHERE ingredient_name = 'Coffee Beans';
UPDATE current_ingredients_stock SET cost_per_unit = 180.00 WHERE ingredient_name = 'Cream';
UPDATE current_ingredients_stock SET cost_per_unit = 45.00 WHERE ingredient_name = 'Pineapple';
UPDATE current_ingredients_stock SET cost_per_unit = 85.00 WHERE ingredient_name = 'Watermelon';
UPDATE current_ingredients_stock SET cost_per_unit = 12.00 WHERE ingredient_name = 'Lemon';
UPDATE current_ingredients_stock SET cost_per_unit = 95.00 WHERE ingredient_name = 'Dragon Fruit';
UPDATE current_ingredients_stock SET cost_per_unit = 120.00 WHERE ingredient_name = 'Tapioca Pearls';
UPDATE current_ingredients_stock SET cost_per_unit = 85.00 WHERE ingredient_name = 'Cola Syrup';
UPDATE current_ingredients_stock SET cost_per_unit = 5.00 WHERE ingredient_name = 'Ice';

-- Verify the update
SELECT ingredient_name, cost_per_unit, 
       (current_quantity * cost_per_unit) as inventory_value
FROM current_ingredients_stock
ORDER BY ingredient_name;

SELECT 'Cost tracking enabled!' as status,
       SUM(current_quantity * cost_per_unit) as total_inventory_value
FROM current_ingredients_stock;
