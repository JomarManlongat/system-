# Hotel Lunera Restaurant - Ingredient Management System

## Overview
This system has been upgraded to include comprehensive ingredient tracking and management. The random 15-25% loss calculation has been removed and replaced with actual ingredient-based cost tracking.

## New Features

### 1. Ingredient Inventory Management
- **Current Stock Tracking**: Real-time tracking of all ingredients in the restaurant
- **Minimum Stock Levels**: Set minimum thresholds for each ingredient
- **Low Stock Alerts**: Automatic alerts when ingredients fall below minimum levels
- **Stock Transfer Logging**: Complete audit trail of all stock movements

### 2. Menu Item - Ingredient Linking
- **Recipe Management**: Define exact ingredients and quantities needed for each menu item
- **Two-Step Menu Creation**: 
  - Step 1: Create menu item with basic details
  - Step 2: Assign ingredients and quantities
- **Flexible Editing**: Modify ingredient requirements at any time

### 3. Automatic Stock Deduction
- **Order Processing**: Ingredients are automatically deducted when orders are completed
- **Usage Logging**: Every ingredient usage is logged with order reference
- **Accurate Costing**: Real-time cost tracking based on actual ingredient consumption

### 4. Integration with Main Inventory System
- **Low Stock Redirection**: When ingredients run low, admins can access the main inventory system
- **Stock Transfer API**: Receive stock from the main inventory system
- **Seamless Synchronization**: Automatic updates to restaurant inventory

## Installation

### Step 1: Run Database Migration
Execute the SQL script to add new tables:
```bash
mysql -u root -p hotel_restaurant < Database/add_ingredient_system.sql
```

Or manually import via phpMyAdmin:
1. Open phpMyAdmin
2. Select `hotel_restaurant` database
3. Go to Import tab
4. Select `Database/add_ingredient_system.sql`
5. Click "Go"

### Step 2: Verify File Structure
Ensure all new files are in place:
```
admin/
├── get_ingredients.php          (Fetch all available ingredients)
├── get_menu_ingredients.php     (Get ingredients for a specific menu item)
├── save_menu_ingredients.php    (Save ingredient assignments)
├── check_low_stock.php          (Check for low stock items)
├── receive_stock.php            (API endpoint for stock transfer)
```

### Step 3: Configure Main Inventory System Integration
Update the inventory system URL in `admin/assets/js/admin.js` if needed:
```javascript
// Line ~XXX in admin.js
goToInventoryBtn?.addEventListener('click', function() {
    window.location.href = 'http://localhost/main_inventory_system/login/';
});
```

## Database Schema

### New Tables

#### 1. current_ingredients_stock
Stores current ingredient inventory levels.
```sql
- id (INT, PRIMARY KEY)
- ingredient_name (VARCHAR(100))
- unit (VARCHAR(50)) - e.g., 'kg', 'liter', 'pieces'
- current_quantity (DECIMAL(10,2))
- min_quantity (DECIMAL(10,2)) - Minimum stock level
- last_updated (TIMESTAMP)
```

#### 2. menu_ingredients
Links menu items with their required ingredients.
```sql
- id (INT, PRIMARY KEY)
- menu_id (INT, FOREIGN KEY → menu.id)
- ingredient_id (INT, FOREIGN KEY → current_ingredients_stock.id)
- quantity_required (DECIMAL(10,2)) - Quantity needed per serving
```

#### 3. ingredient_usage_log
Tracks all ingredient usage.
```sql
- id (INT, PRIMARY KEY)
- ingredient_id (INT, FOREIGN KEY)
- order_id (INT, FOREIGN KEY)
- quantity_used (DECIMAL(10,2))
- usage_date (TIMESTAMP)
- notes (VARCHAR(255))
```

#### 4. stock_transfer_log
Logs stock transfers from main inventory system.
```sql
- id (INT, PRIMARY KEY)
- ingredient_id (INT, FOREIGN KEY)
- quantity_transferred (DECIMAL(10,2))
- transferred_by (VARCHAR(100))
- transfer_date (TIMESTAMP)
- notes (VARCHAR(255))
```

## Usage Guide

### For Admins

#### Adding a New Menu Item
1. Click "Add Menu Item" button
2. Fill in basic details (name, description, price, category, image)
3. Click "Add Item"
4. **NEW**: Ingredient modal will appear
5. Select ingredients from dropdown
6. Enter quantity required per serving
7. Click "+ Add Ingredient" to add more ingredients
8. Click "Save Ingredients" or "Skip" to continue

#### Editing Menu Item Ingredients
1. Click "Edit" button on any menu item
2. Update menu item details as needed
3. Click "Save Changes"
4. **NEW**: Ingredient modal will appear with current ingredients
5. Modify ingredients as needed
6. Click "Save Ingredients"

#### Managing Low Stock
1. Check the "Low Stock Alert" box at the bottom of the admin dashboard
2. Review ingredients that are below minimum levels
3. Click "Go to Inventory System" to restock
4. Log into main inventory system
5. Transfer required stock

### For Cashiers

**No changes to cashier workflow**. The system automatically deducts ingredients when orders are completed and payment is processed.

## API Endpoints

### Receive Stock Transfer
**Endpoint**: `admin/receive_stock.php`
**Method**: POST
**Parameters**:
- `ingredient_name` (string, required) - Name of the ingredient
- `quantity` (float, required) - Quantity to add
- `transferred_by` (string) - Name of person transferring
- `notes` (string) - Additional notes

**Response**:
```json
{
    "status": "success",
    "message": "Stock transferred successfully",
    "new_quantity": 50.00
}
```

**Example Usage** (from main inventory system):
```php
$data = [
    'ingredient_name' => 'Rice',
    'quantity' => 25.00,
    'transferred_by' => 'John Doe',
    'notes' => 'Weekly restock'
];

$ch = curl_init('http://localhost/HotelLuneraRestaurant/admin/receive_stock.php');
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);
```

## Changes from Previous Version

### Removed
- ❌ Random 15-25% loss calculation in revenue charts
- ❌ Artificial loss data generation

### Added
- ✅ Real ingredient tracking system
- ✅ Ingredient-based cost calculation
- ✅ Low stock alerts
- ✅ Stock transfer logging
- ✅ Usage history tracking
- ✅ Integration with main inventory system

### Modified
- 📝 Admin dashboard now shows only revenue (no fake loss)
- 📝 Menu item creation is now a two-step process
- 📝 Order completion automatically deducts ingredients
- 📝 Charts now show "Revenue" instead of "Profit/Loss"

## Troubleshooting

### Issue: Ingredients not deducting after order completion
**Solution**: Ensure menu items have ingredients assigned. Check `menu_ingredients` table.

### Issue: Low stock alert not showing
**Solution**: 
1. Check if ingredients are below `min_quantity`
2. Verify `check_low_stock.php` is accessible
3. Check browser console for JavaScript errors

### Issue: Cannot connect to main inventory system
**Solution**: 
1. Verify main inventory system is running
2. Check URL in `admin.js`
3. Ensure cross-origin requests are allowed

### Issue: Stock transfer API returns error
**Solution**:
1. Verify ingredient name matches exactly (case-sensitive)
2. Check if ingredient exists in `current_ingredients_stock` table
3. Ensure quantity is a positive number

## Sample Ingredients

The system comes pre-loaded with 35 common ingredients:
- Rice, Chicken Breast, Beef Shank, Pork Leg
- Shrimp, Squid, Tuna, Mussels
- Flour, Sugar, Salt, Oil, Milk, Eggs
- Cheese, Bacon, Ham
- Lettuce, Tomatoes, Onions, Garlic
- Various sauces and beverages ingredients

## Future Enhancements

Potential improvements for future versions:
- Ingredient cost tracking for profit margin analysis
- Supplier management
- Automatic reorder suggestions
- Inventory forecasting
- Batch ingredient updates
- Barcode scanning support
- Mobile app for stock checking

## Support

For issues or questions:
1. Check the troubleshooting section
2. Review database logs in phpMyAdmin
3. Check browser console for JavaScript errors
4. Verify all files are properly uploaded

## Version History

**Version 2.0** (Current)
- Added comprehensive ingredient management system
- Removed artificial loss calculation
- Integrated with main inventory system
- Added two-step menu item creation

**Version 1.0** (Previous)
- Basic POS system with menu management
- Random loss calculation (15-25%)
- Simple revenue tracking
