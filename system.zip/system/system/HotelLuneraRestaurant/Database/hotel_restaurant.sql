-- Hotel Restaurant Database Backup
-- Generated: 2025-11-05

SET FOREIGN_KEY_CHECKS=0;

CREATE DATABASE IF NOT EXISTS hotel_restaurant;
USE hotel_restaurant;

DROP TABLE IF EXISTS login;
CREATE TABLE login (
  id int NOT NULL AUTO_INCREMENT,
  username varchar(50) NOT NULL,
  password varchar(255) NOT NULL,
  role enum('admin','cashier') NOT NULL DEFAULT 'cashier',
  PRIMARY KEY (id)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO login (id, username, password, role) VALUES 
('1', 'Ryan', '5f4dcc3b5aa765d61d8327deb882cf99', 'admin'),
('2', 'Mariah', '5f4dcc3b5aa765d61d8327deb882cf99', 'cashier');

DROP TABLE IF EXISTS menu;
CREATE TABLE menu (
  id int NOT NULL AUTO_INCREMENT,
  name varchar(100) NOT NULL,
  description text,
  price decimal(10,2) NOT NULL,
  image varchar(255) DEFAULT 'noimage.jpg',
  status enum('available','unavailable') DEFAULT 'available',
  category varchar(50) DEFAULT NULL,
  sugar_levels varchar(255) DEFAULT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO menu (id, name, description, price, image, status, category, sugar_levels) VALUES
('1', 'Crispy Pata', 'Crispy deep-fried pork leg served with soy-vinegar dip', '799.00', 'crispy_pata.jpg', 'available', 'Main Courses', NULL),
('2', 'Beef Kare-Kare', 'Beef shank and vegetables in peanut sauce', '850.00', 'beef_karekare.jpg', 'available', 'Main Courses', NULL),
('3', 'Seafood Paella', 'Spanish rice dish with shrimp, mussels, and squid', '950.00', 'seafood_paella.jpg', 'available', 'Main Courses', NULL),
('4', 'Chicken Cordon Bleu', 'Chicken breast stuffed with ham and cheese', '380.00', 'chicken_cordonbleu.jpg', 'available', 'Main Courses', NULL),
('5', 'Pasta Carbonara', 'Creamy pasta with bacon and parmesan cheese', '250.00', 'pasta_carbonara.jpg', 'available', 'Main Courses', NULL),
('6', 'Grilled Tuna Belly', 'Fresh tuna belly grilled to perfection', '420.00', 'grilled_tuna.jpg', 'available', 'Main Courses', NULL),
('7', 'Roast Chicken ', 'Roasted chicken infused with rosemary herbs', '360.00', 'roast_chicken.jpg', 'available', 'Main Courses', NULL),
('8', 'Pork Sisig', 'Sizzling chopped pork face with egg and chili', '299.00', 'pork_sisig.jpg', 'available', 'Main Courses', NULL),
('9', 'Caesar Salad Bites', 'Mini romaine lettuce with caesar dressing', '180.00', 'caesar_bites.jpg', 'unavailable', 'Appetizers', NULL),
('10', 'Calamares Fritos', 'squid rings that are battered deep-fried until golden crispy.', '220.00', 'calamares.jpg', 'unavailable', 'Appetizers', NULL),
('11', 'Shrimp Gambas', 'shrimp sautéed in olive oil with lots of garlic and chili peppers.', '250.00', 'shrimp_gambas.jpg', 'available', 'Appetizers', NULL),
('12', 'Tuna Tartare', 'Fresh tuna cubes in citrus dressing', '270.00', 'tuna_tartare.jpg', 'available', 'Appetizers', NULL),
('13', 'Vegetable Spring Rolls', 'Crispy spring rolls with sweet chili sauce', '150.00', 'spring_rolls.jpg', 'available', 'Appetizers', NULL),
('14', 'Prosciutto-Wrapped Melon', 'Sweet melon wrapped in prosciutto ham', '200.00', 'prosciutto_melon.jpg', 'available', 'Appetizers', NULL),
('15', 'Baked Oysters with Cheese', 'Fresh oysters baked with garlic and cheese', '300.00', 'baked_oysters.jpg', 'unavailable', 'Appetizers', NULL),
('16', 'Chicharon Bulaklak Crispy', 'Deep fried ruffled pork fat served with vinegar dip', '250.00', 'chicharon_bulaklak.jpg', 'unavailable', 'Appetizers', NULL),
('17', 'Matcha Cheesecake', 'Creamy cheesecake infused with matcha', '220.00', 'matcha_cheesecake.jpg', 'available', 'Dessert', NULL),
('18', 'Chocolate Lava Cake', 'Warm cake with molten chocolate center', '180.00', 'lava_cake.jpg', 'available', 'Dessert', NULL),
('19', 'Chocolate Mousse', 'Layers of dark, milk and white chocolate mousse', '200.00', 'choco_mousse.jpg', 'available', 'Dessert', NULL),
('20', 'Leche Flan', 'Traditional Filipino caramel custard dessert', '120.00', 'leche_flan.jpg', 'available', 'Dessert', NULL),
('21', 'Halo-Halo Special', 'Mixed fruits, beans, and crushed ice dessert', '150.00', 'halo_halo.jpg', 'available', 'Dessert', NULL),
('22', 'Caramel White Mocha', 'Sweet, creamy, and caramel-kissed over ice.', '250.00', 'Caramel White Mocha.jpg', 'available', 'Dessert', NULL),
('23', 'Matcha Tiramisu', 'Tiramisu with matcha flavor twist', '230.00', 'matcha_tiramisu.jpg', 'available', 'Dessert', NULL),
('24', 'Tiramisu', 'creamy layers of mascarpone and coffee-soaked ladyfingers.', '270.00', 'Tiramisu.jpg', 'available', 'Dessert', NULL),
('25', 'Pineapple Juice', 'Fresh pineapple juice', '90.00', 'pineapple_juice.jpg', 'available', 'Beverages', NULL),
('26', 'Watermelon Shake', 'Fresh watermelon blended', '100.00', 'watermelon_shake.jpg', 'available', 'Beverages', NULL),
('27', 'Iced Coffee Latte', 'Chilled coffee with milk and ice', '110.00', 'iced_coffee.jpg', 'available', 'Beverages', NULL),
('28', 'Hot Chocolate', 'Creamy chocolate coffe', '80.00', 'hot_chocolate.jpg', 'available', 'Beverages', NULL),
('29', 'Lemonade', 'Freshly squeezed lemon juice with syrup', '90.00', 'lemonade.jpg', 'available', 'Beverages', NULL),
('30', 'Tang Lemon Iced Tea', 'Powdered/ready blend iced tea, budget size.', '75.00', 'Tang Lemon Iced Tea.jpg', 'available', 'Beverages', NULL),
('31', 'Milk Tea with Pearls', 'Classic milk tea with tapioca pearls', '120.00', 'milk_tea.jpg', 'available', 'Beverages', NULL),
('32', 'Dragon Fruit Shake', 'Bright pink dragon fruit blended drink', '150.00', 'dragonfruit_shake.jpg', 'available', 'Beverages', NULL),
('35', 'Iced Cola', 'Taste the coldness of the fresh and sweet Iced Cola', '25.00', 'iced_cola.jfif', 'available', 'Beverages', '30%');

DROP TABLE IF EXISTS orders;
CREATE TABLE orders (
  id int NOT NULL AUTO_INCREMENT,
  user_id int NOT NULL,
  status enum('pending','completed','cancelled') DEFAULT 'pending',
  order_date timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY user_id (user_id),
  CONSTRAINT orders_ibfk_1 FOREIGN KEY (user_id) REFERENCES login (id) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO orders (id, user_id, status, order_date) VALUES
('1', '2', 'completed', '2025-10-31 18:26:10'),
('2', '2', 'completed', '2025-10-31 18:33:57'),
('3', '2', 'completed', '2025-10-31 18:38:20'),
('4', '2', 'pending', '2025-10-31 18:44:23');

DROP TABLE IF EXISTS order_items;
CREATE TABLE order_items (
  id int NOT NULL AUTO_INCREMENT,
  order_id int NOT NULL,
  menu_id int NOT NULL,
  quantity int DEFAULT '1',
  sugar_level varchar(10) DEFAULT '100%',
  created_at timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY order_id (order_id),
  KEY menu_id (menu_id),
  CONSTRAINT order_items_ibfk_1 FOREIGN KEY (order_id) REFERENCES orders (id) ON DELETE CASCADE,
  CONSTRAINT order_items_ibfk_2 FOREIGN KEY (menu_id) REFERENCES menu (id) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO order_items (id, order_id, menu_id, quantity, sugar_level, created_at) VALUES
('8', '3', '25', '2', '100%', '2025-10-31 18:38:20'),
('9', '3', '2', '2', '100%', '2025-10-31 18:38:22'),
('10', '3', '3', '5', '100%', '2025-10-31 18:38:23');

DROP TABLE IF EXISTS profits;
CREATE TABLE profits (
  id int NOT NULL AUTO_INCREMENT,
  order_id int NOT NULL,
  cashier_id int NOT NULL,
  total_amount decimal(10,2) NOT NULL,
  profit_date timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  payment_method varchar(50) DEFAULT 'Cash',
  PRIMARY KEY (id),
  KEY order_id (order_id),
  KEY cashier_id (cashier_id),
  CONSTRAINT profits_ibfk_1 FOREIGN KEY (order_id) REFERENCES orders (id) ON DELETE CASCADE,
  CONSTRAINT profits_ibfk_2 FOREIGN KEY (cashier_id) REFERENCES login (id) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO profits (id, order_id, cashier_id, total_amount, profit_date, payment_method) VALUES
('1', '3', '2', '6630.00', '2025-10-31 18:38:31', 'Credit Card');

SET FOREIGN_KEY_CHECKS=1;

