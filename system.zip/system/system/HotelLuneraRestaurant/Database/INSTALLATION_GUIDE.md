# Installation and Setup Guide - Ingredient Management System

## Quick Start (5 Minutes)

### Step 1: Import Database Changes
1. Open phpMyAdmin (http://localhost/phpmyadmin)
2. Select the `hotel_restaurant` database
3. Click on the "Import" tab
4. Click "Choose File" and select: `Database/add_ingredient_system.sql`
5. Click "Go" at the bottom
6. Wait for success message

### Step 2: Verify Installation
Run the verification script:
1. In phpMyAdmin, click on "SQL" tab
2. Copy the contents of `Database/ingredient_system_verification.sql`
3. Paste and click "Go"
4. You should see: "System Ready!" with counts of ingredients and tables

### Step 3: Test the System
1. Open the admin dashboard: http://localhost/HotelLuneraRestaurant/admin/admin.php
2. Login as admin (username: Ryan, password: password)
3. You should see the new "Low Stock Alert" section at the bottom (if there are low stock items)
4. Click "Add Menu Item" to test the two-step process
5. Click "Edit" on any menu item to assign ingredients

## What's New

### ✅ Features Added

1. **Ingredient Inventory System**
   - 35 pre-loaded common ingredients
   - Real-time stock tracking
   - Minimum stock level monitoring
   - Low stock alerts

2. **Two-Step Menu Management**
   - Step 1: Basic menu item info (name, price, category)
   - Step 2: Ingredient assignment (select ingredients and quantities)
   - Works for both Add and Edit operations

3. **Automatic Stock Deduction**
   - Ingredients deducted when orders are completed
   - Complete usage logging for audit trail
   - Prevents negative stock (will show warnings)

4. **Low Stock Management**
   - Alert box appears when ingredients run low
   - Shows which ingredients need restocking
   - Button to redirect to main inventory system

5. **Main Inventory Integration**
   - API endpoint to receive stock transfers
   - Automatic synchronization
   - Transfer logging for accountability

### ❌ Features Removed

1. **Random Loss Calculation (15-25%)**
   - Removed from all charts
   - No more fake loss data
   - Charts now show "Revenue" instead of "Profit/Loss"

## File Changes

### New Files Created (9 files)
```
admin/
  ├── get_ingredients.php              (API: Get all ingredients)
  ├── get_menu_ingredients.php         (API: Get menu item ingredients)
  ├── save_menu_ingredients.php        (API: Save ingredient assignments)
  ├── check_low_stock.php              (API: Check low stock items)
  └── receive_stock.php                (API: Receive stock from main system)

Database/
  ├── add_ingredient_system.sql        (Database migration script)
  ├── ingredient_system_verification.sql (Verification queries)
  ├── stock_transfer_integration_example.php (Integration example)
  └── INGREDIENT_SYSTEM_README.md      (Complete documentation)
```

### Modified Files (5 files)
```
admin/
  ├── admin.php                        (Added ingredient modal + low stock alert)
  ├── admin-dashboard.css              (Added ingredient modal styles)
  ├── add_menu_item.php                (Returns menu_id for ingredient step)
  └── assets/js/admin.js               (Added ingredient management logic)

process_payment.php                    (Added ingredient deduction on order completion)
```

## Database Changes

### New Tables (4 tables)
1. `current_ingredients_stock` - Main ingredient inventory
2. `menu_ingredients` - Links menu items with ingredients
3. `ingredient_usage_log` - Tracks ingredient consumption
4. `stock_transfer_log` - Logs stock transfers

### No Changes to Existing Tables
- All existing tables remain untouched
- No data loss
- System is backward compatible

## How It Works

### 1. Adding a Menu Item
```
User clicks "Add Menu Item"
  ↓
Fills basic info (name, price, etc.)
  ↓
Clicks "Add Item"
  ↓
Menu item saved to database
  ↓
Ingredient modal appears automatically
  ↓
User selects ingredients and quantities
  ↓
Clicks "Save Ingredients" (or "Skip")
  ↓
Done! Menu item is ready
```

### 2. Processing an Order
```
Cashier completes order
  ↓
Payment is processed
  ↓
System calculates ingredient usage
  ↓
Ingredients are deducted from stock
  ↓
Usage is logged
  ↓
Order marked as completed
```

### 3. Stock Management
```
Admin views dashboard
  ↓
Low stock alert appears (if any)
  ↓
Admin clicks "Go to Inventory System"
  ↓
Redirected to main inventory system
  ↓
Transfers required stock
  ↓
API updates restaurant inventory
  ↓
Alert disappears when stock is sufficient
```

## Common Tasks

### Task 1: Assign Ingredients to Existing Menu Items
1. Go to admin dashboard
2. Click "Edit" on any menu item
3. Update details if needed, click "Save Changes"
4. Ingredient modal will appear
5. Select ingredients and enter quantities
6. Click "Save Ingredients"

### Task 2: Check Current Stock Levels
```sql
SELECT ingredient_name, current_quantity, unit, min_quantity
FROM current_ingredients_stock
ORDER BY ingredient_name;
```

### Task 3: View Ingredient Usage History
```sql
SELECT iul.usage_date, cis.ingredient_name, iul.quantity_used, 
       cis.unit, iul.order_id
FROM ingredient_usage_log iul
JOIN current_ingredients_stock cis ON cis.id = iul.ingredient_id
ORDER BY iul.usage_date DESC
LIMIT 50;
```

### Task 4: Manually Add Stock (Without Main System)
```sql
UPDATE current_ingredients_stock 
SET current_quantity = current_quantity + 25.00
WHERE ingredient_name = 'Rice';

-- Log the manual transfer
INSERT INTO stock_transfer_log 
(ingredient_id, quantity_transferred, transferred_by, notes)
SELECT id, 25.00, 'Manual Entry', 'Emergency restock'
FROM current_ingredients_stock 
WHERE ingredient_name = 'Rice';
```

### Task 5: Add a New Ingredient
```sql
INSERT INTO current_ingredients_stock 
(ingredient_name, unit, current_quantity, min_quantity)
VALUES ('Butter', 'kg', 10.00, 2.00);
```

## Integration with Main Inventory System

### Option 1: Use the Example File
1. Copy `Database/stock_transfer_integration_example.php` to your main inventory system
2. Modify the form to match your system's design
3. Use the `transferStockToRestaurant()` function when transferring stock

### Option 2: Direct API Call
```php
$data = [
    'ingredient_name' => 'Rice',
    'quantity' => 25.00,
    'transferred_by' => $_SESSION['username'],
    'notes' => 'Weekly restock'
];

$ch = curl_init('http://localhost/HotelLuneraRestaurant/admin/receive_stock.php');
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);

$result = json_decode($response, true);
if ($result['status'] === 'success') {
    echo "Transfer successful!";
}
```

## Troubleshooting

### Problem: "Table doesn't exist" error
**Solution**: Run the migration script `add_ingredient_system.sql` in phpMyAdmin

### Problem: Ingredients not showing in dropdown
**Solution**: 
1. Check if `current_ingredients_stock` table has data
2. Run: `SELECT COUNT(*) FROM current_ingredients_stock;`
3. If empty, re-run the migration script

### Problem: Stock not deducting after order
**Solution**:
1. Verify menu item has ingredients assigned
2. Check: `SELECT * FROM menu_ingredients WHERE menu_id = X;`
3. If empty, edit the menu item and assign ingredients

### Problem: Low stock alert not appearing
**Solution**:
1. Check if any ingredients are below minimum
2. Run: `SELECT * FROM current_ingredients_stock WHERE current_quantity <= min_quantity;`
3. Check browser console for JavaScript errors
4. Verify `check_low_stock.php` is accessible

### Problem: Cannot transfer stock from main system
**Solution**:
1. Check if main inventory system can reach the restaurant API
2. Test API: `curl -X POST http://localhost/HotelLuneraRestaurant/admin/receive_stock.php -d "ingredient_name=Rice&quantity=10&transferred_by=Test"`
3. Check for CORS issues if systems are on different domains

## Testing Checklist

- [ ] Database migration completed successfully
- [ ] 35 ingredients are loaded in `current_ingredients_stock`
- [ ] Can add new menu item with two-step process
- [ ] Ingredient modal appears after adding menu item
- [ ] Can edit existing menu item and assign ingredients
- [ ] Can view ingredient list in dropdown
- [ ] Low stock alert appears when ingredients are low
- [ ] Can redirect to main inventory system
- [ ] Stock deducts when order is completed
- [ ] Usage is logged in `ingredient_usage_log`
- [ ] API endpoint `receive_stock.php` is accessible
- [ ] Charts show "Revenue" instead of "Profit/Loss"
- [ ] No random loss data in charts

## Support

If you encounter issues:
1. Check this installation guide
2. Review the main README at `Database/INGREDIENT_SYSTEM_README.md`
3. Check phpMyAdmin error logs
4. Check browser console for JavaScript errors
5. Verify all files were uploaded correctly

## Next Steps

After installation:
1. Assign ingredients to all existing menu items
2. Set appropriate minimum stock levels for each ingredient
3. Configure main inventory system integration
4. Train staff on the new two-step menu creation process
5. Monitor stock levels daily

## Success!

Your Hotel Lunera Restaurant system now has:
✅ Real ingredient tracking
✅ Accurate cost calculation
✅ Low stock alerts
✅ Integration-ready API
✅ Complete audit trail
✅ No more fake loss calculations

Enjoy your upgraded system!
