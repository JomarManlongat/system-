-- Add Ingredient Management System to Hotel Restaurant Database
-- This adds ingredient tracking and removes the 15-25% random loss calculation

USE hotel_restaurant;

-- Table to store current ingredient stock in the hotel restaurant
CREATE TABLE IF NOT EXISTS current_ingredients_stock (
  id INT NOT NULL AUTO_INCREMENT,
  ingredient_name VARCHAR(100) NOT NULL,
  unit VARCHAR(50) NOT NULL COMMENT 'kg, liter, pieces, etc',
  current_quantity DECIMAL(10,2) NOT NULL DEFAULT 0,
  min_quantity DECIMAL(10,2) NOT NULL DEFAULT 0 COMMENT 'Minimum stock level before reorder',
  cost_per_unit DECIMAL(10,2) NOT NULL DEFAULT 0 COMMENT 'Cost per unit for calculating expenses',
  last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY unique_ingredient (ingredient_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Table to link menu items with their required ingredients (recipe)
CREATE TABLE IF NOT EXISTS menu_ingredients (
  id INT NOT NULL AUTO_INCREMENT,
  menu_id INT NOT NULL,
  ingredient_id INT NOT NULL,
  quantity_required DECIMAL(10,2) NOT NULL COMMENT 'Quantity needed per serving',
  PRIMARY KEY (id),
  UNIQUE KEY unique_menu_ingredient (menu_id, ingredient_id),
  KEY ingredient_id (ingredient_id),
  CONSTRAINT menu_ingredients_ibfk_1 FOREIGN KEY (menu_id) REFERENCES menu (id) ON DELETE CASCADE,
  CONSTRAINT menu_ingredients_ibfk_2 FOREIGN KEY (ingredient_id) REFERENCES current_ingredients_stock (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Table to log ingredient usage/consumption
CREATE TABLE IF NOT EXISTS ingredient_usage_log (
  id INT NOT NULL AUTO_INCREMENT,
  ingredient_id INT NOT NULL,
  order_id INT NULL,
  quantity_used DECIMAL(10,2) NOT NULL,
  usage_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  notes VARCHAR(255) NULL,
  PRIMARY KEY (id),
  KEY ingredient_id (ingredient_id),
  KEY order_id (order_id),
  CONSTRAINT ingredient_usage_log_ibfk_1 FOREIGN KEY (ingredient_id) REFERENCES current_ingredients_stock (id) ON DELETE CASCADE,
  CONSTRAINT ingredient_usage_log_ibfk_2 FOREIGN KEY (order_id) REFERENCES orders (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Table to log stock transfers from main inventory system
CREATE TABLE IF NOT EXISTS stock_transfer_log (
  id INT NOT NULL AUTO_INCREMENT,
  ingredient_id INT NOT NULL,
  quantity_transferred DECIMAL(10,2) NOT NULL,
  transferred_by VARCHAR(100) NULL COMMENT 'User from main inventory system',
  transfer_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  notes VARCHAR(255) NULL,
  PRIMARY KEY (id),
  KEY ingredient_id (ingredient_id),
  CONSTRAINT stock_transfer_log_ibfk_1 FOREIGN KEY (ingredient_id) REFERENCES current_ingredients_stock (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Sample ingredients (you can add more)
INSERT INTO current_ingredients_stock (ingredient_name, unit, current_quantity, min_quantity, cost_per_unit) VALUES
('Rice', 'kg', 50.00, 10.00, 45.00),
('Chicken Breast', 'kg', 20.00, 5.00, 180.00),
('Beef Shank', 'kg', 15.00, 5.00, 320.00),
('Pork Leg', 'kg', 10.00, 3.00, 250.00),
('Shrimp', 'kg', 8.00, 2.00, 450.00),
('Squid', 'kg', 5.00, 2.00, 280.00),
('Tuna', 'kg', 7.00, 2.00, 380.00),
('Mussels', 'kg', 4.00, 1.00, 220.00),
('Flour', 'kg', 25.00, 5.00, 35.00),
('Sugar', 'kg', 30.00, 5.00, 55.00),
('Salt', 'kg', 10.00, 2.00, 15.00),
('Oil', 'liter', 15.00, 3.00, 120.00),
('Milk', 'liter', 10.00, 2.00, 85.00),
('Eggs', 'pieces', 100, 20, 8.00),
('Cheese', 'kg', 5.00, 1.00, 380.00),
('Bacon', 'kg', 3.00, 1.00, 420.00),
('Ham', 'kg', 4.00, 1.00, 350.00),
('Lettuce', 'kg', 3.00, 1.00, 65.00),
('Tomatoes', 'kg', 5.00, 1.00, 75.00),
('Onions', 'kg', 8.00, 2.00, 45.00),
('Garlic', 'kg', 3.00, 0.50, 95.00),
('Peanut Sauce', 'liter', 2.00, 0.50, 150.00),
('Soy Sauce', 'liter', 3.00, 0.50, 65.00),
('Vinegar', 'liter', 4.00, 1.00, 35.00),
('Chocolate', 'kg', 5.00, 1.00, 280.00),
('Matcha Powder', 'kg', 2.00, 0.50, 850.00),
('Coffee Beans', 'kg', 5.00, 1.00, 420.00),
('Cream', 'liter', 6.00, 1.00, 180.00),
('Pineapple', 'pieces', 20, 5, 45.00),
('Watermelon', 'pieces', 10, 3, 85.00),
('Lemon', 'pieces', 30, 10, 12.00),
('Dragon Fruit', 'pieces', 15, 5, 95.00),
('Tapioca Pearls', 'kg', 3.00, 0.50, 120.00),
('Cola Syrup', 'liter', 5.00, 1.00, 85.00),
('Ice', 'kg', 50.00, 10.00, 5.00)
ON DUPLICATE KEY UPDATE ingredient_name=ingredient_name;

-- End of migration script
