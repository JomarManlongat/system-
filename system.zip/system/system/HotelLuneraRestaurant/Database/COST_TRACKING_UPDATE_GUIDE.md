# Quick Update Guide - Cost Tracking & Inventory Integration

## What's New in This Update

### 1. **Inventory System Button**
- Added green "📦 Inventory System" button next to Logout in admin header
- Links directly to your main inventory system at `http://localhost/main_inventory_system/`
- Opens in new tab for easy navigation

### 2. **Ingredient Cost Tracking**
- Each ingredient now has a `cost_per_unit` field
- Automatically calculates total inventory value
- Tracks actual operational costs based on ingredient usage

### 3. **View Ingredient Stock & Costs Button**
- New button below "Total Menu Items" panel
- Opens comprehensive modal showing:
  - All ingredients with quantities and costs
  - Total value per ingredient (quantity × cost)
  - Low stock indicators
  - Total inventory value

### 4. **Real-Time Cost Analysis**
- Shows Today's actual operational cost (based on ingredients used)
- Displays Today's revenue
- Calculates Today's actual profit (revenue - ingredient cost)
- Shows profit margin percentage
- Color-coded for easy interpretation

## Installation Steps

### If You Already Have the Ingredient System:

**Step 1:** Run the cost tracking update
```sql
-- In phpMyAdmin, import this file:
Database/add_cost_tracking.sql
```

This will:
- Add `cost_per_unit` column to ingredients
- Set realistic prices for all 35 ingredients
- Calculate total inventory value

### If This is a Fresh Installation:

**Step 1:** Run the complete system
```sql
-- In phpMyAdmin, import this file:
Database/add_ingredient_system.sql
```

This includes everything: tables + ingredients + costs

### Step 2:** Verify Installation

Open admin dashboard and check:
- ✅ Green "Inventory System" button appears next to Logout
- ✅ "View Ingredient Stock & Costs" button appears below Total Menu Items
- ✅ Clicking it shows ingredient table with costs
- ✅ Cost analysis summary shows at top of modal

## How It Works

### Cost Tracking Flow:

1. **When you complete an order:**
   - System calculates which ingredients were used
   - Deducts ingredients from stock
   - Logs the usage with ingredient ID and quantity
   - Records the cost (quantity × cost_per_unit)

2. **In the Cost Analysis:**
   - **Today's Cost** = Sum of all ingredient costs used today
   - **Today's Revenue** = Sum of all order totals today
   - **Today's Profit** = Revenue - Cost
   - **Profit Margin** = (Profit ÷ Revenue) × 100

### Understanding the Colors:

**Profit Margin Colors:**
- 🟢 Green (50%+) = Excellent profit margin
- 🟢 Dark Green (30-49%) = Good profit margin
- 🟡 Yellow (0-29%) = Low but positive profit
- 🔴 Red (Negative) = Operating at a loss

## Sample Ingredient Costs

Here are the realistic costs per unit we've set:

| Ingredient | Cost/Unit | Unit |
|------------|-----------|------|
| Rice | ₱45.00 | kg |
| Chicken Breast | ₱180.00 | kg |
| Beef Shank | ₱320.00 | kg |
| Pork Leg | ₱250.00 | kg |
| Shrimp | ₱450.00 | kg |
| Matcha Powder | ₱850.00 | kg |
| Coffee Beans | ₱420.00 | kg |
| Ice | ₱5.00 | kg |

*(Full list of 35 ingredients included)*

## Integration with Main Inventory System

### Important Notes:

1. **We DO NOT modify main_inventory_system**
   - The inventory system remains completely untouched
   - All changes are only in HotelLuneraRestaurant

2. **The inventory button:**
   - Simply links to your existing inventory system
   - Opens in a new tab
   - No code changes needed in inventory system

3. **If you want automatic stock transfer:**
   - Use the example file: `Database/stock_transfer_integration_example.php`
   - Place it in your main inventory system
   - It will call the restaurant's API when you transfer stock

### Manual Stock Transfer (Current Setup):

**In Main Inventory System:**
1. User records usage/transfer
2. Note which ingredients and quantities

**In Restaurant System:**
3. Admin clicks "Inventory System" button
4. Goes to main inventory to check what was transferred
5. Restaurant API endpoint ready to receive (if you implement it)

**Or use the API directly:**
```php
// From your inventory system
$ch = curl_init('http://localhost/HotelLuneraRestaurant/admin/receive_stock.php');
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
    'ingredient_name' => 'Rice',
    'quantity' => 25.00,
    'transferred_by' => 'Username',
    'notes' => 'Weekly restock'
]));
$response = curl_exec($ch);
```

## Understanding the Reports

### Ingredient Stock Modal Shows:

1. **Ingredient Name** - What ingredient it is
2. **Quantity** - How much you currently have
3. **Unit** - Measurement (kg, liter, pieces)
4. **Cost/Unit** - Price per unit
5. **Total Value** - Quantity × Cost (inventory value)
6. **Status** - OK (sufficient) or LOW (needs restock)

### Cost Analysis Summary Shows:

1. **Today's Cost** - How much you spent on ingredients today
2. **Today's Revenue** - How much money you made today
3. **Today's Profit** - Revenue minus Cost
4. **Profit Margin** - Profit as percentage of revenue

### Example Calculation:

```
Today's Orders:
- 5× Crispy Pata (₱799 each) = ₱3,995
- 3× Beef Kare-Kare (₱850 each) = ₱2,550
- 10× Iced Cola (₱25 each) = ₱250

Revenue = ₱6,795

Ingredients Used:
- Pork Leg: 2.5kg × ₱250 = ₱625
- Beef Shank: 1.8kg × ₱320 = ₱576
- Cola Syrup: 0.5L × ₱85 = ₱42.50
- Other ingredients: ₱380
Total Cost = ₱1,623.50

Actual Profit = ₱6,795 - ₱1,623.50 = ₱5,171.50
Profit Margin = (₱5,171.50 ÷ ₱6,795) × 100 = 76.1%
```

## Testing the System

### Test 1: View Ingredient Costs
1. Login to admin dashboard
2. Look for green "Inventory System" button (top right)
3. Scroll to "Total Menu Items" panel
4. Click "View Ingredient Stock & Costs" button
5. Modal should show all 35 ingredients with costs

### Test 2: Check Cost Analysis
1. In the same modal (from Test 1)
2. Look at top section with 4 boxes
3. Should show Today's Cost, Revenue, Profit, Margin
4. If no orders today, values will be ₱0.00

### Test 3: Create Order and See Cost
1. Go to cashier POS
2. Create and complete an order
3. Go back to admin
4. Click "View Ingredient Stock & Costs"
5. Today's Cost should now show ingredient costs
6. Today's Revenue should show order total
7. Profit should be calculated

### Test 4: Check Inventory Button
1. Click "📦 Inventory System" button (top right)
2. Should open main_inventory_system in new tab
3. If you get 404, adjust URL in code

## Updating the Inventory System URL

If your inventory system is at a different location:

**File:** `admin/admin.php`
**Line:** Around 172

```php
<a class="btn btn-inventory" href="http://localhost/main_inventory_system/" target="_blank">
```

Change to your actual path:
```php
<a class="btn btn-inventory" href="http://localhost/YOUR_PATH/" target="_blank">
```

## Customizing Ingredient Costs

To update ingredient costs:

```sql
UPDATE current_ingredients_stock 
SET cost_per_unit = 200.00 
WHERE ingredient_name = 'Chicken Breast';
```

Or update in bulk:
```sql
UPDATE current_ingredients_stock 
SET cost_per_unit = cost_per_unit * 1.10;  -- 10% increase
```

## Benefits of This System

### Before (Random Loss):
- ❌ Fake 15-25% loss calculation
- ❌ No real cost tracking
- ❌ Can't identify unprofitable items
- ❌ No inventory visibility

### After (Real Cost Tracking):
- ✅ Actual ingredient costs tracked
- ✅ Real profit calculation
- ✅ Identify which menu items are profitable
- ✅ Full inventory visibility with values
- ✅ Make data-driven pricing decisions
- ✅ Track operational efficiency

## Next Steps

1. **Assign Ingredients to Menu Items**
   - Edit each menu item
   - Add ingredients and quantities
   - System will auto-calculate costs

2. **Monitor Daily Costs**
   - Check the cost modal daily
   - Watch your profit margins
   - Adjust prices if margins are too low

3. **Set Up Inventory Integration** (Optional)
   - Use the API example provided
   - Automate stock transfers
   - Real-time synchronization

4. **Adjust Ingredient Prices**
   - Update costs based on your suppliers
   - Keep costs current for accurate reporting

## Troubleshooting

**Problem:** Can't see cost_per_unit column
**Solution:** Run `add_cost_tracking.sql` in phpMyAdmin

**Problem:** All costs showing ₱0.00
**Solution:** Run the UPDATE statements in `add_cost_tracking.sql`

**Problem:** Inventory button goes to 404
**Solution:** Update URL in `admin/admin.php` line ~172

**Problem:** Cost analysis shows ₱0.00 even with orders
**Solution:** Make sure menu items have ingredients assigned

**Problem:** Green button not showing
**Solution:** Clear browser cache and refresh

## Files Modified in This Update

1. `admin/admin.php` - Added inventory button + cost modal
2. `admin/admin-dashboard.css` - Styled inventory button
3. `admin/assets/js/admin.js` - Cost modal logic
4. `admin/get_ingredients.php` - Include cost_per_unit
5. `admin/get_ingredient_stock_costs.php` - NEW: Get costs
6. `admin/calculate_actual_profit.php` - NEW: Calculate profit
7. `Database/add_ingredient_system.sql` - Added cost_per_unit
8. `Database/add_cost_tracking.sql` - NEW: Update script

## Summary

You now have:
- ✅ Direct link to inventory system
- ✅ Real-time ingredient cost tracking
- ✅ Actual profit calculation (not random)
- ✅ Full inventory visibility with values
- ✅ Cost analysis dashboard
- ✅ No changes to main inventory system

Your restaurant system now tracks real operational costs and calculates actual profit based on ingredient usage!
