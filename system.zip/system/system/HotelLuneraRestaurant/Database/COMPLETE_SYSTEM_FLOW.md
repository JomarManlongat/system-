# Complete System Flow - Restaurant Ingredient Management with Location-Based Transfer

## Overview

This system provides:
1. **2-step menu item creation/editing** with ingredient assignment
2. **Automatic stock deduction** when customers order
3. **Location-based stock transfer** from main inventory system
4. **Real-time cost and profit calculation**

---

## 1. Two-Step Menu Item Management

### Adding a New Menu Item

**Step 1: Basic Information**
1. Admin clicks "Add Menu Item" button
2. Fills in:
   - Name (e.g., "Crispy Pata")
   - Description
   - Price (e.g., ₱799)
   - Category (Main Courses, Appetizers, Dessert, Beverages)
   - Image filename
3. Clicks "Add Item"

**Step 2: Ingredient Assignment** (Modal opens automatically)
1. Modal appears with title "Set Ingredients for: [Menu Item Name]"
2. Admin clicks "+ Add Ingredient"
3. For each ingredient:
   - Select ingredient from dropdown (shows available quantity)
   - Enter quantity required per serving (e.g., 0.5 kg)
4. Can add multiple ingredients
5. Options:
   - **"Save Ingredients"** - Saves the recipe
   - **"Skip"** - Saves menu item without ingredients (can add later)

### Editing Existing Menu Item

**Step 1: Edit Basic Info**
1. Admin clicks "Edit" on menu item
2. Updates price, description, category, etc.
3. Clicks "Save Changes"

**Step 2: Update Ingredients** (Modal opens automatically)
1. Modal shows current ingredients assigned
2. Admin can:
   - Modify quantities
   - Remove ingredients (click "Remove" button)
   - Add new ingredients (click "+ Add Ingredient")
3. Click "Save Ingredients" to update

**Example Recipe:**
```
Crispy Pata (₱799):
- Pork Leg: 0.8 kg @ ₱250/kg = ₱200 cost
- Salt: 0.05 kg @ ₱15/kg = ₱0.75 cost
- Oil: 0.3 liter @ ₱120/liter = ₱36 cost
Total ingredient cost: ₱236.75
Profit per serving: ₱799 - ₱236.75 = ₱562.25 (70.4% margin)
```

---

## 2. Customer Orders & Stock Deduction

### When Customer Orders (Cashier Dashboard)

**Step 1: Create Order**
1. Cashier adds items to order
2. Sets quantities
3. Clicks "Proceed to Payment"

**Step 2: Process Payment**
1. Select payment method (Cash/Credit Card)
2. Click "Complete Payment"

**Step 3: Automatic Stock Deduction** (Behind the scenes)

System automatically:
1. Gets all items in the order
2. For each item, looks up ingredients from `menu_ingredients` table
3. Calculates total ingredient usage:
   ```
   If order has 2× Crispy Pata:
   - Pork Leg: 0.8 kg × 2 = 1.6 kg deducted
   - Salt: 0.05 kg × 2 = 0.1 kg deducted
   - Oil: 0.3 liter × 2 = 0.6 liter deducted
   ```
4. Updates `current_ingredients_stock`:
   ```sql
   UPDATE current_ingredients_stock 
   SET current_quantity = current_quantity - [quantity_used]
   WHERE id = [ingredient_id]
   ```
5. Logs usage in `ingredient_usage_log`:
   ```sql
   INSERT INTO ingredient_usage_log 
   (ingredient_id, order_id, quantity_used, notes)
   VALUES (?, ?, ?, 'Used for order #123')
   ```
6. Calculates costs:
   ```
   Total ingredient cost = SUM(quantity_used × cost_per_unit)
   Revenue = Sum of item prices
   Profit = Revenue - Ingredient Cost
   ```

### Viewing Stock Status

**Admin Dashboard:**
- Green "View Ingredient Stock & Costs" button below "Total Menu Items"
- Shows:
  - All ingredients with current quantities
  - Cost per unit
  - Total value (quantity × cost)
  - Status indicators (OK/LOW)
  - Today's cost analysis (revenue, cost, profit, margin)

---

## 3. Location-Based Stock Transfer from Main Inventory

### How It Works

When staff in the **main inventory system** records usage:

**Scenario A: Staff in RESTAURANT location**
```
1. Staff: "I used 25 kg of Rice"
2. Location: "restaurant"
3. System: Records in inventory_managementdb
4. System: Calls restaurant API with location="restaurant"
5. Restaurant API: Checks location
6. Location = "restaurant" → ✅ TRANSFER
7. Result: Stock added to hotel_restaurant.current_ingredients_stock
```

**Scenario B: Staff in ROOM location**
```
1. Staff: "I used 10 kg of Rice"
2. Location: "room"
3. System: Records in inventory_managementdb
4. System: Calls restaurant API with location="room"
5. Restaurant API: Checks location
6. Location ≠ "restaurant" → ⏭️ SKIP
7. Result: Stock stays only in inventory system (for room service)
```

### Implementation in Main Inventory System

**File:** Place in your inventory system (e.g., `record_usage.php`)

```php
// When staff records usage
$user_location = $_SESSION['user_location']; // From user profile

// Call restaurant API
$ch = curl_init('http://localhost/HotelLuneraRestaurant/admin/receive_stock.php');
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
    'ingredient_name' => 'Rice',
    'quantity' => 25.00,
    'user_location' => $user_location, // IMPORTANT!
    'transferred_by' => $_SESSION['username'],
    'notes' => 'Staff usage recorded'
]));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);

$result = json_decode($response, true);

// Handle response
if ($result['status'] === 'success') {
    echo "Transferred to restaurant!";
} elseif ($result['status'] === 'skipped') {
    echo "Recorded in inventory only (location: " . $result['user_location'] . ")";
}
```

### API Response Examples

**Success Response (Restaurant location):**
```json
{
    "status": "success",
    "message": "Stock transferred successfully to restaurant",
    "new_quantity": 75.50,
    "user_location": "restaurant"
}
```

**Skipped Response (Room location):**
```json
{
    "status": "skipped",
    "message": "Transfer skipped - user location is not restaurant (location: room)",
    "user_location": "room"
}
```

**Error Response:**
```json
{
    "status": "error",
    "message": "Ingredient not found in restaurant inventory"
}
```

---

## 4. Profit & Loss Calculation

### Real-Time Cost Tracking

**Based on Actual Ingredient Usage:**

When viewing "Ingredient Stock & Costs" modal, you see:

```
┌─────────────────────────────────────────────┐
│ Cost Analysis Summary                        │
├─────────────────────────────────────────────┤
│ Today's Cost:     ₱1,245.50  (ingredients)  │
│ Today's Revenue:  ₱4,850.00  (sales)        │
│ Today's Profit:   ₱3,604.50  (actual)       │
│ Profit Margin:    74.3%      (excellent!)   │
└─────────────────────────────────────────────┘
```

**Calculation Method:**
```
Today's Cost = SUM(ingredient_usage × cost_per_unit) for today
Today's Revenue = SUM(order_total) for completed orders today
Today's Profit = Revenue - Cost
Profit Margin = (Profit ÷ Revenue) × 100
```

**Color Indicators:**
- 🟢 Green (50%+ margin) = Excellent
- 🟢 Dark Green (30-49%) = Good
- 🟡 Yellow (0-29%) = Low but positive
- 🔴 Red (Negative) = Loss

### Example Calculation

**Orders Today:**
```
Order #101: 2× Crispy Pata @ ₱799 = ₱1,598
Order #102: 1× Beef Kare-Kare @ ₱850 = ₱850
Order #103: 5× Iced Cola @ ₱25 = ₱125
Total Revenue: ₱2,573
```

**Ingredients Used:**
```
Crispy Pata (2 servings):
- Pork Leg: 1.6kg × ₱250 = ₱400
- Oil: 0.6L × ₱120 = ₱72
- Salt: 0.1kg × ₱15 = ₱1.50

Beef Kare-Kare (1 serving):
- Beef Shank: 0.5kg × ₱320 = ₱160
- Peanut Sauce: 0.2L × ₱150 = ₱30
- Vegetables: (various) = ₱45

Iced Cola (5 servings):
- Cola Syrup: 0.25L × ₱85 = ₱21.25
- Sugar: 0.15kg × ₱55 = ₱8.25
- Ice: 1kg × ₱5 = ₱5

Total Ingredient Cost: ₱742.50
```

**Profit Analysis:**
```
Revenue:        ₱2,573.00
Ingredient Cost: ₱742.50
Actual Profit:  ₱1,830.50
Profit Margin:  71.1% ✅
```

---

## 5. Database Tables & Relationships

### Core Tables

**1. `current_ingredients_stock`**
```sql
- id (PK)
- ingredient_name (e.g., "Rice")
- unit (e.g., "kg")
- current_quantity (e.g., 50.00)
- min_quantity (e.g., 10.00)
- cost_per_unit (e.g., 45.00)
- last_updated
```

**2. `menu_ingredients`** (Recipe link)
```sql
- id (PK)
- menu_id (FK → menu.id)
- ingredient_id (FK → current_ingredients_stock.id)
- quantity_required (e.g., 0.8 for 0.8kg per serving)
```

**3. `ingredient_usage_log`** (Tracking)
```sql
- id (PK)
- ingredient_id (FK)
- order_id (FK)
- quantity_used (e.g., 1.6)
- usage_date
- notes
```

**4. `stock_transfer_log`** (From inventory system)
```sql
- id (PK)
- ingredient_id (FK)
- quantity_transferred
- transferred_by
- transfer_date
- notes
```

### Query Examples

**Get total cost for today:**
```sql
SELECT SUM(iul.quantity_used * cis.cost_per_unit) as total_cost
FROM ingredient_usage_log iul
JOIN current_ingredients_stock cis ON cis.id = iul.ingredient_id
WHERE DATE(iul.usage_date) = CURDATE();
```

**Get ingredients for a menu item:**
```sql
SELECT cis.ingredient_name, mi.quantity_required, cis.unit
FROM menu_ingredients mi
JOIN current_ingredients_stock cis ON cis.id = mi.ingredient_id
WHERE mi.menu_id = 1;
```

**Get low stock items:**
```sql
SELECT ingredient_name, current_quantity, min_quantity
FROM current_ingredients_stock
WHERE current_quantity <= min_quantity;
```

---

## 6. Complete User Flow Examples

### Example 1: Adding New Menu Item with Ingredients

**Admin Flow:**
1. Login → Admin Dashboard
2. Click "Add Menu Item"
3. Fill form:
   - Name: "Mango Graham Float"
   - Price: ₱180
   - Category: Dessert
   - Image: mango_float.jpg
4. Click "Add Item"
5. **✨ Ingredient Modal Opens Automatically**
6. Click "+ Add Ingredient"
7. Select "Cream" → Enter "0.3" (liter)
8. Click "+ Add Ingredient"
9. Select "Sugar" → Enter "0.1" (kg)
10. Click "+ Add Ingredient"
11. Select "Mango" (if exists) → Enter "0.2" (kg)
12. Click "Save Ingredients"
13. Success! Menu item with recipe saved

**Result:**
- Menu item appears in dashboard
- Ingredients linked in `menu_ingredients` table
- When ordered: System knows to deduct 0.3L cream, 0.1kg sugar, 0.2kg mango

### Example 2: Customer Orders & Automatic Deduction

**Cashier Flow:**
1. Customer orders: 3× Mango Graham Float
2. Cashier adds to cart
3. Proceeds to payment
4. Completes payment

**System Auto-Process:**
```
Order #105 completed
Items: 3× Mango Graham Float @ ₱180

Ingredient Deductions:
- Cream: 0.3L × 3 = 0.9L deducted
- Sugar: 0.1kg × 3 = 0.3kg deducted
- Mango: 0.2kg × 3 = 0.6kg deducted

Cost Calculation:
- Cream: 0.9L × ₱180/L = ₱162
- Sugar: 0.3kg × ₱55/kg = ₱16.50
- Mango: 0.6kg × ₱65/kg = ₱39
Total Cost: ₱217.50

Revenue: 3 × ₱180 = ₱540
Profit: ₱540 - ₱217.50 = ₱322.50 (59.7% margin)
```

### Example 3: Inventory Staff Records Usage

**Inventory System Flow:**

**Staff A (Restaurant Location):**
1. Logs in → Location: "restaurant"
2. Records usage: 20kg Rice
3. System saves to inventory_managementdb
4. System calls restaurant API with location="restaurant"
5. ✅ Transfer happens
6. Rice stock in restaurant increases by 20kg
7. Logged in `stock_transfer_log`

**Staff B (Room Service Location):**
1. Logs in → Location: "room"
2. Records usage: 15kg Rice
3. System saves to inventory_managementdb
4. System calls restaurant API with location="room"
5. ⏭️ Transfer skipped (not restaurant)
6. Rice stays only in inventory system
7. No change in restaurant database

---

## 7. Testing Checklist

### Test the 2-Step Menu Creation:
- [ ] Add new menu item → Ingredient modal appears
- [ ] Can add multiple ingredients
- [ ] Can skip ingredient assignment
- [ ] Edit menu item → Can update ingredients
- [ ] Can remove ingredients

### Test Stock Deduction:
- [ ] Create order → Complete payment
- [ ] Check `ingredient_usage_log` → Usage recorded
- [ ] Check `current_ingredients_stock` → Quantities reduced
- [ ] View cost modal → Today's cost updated

### Test Location-Based Transfer:
- [ ] Transfer with location="restaurant" → Stock increases
- [ ] Transfer with location="room" → Stock unchanged
- [ ] Check `stock_transfer_log` → Only restaurant transfers logged

### Test Cost Calculation:
- [ ] Complete orders → Check cost modal
- [ ] Today's Cost = Sum of ingredient costs
- [ ] Today's Profit = Revenue - Cost
- [ ] Profit Margin calculated correctly

---

## 8. Support & Troubleshooting

**Issue:** Ingredient modal doesn't appear after adding menu item
**Solution:** Check `admin.js` - ensure `openIngredientModal()` is called after successful add

**Issue:** Stock not deducting after order
**Solution:** Check if menu items have ingredients assigned in `menu_ingredients` table

**Issue:** All transfers going to restaurant (even from room)
**Solution:** Verify `user_location` parameter is being sent correctly from inventory system

**Issue:** Cost showing ₱0.00
**Solution:** Run `add_cost_tracking.sql` to set ingredient costs

---

This system provides complete ingredient management with location-aware stock transfers, automatic cost tracking, and real-time profit analysis!
