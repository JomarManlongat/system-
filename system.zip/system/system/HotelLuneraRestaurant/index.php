<?php
session_name('RESTAURANT_SESSION');
session_start();
include("connection.php");

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'cashier') {
    header("Location: login.php");
    exit();
}


$user_id = $_SESSION['user_id'];

// Safety tables
$conn->query("CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    status VARCHAR(20) DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB");

$conn->query("CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    menu_id INT NOT NULL,
    quantity INT DEFAULT 1,
    sugar_level VARCHAR(10) DEFAULT '100%',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB");

$category = isset($_GET['category']) ? $_GET['category'] : 'Main Courses';

// Only show available menu items to staff
$stmt = $conn->prepare("SELECT * FROM menu WHERE category = ? AND status = 'available' ORDER BY name ASC");
$stmt->bind_param("s", $category);
$stmt->execute();
$menu = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Restaurant Dashboard</title>
<link rel="stylesheet" href="assets/css/style.css">
<!-- Cashier dashboard styles: see /assets/css/cashier-dashboard.css for sections and editing tips -->
<link rel="stylesheet" href="assets/css/cashier-dashboard.css">
<meta name="cashier-name" content="<?= htmlspecialchars($_SESSION['username'] ?? 'Cashier') ?>">

</head>
<body>

<header><h1>Hotel Lunera Restaurant POS System</h1></header> 

<div class="top-buttons">
    <div class="nav-center">
        <a href="index.php?category=Main Courses" class="<?= ($category == 'Main Courses') ? 'active' : '' ?>">Main Courses</a>
        <a href="index.php?category=Appetizers" class="<?= ($category == 'Appetizers') ? 'active' : '' ?>">Appetizers</a>
        <a href="index.php?category=Dessert" class="<?= ($category == 'Dessert') ? 'active' : '' ?>">Dessert</a>
        <a href="index.php?category=Beverages" class="<?= ($category == 'Beverages') ? 'active' : '' ?>">Beverages</a>
    </div>
    <div class="nav-right">
        <a href="logout.php">🚪 Logout</a>
    </div>
</div>

<div class="dashboard">
    <div class="menu-section">
        <div class="menu-container">
        <?php while ($row = $menu->fetch_assoc()): ?>
            <div class="menu-card" data-category="<?= htmlspecialchars($row['category']) ?>">
                <img src="images/<?= htmlspecialchars($row['image']) ?>" alt="<?= htmlspecialchars($row['name']) ?>" onerror="this.onerror=null; this.src='images/Lunera.jfif'">
                <h3><?= htmlspecialchars($row['name']) ?></h3>
                <p><?= htmlspecialchars($row['description']) ?></p>
                <p class="price">₱<?= number_format($row['price'], 2) ?></p>
                <p>Status: <b style="color:<?= ($row['status'] === 'available') ? 'green' : 'red' ?>"><?= htmlspecialchars($row['status']) ?></b></p>

                <?php if ($row['category'] === 'Beverages'): ?>
                    <label><b>Sugar Level:</b></label>
                    <select id="sugar_level_<?= (int)$row['id'] ?>" class="sugar-select">
                        <option value="0%">0%</option>
                        <option value="25%">25%</option>
                        <option value="50%">50%</option>
                        <option value="75%">75%</option>
                        <option value="100%" selected>100%</option>
                    </select>
                <?php endif; ?>

                <button class="order-btn" onclick="addToOrder(<?= (int)$row['id'] ?>, '<?= htmlspecialchars($row['category']) ?>')" <?= ($row['status'] === 'available') ? '' : 'disabled' ?>>Add to Order</button>
            </div>
        <?php endwhile; ?>
        </div>
    </div>

    <div class="order-section">
        <h2>🛒 Current Order</h2>
        <div class="order-list">
            <p style="color:gray;">Loading order...</p>
        </div>
    </div>
</div>

<!-- Payment Modal -->
<div id="paymentModal" class="modal" style="pointer-events:auto;">
    <div class="modal-content" style="pointer-events:auto;">
        <h3>Select Payment Method</h3>
        <button class="payment-btn" onclick="selectPayment('Cash')">💵 Cash</button>
        <button class="payment-btn" onclick="selectPayment('Credit Card')">💳 Credit Card</button>
        <button class="payment-btn" onclick="selectPayment('Mobile Payment')">📱 Mobile Payment</button>
        <br>
        <button class="close-btn" onclick="closePaymentPopup()">Close</button>
    </div>
</div>

<!-- Cash Modal -->
<div id="cashModal" class="modal" style="pointer-events:auto;">
    <div class="modal-content" style="pointer-events:auto;">
        <h3>💵 Cash Payment</h3>
        <label><b>Enter Amount Tendered:</b></label>
        <input type="number" id="cashAmount" placeholder="Enter amount" style="width:90%;padding:8px;margin:10px 0;border-radius:6px;border:1px solid #ccc;">
        <button class="payment-btn" onclick="processCashPayment()">Confirm Payment</button>
        <button class="close-btn" onclick="closeCashModal()">Cancel</button>
    </div>
</div>

<!-- Receipt Modal -->
<div id="receiptModal" class="modal" style="pointer-events:auto;">
    <div class="modal-content" id="receiptModalContent" style="pointer-events:auto;">
        <div id="receiptContent"></div>
        <button id="printReceiptBtn" class="payment-btn" style="margin-top:12px;">Print Receipt</button>
    </div>
</div>

<!-- Notification Modal (for printer unavailable/cancel) -->
<div id="notifyModal" class="modal" style="pointer-events:auto;">
    <div class="modal-content" style="max-width:360px;text-align:center;pointer-events:auto;">
        <h3 style="margin:0 0 8px 0; color: maroon;">Notice</h3>
        <p id="notifyMessage" style="margin:0 0 12px 0; color:#333;">No printer available.</p>
        <button class="close-btn" onclick="closeNotify()">OK</button>
    </div>
</div>

<script src="assets/js/pos.js"></script>


</body>
</html>
