-- Add new columns to transactions table for delivery tracking
-- Run this SQL script to update your transactions table

-- Add columns one by one (compatible with all MySQL versions)
ALTER TABLE `transactions` ADD COLUMN `ReceivedBy` VARCHAR(100) NULL DEFAULT NULL COMMENT 'Name of person who received the delivery';
ALTER TABLE `transactions` ADD COLUMN `RecordedBy` VARCHAR(100) NULL DEFAULT NULL COMMENT 'Name of person who recorded the delivery';
ALTER TABLE `transactions` ADD COLUMN `Description` TEXT NULL DEFAULT NULL COMMENT 'Additional notes about the transaction';
