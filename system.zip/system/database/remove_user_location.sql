-- Remove Location column from users table only (if it exists)
-- This allows staff to see all inventory items regardless of their assigned location
-- Suppliers and items keep their Location column for organizational purposes

-- Note: Make sure to backup your database before running this migration!

-- Drop Location column from users table if it still exists
SET @dbname = DATABASE();
SET @tablename = "users";
SET @columnname = "Location";
SET @preparedStatement = (SELECT IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE
    (COLUMN_NAME = @columnname) AND
    (TABLE_NAME = @tablename) AND
    (TABLE_SCHEMA = @dbname)
  ) > 0,
  CONCAT("ALTER TABLE ", @dbname, ".", @tablename, " DROP COLUMN ", @columnname),
  "SELECT 1"
));
PREPARE alterIfExists FROM @preparedStatement;
EXECUTE alterIfExists;
DEALLOCATE PREPARE alterIfExists;
