-- Add ReceivedDate and ReceivedTime columns to transactions table
-- Run this SQL script to update your transactions table

-- Add ReceivedDate column
ALTER TABLE `transactions` ADD COLUMN `ReceivedDate` DATE NULL DEFAULT NULL COMMENT 'Date when the delivery was received';

-- Add ReceivedTime column
ALTER TABLE `transactions` ADD COLUMN `ReceivedTime` TIME NULL DEFAULT NULL COMMENT 'Time when the delivery was received';
