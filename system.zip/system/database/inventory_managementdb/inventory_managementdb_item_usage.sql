-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: inventory_managementdb
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `item_usage`
--

DROP TABLE IF EXISTS `item_usage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `item_usage` (
  `UsageID` int NOT NULL AUTO_INCREMENT,
  `ItemID` varchar(50) NOT NULL,
  `Quantity` int NOT NULL,
  `UserID` varchar(50) NOT NULL,
  `Notes` text,
  `CreatedAt` datetime NOT NULL,
  `synced_to_restaurant` tinyint(1) DEFAULT '0',
  `synced_at` datetime DEFAULT NULL,
  PRIMARY KEY (`UsageID`),
  KEY `idx_item` (`ItemID`),
  KEY `idx_user` (`UserID`),
  KEY `idx_date` (`CreatedAt`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_usage`
--

LOCK TABLES `item_usage` WRITE;
/*!40000 ALTER TABLE `item_usage` DISABLE KEYS */;
INSERT INTO `item_usage` VALUES (10,'18',10,'1','asd','2025-10-30 09:33:43',0,NULL),(29,'1',100,'1','','2025-11-18 12:18:01',0,NULL),(30,'1',15,'1','','2025-11-19 22:12:15',0,NULL),(31,'13',1,'4','','2025-11-19 22:59:08',0,NULL),(32,'12',12,'2','','2025-11-25 08:29:55',0,NULL),(41,'12',1,'2','','2025-11-28 21:32:54',0,NULL),(42,'18',12,'2','','2025-11-30 23:25:09',0,NULL),(43,'746',5,'2','','2025-12-02 19:58:56',0,NULL),(44,'735',5,'2','','2025-12-02 20:01:30',0,NULL),(45,'15',1,'5','','2025-12-02 20:22:13',0,NULL),(46,'15',4,'2','','2025-12-05 22:32:39',0,NULL),(47,'719',1,'1','','2025-12-05 23:23:09',0,NULL),(48,'722',1,'2','','2025-12-08 23:11:43',0,NULL),(49,'722',1,'2','asd','2025-12-10 23:24:46',0,NULL),(50,'719',16,'2','','2025-12-11 18:19:15',0,NULL),(51,'722',3,'2','asd','2025-12-11 18:51:33',0,NULL);
/*!40000 ALTER TABLE `item_usage` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `after_item_usage_sync_restaurant` AFTER INSERT ON `item_usage` FOR EACH ROW BEGIN
  DECLARE v_ingredient_name VARCHAR(255);
  DECLARE v_conversion_factor DECIMAL(10,4) DEFAULT 1.0000;
  DECLARE v_restaurant_qty DECIMAL(14,4) DEFAULT 0;
  DECLARE v_unit VARCHAR(100) DEFAULT NULL;
  DECLARE v_cost_per_unit DECIMAL(14,4) DEFAULT 0;
  DECLARE v_affected_rows INT DEFAULT 0;

  -- Prefer mapping
  SELECT restaurant_ingredient_name, conversion_factor
    INTO v_ingredient_name, v_conversion_factor
  FROM inventory_managementdb.item_ingredient_mapping
  WHERE inventory_item_id = CAST(NEW.ItemID AS UNSIGNED)
    AND auto_sync_enabled = 1
  LIMIT 1;

  -- Fallback to items/supplieritems
  IF v_ingredient_name IS NULL OR v_ingredient_name = '' THEN
    SELECT COALESCE(si.ItemName, i.ItemName), COALESCE(si.Measurement, i.Measurement), COALESCE(si.Price, 0)
      INTO v_ingredient_name, v_unit, v_cost_per_unit
    FROM inventory_managementdb.items i
    LEFT JOIN inventory_managementdb.supplieritems si ON i.SupplierItemID = si.SupplierItemID
    WHERE i.ItemID = CAST(NEW.ItemID AS UNSIGNED)
    LIMIT 1;
    
    -- Apply automatic conversion based on inventory measurement unit
    CASE LOWER(v_unit)
      WHEN 'pack' THEN 
        SET v_conversion_factor = 15.0;
        SET v_unit = 'pieces';
      WHEN 'box' THEN 
        SET v_conversion_factor = 24.0;
        SET v_unit = 'pieces';
      WHEN 'sack' THEN 
        SET v_conversion_factor = 50.0;
        SET v_unit = 'kg';
      WHEN 'bottle' THEN 
        SET v_conversion_factor = 1.0;
        SET v_unit = 'liter';
      WHEN 'sets' THEN 
        SET v_conversion_factor = 6.0;
        SET v_unit = 'pieces';
      ELSE 
        SET v_conversion_factor = 1.0;
    END CASE;
  ELSE
    SELECT COALESCE(si.Measurement, i.Measurement), COALESCE(si.Price, 0)
      INTO v_unit, v_cost_per_unit
    FROM inventory_managementdb.items i
    LEFT JOIN inventory_managementdb.supplieritems si ON i.SupplierItemID = si.SupplierItemID
    WHERE i.ItemID = CAST(NEW.ItemID AS UNSIGNED)
    LIMIT 1;
  END IF;

  SET v_restaurant_qty = NEW.Quantity * v_conversion_factor;

  UPDATE hotel_restaurant.current_ingredients_stock
     SET current_quantity = current_quantity + v_restaurant_qty
   WHERE ingredient_name = v_ingredient_name;

  SET v_affected_rows = ROW_COUNT();

  IF v_affected_rows > 0 THEN
    INSERT INTO hotel_restaurant.stock_transfer_log (ingredient_id, quantity_transferred, transferred_by, notes)
    SELECT id, v_restaurant_qty, 'Inventory Trigger', CONCAT('Auto-sync from item_usage #', NEW.UsageID)
      FROM hotel_restaurant.current_ingredients_stock
     WHERE ingredient_name = v_ingredient_name
     LIMIT 1;
  ELSE
    INSERT INTO hotel_restaurant.current_ingredients_stock (ingredient_name, unit, current_quantity, cost_per_unit)
    VALUES (v_ingredient_name, v_unit, v_restaurant_qty, v_cost_per_unit);

    INSERT INTO hotel_restaurant.stock_transfer_log (ingredient_id, quantity_transferred, transferred_by, notes)
    SELECT id, v_restaurant_qty, 'Inventory Trigger', CONCAT('Auto-created ingredient & auto-sync from item_usage #', NEW.UsageID)
      FROM hotel_restaurant.current_ingredients_stock
     WHERE ingredient_name = v_ingredient_name
     ORDER BY id DESC
     LIMIT 1;
  END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-11 20:18:20
