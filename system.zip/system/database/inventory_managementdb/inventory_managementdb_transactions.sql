-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: inventory_managementdb
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transactions` (
  `TransactionID` int NOT NULL AUTO_INCREMENT,
  `ItemID` int NOT NULL,
  `Quantity` int NOT NULL,
  `Type` enum('Added Stock','Usage Stock') NOT NULL,
  `UserID` int NOT NULL,
  `SupplierID` int DEFAULT NULL,
  `DateTime` datetime DEFAULT CURRENT_TIMESTAMP,
  `ReceivedBy` varchar(100) DEFAULT NULL COMMENT 'Name of person who received the delivery',
  `RecordedBy` varchar(100) DEFAULT NULL COMMENT 'Name of person who recorded the delivery',
  `Description` text COMMENT 'Additional notes about the transaction',
  `ReceivedDate` date DEFAULT NULL,
  `ReceivedTime` time DEFAULT NULL,
  PRIMARY KEY (`TransactionID`),
  KEY `ItemID` (`ItemID`),
  KEY `UserID` (`UserID`),
  KEY `SupplierID` (`SupplierID`),
  CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`ItemID`) REFERENCES `items` (`ItemID`),
  CONSTRAINT `transactions_ibfk_2` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`),
  CONSTRAINT `transactions_ibfk_3` FOREIGN KEY (`SupplierID`) REFERENCES `suppliers` (`SupplierID`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
INSERT INTO `transactions` VALUES (8,746,5,'Added Stock',3,73,'2025-12-02 19:58:14',NULL,NULL,NULL,NULL,NULL),(9,746,5,'Usage Stock',2,NULL,'2025-12-02 19:58:56',NULL,NULL,NULL,NULL,NULL),(10,735,9,'Added Stock',3,72,'2025-12-02 20:00:41',NULL,NULL,NULL,NULL,NULL),(11,735,5,'Usage Stock',2,NULL,'2025-12-02 20:01:30',NULL,NULL,NULL,NULL,NULL),(12,15,1,'Usage Stock',5,NULL,'2025-12-02 20:22:13',NULL,NULL,NULL,NULL,NULL),(13,722,7,'Added Stock',5,71,'2025-12-05 22:31:56',NULL,NULL,NULL,NULL,NULL),(14,719,1,'Added Stock',5,71,'2025-12-05 22:31:56',NULL,NULL,NULL,NULL,NULL),(15,15,4,'Usage Stock',2,NULL,'2025-12-05 22:32:39',NULL,NULL,NULL,NULL,NULL),(16,719,1,'Usage Stock',1,NULL,'2025-12-05 23:23:09',NULL,NULL,NULL,NULL,NULL),(17,754,8,'Added Stock',5,6,'2025-12-06 10:07:39',NULL,NULL,NULL,NULL,NULL),(18,722,1,'Usage Stock',2,NULL,'2025-12-08 23:11:43',NULL,NULL,NULL,NULL,NULL),(19,722,1,'Usage Stock',2,NULL,'2025-12-10 23:24:46','jomar','rosela L. Sanchez','asd','2013-12-28','03:12:00'),(21,719,5,'Added Stock',1,71,'2025-12-11 18:16:17','123123','','','2024-10-11','00:32:00'),(22,719,16,'Usage Stock',2,NULL,'2025-12-11 18:19:15','jomar','rosela L. Sanchez','','2029-10-29','00:32:00'),(23,722,3,'Usage Stock',2,NULL,'2025-12-11 18:51:33','jomar','rosela L. Sanchez','asd','2025-12-01','00:33:00');
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_transactions_after_insert_noti` AFTER INSERT ON `transactions` FOR EACH ROW BEGIN
    INSERT INTO notifications (title, message, type)
    VALUES (
        'Transaction',
        CONCAT('Transaction on ItemID: ', NEW.ItemID, ' - Quantity: ', NEW.Quantity, ' (', NEW.Type, ')'),
        'added'
    );
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-11 20:18:19
