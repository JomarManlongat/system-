-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: inventory_managementdb
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `supplieritems`
--

DROP TABLE IF EXISTS `supplieritems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supplieritems` (
  `SupplierItemID` int NOT NULL AUTO_INCREMENT,
  `SupplierID` int NOT NULL,
  `ItemName` varchar(100) NOT NULL,
  `Measurement` enum('Box','Pack','Sack','Pcs','Sets','Bottle') NOT NULL,
  `Price` decimal(10,2) NOT NULL,
  `InitialStock` int NOT NULL DEFAULT '0',
  `DefaultExpiryDate` date DEFAULT NULL,
  `DefaultMinimumStock` int NOT NULL DEFAULT '10',
  PRIMARY KEY (`SupplierItemID`),
  KEY `SupplierID` (`SupplierID`),
  CONSTRAINT `supplieritems_ibfk_1` FOREIGN KEY (`SupplierID`) REFERENCES `suppliers` (`SupplierID`)
) ENGINE=InnoDB AUTO_INCREMENT=540 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplieritems`
--

LOCK TABLES `supplieritems` WRITE;
/*!40000 ALTER TABLE `supplieritems` DISABLE KEYS */;
INSERT INTO `supplieritems` VALUES (3,2,'Shampoo','Bottle',120.00,0,NULL,10),(4,2,'Soap','Pack',30.00,0,NULL,10),(11,6,'Chicken','Box',170.00,0,NULL,0),(12,6,'Soap','Pack',150.00,0,NULL,0),(505,71,'Rice','Sack',45.00,50,NULL,10),(506,71,'Chicken Breast','Pack',180.00,20,NULL,5),(507,71,'Beef Shank','Pack',320.00,15,NULL,5),(508,71,'Pork Leg','Pack',250.00,10,NULL,3),(509,71,'Shrimp','Pack',450.00,8,NULL,2),(510,71,'Squid','Pack',280.00,5,NULL,2),(511,71,'Tuna','Pack',380.00,7,NULL,2),(512,71,'Mussels','Pack',220.00,4,NULL,1),(513,71,'Lettuce','Pack',65.00,3,NULL,1),(514,71,'Tomatoes','Pack',75.00,5,NULL,1),(515,71,'Onions','Pack',45.00,8,NULL,2),(516,71,'Garlic','Pack',95.00,3,NULL,1),(517,72,'Milk','Bottle',85.00,10,NULL,2),(518,72,'Eggs','Sets',8.00,100,NULL,20),(519,72,'Cheese','Pack',380.00,5,NULL,1),(520,72,'Cream','Bottle',180.00,6,NULL,1),(521,72,'Bacon','Pack',420.00,3,NULL,1),(522,72,'Ham','Pack',350.00,4,NULL,1),(523,72,'Peanut Sauce','Bottle',150.00,2,NULL,1),(524,72,'Chocolate','Pack',280.00,5,NULL,1),(525,72,'Matcha Powder','Pack',850.00,2,NULL,1),(526,72,'Coffee Beans','Pack',420.00,5,NULL,1),(527,72,'Tapioca Pearls','Pack',120.00,3,NULL,1),(528,73,'Flour','Sack',35.00,25,NULL,5),(529,73,'Sugar','Sack',55.00,30,NULL,5),(530,73,'Salt','Pack',15.00,10,NULL,2),(531,73,'Oil','Bottle',120.00,15,NULL,3),(532,73,'Soy Sauce','Bottle',65.00,3,NULL,1),(533,73,'Vinegar','Bottle',35.00,4,NULL,1),(534,73,'Pineapple','Pcs',45.00,20,NULL,5),(535,73,'Watermelon','Pcs',85.00,10,NULL,3),(536,73,'Lemon','Pcs',12.00,30,NULL,10),(537,73,'Dragon Fruit','Pcs',95.00,15,NULL,5),(538,73,'Cola Syrup','Bottle',85.00,3,NULL,1),(539,73,'Ice','Sack',5.00,100,NULL,10);
/*!40000 ALTER TABLE `supplieritems` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_supplieritems_after_insert` AFTER INSERT ON `supplieritems` FOR EACH ROW BEGIN
    -- Create matching item
    INSERT INTO items (ItemName, SupplierItemID, Stock, Measurement, ExpiryDate, Conditions, MinimumStock, Location)
    VALUES (NEW.ItemName, NEW.SupplierItemID, 0, NEW.Measurement, NEW.DefaultExpiryDate, 'Good', NEW.DefaultMinimumStock, 'Restaurant');

    -- Log notification
    INSERT INTO notifications (title, message, type)
    VALUES (
        'Supplier Item Added',
        CONCAT('New supplier item added: ', NEW.ItemName),
        'added'
    );
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-11 20:18:21
