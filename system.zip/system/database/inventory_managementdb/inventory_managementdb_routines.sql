-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: inventory_managementdb
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping events for database 'inventory_managementdb'
--
/*!50106 SET @save_time_zone= @@TIME_ZONE */ ;
/*!50106 DROP EVENT IF EXISTS `daily_expiration_check` */;
DELIMITER ;;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;;
/*!50003 SET character_set_client  = utf8mb4 */ ;;
/*!50003 SET character_set_results = utf8mb4 */ ;;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;;
/*!50003 SET @saved_time_zone      = @@time_zone */ ;;
/*!50003 SET time_zone             = 'SYSTEM' */ ;;
/*!50106 CREATE*/ /*!50117 DEFINER=`root`@`localhost`*/ /*!50106 EVENT `daily_expiration_check` ON SCHEDULE EVERY 1 DAY STARTS '2025-11-14 00:00:00' ON COMPLETION NOT PRESERVE ENABLE DO BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE v_item_id INT;
    DECLARE v_expiry_date DATE;
    DECLARE days_until_expiry INT;
    
    DECLARE cur CURSOR FOR 
        SELECT ItemID, ExpiryDate 
        FROM items 
        WHERE ExpiryDate IS NOT NULL;
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    OPEN cur;
    
    read_loop: LOOP
        FETCH cur INTO v_item_id, v_expiry_date;
        IF done THEN
            LEAVE read_loop;
        END IF;
        
        SET days_until_expiry = DATEDIFF(v_expiry_date, CURDATE());
        
        IF days_until_expiry < 0 THEN
            UPDATE alerts 
            SET Status = 'Resolved'
            WHERE ItemID = v_item_id 
            AND Type = 'Expiry Soon' 
            AND Status = 'Pending';
            
            INSERT INTO alerts (Type, ItemID, Details, Status)
            SELECT 'Expired', v_item_id,
                   CONCAT('Item expired on ', DATE_FORMAT(v_expiry_date, '%Y-%m-%d'), '. Remove from inventory immediately.'),
                   'Pending'
            WHERE NOT EXISTS (
                SELECT 1 FROM alerts 
                WHERE ItemID = v_item_id 
                AND Type = 'Expired' 
                AND Status = 'Pending'
            );
            
        ELSEIF days_until_expiry >= 0 AND days_until_expiry <= 30 THEN
            INSERT INTO alerts (Type, ItemID, Details, Status)
            SELECT 'Expiry Soon', v_item_id,
                   CONCAT('Item will expire on ', DATE_FORMAT(v_expiry_date, '%Y-%m-%d'), '. Use within ', days_until_expiry, ' days.'),
                   'Pending'
            WHERE NOT EXISTS (
                SELECT 1 FROM alerts 
                WHERE ItemID = v_item_id 
                AND Type IN ('Expiry Soon', 'Expired')
                AND Status = 'Pending'
            );
            
        ELSE
            UPDATE alerts 
            SET Status = 'Resolved'
            WHERE ItemID = v_item_id 
            AND Type IN ('Expiry Soon', 'Expired')
            AND Status = 'Pending';
        END IF;
        
    END LOOP;
    
    CLOSE cur;
END */ ;;
/*!50003 SET time_zone             = @saved_time_zone */ ;;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;;
/*!50003 SET character_set_client  = @saved_cs_client */ ;;
/*!50003 SET character_set_results = @saved_cs_results */ ;;
/*!50003 SET collation_connection  = @saved_col_connection */ ;;
/*!50106 DROP EVENT IF EXISTS `ev_check_expiry` */;;
DELIMITER ;;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;;
/*!50003 SET character_set_client  = utf8mb4 */ ;;
/*!50003 SET character_set_results = utf8mb4 */ ;;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;;
/*!50003 SET @saved_time_zone      = @@time_zone */ ;;
/*!50003 SET time_zone             = 'SYSTEM' */ ;;
/*!50106 CREATE*/ /*!50117 DEFINER=`root`@`localhost`*/ /*!50106 EVENT `ev_check_expiry` ON SCHEDULE EVERY 1 DAY STARTS '2025-09-28 23:07:58' ON COMPLETION NOT PRESERVE ENABLE DO BEGIN
    -- Expired items
    INSERT INTO notifications (title, message, type)
    SELECT 'Expired Item',
           CONCAT('Expired: ', i.ItemName, ' (', i.ExpiryDate, ')'),
           'pending'
    FROM items i
    WHERE i.ExpiryDate IS NOT NULL AND i.ExpiryDate < CURRENT_DATE();

    -- Expiring soon (within 30 days)
    INSERT INTO notifications (title, message, type)
    SELECT 'Expiring Soon',
           CONCAT('Expiring soon: ', i.ItemName, ' (', i.ExpiryDate, ')'),
           'pending'
    FROM items i
    WHERE i.ExpiryDate IS NOT NULL
      AND i.ExpiryDate BETWEEN CURRENT_DATE() AND (CURRENT_DATE() + INTERVAL 30 DAY);
END */ ;;
/*!50003 SET time_zone             = @saved_time_zone */ ;;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;;
/*!50003 SET character_set_client  = @saved_cs_client */ ;;
/*!50003 SET character_set_results = @saved_cs_results */ ;;
/*!50003 SET collation_connection  = @saved_col_connection */ ;;
/*!50106 DROP EVENT IF EXISTS `ev_expiring_soon_alerts` */;;
DELIMITER ;;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;;
/*!50003 SET character_set_client  = utf8mb4 */ ;;
/*!50003 SET character_set_results = utf8mb4 */ ;;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;;
/*!50003 SET @saved_time_zone      = @@time_zone */ ;;
/*!50003 SET time_zone             = 'SYSTEM' */ ;;
/*!50106 CREATE*/ /*!50117 DEFINER=`root`@`localhost`*/ /*!50106 EVENT `ev_expiring_soon_alerts` ON SCHEDULE EVERY 1 DAY STARTS '2025-09-18 00:00:00' ON COMPLETION NOT PRESERVE ENABLE DO BEGIN
    INSERT INTO Alerts (ItemID, Type, Details, Status)
    SELECT i.ItemID, 'Expiring Soon',
           CONCAT(s.ItemName, ' will expire on ', DATE_FORMAT(i.ExpiryDate, '%Y-%m-%d')),
           'Pending'
    FROM Items i
    JOIN SupplierItems s ON i.SupplierItemID = s.SupplierItemID
    WHERE s.HasExpiry = 1
      AND i.ExpiryDate BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY)
      AND i.Stock > 0
      AND NOT EXISTS (
           SELECT 1 FROM Alerts a
           WHERE a.ItemID = i.ItemID
             AND a.Type = 'Expiring Soon'
             AND a.Status = 'Pending'
      );
END */ ;;
/*!50003 SET time_zone             = @saved_time_zone */ ;;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;;
/*!50003 SET character_set_client  = @saved_cs_client */ ;;
/*!50003 SET character_set_results = @saved_cs_results */ ;;
/*!50003 SET collation_connection  = @saved_col_connection */ ;;
/*!50106 DROP EVENT IF EXISTS `ev_low_stock_alerts` */;;
DELIMITER ;;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;;
/*!50003 SET character_set_client  = utf8mb4 */ ;;
/*!50003 SET character_set_results = utf8mb4 */ ;;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;;
/*!50003 SET @saved_time_zone      = @@time_zone */ ;;
/*!50003 SET time_zone             = 'SYSTEM' */ ;;
/*!50106 CREATE*/ /*!50117 DEFINER=`root`@`localhost`*/ /*!50106 EVENT `ev_low_stock_alerts` ON SCHEDULE EVERY 1 DAY STARTS '2025-09-17 22:55:39' ON COMPLETION NOT PRESERVE ENABLE DO BEGIN
    -- Insert low stock alerts for items below 10
    INSERT INTO Alerts (ItemID, Type, Details, Status)
    SELECT i.ItemID, 'Low Stock', 
           CONCAT(i.ItemName, ' stock is below 10'), 
           'Pending'
    FROM Items i
    WHERE i.Stock < i.minstock
      AND i.Conditions = 'Good'
      AND NOT EXISTS (
          SELECT 1 FROM Alerts a
          WHERE a.ItemID = i.ItemID 
            AND a.Type = 'Low Stock' 
            AND a.Status = 'Pending'
      );
END */ ;;
/*!50003 SET time_zone             = @saved_time_zone */ ;;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;;
/*!50003 SET character_set_client  = @saved_cs_client */ ;;
/*!50003 SET character_set_results = @saved_cs_results */ ;;
/*!50003 SET collation_connection  = @saved_col_connection */ ;;
/*!50106 DROP EVENT IF EXISTS `ev_move_expired_items` */;;
DELIMITER ;;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;;
/*!50003 SET character_set_client  = utf8mb4 */ ;;
/*!50003 SET character_set_results = utf8mb4 */ ;;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;;
/*!50003 SET @saved_time_zone      = @@time_zone */ ;;
/*!50003 SET time_zone             = 'SYSTEM' */ ;;
/*!50106 CREATE*/ /*!50117 DEFINER=`root`@`localhost`*/ /*!50106 EVENT `ev_move_expired_items` ON SCHEDULE EVERY 1 DAY STARTS '2025-09-19 00:00:00' ON COMPLETION NOT PRESERVE ENABLE DO BEGIN
    -- Move expired items into Issues
    INSERT INTO Issues (ItemID, ItemName, Location, Stock, ExpiryDate, Conditions, QuantityAffected)
    SELECT i.ItemID, si.ItemName, 'Restaurant', i.Stock, i.ExpiryDate, 'Expired', i.Stock
    FROM Items i
    JOIN SupplierItems si ON i.SupplierItemID = si.SupplierItemID
    WHERE i.ExpiryDate IS NOT NULL AND i.ExpiryDate < CURDATE() AND i.Stock > 0;

    -- Reset expired items stock to 0
    UPDATE Items
    SET Stock = 0
    WHERE ExpiryDate IS NOT NULL AND ExpiryDate < CURDATE();
END */ ;;
/*!50003 SET time_zone             = @saved_time_zone */ ;;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;;
/*!50003 SET character_set_client  = @saved_cs_client */ ;;
/*!50003 SET character_set_results = @saved_cs_results */ ;;
/*!50003 SET collation_connection  = @saved_col_connection */ ;;
DELIMITER ;
/*!50106 SET TIME_ZONE= @save_time_zone */ ;

--
-- Dumping routines for database 'inventory_managementdb'
--
/*!50003 DROP PROCEDURE IF EXISTS `check_all_expirations` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `check_all_expirations`()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE v_item_id INT;
    DECLARE v_expiry_date DATE;
    DECLARE days_until_expiry INT;
    
    DECLARE cur CURSOR FOR 
        SELECT ItemID, ExpiryDate 
        FROM items 
        WHERE ExpiryDate IS NOT NULL;
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    OPEN cur;
    
    read_loop: LOOP
        FETCH cur INTO v_item_id, v_expiry_date;
        IF done THEN
            LEAVE read_loop;
        END IF;
        
        SET days_until_expiry = DATEDIFF(v_expiry_date, CURDATE());
        
        IF days_until_expiry < 0 THEN
            UPDATE alerts 
            SET Status = 'Resolved'
            WHERE ItemID = v_item_id 
            AND Type = 'Expiry Soon' 
            AND Status = 'Pending';
            
            INSERT INTO alerts (Type, ItemID, Details, Status)
            SELECT 'Expired', v_item_id,
                   CONCAT('Item expired on ', DATE_FORMAT(v_expiry_date, '%Y-%m-%d'), '. Remove from inventory immediately.'),
                   'Pending'
            WHERE NOT EXISTS (
                SELECT 1 FROM alerts 
                WHERE ItemID = v_item_id 
                AND Type = 'Expired' 
                AND Status = 'Pending'
            );
            
        ELSEIF days_until_expiry >= 0 AND days_until_expiry <= 30 THEN
            INSERT INTO alerts (Type, ItemID, Details, Status)
            SELECT 'Expiry Soon', v_item_id,
                   CONCAT('Item will expire on ', DATE_FORMAT(v_expiry_date, '%Y-%m-%d'), '. Use within ', days_until_expiry, ' days.'),
                   'Pending'
            WHERE NOT EXISTS (
                SELECT 1 FROM alerts 
                WHERE ItemID = v_item_id 
                AND Type IN ('Expiry Soon', 'Expired')
                AND Status = 'Pending'
            );
            
        ELSE
            UPDATE alerts 
            SET Status = 'Resolved'
            WHERE ItemID = v_item_id 
            AND Type IN ('Expiry Soon', 'Expired')
            AND Status = 'Pending';
        END IF;
        
    END LOOP;
    
    CLOSE cur;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-11 20:18:23
