-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: inventory_managementdb
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `items` (
  `ItemID` int NOT NULL AUTO_INCREMENT,
  `ItemName` varchar(100) NOT NULL,
  `SupplierItemID` int NOT NULL,
  `Location` enum('Restaurant','Room') NOT NULL DEFAULT 'Restaurant',
  `Stock` int NOT NULL,
  `Measurement` enum('Box','Pack','Sack','Pcs','Sets','Bottle') NOT NULL,
  `ExpiryDate` date DEFAULT NULL,
  `Conditions` varchar(50) DEFAULT NULL,
  `MinimumStock` int NOT NULL DEFAULT '10',
  PRIMARY KEY (`ItemID`),
  KEY `SupplierItemID` (`SupplierItemID`),
  CONSTRAINT `items_ibfk_1` FOREIGN KEY (`SupplierItemID`) REFERENCES `supplieritems` (`SupplierItemID`)
) ENGINE=InnoDB AUTO_INCREMENT=755 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `items`
--

LOCK TABLES `items` WRITE;
/*!40000 ALTER TABLE `items` DISABLE KEYS */;
INSERT INTO `items` VALUES (15,'Shampoo',3,'Restaurant',0,'Bottle',NULL,'Out of Stock',10),(17,'Soap',4,'Restaurant',0,'Pack',NULL,'Out of Stock',10),(719,'Rice',505,'Restaurant',0,'Sack','2026-01-02','Out of Stock',10),(720,'Chicken Breast',506,'Restaurant',0,'Pack',NULL,'Good',5),(721,'Beef Shank',507,'Restaurant',0,'Pack',NULL,'Good',5),(722,'Pork Leg',508,'Restaurant',2,'Pack','2025-12-31','Low Stock',3),(723,'Shrimp',509,'Restaurant',1,'Pack',NULL,'Low Stock',2),(724,'Squid',510,'Restaurant',0,'Pack',NULL,'Good',2),(725,'Tuna',511,'Restaurant',0,'Pack',NULL,'Good',2),(726,'Mussels',512,'Restaurant',0,'Pack',NULL,'Good',1),(727,'Lettuce',513,'Restaurant',0,'Pack',NULL,'Good',1),(728,'Tomatoes',514,'Restaurant',0,'Pack',NULL,'Good',1),(729,'Onions',515,'Restaurant',0,'Pack',NULL,'Good',2),(730,'Garlic',516,'Restaurant',0,'Pack',NULL,'Good',1),(731,'Milk',517,'Restaurant',0,'Bottle',NULL,'Good',2),(732,'Eggs',518,'Restaurant',0,'Sets',NULL,'Good',20),(733,'Cheese',519,'Restaurant',0,'Pack',NULL,'Good',1),(734,'Cream',520,'Restaurant',0,'Bottle',NULL,'Good',1),(735,'Bacon',521,'Restaurant',4,'Pack','2026-07-23','Low Stock',1),(736,'Ham',522,'Restaurant',0,'Pack',NULL,'Good',1),(737,'Peanut Sauce',523,'Restaurant',0,'Bottle',NULL,'Good',1),(738,'Chocolate',524,'Restaurant',0,'Pack',NULL,'Good',1),(739,'Matcha Powder',525,'Restaurant',0,'Pack',NULL,'Good',1),(740,'Coffee Beans',526,'Restaurant',0,'Pack',NULL,'Good',1),(741,'Tapioca Pearls',527,'Restaurant',0,'Pack',NULL,'Good',1),(742,'Flour',528,'Restaurant',0,'Sack',NULL,'Good',5),(743,'Sugar',529,'Restaurant',0,'Sack',NULL,'Good',5),(744,'Salt',530,'Restaurant',0,'Pack',NULL,'Good',2),(745,'Oil',531,'Restaurant',0,'Bottle',NULL,'Good',3),(746,'Soy Sauce',532,'Restaurant',0,'Bottle','2026-05-21','Out of Stock',1),(747,'Vinegar',533,'Restaurant',0,'Bottle',NULL,'Good',1),(748,'Pineapple',534,'Restaurant',0,'Pcs',NULL,'Good',5),(749,'Watermelon',535,'Restaurant',0,'Pcs',NULL,'Good',3),(750,'Lemon',536,'Restaurant',0,'Pcs',NULL,'Good',10),(751,'Dragon Fruit',537,'Restaurant',0,'Pcs',NULL,'Good',5),(752,'Cola Syrup',538,'Restaurant',0,'Bottle',NULL,'Good',1),(753,'Ice',539,'Restaurant',0,'Sack',NULL,'Good',10),(754,'Soap',12,'Restaurant',8,'Pack','2026-08-27','Low Stock',10);
/*!40000 ALTER TABLE `items` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_items_after_insert_noti` AFTER INSERT ON `items` FOR EACH ROW BEGIN
    -- Item Added
    INSERT INTO notifications (title, message, type)
    VALUES (
        'Item Added',
        CONCAT('New item added: ', NEW.ItemName, ' (', NEW.Stock, ' ', NEW.Measurement, ')'),
        'added'
    );

    -- Low stock
    IF NEW.Stock <= NEW.MinimumStock AND NEW.Stock > 0 THEN
        INSERT INTO notifications (title, message, type)
        VALUES (
            'Low Stock',
            CONCAT('Low stock: ', NEW.ItemName, ' (Remaining: ', NEW.Stock, ', Minimum: ', NEW.MinimumStock, ')'),
            'pending'
        );
    END IF;

    -- Out of stock
    IF NEW.Stock = 0 THEN
        INSERT INTO notifications (title, message, type)
        VALUES (
            'Out of Stock',
            CONCAT('Out of stock: ', NEW.ItemName),
            'pending'
        );
    END IF;

    -- Already expired
    IF NEW.ExpiryDate IS NOT NULL AND NEW.ExpiryDate < CURRENT_DATE() THEN
        INSERT INTO notifications (title, message, type)
        VALUES (
            'Expired Item',
            CONCAT('Expired: ', NEW.ItemName, ' (', NEW.ExpiryDate, ')'),
            'pending'
        );
    END IF;

    -- Expiring soon (within 30 days)
    IF NEW.ExpiryDate IS NOT NULL AND NEW.ExpiryDate BETWEEN CURRENT_DATE() AND (CURRENT_DATE() + INTERVAL 30 DAY) THEN
        INSERT INTO notifications (title, message, type)
        VALUES (
            'Expiring Soon',
            CONCAT('Expiring soon: ', NEW.ItemName, ' (', NEW.ExpiryDate, ')'),
            'pending'
        );
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_items_after_insert_expired` AFTER INSERT ON `items` FOR EACH ROW BEGIN
    IF NEW.ExpiryDate IS NOT NULL AND NEW.ExpiryDate < CURRENT_DATE() THEN
        -- Insert into issues
        INSERT INTO issues (ItemID, Description, Status, CreatedAt)
        VALUES (NEW.ItemID, 
                CONCAT('Item expired on insert: ', NEW.ItemName, ' (', NEW.ExpiryDate, ')'), 
                'pending', 
                NOW());

        -- Delete from items
        DELETE FROM items WHERE ItemID = NEW.ItemID;
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `check_expiration_on_insert` AFTER INSERT ON `items` FOR EACH ROW BEGIN
    DECLARE days_until_expiry INT;
    
    IF NEW.ExpiryDate IS NOT NULL THEN
        SET days_until_expiry = DATEDIFF(NEW.ExpiryDate, CURDATE());
        
        IF days_until_expiry < 0 THEN
            INSERT INTO alerts (Type, ItemID, Details, Status)
            SELECT 'Expired', NEW.ItemID, 
                   CONCAT('Item expired on ', DATE_FORMAT(NEW.ExpiryDate, '%Y-%m-%d'), '. Remove from inventory immediately.'),
                   'Pending'
            WHERE NOT EXISTS (
                SELECT 1 FROM alerts 
                WHERE ItemID = NEW.ItemID 
                AND Type = 'Expired' 
                AND Status = 'Pending'
            );
            
        ELSEIF days_until_expiry >= 0 AND days_until_expiry <= 30 THEN
            INSERT INTO alerts (Type, ItemID, Details, Status)
            SELECT 'Expiry Soon', NEW.ItemID,
                   CONCAT('Item will expire on ', DATE_FORMAT(NEW.ExpiryDate, '%Y-%m-%d'), '. Use within ', days_until_expiry, ' days.'),
                   'Pending'
            WHERE NOT EXISTS (
                SELECT 1 FROM alerts 
                WHERE ItemID = NEW.ItemID 
                AND Type IN ('Expiry Soon', 'Expired')
                AND Status = 'Pending'
            );
        END IF;
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `after_item_insert` AFTER INSERT ON `items` FOR EACH ROW BEGIN
    DECLARE alert_exists INT;
    
    IF NEW.Stock <= 10 AND NEW.Stock > 0 THEN
        SELECT COUNT(*) INTO alert_exists FROM alerts WHERE ItemID = NEW.ItemID AND Type = 'Low Stock';
        
        IF alert_exists = 0 THEN
            INSERT INTO alerts (ItemID, Type, Details, Status) 
            VALUES (NEW.ItemID, 'Low Stock', CONCAT('Stock level is low: ', NEW.Stock, ' remaining'), 'Pending');
        ELSE
            UPDATE alerts 
            SET Details = CONCAT('Stock level is low: ', NEW.Stock, ' remaining'), Status = 'Pending'
            WHERE ItemID = NEW.ItemID AND Type = 'Low Stock';
        END IF;
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `check_expiration_on_update` AFTER UPDATE ON `items` FOR EACH ROW BEGIN
    DECLARE days_until_expiry INT;
    
    IF NEW.ExpiryDate IS NOT NULL AND (OLD.ExpiryDate IS NULL OR NEW.ExpiryDate != OLD.ExpiryDate) THEN
        SET days_until_expiry = DATEDIFF(NEW.ExpiryDate, CURDATE());
        
        IF days_until_expiry < 0 THEN
            UPDATE alerts SET Status = 'Resolved' WHERE ItemID = NEW.ItemID AND Type = 'Expiry Soon' AND Status = 'Pending';
            INSERT INTO alerts (Type, ItemID, Details, Status)
            SELECT 'Expired', NEW.ItemID,
                   CONCAT('Item expired on ', DATE_FORMAT(NEW.ExpiryDate, '%Y-%m-%d'), '. Remove from inventory immediately.'),
                   'Pending'
            WHERE NOT EXISTS (SELECT 1 FROM alerts WHERE ItemID = NEW.ItemID AND Type = 'Expired' AND Status = 'Pending');
        ELSEIF days_until_expiry >= 0 AND days_until_expiry <= 30 THEN
            INSERT INTO alerts (Type, ItemID, Details, Status)
            SELECT 'Expiry Soon', NEW.ItemID,
                   CONCAT('Item will expire on ', DATE_FORMAT(NEW.ExpiryDate, '%Y-%m-%d'), '. Use within ', days_until_expiry, ' days.'),
                   'Pending'
            WHERE NOT EXISTS (SELECT 1 FROM alerts WHERE ItemID = NEW.ItemID AND Type IN ('Expiry Soon', 'Expired') AND Status = 'Pending');
        ELSE
            UPDATE alerts SET Status = 'Resolved' WHERE ItemID = NEW.ItemID AND Type IN ('Expiry Soon', 'Expired') AND Status = 'Pending';
        END IF;
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `after_item_update` AFTER UPDATE ON `items` FOR EACH ROW BEGIN
    DECLARE alert_exists INT;
    
    IF NEW.Stock <= 10 AND NEW.Stock > 0 THEN
        SELECT COUNT(*) INTO alert_exists FROM alerts WHERE ItemID = NEW.ItemID AND Type = 'Low Stock';
        
        IF alert_exists = 0 THEN
            INSERT INTO alerts (ItemID, Type, Details, Status) 
            VALUES (NEW.ItemID, 'Low Stock', CONCAT('Stock level is low: ', NEW.Stock, ' remaining'), 'Pending');
        ELSE
            UPDATE alerts 
            SET Details = CONCAT('Stock level is low: ', NEW.Stock, ' remaining'), Status = 'Pending'
            WHERE ItemID = NEW.ItemID AND Type = 'Low Stock';
        END IF;
    ELSEIF NEW.Stock > 10 THEN
        DELETE FROM alerts WHERE ItemID = NEW.ItemID AND Type = 'Low Stock';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-11 20:18:21
