-- Add CreatedAt column to alerts and issues tables
-- Run this migration to add timestamp tracking for when alerts and issues were created

-- Add CreatedAt to alerts table
ALTER TABLE `alerts` 
ADD COLUMN `CreatedAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER `Status`;

-- Add CreatedAt to issues table  
ALTER TABLE `issues`
ADD COLUMN `CreatedAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER `QuantityAffected`;

-- Note: Existing records will automatically get the current timestamp due to DEFAULT CURRENT_TIMESTAMP
-- No UPDATE statements needed - the ALTER TABLE with DEFAULT handles it
