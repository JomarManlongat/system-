-- Update "Both" location to "Restaurant" for items
UPDATE items 
SET Location = 'Restaurant'
WHERE Location = 'Both';

-- Update "Both" location to "Restaurant" for suppliers
UPDATE suppliers 
SET Location = 'Restaurant'
WHERE Location = 'Both';
