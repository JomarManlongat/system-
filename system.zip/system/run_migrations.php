<?php
// Simple migration runner
require_once 'main_inventory_system/login/database-account.php';

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

echo "Connected to database successfully.\n";

// Read and execute remove_both_locations.sql
echo "\n--- Running remove_both_locations.sql ---\n";
$sql1 = file_get_contents('database/remove_both_locations.sql');
if ($conn->multi_query($sql1)) {
    do {
        if ($result = $conn->store_result()) {
            $result->free();
        }
    } while ($conn->next_result());
    echo "✓ Successfully updated 'Both' locations to 'Restaurant'\n";
} else {
    echo "✗ Error: " . $conn->error . "\n";
}

// Read and execute remove_user_location.sql
echo "\n--- Running remove_user_location.sql ---\n";
$sql2 = file_get_contents('database/remove_user_location.sql');
if ($conn->multi_query($sql2)) {
    do {
        if ($result = $conn->store_result()) {
            $result->free();
        }
    } while ($conn->next_result());
    echo "✓ Successfully removed Location column from users table\n";
} else {
    echo "✗ Error: " . $conn->error . "\n";
}

$conn->close();
echo "\n✓ All migrations completed successfully!\n";
?>
