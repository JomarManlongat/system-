<?php
require __DIR__ . '/login/database-account.php';

// Check the orders table columns
$result = $conn->query("DESCRIBE orders");
echo "=== ORDERS TABLE SCHEMA ===\n";
while ($row = $result->fetch_assoc()) {
  echo "Column: " . $row['Field'] . " | Type: " . $row['Type'] . " | Null: " . $row['Null'] . " | Default: " . $row['Default'] . "\n";
}

$conn->close();
?>
