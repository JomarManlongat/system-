<?php
// Disable all error output
error_reporting(0);
ini_set('display_errors', 0);

// Start output buffering to catch any stray output
ob_start();

// Use separate session name for inventory system to prevent session collision with restaurant
session_name('INVENTORY_SESSION');
session_start();

// Include database connection
$servername = "localhost";
$username   = "root";       
$password   = "Jojenjusjmjai09";           
$database   = "inventory_managementdb"; 

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'message' => 'Database connection failed. Please try again later.'
    ]);
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user = $_POST['username'] ?? '';
    $pass = $_POST['password'] ?? '';

    // prevent SQL injection
    $user = mysqli_real_escape_string($conn, $user);

    // query (check username only)
    $sql = "SELECT * FROM users WHERE username='$user' LIMIT 1";
    $result = mysqli_query($conn, $sql);

    // Clear any output buffer
    ob_end_clean();

    if ($result && mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);
        
        // Check if user is active (if Status column exists)
        $userStatus = $row['Status'] ?? $row['status'] ?? 'Active';
        if ($userStatus === 'Inactive') {
            header('Content-Type: application/json');
            echo json_encode([
                'success' => false,
                'message' => 'This account has been deactivated. Please contact an administrator.'
            ]);
            exit();
        }
        
        // Check password - supports both hashed and plain text (for backward compatibility)
        $password_valid = false;
        $stored_password = $row['password'] ?? ($row['Password'] ?? '');
        
        // First try password_verify for hashed passwords
        if (password_verify($pass, $stored_password)) {
            $password_valid = true;
        } 
        // Fallback to plain text comparison for old passwords
        elseif ($pass === $stored_password) {
            $password_valid = true;
        }
        
        if (!$password_valid) {
            header('Content-Type: application/json');
            echo json_encode([
                'success' => false,
                'message' => 'Invalid username or password. Please try again.'
            ]);
            exit();
        }

        $_SESSION['username'] = $row['username'];
        $_SESSION['UserID'] = $row['UserID']; // Store UserID for delete operations
        
        // Store user's full name in session
        $userName = '';
        if (isset($row['Name'])) {
            $userName = $row['Name'];
        } elseif (isset($row['name'])) {
            $userName = $row['name'];
        } elseif (isset($row['FullName'])) {
            $userName = $row['FullName'];
        } elseif (isset($row['full_name'])) {
            $userName = $row['full_name'];
        }
        $_SESSION['user_name'] = $userName;
        
        // Store user's location (Restaurant/Room) in session
        // If the Location column exists but is NULL, preserve NULL so user can access both locations.
        if (array_key_exists('Location', $row)) {
            $userLocation = $row['Location']; // may be NULL
        } else {
            $userLocation = null; // no Location column defined
        }
        
        // Check for role in both cases (Roles or roles column)
        $userRole = '';
        if (isset($row['Roles'])) {
            $userRole = $row['Roles'];
        } elseif (isset($row['roles'])) {
            $userRole = $row['roles'];
        } elseif (isset($row['role'])) {
            $userRole = $row['role'];
        } elseif (isset($row['Role'])) {
            $userRole = $row['Role'];
        }
        
        $_SESSION['roles'] = $userRole;
        $_SESSION['Role'] = $userRole; // Add for authentication checks

        // Determine redirect based on role (case-insensitive)
        $redirect = '../admin-page/admin_inv_man.php'; // default for admin
        
        $roleLower = strtolower(trim($userRole));
        if ($roleLower === 'staff') {
            $redirect = '../staff-page/staff_inv_man.php';
        }

        // Return success with redirect URL
        header('Content-Type: application/json');
        echo json_encode([
            'success' => true,
            'redirect' => $redirect,
            'role' => $userRole, // Debug: send role back to check
            'location' => $userLocation // Include location for debugging
        ]);
    } else {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Invalid username or password. Please try again.'
        ]);
    }
    exit();
}
?>