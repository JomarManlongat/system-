<?php include '../nocache.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Management System</title>
    <link rel="stylesheet" type="text/css" href="login.css">
    
</head>
<body>
    <div class="header-top">
        <div class="for-design">
            <img src="../logos/moon.png" id="header-logo" height="23px" width="23px">
            <h2 class="text-header">  Lunera Hotel </h2>
        </div>

    </div>
    <form id="login" action="login-function.php" method="POST" autocomplete="off">
        <div class="login-container">
            <div class="title-logo">
                <img src="../logos/stock-management.png" alt="website logo" class="logo-im">
                <h2> Inventory Management</h2>
            </div>
            <p> Sign in to your account to management inventory.</p>
            <div id="login_error_message" style="display: none; color: #dc3545; background: #f8d7da; padding: 10px; border-radius: 5px; margin-bottom: 15px; font-size: 14px; text-align: center;"></div>
            <div class="container">
                <input type="text" class="email" name="username" autocomplete="off" placeholder="" required>
                <label for="email">Username</label>
            </div>
            <div class="container">
                <input type="password" class="password" name="password" autocomplete="new-password" placeholder="" required>
                <label for="password">Password</label>
            </div>
            <button type="submit" class="btn-submit-login">Sign In</button>
        </div>
    </form>
    <script src="login.js"></script>
    <div id="loader-wrapper">
        <div id="loader"></div>
    </div>
</body>
</html>

