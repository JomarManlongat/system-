<?php
require __DIR__ . '/login/database-account.php';

echo "=== CHECKING ORDER DATABASE STATUS ===\n\n";

// Check the latest orders
$result = $conn->query("SELECT OrderID, SupplierID, Status FROM orders ORDER BY OrderID DESC LIMIT 5");
echo "Latest Orders:\n";
while ($row = $result->fetch_assoc()) {
  echo "  ORD" . str_pad($row['OrderID'], 3, '0', STR_PAD_LEFT) . " - Status: " . $row['Status'] . " (Supplier ID: " . $row['SupplierID'] . ")\n";
}

echo "\n=== CHECKING ORDERDETAILS STATUS ===\n\n";

// Check the enum values for Status column
$result = $conn->query("SHOW COLUMNS FROM orderdetails WHERE Field = 'Status'");
if ($row = $result->fetch_assoc()) {
  echo "Status column type: " . $row['Type'] . "\n";
}

echo "\nSample OrderDetails:\n";
$result = $conn->query("SELECT OrderDetailID, OrderID, Status FROM orderdetails ORDER BY OrderDetailID DESC LIMIT 5");
while ($row = $result->fetch_assoc()) {
  echo "  OrderDetail " . $row['OrderDetailID'] . " (Order " . $row['OrderID'] . ") - Status: " . $row['Status'] . "\n";
}

$conn->close();
?>
