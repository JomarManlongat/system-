<?php
// Disable browser caching
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// OPTIONAL: Reset PHP opcode cache (for development)
if (function_exists('opcache_reset')) {
    opcache_reset();
}
?>