<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "=== TESTING SUBMIT_ORDER.PHP ===\n";

// Simulate a POST request with test data - using CORRECT supplier item ID
$_POST['supplier_id'] = '71';  // Fresh Food Wholesale
$_POST['items'] = json_encode([
  ['supplier_item_id' => '505', 'quantity' => '5']  // Rice - correct ID
]);

echo "POST supplier_id: " . $_POST['supplier_id'] . "\n";
echo "POST items: " . $_POST['items'] . "\n";

// Include the actual submit_order.php
require __DIR__ . '/admin-page/orders/submit_order.php';
?>
