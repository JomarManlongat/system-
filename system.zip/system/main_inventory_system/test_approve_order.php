<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "=== TESTING APPROVE_ORDER.PHP ===\n";

// Simulate a POST request to approve the order we just created
$_POST['order_id'] = '16';  // Order ID from previous test

echo "POST order_id: " . $_POST['order_id'] . "\n";

// Include the approve order script
require __DIR__ . '/admin-page/orders/approve_order.php';
?>
