<?php
require __DIR__ . '/login/database-account.php';

// Check what supplier items exist
$result = $conn->query("SELECT SupplierItemID, ItemName, SupplierID FROM supplieritems LIMIT 10");
echo "=== SUPPLIER ITEMS IN DATABASE ===\n";
while ($row = $result->fetch_assoc()) {
  echo "ID: " . $row['SupplierItemID'] . " | Name: " . $row['ItemName'] . " | SupplierID: " . $row['SupplierID'] . "\n";
}

echo "\n=== SUPPLIERS ===\n";
$suppResult = $conn->query("SELECT SupplierID, SupplierName FROM suppliers LIMIT 10");
while ($row = $suppResult->fetch_assoc()) {
  echo "ID: " . $row['SupplierID'] . " | Name: " . $row['SupplierName'] . "\n";
}

$conn->close();
?>
