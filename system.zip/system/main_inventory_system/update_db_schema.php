<?php
require __DIR__ . '/login/database-account.php';

echo "=== UPDATING DATABASE SCHEMA ===\n";

// The orders table Status is varchar(50), so it's fine with "To Be Recorded"
// But let's verify the actual values are being used properly

// Check current orders status values
$result = $conn->query("SELECT DISTINCT Status FROM orders ORDER BY Status");
echo "Current order statuses in database:\n";
while ($row = $result->fetch_assoc()) {
  echo "  - " . $row['Status'] . "\n";
}

// Alter orderdetails to add "To Be Recorded"
$sql = "ALTER TABLE orderdetails MODIFY COLUMN Status ENUM('Pending Approval','To Be Recorded','In Transit','Received','Shipped') DEFAULT 'Pending Approval'";

if ($conn->query($sql)) {
  echo "\n✓ Successfully updated orderdetails Status enum\n";
} else {
  echo "\n✗ Error updating orderdetails: " . $conn->error . "\n";
}

// Check orderdetails schema
$result = $conn->query("SHOW COLUMNS FROM orderdetails WHERE Field = 'Status'");
if ($row = $result->fetch_assoc()) {
  echo "\nOrderdetails Status column type: " . $row['Type'] . "\n";
}

$conn->close();
?>
