<?php
// Record Usage Modal - Popup form for recording item consumption/usage
// Ensure session available so we can detect logged-in user and role
if (session_status() === PHP_SESSION_NONE) {
    session_name('INVENTORY_SESSION');
    session_start();
}
?>
<div id="recordUsageModal" class="modal" aria-hidden="true" style="display:none;">
  <div class="modal-content">
    <div class="modal-header">
      <h3 style="margin:0;">Record Item Usage</h3>
      <span class="close" onclick="closeUsageModal()" aria-label="Close">&times;</span>
    </div>

    <form id="recordUsageForm" method="POST" action="../functions/save_usage.php" class="usage-form" novalidate>
      <!-- Search / Select item (combined field) -->
      <div id="usage_search_block">
        <label for="usage_search">Item</label>
        <input type="search" id="usage_search" placeholder="Type item name or ID" autocomplete="off" />
        <div id="usage_dropdown" style="display:none; max-height:220px; overflow:auto;"></div>
      </div>

      <!-- Hidden input containing the ItemID to submit -->
      <input type="hidden" id="usage_item" name="item" />

      <!-- Quantity -->
      <label for="usage_quantity">Quantity Used</label>
      <input type="number" id="usage_quantity" name="quantity" min="1" required value="1" />

      <!-- User (populated from DB) -->
      <label for="usage_user">User</label>
      <?php
      // determine session user and role
      $sess_userid = $_SESSION['UserID'] ?? $_SESSION['user_id'] ?? '';
      $sess_username = $_SESSION['user_name'] ?? $_SESSION['username'] ?? '';
      $sess_role = strtolower($_SESSION['Role'] ?? $_SESSION['roles'] ?? $_SESSION['role'] ?? '');

      // if staff, we'll disable the select and emit a hidden input so the value is posted
      $select_disabled = ($sess_role === 'staff') ? ' disabled' : '';
      echo "<select id=\"usage_user\" name=\"user_select\" required{$select_disabled}>";
      echo "<option value=\"\">Select a user</option>";
      ?>
        <?php
        // include DB connection and output users
        include __DIR__ . '/../../login/database-account.php';
        
        // Check if Status column exists
        $hasStatus = false;
        $chkStatus = $conn->query("SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME='users' AND COLUMN_NAME='Status'");
        if ($chkStatus && $chkStatus->num_rows > 0) {
          $hasStatus = true;
        }
        
        $sql = "SELECT UserID, Username FROM users WHERE 1=1";
        if ($hasStatus) {
          $sql .= " AND (Status = 'Active' OR Status IS NULL)";
        }
        $sql .= " ORDER BY Username ASC";
        
        $res = $conn->query($sql);
        if ($res) {
          while ($row = $res->fetch_assoc()) {
            $uId = htmlspecialchars($row['UserID']);
            $uName = htmlspecialchars($row['Username']);
            $selected = ($sess_userid !== '' && (string)$sess_userid === (string)$row['UserID']) ? ' selected' : '';
            echo "<option value='{$uId}'{$selected}>{$uName}</option>";
          }
        }
        ?>
        </select>
        <?php
        // output a hidden input named 'user' when staff (disabled selects are not submitted)
        if ($select_disabled) {
          $hidVal = htmlspecialchars($sess_userid ?: '');
          echo "<input type=\"hidden\" name=\"user\" id=\"usage_user_hidden\" value=\"{$hidVal}\">";
        } else {
          // keep a hidden field in sync for non-staff too (server expects 'user')
          echo '<input type="hidden" name="user" id="usage_user_hidden" value="">';
        }
        ?>

      <!-- Received By (who got the item) -->
      <label for="usage_received_by">Received By (Who got the item)</label>
      <input type="text" id="usage_received_by" name="received_by" placeholder="Enter receiver name (optional)" maxlength="50" />

      <!-- Date and Time Used -->
      <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-top:12px;">
        <div>
          <label for="usage_date">Date Used (optional)</label>
          <input type="date" id="usage_date" name="usage_date" />
        </div>
        <div>
          <label for="usage_time">Time Used (optional)</label>
          <input type="time" id="usage_time" name="usage_time" />
        </div>
      </div>

      <!-- Notes -->
      <label for="usage_notes" style="margin-top:12px;">Description (optional)</label>
      <textarea id="usage_notes" name="notes" placeholder="Add notes about this usage (optional)" maxlength="250" style="width:100%; height:60px; padding:8px; border:1px solid #d1d5db; border-radius:6px; font-size:13px; resize:vertical;"></textarea>

      <div id="usage_message" style="color:#b00; margin-top:8px; display:none;"></div>

      <!-- Buttons -->
      <div class="modal-actions" style="margin-top:12px;">
        <button type="button" class="cancel-btn" onclick="closeUsageModal()">Cancel</button>
        <button type="submit" class="save-btn" id="usage_save_btn">Record Usage</button>
      </div>
    </form>
  </div>
</div>
