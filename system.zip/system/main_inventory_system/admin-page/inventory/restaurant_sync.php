<?php
// restaurant_sync.php
// Provides sync_usage_to_restaurant($conn, $usage_id)
// Requires: $servername, $username, $password available in scope or passed as globals

/**
 * Get conversion factor from inventory unit to restaurant unit
 * Based on standard food service measurements
 */
function getConversionFactor($inventoryUnit) {
    $unit = strtolower(trim($inventoryUnit ?? ''));
    
    switch ($unit) {
        case 'pack':
            return 15.0; // 1 pack = 15 pieces (average for food items)
        case 'box':
            return 24.0; // 1 box = 24 pieces (standard case pack)
        case 'sack':
            return 50.0; // 1 sack = 50 kg (standard rice/flour sack)
        case 'bottle':
            return 1.0; // 1 bottle = 1 liter (assuming standard bottles)
        case 'sets':
            return 6.0; // 1 set = 6 pieces (standard set pack)
        case 'pcs':
        case 'pieces':
            return 1.0; // Already in pieces
        default:
            return 1.0; // No conversion
    }
}

/**
 * Get the restaurant unit that corresponds to inventory unit
 */
function getRestaurantUnit($inventoryUnit) {
    $unit = strtolower(trim($inventoryUnit ?? ''));
    
    switch ($unit) {
        case 'pack':
        case 'box':
        case 'sets':
            return 'pieces'; // Convert to pieces for restaurant use
        case 'sack':
            return 'kg'; // Sacks become kg in restaurant
        case 'bottle':
            return 'liter'; // Bottles become liters
        case 'pcs':
        case 'pieces':
            return 'pieces';
        default:
            return $inventoryUnit; // Keep original if unknown
    }
}

function sync_usage_to_restaurant($conn, $usage_id) {
    // Validate
    $usage_id = intval($usage_id);
    if ($usage_id <= 0) return false;

    // Load the usage row
    $uStmt = $conn->prepare("SELECT UsageID, ItemID, Quantity FROM item_usage WHERE UsageID = ? LIMIT 1");
    if (!$uStmt) return false;
    $uStmt->bind_param('i', $usage_id);
    $uStmt->execute();
    $ures = $uStmt->get_result();
    if (!$ures || $ures->num_rows === 0) { $uStmt->close(); return false; }
    $urow = $ures->fetch_assoc();
    $uStmt->close();

    $item = intval($urow['ItemID']);
    $quantity = floatval($urow['Quantity']);
    if ($item <= 0 || $quantity <= 0) return false;

    // Attempt to resolve ingredient name and conversion factor
    $ingredientName = null;
    $conv = 1.0;
    $derivedUnit = null;
    $derivedCost = null;

    $mapStmt = $conn->prepare("SELECT restaurant_ingredient_name, conversion_factor FROM item_ingredient_mapping WHERE inventory_item_id = ? LIMIT 1");
    if ($mapStmt) {
        $mapStmt->bind_param('i', $item);
        $mapStmt->execute();
        $mres = $mapStmt->get_result();
        if ($mres && $mres->num_rows) {
            $mrow = $mres->fetch_assoc();
            $ingredientName = $mrow['restaurant_ingredient_name'];
            $conv = floatval($mrow['conversion_factor']) ?: 1.0;
        }
        $mapStmt->close();
    }

    if (!$ingredientName) {
        $derive = $conn->prepare("SELECT i.ItemName AS name, i.Measurement AS inv_unit, si.Measurement AS unit, si.Price AS cost FROM items i LEFT JOIN supplieritems si ON i.SupplierItemID = si.SupplierItemID WHERE i.ItemID = ? LIMIT 1");
        if ($derive) {
            $derive->bind_param('i', $item);
            $derive->execute();
            $dres = $derive->get_result();
            if ($dres && $dres->num_rows) {
                $drow = $dres->fetch_assoc();
                $ingredientName = $drow['name'] ?: ('Item ' . $item);
                $inventoryUnit = $drow['inv_unit'] ?? $drow['unit'] ?? null;
                $derivedUnit = $drow['unit'] ?? null;
                $derivedCost = is_numeric($drow['cost']) ? floatval($drow['cost']) : null;
                
                // Apply automatic conversion based on inventory measurement
                $conv = getConversionFactor($inventoryUnit);
                $derivedUnit = getRestaurantUnit($inventoryUnit);
            }
            $derive->close();
        }
    }

    if (!$ingredientName) return false;
    $restQty = $quantity * $conv;

    // Connect to restaurant DB
    global $servername, $username, $password;
    $rconn = new mysqli($servername, $username, $password, 'hotel_restaurant');
    if ($rconn->connect_error) return false;

    // Discover columns
    $colRes = $rconn->query("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = 'hotel_restaurant' AND TABLE_NAME = 'current_ingredients_stock'");
    $cols = [];
    while ($cr = $colRes->fetch_assoc()) $cols[] = $cr['COLUMN_NAME'];

    $idCol = null; $nameCol = null; $qtyCol = null; $unitCol = null; $costCol = null;
    foreach ($cols as $c) {
        $lc = strtolower($c);
        if (!$idCol && in_array($lc, ['id','ingredientid','stockid','currentingredientsid'])) $idCol = $c;
        if (!$nameCol && in_array($lc, ['ingredientname','ingredient_name','name','ingredient'])) $nameCol = $c;
        if (!$qtyCol && in_array($lc, ['currentquantity','current_quantity','quantity','qty','current_qty','stock'])) $qtyCol = $c;
        if (!$unitCol && in_array($lc, ['unit','measurement','uom'])) $unitCol = $c;
        if (!$costCol && in_array($lc, ['costperunit','cost_per_unit','cost','price'])) $costCol = $c;
    }

    if (!$nameCol || !$qtyCol) { $rconn->close(); return false; }

    // Prefer matching by name+cost when cost available
    $foundRows = [];
    if ($costCol && $derivedCost !== null) {
        $safeName = $rconn->real_escape_string($ingredientName);
        $safeCost = floatval($derivedCost);
        $q = "SELECT * FROM current_ingredients_stock WHERE `$nameCol` = '$safeName' AND `$costCol` = " . $safeCost;
        $res = $rconn->query($q);
        while ($rr = $res->fetch_assoc()) $foundRows[] = $rr;
    }

    if (empty($foundRows)) {
        $safeName = $rconn->real_escape_string($ingredientName);
        $q = "SELECT * FROM current_ingredients_stock WHERE `$nameCol` = '$safeName'";
        $res2 = $rconn->query($q);
        while ($rr = $res2->fetch_assoc()) $foundRows[] = $rr;
    }

    if (count($foundRows) === 0) {
        // insert
        $insCols = ["`$nameCol`", "`$qtyCol`"];
        $insVals = ['?', '?'];
        if ($unitCol) { $insCols[] = "`$unitCol`"; $insVals[] = '?'; }
        if ($costCol) { $insCols[] = "`$costCol`"; $insVals[] = '?'; }
        $qins = "INSERT INTO current_ingredients_stock (" . implode(',', $insCols) . ") VALUES (" . implode(',', $insVals) . ")";
        $ist = $rconn->prepare($qins);
        if ($ist) {
            $bindTypes = 'sd';
            $bindParams = [$ingredientName, $restQty];
            if ($unitCol) { $bindTypes .= 's'; $bindParams[] = $derivedUnit ?? ''; }
            if ($costCol) { $bindTypes .= 'd'; $bindParams[] = $derivedCost !== null ? floatval($derivedCost) : 0.0; }
            $ist->bind_param($bindTypes, ...$bindParams);
            $ist->execute();
            $ist->close();
        }

    } else if (count($foundRows) === 1) {
        $keep = $foundRows[0];
        $keepId = $keep[$idCol];
        $ust = $rconn->prepare("UPDATE current_ingredients_stock SET `$qtyCol` = `$qtyCol` + ? WHERE `$idCol` = ?");
        if ($ust) { $ust->bind_param('di', $restQty, $keepId); $ust->execute(); $ust->close(); }
    } else {
        // combine duplicates
        $total = 0; $ids = [];
        foreach ($foundRows as $rrow) { $total += floatval($rrow[$qtyCol]); $ids[] = intval($rrow[$idCol]); }
        $total += $restQty;
        sort($ids);
        $keepId = array_shift($ids);
        $ust = $rconn->prepare("UPDATE current_ingredients_stock SET `$qtyCol` = ? WHERE `$idCol` = ?");
        if ($ust) { $ust->bind_param('di', $total, $keepId); $ust->execute(); $ust->close(); }
        foreach ($ids as $delId) { $dlt = $rconn->prepare("DELETE FROM current_ingredients_stock WHERE `$idCol` = ?"); if ($dlt) { $dlt->bind_param('i', $delId); $dlt->execute(); $dlt->close(); } }
    }

    // mark item_usage as synced (guard if column exists)
    $chk = $conn->query("SHOW COLUMNS FROM item_usage LIKE 'synced_to_restaurant'");
    if ($chk && $chk->num_rows > 0) {
        $mark = $conn->prepare("UPDATE item_usage SET synced_to_restaurant = 1, synced_at = NOW() WHERE UsageID = ?");
        if ($mark) { $mark->bind_param('i', $usage_id); $mark->execute(); $mark->close(); }
    }

    // close
    $rconn->close();
    return true;
}

?>