<?php
header('Content-Type: application/json; charset=utf-8');
session_name('INVENTORY_SESSION');
session_start();
require_once __DIR__ . '/../../login/database-account.php';

$q = isset($_GET['q']) ? trim($_GET['q']) : '';
if ($q === '') { 
    echo json_encode([]); 
    exit; 
}

$like = "%{$q}%";

$sql = "SELECT i.ItemID, si.ItemName, i.Stock, si.Measurement, i.Location
        FROM items i
        JOIN supplieritems si ON i.SupplierItemID = si.SupplierItemID
        WHERE (i.ItemID LIKE ? OR si.ItemName LIKE ?)
        ORDER BY si.ItemName ASC
        LIMIT 40";

if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param('ss', $like, $like);
    $stmt->execute();
    $res = $stmt->get_result();
    $out = [];
    while ($row = $res->fetch_assoc()) {
        $out[] = [
            'ItemID' => $row['ItemID'],
            'ItemName' => $row['ItemName'],
            'Stock' => $row['Stock'],
            'Measurement' => $row['Measurement'],
            'Location' => $row['Location']
        ];
    }
    echo json_encode($out);
    $stmt->close();
} else {
    echo json_encode([]);
}
exit;
