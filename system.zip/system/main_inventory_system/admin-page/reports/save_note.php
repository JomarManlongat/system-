<?php
require_once __DIR__ . '/../../login/database-account.php';
header('Content-Type: application/json');

$note = trim($_POST['note'] ?? '');
if ($note === '') { echo json_encode(['ok'=>false,'error'=>'Note is empty']); exit; }

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) { echo json_encode(['ok'=>false,'error'=>'DB error']); exit; }

$conn->query("CREATE TABLE IF NOT EXISTS report_notes (
    NoteID INT AUTO_INCREMENT PRIMARY KEY,
    Note TEXT,
    CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

$stmt = $conn->prepare("INSERT INTO report_notes (Note) VALUES (?)");
$stmt->bind_param('s', $note);
$ok = $stmt->execute();

echo json_encode(['ok' => (bool)$ok]);
$stmt->close();
$conn->close();
