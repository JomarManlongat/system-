<?php
require_once __DIR__ . '/../../login/database-account.php';
header('Content-Type: application/json');

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) { echo json_encode([]); exit; }

$locations = [];
$colRes = $conn->query("SHOW COLUMNS FROM items LIKE 'Location'");
if ($colRes && $colRes->num_rows > 0) {
    $q = $conn->query("SELECT DISTINCT Location FROM items WHERE Location IS NOT NULL AND Location <> '' ORDER BY Location ASC");
    if ($q) {
        while ($row = $q->fetch_assoc()) { $locations[] = $row['Location']; }
    }
}

echo json_encode($locations);
$conn->close();
