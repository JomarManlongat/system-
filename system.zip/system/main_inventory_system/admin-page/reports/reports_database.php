<?php
session_name('INVENTORY_SESSION');
session_start();
require_once __DIR__ . '/../../login/database-account.php';

function esc($s){return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8');}

$search = $_GET['search'] ?? '';
$date_from = $_GET['from'] ?? '';
$date_to = $_GET['to'] ?? '';
$location = $_GET['location'] ?? 'all';
$top = (int)($_GET['top'] ?? 0);
$transType = $_GET['type'] ?? 'all'; // Stock Added | Usage Recorded

// Location filtering removed; all users see all locations
$user_location = null;
$userRole = $_SESSION['Role'] ?? $_SESSION['roles'] ?? '';

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) { die('DB connection failed'); }

// Check if items has Location column (to avoid SQL errors on some schemas)
$hasLocation = false;
$colRes = $conn->query("SHOW COLUMNS FROM items LIKE 'Location'");
if ($colRes && $colRes->num_rows > 0) { $hasLocation = true; }

$sql = "SELECT t.TransactionID, t.ItemID, i.ItemName, i.Location AS ItemLocation, t.Type, t.Quantity, t.UserID, u.NAME AS UserName, t.DateTime, "
     . "s.SupplierName"
     . " FROM transactions t"
     . " LEFT JOIN items i ON t.ItemID = i.ItemID"
     . " LEFT JOIN users u ON t.UserID = u.UserID"
     . " LEFT JOIN supplieritems si ON i.SupplierItemID = si.SupplierItemID"
     . " LEFT JOIN suppliers s ON si.SupplierID = s.SupplierID"
     . " WHERE 1=1";$params = [];

// Staff users see all locations

if ($search !== '') {
    $safe = '%' . $conn->real_escape_string($search) . '%';
    $sql .= " AND (t.TransactionID LIKE '$safe' OR i.ItemName LIKE '$safe' OR u.NAME LIKE '$safe')";
}
if ($date_from !== '') {
    $safe = $conn->real_escape_string($date_from);
    $sql .= " AND DATE(t.DateTime) >= '$safe'";
}
if ($date_to !== '') {
    $safe = $conn->real_escape_string($date_to);
    $sql .= " AND DATE(t.DateTime) <= '$safe'";
}
if ($transType !== 'all') {
    // Normalize known values: transactions.Type may be like 'Added Stock' or 'Usage Stock'
    if ($transType === 'Stock Added') {
        $sql .= " AND (t.Type LIKE '%Add%' OR t.Type='Added Stock')";
    } else if ($transType === 'Usage Recorded') {
        $sql .= " AND (t.Type LIKE '%Usage%' OR t.Type='Usage Stock')";
    }
}
// Ignore location filter parameter entirely (column removed)

$sql .= " ORDER BY t.DateTime DESC";
if ($top > 0) { $sql .= " LIMIT " . intval($top); }

$res = $conn->query($sql);

// Build HTML rows
$out = '';
if ($res && $res->num_rows) {
    while ($r = $res->fetch_assoc()) {
        $badge = 'badge-usage';
        $label = 'Usage Recorded';
        $t = strtolower($r['Type'] ?? '');
        if (strpos($t, 'add') !== false) { $badge = 'badge-added'; $label = 'Stock Added'; }
        
        $transId = esc($r['TransactionID']);
        $itemName = esc($r['ItemName']);
        $qty = esc($r['Quantity']);
        $userName = esc($r['UserName']);
        $supplier = esc($r['SupplierName'] ?? 'N/A');
        $dateTime = esc($r['DateTime']);
        
        $out .= '<tr>'
             . '<td>' . $transId . '</td>'
             . '<td>' . $itemName . '</td>'
             . '<td>' . $qty . '</td>'
             . '<td><span class="badge ' . $badge . '">' . $label . '</span></td>'
             . '<td>' . $userName . '</td>'
             . '<td>' . $supplier . '</td>'
             . '<td>' . $dateTime . '</td>'
             . '</tr>';
    }
}

echo $out;
$conn->close();
