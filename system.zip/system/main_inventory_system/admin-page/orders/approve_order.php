<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
session_name('INVENTORY_SESSION');
session_start();
require __DIR__ . '/../../login/database-account.php';
header('Content-Type: application/json; charset=utf-8');

if (!$conn) { echo json_encode(['success'=>false,'error'=>'DB']); exit; }

$orderId = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;

if ($orderId <= 0) {
  echo json_encode(['success'=>false,'error'=>'Invalid order ID']);
  exit;
}

try {
  // Update order status to "To Be Recorded"
  $newStatus = 'To Be Recorded';
  $stmt = $conn->prepare("UPDATE orders SET Status = ? WHERE OrderID = ?");
  $stmt->bind_param('si', $newStatus, $orderId);
  if (!$stmt->execute()) throw new Exception('Update failed');
  $stmt->close();

  // Also update all orderdetails for this order
  $detailStmt = $conn->prepare("UPDATE orderdetails SET Status = ? WHERE OrderID = ?");
  $detailStmt->bind_param('si', $newStatus, $orderId);
  $detailStmt->execute();
  $detailStmt->close();

  $conn->close();
  echo json_encode(['success'=>true,'message'=>'Order approved successfully']);
} catch (Exception $e) {
  $conn->close();
  echo json_encode(['success'=>false,'error'=>$e->getMessage()]);
}
?>
