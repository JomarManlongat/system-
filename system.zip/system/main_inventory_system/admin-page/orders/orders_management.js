// Orders Management System
console.log('[ORDERS_MGMT] Script file loaded!');

// Define approveOrder at GLOBAL scope FIRST
window.approveOrder = function(orderId) {
  console.log('[APPROVE] Function called with orderId:', orderId);
  if (confirm('Are you sure you want to approve this order?')) {
    console.log('[APPROVE] User confirmed, sending request...');
    const numericId = String(orderId || '').replace(/\D/g, '');
    if (!numericId) {
      alert('Invalid order ID');
      console.error('[APPROVE] Invalid ID parsed from', orderId);
      return;
    }

    console.log('[APPROVE] Parsed numericId:', numericId);

    const formData = new FormData();
    formData.append('order_id', numericId);
    const path = window.location.pathname.includes('/orders/') ? '' : 'orders/';
    
    fetch(path + 'approve_order.php', { method: 'POST', body: formData })
      .then(r => {
        console.log('[APPROVE] Response status:', r.status);
        return r.json();
      })
      .then(data => {
        console.log('[APPROVE] Response data:', data);
        if (data.success) {
          alert('Order approved successfully!');
          if (typeof window.reloadOrders === 'function') window.reloadOrders();
          else location.reload();
        } else {
          alert('Error: ' + (data.error || 'Failed to approve order'));
        }
      })
      .catch(err => {
        console.error('[APPROVE] Error:', err);
        alert('Failed to approve order: ' + err.message);
      });
  }
};
console.log('[ORDERS_MGMT] approveOrder defined:', typeof window.approveOrder);

(function(){
  console.log('[ORDERS_MGMT] Initializing Orders Management System');
  const ORDERS_PATH = window.location.pathname.includes('/orders/') ? '' : 'orders/';
  console.log('[ORDERS_MGMT] ORDERS_PATH set to:', ORDERS_PATH);
  
  function notify(msg, type = 'success') {
    if (typeof window.showNotification === 'function') {
      window.showNotification(msg, type);
      return;
    }
    alert(msg);
  }

  function notifyCentered(msg, type = 'success') {
    const el = document.createElement('div');
    el.textContent = msg;
    el.style.cssText = `
      position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);
      background: ${type === 'success' ? '#28a745' : '#dc3545'};
      color: #fff; padding: 20px 30px; border-radius: 8px;
      box-shadow: 0 10px 40px rgba(0,0,0,0.3); z-index: 10000; opacity: 0;
      transition: all .3s ease; font-size: 16px; font-weight: 500;
    `;
    document.body.appendChild(el);
    requestAnimationFrame(() => { el.style.opacity = '1'; });
    setTimeout(() => { el.style.opacity = '0'; setTimeout(() => el.remove(), 300); }, 2500);
  }

  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  // Load Orders Table
  function loadOrders() {
    const tbody = document.getElementById('orders_table_body');
    if (!tbody) return;
    fetch(ORDERS_PATH + 'orders_database.php', { method: 'POST' })
      .then(r => r.text())
      .then(html => { tbody.innerHTML = html; })
      .catch(() => { tbody.innerHTML = '<tr><td colspan="8">Failed to load orders.</td></tr>'; });
  }

  window.reloadOrders = loadOrders;

  // Create New Order
  window.openCreateOrderModal = function(preselectedSupplierId = null, preselectedSupplierName = null) {
    const modal = document.getElementById('createOrderModal');
    if (!modal) return;
    const container = document.getElementById('order_items_container');
    if (container) container.innerHTML = '';
    
    const select = document.getElementById('order_supplier_select');
    
    // Always enable and load suppliers
    if (select) {
      select.disabled = false;
      select.value = '';
    }
    
    loadSuppliersForOrder();
    
    modal.style.display = 'flex';
  };

  window.closeCreateOrderModal = function() {
    const modal = document.getElementById('createOrderModal');
    if (modal) {
      modal.style.display = 'none';
      
      // Re-enable the supplier select for next time
      const select = document.getElementById('order_supplier_select');
      if (select) {
        select.disabled = false;
        select.value = '';
      }
      
      // Clear items
      const container = document.getElementById('order_items_container');
      if (container) container.innerHTML = '';
      
      selectedSupplierID = null;
    }
  };

  function loadSuppliersForOrder() {
    fetch(ORDERS_PATH + 'get_suppliers.php')
      .then(r => r.json())
      .then(data => {
        const select = document.getElementById('order_supplier_select');
        if (!select) return;
        select.innerHTML = '<option value="">Select a supplier</option>';
        if (data.success && Array.isArray(data.suppliers)) {
          data.suppliers.forEach(s => {
            const option = document.createElement('option');
            option.value = s.SupplierID;
            option.textContent = s.SupplierName;
            select.appendChild(option);
          });
        }
      })
      .catch(err => console.error('Error loading suppliers:', err));
  }

  let supplierItems = [];
  let selectedSupplierID = null;

  window.onSupplierChanged = function() {
    const select = document.getElementById('order_supplier_select');
    selectedSupplierID = select ? select.value : null;
    const container = document.getElementById('order_items_container');
    const createBtn = document.getElementById('create_order_btn');
    
    // Always clear existing rows when supplier changes
    if (container) container.innerHTML = '';
    
    if (selectedSupplierID) {
      loadSupplierItems(selectedSupplierID);
      if (createBtn) createBtn.disabled = false;
    } else {
      if (createBtn) createBtn.disabled = true;
      supplierItems = [];
    }
  };

  function loadSupplierItems(supplierId) {
    fetch(ORDERS_PATH + 'get_items_by_supplier.php?supplier_id=' + supplierId)
      .then(r => r.json())
      .then(data => {
        if (data.success && Array.isArray(data.items)) {
          supplierItems = data.items;
          // Automatically add first row after items load
          if (supplierItems.length > 0) {
            addOrderItemRow();
          }
        } else {
          supplierItems = [];
          notify('No items found for this supplier', 'info');
        }
      })
      .catch(err => {
        console.error('Error loading items:', err);
        supplierItems = [];
      });
  }

  window.addOrderItemRow = function() {
    if (!selectedSupplierID) {
      notify('Please select a supplier first', 'error');
      return;
    }
    if (supplierItems.length === 0) {
      notify('No items available for this supplier', 'error');
      return;
    }
    const container = document.getElementById('order_items_container');
    if (!container) return;
    const rowId = 'order_item_row_' + Date.now();
    const div = document.createElement('div');
    div.id = rowId;
    div.style.cssText = 'display:flex; gap:10px; margin-bottom:10px; align-items:center;';
    let html = '<select class="input-select" style="flex:1;" data-row="' + rowId + '">';
    html += '<option value="">Select item</option>';
    supplierItems.forEach(item => {
      html += '<option value="' + item.SupplierItemID + '">' + escapeHtml(item.ItemName) + ' (' + escapeHtml(item.Measurement) + ')</option>';
    });
    html += '</select>';
    html += '<input type="number" class="input-number" placeholder="Qty" min="1" value="1" style="width:80px;" data-row="' + rowId + '">';
    html += '<button type="button" class="white-btn" onclick="removeOrderItemRow(\'' + rowId + '\')" style="padding:8px 12px;">Remove</button>';
    div.innerHTML = html;
    container.appendChild(div);
  };

  window.removeOrderItemRow = function(rowId) {
    const row = document.getElementById(rowId);
    if (row) row.remove();
  };

  window.submitNewOrder = function() {
    if (!selectedSupplierID) {
      notify('Please select a supplier', 'error');
      return;
    }
    const container = document.getElementById('order_items_container');
    if (!container) return;
    const rows = container.querySelectorAll('[id^="order_item_row_"]');
    if (rows.length === 0) {
      notify('Please add at least one item', 'error');
      return;
    }
    const items = [];
    let hasError = false;
    rows.forEach(row => {
      const select = row.querySelector('select');
      const input = row.querySelector('input[type="number"]');
      const itemId = select ? select.value : '';
      const qty = input ? parseInt(input.value) : 0;
      if (!itemId || qty <= 0) {
        hasError = true;
        return;
      }
      items.push({ supplier_item_id: itemId, quantity: qty });
    });
    if (hasError) {
      notify('Please fill in all items with valid quantities', 'error');
      return;
    }
    if (items.length === 0) {
      notify('No valid items to order', 'error');
      return;
    }
    const formData = new FormData();
    formData.append('supplier_id', selectedSupplierID);
    formData.append('items', JSON.stringify(items));
    fetch(ORDERS_PATH + 'submit_order.php', {
      method: 'POST',
      body: formData
    })
    .then(r => r.json())
    .then(data => {
      if (data.success) {
        notify('Order created successfully!', 'success');
        closeCreateOrderModal();
        loadOrders();
      } else {
        notify(data.error || 'Failed to create order', 'error');
      }
    })
    .catch(err => {
      console.error(err);
      notify('Failed to create order. Please try again.', 'error');
    });
  }

  // View Order Details
  window.viewOrder = function(orderId) {
    const modal = document.getElementById('viewOrderModal');
    if (!modal) return;
    const formData = new FormData();
    formData.append('order_id', orderId);
    formData.append('view_mode', 'view');
    fetch(ORDERS_PATH + 'get_order_details.php', { method: 'POST', body: formData })
      .then(r => r.json())
      .then(data => {
        console.log('Order details loaded:', data);
        if (data.success) {
          const titleEl = document.getElementById('view_order_title');
          const infoEl = document.getElementById('view_order_info');
          const tbody = document.getElementById('view_order_items_body');
          
          const orderStatus = data.order && data.order.status ? data.order.status.toLowerCase() : '';
          console.log('Order status:', orderStatus);
          
          if (titleEl) titleEl.textContent = 'Order Details: ' + (data.order && data.order.id ? data.order.id : 'ORD' + orderId);
          if (infoEl) {
            const supplierName = (data.order && data.order.supplier) ? data.order.supplier : '';
            const date = (data.order && data.order.date) ? data.order.date : '';
            infoEl.textContent = 'From ' + supplierName + ' on ' + date;
          }
          if (tbody && Array.isArray(data.items)) {
            tbody.innerHTML = '';
            data.items.forEach(item => {
              const tr = document.createElement('tr');
              // Determine status display
              let statusDisplay = 'Not Received';
              if (orderStatus === 'cancelled') {
                statusDisplay = 'Cancelled';
              } else if (item.received && parseInt(item.received) > 0) {
                statusDisplay = 'Received';
              }
              console.log('Item:', item.item_name, 'Status:', statusDisplay, 'Received:', item.received);
              tr.innerHTML = '<td>' + escapeHtml(item.item_name || '') + '</td><td>' + escapeHtml(item.unit || item.measurement || '') + '</td><td>' + (item.total_ordered || item.ordered || 0) + '</td><td>' + statusDisplay + '</td>';
              tbody.appendChild(tr);
            });
          }
        }
      })
      .catch(err => {
        console.error('Error loading order:', err);
        notify('Failed to load order details', 'error');
      });
    modal.style.display = 'flex';
  };

  window.closeViewOrderModal = function() {
    const modal = document.getElementById('viewOrderModal');
    if (modal) modal.style.display = 'none';
  };

  // Approve Order
  console.log('[ORDERS_MGMT] Defining window.approveOrder');
  window.approveOrder = function(orderId) {
    console.log('[APPROVE] Function called with orderId:', orderId);
    console.log('[APPROVE] orderId type:', typeof orderId);
    
    // Fallback to browser confirm - always use this to ensure it works
    if (confirm('Are you sure you want to approve this order?')) {
      console.log('[APPROVE] User confirmed, sending request...');
      const formData = new FormData();
      formData.append('order_id', orderId);

      fetch(ORDERS_PATH + 'approve_order.php', { method: 'POST', body: formData })
        .then(r => {
          console.log('[APPROVE] Response status:', r.status);
          return r.json();
        })
        .then(data => {
          console.log('[APPROVE] Response data:', data);
          if (data.success) {
            alert('Order approved successfully! Status changed to "To Be Recorded".');
            loadOrders();
          } else {
            alert('Error: ' + (data.error || 'Failed to approve order'));
          }
        })
        .catch(err => {
          console.error('[APPROVE] Error:', err);
          alert('Failed to approve order: ' + err.message);
        });
    } else {
      console.log('[APPROVE] User cancelled');
    }
    
    // OLD CODE with modal - keeping as fallback
    if (false && typeof window.showConfirmationModal === 'function') {
      window.showConfirmationModal(
        'Are you sure you want to approve this order?\n\nThe order status will change to "To Be Recorded" and items will be ready for delivery recording.',
        'Confirm Approval'
      ).then(confirmed => {
        if (confirmed) {
          const formData = new FormData();
          formData.append('order_id', orderId);

          fetch(ORDERS_PATH + 'approve_order.php', { method: 'POST', body: formData })
            .then(r => r.json())
            .then(data => {
              if (data.success) {
                notify('Order approved successfully! Status changed to "To Be Recorded".', 'success');
                loadOrders();
              } else {
                notify(data.error || 'Failed to approve order', 'error');
              }
            })
            .catch(err => {
              console.error('Error approving order:', err);
              notify('Failed to approve order', 'error');
            });
        }
      });
    }
          })
          .catch(err => {
            console.error('Error approving order:', err);
            notify('Failed to approve order', 'error');
          });
      }
    }
  };

  // Receive Order
  let currentReceiveOrderId = null;
  let receiveItemsData = [];
  let reportedIssues = [];

  window.receiveOrder = function(orderId) {
    console.log('[RECEIVE] Button clicked for order:', orderId);
    currentReceiveOrderId = orderId;
    const modal = document.getElementById('receiveOrderModal');
    const title = document.getElementById('receive_order_title');
    if (title) title.textContent = 'Record Delivery: ' + orderId;
    reportedIssues = []; // Reset issues for new order
    const formData = new FormData();
    formData.append('order_id', orderId);
    formData.append('view_mode', 'receive');
    fetch(ORDERS_PATH + 'get_order_details.php', { method: 'POST', body: formData })
      .then(r => r.json())
      .then(data => {
        if (data.success && Array.isArray(data.items)) {
          if (data.items.length === 0) {
            notify('This order has been fully received. No remaining items.', 'info');
            return;
          }
          receiveItemsData = data.items.map((item, idx) => ({
            rowId: 'row_' + orderId + '_' + idx + '_' + Date.now(), // Unique row ID
            orderDetailId: item.order_detail_id, // Track orderdetails row
            supplierItemId: item.supplier_item_id,
            itemName: item.item_name,
            measurement: item.unit || 'Pcs', // Get measurement from item
            ordered: item.quantity,
            accept: item.quantity,
            expiryDate: ''
          }));
          renderReceiveItems();
          if (modal) modal.style.display = 'flex';
        } else {
          notify(data.error || 'Failed to load order details', 'error');
        }
      })
      .catch(err => {
        console.error(err);
        notify('Failed to load order details', 'error');
      });
  };

  window.closeReceiveOrderModal = function() {
    const modal = document.getElementById('receiveOrderModal');
    if (modal) modal.style.display = 'none';
    currentReceiveOrderId = null;
    receiveItemsData = [];
    reportedIssues = []; // Reset issues when closing
  };

  function renderReceiveItems() {
    const tbody = document.getElementById('receive_order_items_body');
    if (!tbody) return;
    tbody.innerHTML = '';
    receiveItemsData.forEach((item, index) => {
      // Calculate issue quantity for THIS SPECIFIC ROW (not all items with same supplierItemId)
      const issueQty = reportedIssues
        .filter(issue => issue.row_id === item.rowId)
        .reduce((sum, issue) => sum + issue.quantity, 0);
      
      const itemNameDisplay = issueQty > 0 
        ? escapeHtml(item.itemName) + ' <span style="color: #ef4444; font-size: 12px; font-weight: 600;">(Issue: ' + issueQty + ')</span>'
        : escapeHtml(item.itemName);
      
      const maxAccept = item.ordered;
      const currentAccept = item.accept;
      
      const tr = document.createElement('tr');
      tr.innerHTML = '<td>' + itemNameDisplay + '</td>' +
        '<td style="text-align: center;">' + item.ordered + '</td>' +
        '<td style="text-align: center;"><input type="date" class="input-text" value="' + item.expiryDate + '" onchange="updateExpiryDate(' + index + ', this.value)" required style="width: 150px;"></td>' +
        '<td style="text-align: center;"><button type="button" class="report-issue-btn" onclick="openReportIssueModal(' + index + ', \'' + escapeHtml(item.itemName).replace(/'/g, "\\'") + '\')" ' + (currentAccept <= 0 ? 'disabled' : '') + '>Report Issue</button></td>';
      tbody.appendChild(tr);
    });
  }

  window.updateAcceptQuantity = function(index, value) {
    const qty = parseInt(value) || 0;
    const item = receiveItemsData[index];
    // Calculate max accept based on ordered minus reported issues
    const issueQty = reportedIssues
      .filter(issue => issue.row_id === item.rowId)
      .reduce((sum, issue) => sum + issue.quantity, 0);
    const maxAccept = item.ordered - issueQty;
    item.accept = Math.min(Math.max(0, qty), maxAccept);
    // Re-render to update the UI with corrected value
    renderReceiveItems();
  };

  window.updateExpiryDate = function(index, value) {
    receiveItemsData[index].expiryDate = value;
  };

  window.confirmDelivery = function() {
    const receivedBy = document.getElementById('received_by_input').value.trim();
    const receivedDate = document.getElementById('received_date_input').value.trim();
    const receivedTime = document.getElementById('received_time_input').value.trim();
    const description = document.getElementById('receive_description').value.trim();
    const recordedBy = document.getElementById('recorded_by_input').value.trim();
    
    console.log('Confirm Delivery - Received By:', receivedBy, 'Date:', receivedDate, 'Time:', receivedTime, 'Items:', receiveItemsData.length);
    
    if (!receivedBy) {
      notify('Please enter who received the order', 'error');
      return;
    }
    if (!receivedDate) {
      notify('Please enter the date received', 'error');
      return;
    }
    
    // Validate date format and value
    const dateObj = new Date(receivedDate);
    if (isNaN(dateObj.getTime())) {
      notify('Please enter a valid date (YYYY-MM-DD)', 'error');
      return;
    }
    
    // Check if date is not in the future
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    dateObj.setHours(0, 0, 0, 0);
    if (dateObj > today) {
      notify('Date cannot be in the future', 'error');
      return;
    }
    
    if (!receivedTime) {
      notify('Please enter the time received', 'error');
      return;
    }
    if (!currentReceiveOrderId) {
      notify('No order selected', 'error');
      return;
    }
    
    const formData = new FormData();
    formData.append('order_id', currentReceiveOrderId);
    formData.append('received_by', receivedBy);
    formData.append('received_date', receivedDate);
    formData.append('received_time', receivedTime);
    formData.append('recorded_by', recordedBy);
    formData.append('description', description);
    formData.append('items', JSON.stringify(receiveItemsData));
    formData.append('issues', JSON.stringify(reportedIssues));
    
    console.log('Sending to:', ORDERS_PATH + 'receive_order_new.php');
    console.log('Form data - order_id:', currentReceiveOrderId, 'received_by:', receivedBy, 'date:', receivedDate, 'time:', receivedTime);
    console.log('Items to receive:', JSON.stringify(receiveItemsData));
    console.log('Issues:', JSON.stringify(reportedIssues));
    
    fetch(ORDERS_PATH + 'receive_order_new.php', {
      method: 'POST',
      body: formData
    })
    .then(r => {
      console.log('Response status:', r.status);
      if (!r.ok) {
        throw new Error('Server returned ' + r.status);
      }
      return r.text();
    })
    .then(text => {
      console.log('Response text:', text);
      try {
        const data = JSON.parse(text);
        if (data.success) {
          notifyCentered(data.message || 'Order received successfully!', 'success');
          closeReceiveOrderModal();
          loadOrders();
          reportedIssues = [];
        } else {
          notify(data.error || 'Failed to receive order', 'error');
        }
      } catch(e) {
        console.error('JSON parse error:', e);
        console.error('Response text:', text);
        notify('Server error: Invalid response format', 'error');
      }
    })
    .catch(err => {
      console.error('Fetch error:', err);
      notify('Network error: ' + err.message, 'error');
    });
  };

  // Cancel Order
  window.cancelOrder = function(orderId) {
    if (typeof window.showConfirmationModal === 'function') {
      window.showConfirmationModal('Are you sure you want to cancel order #' + orderId + '?', 'Confirm Cancellation').then(confirmed => {
        if (confirmed) {
          const formData = new FormData();
          formData.append('order_id', orderId);
          
          fetch(ORDERS_PATH + 'cancel_order.php', {
            method: 'POST',
            body: formData
          })
          .then(r => r.json())
          .then(data => {
            if (data.success) {
              notify('Order cancelled successfully', 'success');
              loadOrders();
            } else {
              notify(data.error || 'Failed to cancel order', 'error');
            }
          })
          .catch(err => {
            console.error('Error:', err);
            notify('Network error: ' + err.message, 'error');
          });
        }
      });
    } else {
      if (confirm('Are you sure you want to cancel order #' + orderId + '?')) {
        const formData = new FormData();
        formData.append('order_id', orderId);
        
        fetch(ORDERS_PATH + 'cancel_order.php', {
          method: 'POST',
          body: formData
        })
        .then(r => r.json())
        .then(data => {
          if (data.success) {
            notify('Order cancelled successfully', 'success');
            loadOrders();
          } else {
            notify(data.error || 'Failed to cancel order', 'error');
          }
        })
        .catch(err => {
          console.error('Error:', err);
          notify('Network error: ' + err.message, 'error');
        });
      }
    }
  };

  // Report Issue Modal
  let currentReportItemIndex = null;
  let currentReportItemName = '';

  window.openReportIssueModal = function(itemIndex, itemName) {
    currentReportItemIndex = itemIndex;
    currentReportItemName = itemName;
    const modal = document.getElementById('reportIssueModal');
    const title = document.getElementById('report_issue_title');
    if (title) title.textContent = 'Report Issue for ' + itemName;
    
    // Reset form and set max to remaining unprocessed quantity
    const qtyInput = document.getElementById('return_quantity');
    const reasonInput = document.getElementById('return_reason');
    const conditionSelect = document.getElementById('return_condition');
    const item = receiveItemsData[itemIndex];
    if (qtyInput && item) {
      // Calculate how much has already been reported as issues
      const issueQty = reportedIssues
        .filter(issue => issue.row_id === item.rowId)
        .reduce((sum, issue) => sum + issue.quantity, 0);
      const remaining = item.ordered - issueQty;
      
      qtyInput.value = Math.min(1, remaining);
      qtyInput.max = remaining;
      qtyInput.min = remaining > 0 ? 1 : 0;
    }
    if (reasonInput) reasonInput.value = '';
    if (conditionSelect) conditionSelect.value = 'Damaged';
    
    if (modal) modal.style.display = 'flex';
  };

  window.closeReportIssueModal = function() {
    const modal = document.getElementById('reportIssueModal');
    if (modal) modal.style.display = 'none';
    currentReportItemIndex = null;
    currentReportItemName = '';
  };

  window.submitIssueReport = function() {
    const qty = parseInt(document.getElementById('return_quantity').value) || 0;
    const condition = document.getElementById('return_condition').value;
    const reason = document.getElementById('return_reason').value.trim();
    if (qty <= 0) {
      notify('Please enter a valid quantity to report', 'error');
      return;
    }
    if (!condition) {
      notify('Please select a condition for the issue', 'error');
      return;
    }
    if (!reason) {
      notify('Please provide a description for the issue', 'error');
      return;
    }
    if (currentReportItemIndex === null) {
      notify('No item selected', 'error');
      return;
    }
    const item = receiveItemsData[currentReportItemIndex];
    if (!item) {
      notify('Item not found', 'error');
      return;
    }
    // Calculate how much has already been reported as issues
    const issueQty = reportedIssues
      .filter(issue => issue.row_id === item.rowId)
      .reduce((sum, issue) => sum + issue.quantity, 0);
    
    // Remaining is: ordered - (what's been manually reduced from accept) - (what's been reported as issues)
    // Since accept starts at ordered, we need: ordered - issueQty
    const remainingToProcess = item.ordered - issueQty;
    
    if (qty > remainingToProcess) {
      notify('Cannot report ' + qty + '. Only ' + remainingToProcess + ' remaining to process', 'error');
      return;
    }
    // Store the issue in the array
    reportedIssues.push({
      order_id: currentReceiveOrderId,
      row_id: item.rowId, // Use unique row ID
      order_detail_id: item.orderDetailId, // Track orderdetails row for backend
      supplier_item_id: item.supplierItemId,
      item_name: item.itemName,
      quantity: qty,
      condition: condition,
      reason: reason,
      expiry_date: item.expiryDate || null // Include the expiry date
    });
    // Reduce accept quantity to account for reported issues
    item.accept = Math.max(0, item.accept - qty);
    renderReceiveItems();
    notify('Issue recorded: ' + qty + ' unit(s) of ' + currentReportItemName + ' will be accepted and reported', 'success');
    closeReportIssueModal();
  };

  // Toggle action menu dropdown
  window.toggleActionMenu = function(event, button) {
    event.preventDefault();
    event.stopPropagation();
    console.log('[ORDERS_MGMT] toggleActionMenu for order row');
    
    // Close all other dropdowns first
    document.querySelectorAll('.action-dropdown').forEach(d => {
      if (d !== button.nextElementSibling) {
        d.style.display = 'none';
      }
    });
    
    // Toggle the clicked button's dropdown
    const dropdown = button.nextElementSibling;
    if (dropdown && dropdown.classList.contains('action-dropdown')) {
      const currentDisplay = window.getComputedStyle(dropdown).display;
      console.log('[TOGGLE] Current display:', currentDisplay, 'Setting to:', currentDisplay === 'none' ? 'flex' : 'none');
      dropdown.style.display = currentDisplay === 'none' ? 'flex' : 'none';
    }
  };

  // Handle clicks on dropdown links - simplified
  document.addEventListener('click', function(event) {
    // If clicking inside action dropdown, don't close it
    const clickedLink = event.target.closest('.action-dropdown a');
    if (clickedLink) {
      console.log('[DROPDOWN] Link clicked:', clickedLink.textContent);
      // Let the onclick handler execute, then close dropdown
      setTimeout(() => {
        document.querySelectorAll('.action-dropdown').forEach(d => d.style.display = 'none');
      }, 100);
      return;
    }
    
    // Close all dropdowns when clicking elsewhere
    if (!event.target.closest('.action-menu')) {
      document.querySelectorAll('.action-dropdown').forEach(d => d.style.display = 'none');
    }
  });

  // Initialize
  console.log('[ORDERS_MGMT] Setting up DOMContentLoaded listener');
  document.addEventListener('DOMContentLoaded', () => {
    console.log('[ORDERS_MGMT] DOMContentLoaded fired, loading orders');
    loadOrders();
    const newBtn = document.getElementById('orderss');
    if (newBtn) newBtn.addEventListener('click', openCreateOrderModal);
    window.addEventListener('click', (e) => {
      const viewModal = document.getElementById('viewOrderModal');
      const receiveModal = document.getElementById('receiveOrderModal');
      const createModal = document.getElementById('createOrderModal');
      const reportModal = document.getElementById('reportIssueModal');
      if (e.target === viewModal) closeViewOrderModal();
      if (e.target === receiveModal) closeReceiveOrderModal();
      if (e.target === createModal) closeCreateOrderModal();
      if (e.target === reportModal) closeReportIssueModal();
    });
  });

  console.log('[ORDERS_MGMT] Orders Management System initialized. Available functions:');
  console.log('  - window.approveOrder:', typeof window.approveOrder);
  console.log('  - window.receiveOrder:', typeof window.receiveOrder);
  console.log('  - window.toggleActionMenu:', typeof window.toggleActionMenu);

})();