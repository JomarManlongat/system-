<?php
// Test what orders_database.php actually outputs
header('Content-Type: text/html');

// Include the connection
require_once __DIR__ . '/../../../database/connection.php';

// Include the orders_database.php file to see its output
ob_start();
include 'orders_database.php';
$output = ob_get_clean();

// Show both raw HTML and rendered
?>
<!DOCTYPE html>
<html>
<head>
    <title>Debug Orders HTML Output</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; }
        .container { max-width: 1200px; margin: 0 auto; }
        h1 { color: #333; }
        .section { background: white; padding: 20px; margin: 20px 0; border-radius: 5px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        pre { background: #f0f0f0; padding: 10px; border-radius: 3px; overflow-x: auto; }
        .rendered { background: #f5f5f5; padding: 10px; }
        code { font-family: monospace; }
        a { color: #007bff; text-decoration: none; }
        a:hover { text-decoration: underline; }
    </style>
</head>
<body>

<div class="container">
    <h1>Orders Database Output Debug</h1>
    
    <div class="section">
        <h2>Raw HTML (what orders_database.php outputs):</h2>
        <pre><?php echo htmlspecialchars($output, ENT_QUOTES); ?></pre>
    </div>
    
    <div class="section">
        <h2>Rendered Output (how it looks):</h2>
        <table border="1" cellpadding="10" style="width: 100%; border-collapse: collapse;">
            <thead style="background: #f8f9fa;">
                <tr>
                    <th>Order ID</th>
                    <th>Supplier</th>
                    <th>Items</th>
                    <th>Total</th>
                    <th>Status</th>
                    <th>Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php echo $output; ?>
            </tbody>
        </table>
    </div>
    
    <div class="section">
        <h2>Analysis:</h2>
        <ul>
            <li>✓ Orders are being retrieved from database</li>
            <li>✓ HTML is being generated</li>
            <li>? Buttons should have <code>href="javascript:approveOrder(...)"</code> format</li>
            <li>? Click on the menu button (⋮) to see if dropdown appears</li>
            <li>? Try clicking an Approve button to see if it works</li>
        </ul>
    </div>
</div>

</body>
</html>
