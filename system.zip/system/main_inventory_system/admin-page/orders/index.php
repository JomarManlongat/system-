<!-- Orders Page (index.php) -->
<?php
// Include database connection for modal user dropdown
require_once __DIR__ . '/../../login/database-account.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Orders</title>
  <link rel="stylesheet" href="../admin_inv_man.css">
  <style>
    /* Standalone Orders page overrides to avoid admin layout offsets */
    .standalone-orders .header-page-admin h2 {
      position: static !important;
      width: auto !important;
      margin: 16px 0 8px 0 !important;
      color: #0f172a !important;
      background: transparent !important;
      border: none !important;
      font-size: 20px !important;
      height: auto !important;
    }
    .standalone-orders .whole_box { margin: 0; }
    .standalone-orders .orders_design { justify-content: flex-end; margin: 8px 0 0 0; padding: 0 8px; }
    .standalone-orders .inventory_table { width: 100% !important; margin: 16px 0 0 0 !important; }
    .standalone-orders .inventory_table table { width: 100% !important; }
  </style>
</head>
<body class="standalone-orders" style="background:#f4fbff;">
  <div class="page active-page" style="padding:16px; max-width:1100px; margin:0 auto;">
    <div class="header-page-admin">
      <h2>Order</h2>
    </div>
    <div class="whole_box">
      <div class="orders_design">
        <!-- Search is optional; you can uncomment and style as needed -->
        <!-- <input type="search" id="search_bar_orders" class="search_bar" placeholder=" Search orders by ID, supplier or status ..."> -->
      </div>
      <div class="inventory_table">
        <table>
          <thead>
            <tr>
              <th>Order ID</th>
              <th>Supplier</th>
              <th>Items</th>
              <th>Total</th>
              <th>Status</th>
              <th>Date</th>
              <th style="text-align:right">Actions</th>
            </tr>
          </thead>
          <tbody id="orders_table_body"></tbody>
        </table>
      </div>
    </div>
  </div>

  <?php include 'order_modals.php'; ?>
  <script src="orders_management.js?v=<?php echo time(); ?>"></script>
</body>
</html>
