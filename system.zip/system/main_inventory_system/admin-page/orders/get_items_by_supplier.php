<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
session_name('INVENTORY_SESSION');
session_start();
require __DIR__ . '/../../login/database-account.php';
header('Content-Type: application/json; charset=utf-8');

if (!$conn) { echo json_encode(['success'=>false,'error'=>'DB']); exit; }
$supplierId = isset($_GET['supplier_id']) ? intval($_GET['supplier_id']) : (isset($_POST['supplier_id']) ? intval($_POST['supplier_id']) : 0);
if ($supplierId <= 0) { echo json_encode(['success'=>true,'items'=>[]]); exit; }

$sql = "SELECT SupplierItemID, ItemName, Measurement, Price FROM supplieritems WHERE SupplierID = ? ORDER BY ItemName";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $supplierId);
$stmt->execute();
$res = $stmt->get_result();
$items = [];
while ($row = $res->fetch_assoc()) { $items[] = $row; }
$stmt->close();
$conn->close();

echo json_encode(['success'=>true,'items'=>$items]);
