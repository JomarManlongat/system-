<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
session_name('INVENTORY_SESSION');
session_start();
require __DIR__ . '/../../login/database-account.php';
header('Content-Type: application/json; charset=utf-8');

if (!$conn) { echo json_encode(['success'=>false,'error'=>'DB']); exit; }

$supplierId = isset($_POST['supplier_id']) ? intval($_POST['supplier_id']) : 0;
$itemsJson  = $_POST['items'] ?? '[]';

// Get current user
$currentUserId = $_SESSION['UserID'] ?? $_SESSION['user_id'] ?? 0;
$currentUserName = $_SESSION['username'] ?? $_SESSION['user_name'] ?? 'Unknown';

$items = json_decode($itemsJson, true);
if (!is_array($items)) $items = [];

// Validate items first - make sure we have at least one valid item
$validItems = [];
foreach ($items as $it) {
  $sid = intval($it['supplier_item_id'] ?? 0);
  $qty = intval($it['quantity'] ?? 0);
  if ($sid > 0 && $qty > 0) {
    $validItems[] = ['supplier_item_id' => $sid, 'quantity' => $qty];
  }
}

if ($supplierId <= 0 || count($validItems) === 0) {
  echo json_encode(['success'=>false,'error'=>'No items were accepted.']);
  exit;
}

$conn->begin_transaction();
try {
  // Insert order header with Received status (immediate delivery)
  $status = 'Received';
  $today  = date('Y-m-d');
  $stmt = $conn->prepare("INSERT INTO orders (SupplierID, OrderDate, Status) VALUES (?, ?, ?)");
  $stmt->bind_param('iss', $supplierId, $today, $status);
  if (!$stmt->execute()) throw new Exception('Insert order failed');
  $orderId = $stmt->insert_id;
  $stmt->close();

  // Process each item - add to inventory and order details
  $stmtD = $conn->prepare("INSERT INTO orderdetails (OrderID, SupplierItemID, Quantity, Status, ReceivedQuantity) VALUES (?, ?, ?, ?, ?)");
  foreach ($validItems as $it) {
    $sid = $it['supplier_item_id'];
    $qty = $it['quantity'];
    $dStatus = 'Received';
    $receivedQty = $qty;
    
    $stmtD->bind_param('iiisi', $orderId, $sid, $qty, $dStatus, $receivedQty);
    if (!$stmtD->execute()) throw new Exception('Insert detail failed');
    
    // Get supplier item details
    $detailsStmt = $conn->prepare("SELECT ItemName, Measurement FROM supplieritems WHERE SupplierItemID = ?");
    $detailsStmt->bind_param('i', $sid);
    $detailsStmt->execute();
    $detailsResult = $detailsStmt->get_result();
    if ($detailsRow = $detailsResult->fetch_assoc()) {
      $itemName = $detailsRow['ItemName'];
      $measurement = $detailsRow['Measurement'];
      
      // Check if item exists in inventory
      $itemStmt = $conn->prepare("SELECT ItemID, Stock FROM items WHERE SupplierItemID = ? LIMIT 1");
      $itemStmt->bind_param('i', $sid);
      $itemStmt->execute();
      $itemResult = $itemStmt->get_result();
      
      if ($itemRow = $itemResult->fetch_assoc()) {
        // Item exists - add to stock
        $itemId = $itemRow['ItemID'];
        $newStock = $itemRow['Stock'] + $qty;
        $updateStmt = $conn->prepare("UPDATE items SET Stock = ? WHERE ItemID = ?");
        $updateStmt->bind_param('ii', $newStock, $itemId);
        $updateStmt->execute();
        $updateStmt->close();
      } else {
        // Create new item in inventory
        $insertItem = $conn->prepare("INSERT INTO items (SupplierItemID, ItemName, Location, Stock, Measurement, Conditions, MinimumStock) VALUES (?, ?, 'Restaurant', ?, ?, 'Good', 10)");
        $insertItem->bind_param('isss', $sid, $itemName, $qty, $measurement);
        $insertItem->execute();
        $itemId = $conn->insert_id;
        $insertItem->close();
      }
      
      $itemStmt->close();
    }
    $detailsStmt->close();
  }
  $stmtD->close();

  $conn->commit();
  echo json_encode(['success'=>true,'order_id'=>$orderId]);
} catch (Exception $e) {
  $conn->rollback();
  echo json_encode(['success'=>false,'error'=>$e->getMessage()]);
}

$conn->close();
?>
