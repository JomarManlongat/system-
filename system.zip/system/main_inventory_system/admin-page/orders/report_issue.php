<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../../login/database-account.php';

$orderId = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;
$supplierItemId = isset($_POST['supplier_item_id']) ? intval($_POST['supplier_item_id']) : 0;
$itemName = isset($_POST['item_name']) ? trim($_POST['item_name']) : '';
$quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 0;
$condition = isset($_POST['condition']) ? trim($_POST['condition']) : 'Damaged';
$reason = isset($_POST['reason']) ? trim($_POST['reason']) : '';

if ($orderId <= 0 || $supplierItemId <= 0 || $quantity <= 0 || !$reason || !$condition) {
    echo json_encode(['success' => false, 'error' => 'Invalid issue data.']);
    exit;
}

// Get ItemID, Location, Stock, and ExpiryDate from items table
$itemId = 0;
$location = 'Restaurant'; // Default
$stock = 0;
$expiryDate = null;

$stmt = $conn->prepare("SELECT ItemID, Location, Stock, ExpiryDate FROM items WHERE SupplierItemID = ? LIMIT 1");
$stmt->bind_param('i', $supplierItemId);
$stmt->execute();
$res = $stmt->get_result();
if ($row = $res->fetch_assoc()) {
    $itemId = $row['ItemID'];
    $location = $row['Location'];
    $stock = $row['Stock'];
    $expiryDate = $row['ExpiryDate'];
}
$stmt->close();

if ($itemId <= 0) {
    echo json_encode(['success' => false, 'error' => 'Item not found in inventory.']);
    exit;
}

// Insert into issues table with correct columns
$insert = $conn->prepare("INSERT INTO issues (ItemID, ItemName, Location, Stock, ExpiryDate, Conditions, Reason, QuantityAffected) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
$insert->bind_param('ississi', $itemId, $itemName, $location, $stock, $expiryDate, $condition, $reason, $quantity);
if ($insert->execute()) {
    echo json_encode(['success' => true, 'message' => 'Issue reported successfully']);
} else {
    echo json_encode(['success' => false, 'error' => 'Failed to save issue: ' . $conn->error]);
}
$insert->close();
?>
