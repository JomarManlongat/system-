<?php
// Orders table loader - NO GROUP_CONCAT, fetching items separately per order
// Outputs HTML <tr> rows matching the design in admin_inv_man.php

error_reporting(E_ALL);
ini_set('display_errors', 0);
session_name('INVENTORY_SESSION');
session_start();
require __DIR__ . '/../../login/database-account.php';

header('Content-Type: text/html; charset=utf-8');

if (!$conn) {
  http_response_code(500);
  echo '<tr><td colspan="8" style="color:#c00">Database connection error.</td></tr>';
  exit;
}

$search = isset($_POST['search']) ? trim($_POST['search']) : '';
$supplierFilter = isset($_POST['supplier_id']) ? (int)$_POST['supplier_id'] : 0;
$top = isset($_POST['top']) ? intval($_POST['top']) : 200;
if ($top <= 0) $top = 200;
$location = isset($_POST['location']) ? trim($_POST['location']) : 'All';
$dateFrom = isset($_POST['date_from']) ? trim($_POST['date_from']) : '';
$dateTo   = isset($_POST['date_to']) ? trim($_POST['date_to']) : '';

// No location restriction
$user_location = null;
$userRole = $_SESSION['Role'] ?? $_SESSION['roles'] ?? '';

// Get orders WITHOUT GROUP_CONCAT - we'll fetch items for each order separately
$sql = "
  SELECT DISTINCT
    o.OrderID AS id,
    o.SupplierID,
    s.SupplierName AS supplier,
    s.Location AS location,
    o.OrderDate AS order_date,
    o.Status AS status
  FROM orders o
  LEFT JOIN suppliers s ON s.SupplierID = o.SupplierID
";

// Add joins only if searching by item name
if ($search !== '') {
  $sql .= "
    LEFT JOIN orderdetails od ON od.OrderID = o.OrderID
    LEFT JOIN supplieritems si ON si.SupplierItemID = od.SupplierItemID
  ";
}

$types = '';
$params = [];
$needsWhere = false;
if ($search !== '' || $supplierFilter > 0 || $location !== 'All' || $dateFrom !== '' || $dateTo !== '') {
  $needsWhere = true;
}

if ($needsWhere) {
  $sql .= ' WHERE ';
  $clauses = [];

  // Staff see all locations
  
  if ($search !== '') {
    $clauses[] = '(o.OrderID LIKE ? OR s.SupplierName LIKE ? OR o.Status LIKE ? OR si.ItemName LIKE ?)';
    $like = "%$search%";
    $params = array_merge($params, [$like, $like, $like, $like]);
    $types .= 'ssss';
  }
  if ($supplierFilter > 0) {
    $clauses[] = 'o.SupplierID = ?';
    $params[] = $supplierFilter;
    $types .= 'i';
  }

  if ($dateFrom !== '') {
    $clauses[] = 'o.OrderDate >= ?';
    $params[] = $dateFrom . ' 00:00:00';
    $types .= 's';
  }
  if ($dateTo !== '') {
    $clauses[] = 'o.OrderDate <= ?';
    $params[] = $dateTo . ' 23:59:59';
    $types .= 's';
  }
  $sql .= implode(' AND ', $clauses);
}

$sql .= " ORDER BY o.OrderDate DESC, o.OrderID DESC LIMIT " . intval($top);

$stmt = $conn->prepare($sql);
if ($stmt === false) {
  echo '<tr><td colspan="8" style="color:#c00">Query error.</td></tr>';
  exit;
}
if ($params) { $stmt->bind_param($types, ...$params); }
$stmt->execute();
$result = $stmt->get_result();

if (!$result || $result->num_rows === 0) {
  echo '<tr><td colspan="8" style="text-align:center;color:#666;padding:16px">No orders found.</td></tr>';
  exit;
}

function esc($v) { return htmlspecialchars((string)$v ?? '', ENT_QUOTES, 'UTF-8'); }
function fmt_order_id($id) { return 'ORD' . str_pad((string)$id, 3, '0', STR_PAD_LEFT); }
function fmt_date($d) { $t = strtotime($d); return $t ? date('n/j/Y', $t) : esc($d); }
function fmt_money($n) { return number_format((float)$n, 2); }
function status_badge($status) {
  $s = trim((string)$status);
  $styles = [
    'Pending Approval' => 'background:#FFD54F;color:#111;',
    'To Be Recorded'   => 'background:#FF9800;color:#fff;',
    'Approved'         => 'background:#e2e3e5;color:#333;',
    'Shipped'          => 'background:#1E88E5;color:#fff;',
    'In Transit'       => 'background:#1976D2;color:#fff;',
    'Received'         => 'background:#28A745;color:#fff;',
    'Completed'        => 'background:#28A745;color:#fff;',
    'Cancelled'        => 'background:#6c757d;color:#fff;',
  ];
  $style = $styles[$s] ?? 'background:#e2e3e5;color:#333;';
  return '<span style="padding:6px 10px;border-radius:14px;font-weight:600;font-size:12px;'.$style.'">'.esc($s).'</span>';
}

while ($row = $result->fetch_assoc()) {
  $id = (int)$row['id'];
  $supplier = $row['supplier'] ?? '-';
  $status = $row['status'] ?? '-';
  $date = $row['order_date'] ?? '';
  $location = $row['location'] ?? 'N/A';

  // Fetch items ONLY for THIS specific order - no cross-contamination possible
  $itemsSql = "
    SELECT si.ItemName, od.Quantity, si.Measurement, si.Price
    FROM orderdetails od
    INNER JOIN supplieritems si ON si.SupplierItemID = od.SupplierItemID
    WHERE od.OrderID = ?
    ORDER BY od.OrderDetailID
  ";
  $itemsStmt = $conn->prepare($itemsSql);
  $itemsStmt->bind_param('i', $id);
  $itemsStmt->execute();
  $itemsResult = $itemsStmt->get_result();
  
  $itemsDisplay = [];
  $total = 0;
  while ($item = $itemsResult->fetch_assoc()) {
    $itemsDisplay[] = $item['ItemName'] . ' (' . $item['Quantity'] . ' ' . $item['Measurement'] . ')';
    $total += $item['Quantity'] * floatval($item['Price']);
  }
  $itemsStmt->close();

  $itemsHtml = '';
  if (!empty($itemsDisplay)) {
    $chunks = array_map(function($p){ return '<div class="order-item">'.esc($p).'</div>'; }, $itemsDisplay);
    $itemsHtml = implode('', $chunks);
  }

  // Enable/disable buttons based on status
  $canApprove = (strtolower($status) === 'pending approval');
  $approveClass = $canApprove ? '' : 'disabled';
  $approveOnclick = $canApprove ? 'onclick="approveOrder(\'' . esc($id) . '\')"' : 'onclick="return false;" tabindex="-1" style="pointer-events:none;opacity:0.5;"';
  
  $canRecord = (strtolower($status) === 'to be recorded');
  $recordClass = $canRecord ? '' : 'disabled';
  $recordOnclick = $canRecord ? 'onclick="receiveOrder(\'' . esc($id) . '\')"' : 'onclick="return false;" tabindex="-1" style="pointer-events:none;opacity:0.5;"';

  $canCancel = (strtolower($status) !== 'received' && strtolower($status) !== 'cancelled');
  $cancelClass = $canCancel ? '' : 'disabled';
  $cancelOnclick = $canCancel ? 'onclick="cancelOrder(\'' . esc($id) . '\')"' : 'onclick="return false;" tabindex="-1" style="pointer-events:none;opacity:0.5;"';

  echo '<tr class="order-row">';
  echo '<td class="p-4 align-middle font-medium">' . esc(fmt_order_id($id)) . '</td>';
  echo '<td class="p-4 align-middle">' . esc($supplier) . '</td>';
  echo '<td class="p-4 align-middle">' . esc($location) . '</td>';
  echo '<td class="p-4 align-middle"><div class="order-items-list">' . $itemsHtml . '</div></td>';
  echo '<td class="p-4 align-middle">' . esc(fmt_money($total)) . '</td>';
  echo '<td class="p-4 align-middle">' . status_badge($status) . '</td>';
  echo '<td class="p-4 align-middle">' . esc(fmt_date($date)) . '</td>';
  echo '<td class="p-4 align-middle" style="text-align:center;">';
  echo '  <div class="action-menu" style="display:inline-block;">';
  echo '    <button class="action-btn" onclick="toggleActionMenu(event, this)" title="Actions">⋮</button>';
  echo '    <div class="action-dropdown" style="display:none;">';
  echo '      <a href="javascript:viewOrder(\'' . esc($id) . '\')">View Details</a>';
  echo '      <a href="javascript:approveOrder(\'' . esc($id) . '\')' . (!$canApprove ? '" class="disabled"' : '"') . '>Approve</a>';
  echo '      <a href="javascript:receiveOrder(\'' . esc($id) . '\')' . (!$canRecord ? '" class="disabled"' : '"') . '>Record Delivery</a>';
  echo '      <a href="javascript:cancelOrder(\'' . esc($id) . '\')' . (!$canCancel ? '" class="disabled"' : '"') . '>Cancel Order</a>';
  echo '    </div>';
  echo '  </div>';
  echo '</td>';
  echo '</tr>';
}

$stmt->close();
$conn->close();
