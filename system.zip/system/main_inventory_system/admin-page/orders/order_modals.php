<!-- View Order Details Modal -->
<div id="viewOrderModal" class="modal">
  <div class="order-dialog">
    <div class="modal-header">
      <span class="close" onclick="closeViewOrderModal()">&times;</span>
    </div>
    
    <div class="title-group">
      <h2 id="view_order_title" class="dialog-title">Order Details</h2>
      <p id="view_order_info" class="dialog-desc">From Supplier on Date</p>
    </div>
    
    <div class="order-table-wrapper">
      <table class="order-table">
        <thead>
          <tr>
            <th>Item</th>
            <th>Unit</th>
            <th>Ordered</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody id="view_order_items_body">
          <!-- Items will be loaded here -->
        </tbody>
      </table>
    </div>
  </div>
</div>
<!-- Create New Order Modal -->
<div id="createOrderModal" class="modal">
  <div class="order-dialog">
    <div class="modal-header" style="justify-content: space-between; align-items:center;">
      <h2 class="dialog-title" style="margin:0;">Create New Order</h2>
      <span class="close" onclick="closeCreateOrderModal()">&times;</span>
    </div>

    <div class="title-group" style="margin-top:8px; margin-bottom:16px;">
      <p class="dialog-desc">Select a supplier and add items to order.</p>
    </div>

    <div class="form-group">
      <label for="order_supplier_select" class="dialog-desc" style="display:block; margin-bottom:6px; color:#374151;">Supplier</label>
      <select id="order_supplier_select" class="input-select" style="width:100%;" onchange="onSupplierChanged()">
        <option value="">Select a supplier</option>
      </select>
    </div>

    <div class="form-group" style="margin-top:16px;">
      <label class="dialog-desc" style="display:block; margin-bottom:6px; color:#374151;">Items</label>
      <div id="order_items_container"></div>
      <button class="white-btn" type="button" style="margin-top:10px;" onclick="addOrderItemRow()">Add Item</button>
    </div>

    <div class="actions-row">
      <button class="white-btn" type="button" onclick="closeCreateOrderModal()">Cancel</button>
      <button class="blue_design" id="create_order_btn" type="button" onclick="submitNewOrder()" disabled>Create Order</button>
    </div>
  </div>
</div>

<!-- Receive Order Modal -->
<div id="receiveOrderModal" class="modal" style="display:none;">
  <div class="order-dialog" style="max-width: 900px; width: 90%;">
    <div class="modal-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
      <h2 id="receive_order_title" class="dialog-title" style="margin: 0;">Record Delivery</h2>
      <span class="close" onclick="closeReceiveOrderModal()" style="cursor: pointer;">&times;</span>
    </div>

    <?php
      // Build connection if needed
      if (!isset($conn) || !$conn || $conn->connect_errno) {
        require_once __DIR__ . '/../../login/database-account.php';
      }
      $currentUserID = $_SESSION['UserID'] ?? '';
      $currentUserRole = strtolower($_SESSION['Role'] ?? $_SESSION['roles'] ?? '');
      $isStaff = ($currentUserRole === 'staff');
      $currentUserName = '';
      $currentUserRoleLabel = '';
      if ($currentUserID) {
        $me = $conn->query("SELECT Name, Role FROM users WHERE UserID = '" . $conn->real_escape_string($currentUserID) . "' LIMIT 1");
        if ($me && $me->num_rows > 0) {
          $meRow = $me->fetch_assoc();
          $currentUserName = $meRow['Name'] ?? '';
          $currentUserRoleLabel = $meRow['Role'] ?? '';
        }
      }
    ?>

    <div class="form-group" style="margin-bottom: 16px;">
      <label class="dialog-desc" style="display: block; margin-bottom: 6px; color: #374151; font-weight: 500; font-size: 13px;">Received By</label>
      <input id="received_by_input" type="text" class="input-select" placeholder="Enter receiver name" maxlength="50" style="width:calc(100% - 24px); padding: 8px 10px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 13px;" />
    </div>

    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 16px;">
      <div class="form-group">
        <label class="dialog-desc" style="display: block; margin-bottom: 6px; color: #374151; font-weight: 500; font-size: 13px;">Date Received</label>
        <input id="received_date_input" type="date" class="input-select" style="width:calc(100% - 24px); padding: 8px 10px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 13px;" />
      </div>
      <div class="form-group">
        <label class="dialog-desc" style="display: block; margin-bottom: 6px; color: #374151; font-weight: 500; font-size: 13px;">Time Received</label>
        <input id="received_time_input" type="time" class="input-select" style="width:calc(100% - 24px); padding: 8px 10px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 13px;" />
      </div>
    </div>

    <div class="order-table-wrapper" style="margin-top: 24px;">
      <table class="order-table">
        <thead>
          <tr>
            <th>Item</th>
            <th>Ordered</th>
            <th>Expiry Date</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody id="receive_order_items_body">
          <!-- Items populated by JavaScript -->
        </tbody>
      </table>
    </div>

    <div class="form-group" style="margin-bottom: 16px;">
      <label class="dialog-desc" style="display: block; margin-bottom: 6px; color: #374151; font-weight: 500; font-size: 13px;">Description (optional)</label>
      <textarea id="receive_description" class="input-select" placeholder="Add delivery notes (optional)" maxlength="250" style="width:calc(100% - 24px); height: 70px; max-height: 70px; padding: 8px 10px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 13px; resize: none; overflow-y: auto;"></textarea>
    </div>

    <div class="form-group" style="margin-bottom: 16px;">
      <label class="dialog-desc" style="display: block; margin-bottom: 6px; color: #374151; font-weight: 500; font-size: 13px;">Recorded By</label>
      <input type="text" id="recorded_by_input" class="input-select" value="<?php echo htmlspecialchars(trim($currentUserName . ($currentUserRoleLabel ? ' (' . $currentUserRoleLabel . ')' : ''))); ?>" disabled maxlength="50" style="width:calc(100% - 24px); padding: 8px 10px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 13px; background-color: #f3f4f6; color: #6b7280;" />
    </div>

    <div class="actions-row" style="margin-top: 32px; display: flex; justify-content: flex-end; gap: 12px;">
      <button type="button" class="white-btn" onclick="closeReceiveOrderModal()">Cancel</button>
      <button type="button" class="blue_design" id="confirm_delivery_btn" onclick="confirmDelivery()">Record Delivery</button>
    </div>
  </div>
</div>

<!-- Report Issue Modal (for individual items) -->
<div id="reportIssueModal" class="modal" style="display:none;">
  <div class="order-dialog" style="max-width: 500px; width: 90%;">
    <div style="display: flex; justify-content: space-between; align-items: center; padding-bottom: 16px; border-bottom: 1px solid #e5e7eb;">
      <h2 style="margin: 0; font-size: 18px; font-weight: 600; color: #111827;" id="report_issue_title">Report Issue for Sugar</h2>
      <span class="close" onclick="closeReportIssueModal()" style="cursor: pointer; font-size: 28px; color: #6b7280;">&times;</span>
    </div>


    <div style="margin-top: 24px;">
      <label style="display: block; font-size: 14px; font-weight: 500; color: #374151; margin-bottom: 8px;">Quantity to Return</label>
      <input type="number" id="return_quantity" min="1" value="1" style="width: 100%; padding: 10px 12px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 14px;">
    </div>

    <div style="margin-top: 20px;">
      <label style="display: block; font-size: 14px; font-weight: 500; color: #374151; margin-bottom: 8px;">Condition</label>
      <select id="return_condition" style="width: 100%; padding: 10px 12px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 14px;">
        <option value="Damaged">Damaged</option>
        <option value="Expired">Expired</option>
        <option value="Out of Stock">Out of Stock</option>
      </select>
    </div>

    <div style="margin-top: 20px;">
      <label style="display: block; font-size: 14px; font-weight: 500; color: #374151; margin-bottom: 8px;">Description</label>
      <textarea id="return_reason" placeholder="Describe the issue..." style="width: 100%; padding: 10px 12px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 14px; min-height: 80px; resize: vertical;"></textarea>
    </div>

    <div style="margin-top: 32px; display: flex; justify-content: flex-end; gap: 12px; padding-top: 16px; border-top: 1px solid #e5e7eb;">
      <button type="button" onclick="closeReportIssueModal()" style="padding: 10px 24px; background: white; border: 1px solid #d1d5db; border-radius: 6px; font-size: 14px; font-weight: 500; color: #374151; cursor: pointer;">Cancel</button>
      <button type="button" onclick="submitIssueReport()" style="padding: 10px 24px; background: #3b82f6; border: none; border-radius: 6px; font-size: 14px; font-weight: 500; color: white; cursor: pointer;">Submit Report</button>
    </div>
  </div>
</div>
