<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
session_name('INVENTORY_SESSION');
session_start();
require __DIR__ . '/../../login/database-account.php';
header('Content-Type: application/json; charset=utf-8');

if (!$conn) { echo json_encode(['success'=>false,'error'=>'DB']); exit; }

$supplierId = isset($_POST['supplier_id']) ? intval($_POST['supplier_id']) : 0;
$itemsJson  = $_POST['items'] ?? '[]';

error_log("DEBUG: Raw POST data - supplier_id=$supplierId, items_json=" . substr($itemsJson, 0, 200));

$items = json_decode($itemsJson, true);
if (!is_array($items)) $items = [];

error_log("DEBUG: Decoded items count: " . count($items) . ", items: " . json_encode($items));

// Validate items first - make sure we have at least one valid item
$validItems = [];
foreach ($items as $it) {
  $sid = intval($it['supplier_item_id'] ?? 0);
  $qty = intval($it['quantity'] ?? 0);
  error_log("DEBUG: Processing item - sid=$sid, qty=$qty, raw_sid=" . ($it['supplier_item_id'] ?? 'NULL'));
  if ($sid > 0 && $qty > 0) {
    $validItems[] = ['supplier_item_id' => $sid, 'quantity' => $qty];
  }
}

error_log("DEBUG: Valid items count: " . count($validItems));

if ($supplierId <= 0 || count($validItems) === 0) {
  error_log("DEBUG: Validation failed - supplierId=$supplierId, validItems=" . count($validItems));
  echo json_encode(['success'=>false,'error'=>'No items were accepted.']);
  exit;
}

// Validate that all supplier items exist and belong to this supplier
$invalidItems = [];
foreach ($validItems as $it) {
  $sid = $it['supplier_item_id'];
  $checkStmt = $conn->prepare("SELECT SupplierItemID FROM supplieritems WHERE SupplierItemID = ? AND SupplierID = ?");
  $checkStmt->bind_param('ii', $sid, $supplierId);
  $checkStmt->execute();
  $checkResult = $checkStmt->get_result();
  if ($checkResult->num_rows === 0) {
    $invalidItems[] = $sid;
    error_log("DEBUG: Invalid supplier item - sid=$sid for supplier=$supplierId");
  }
  $checkStmt->close();
}

if (count($invalidItems) > 0) {
  error_log("DEBUG: Found invalid items: " . json_encode($invalidItems));
  echo json_encode(['success'=>false,'error'=>'One or more items are invalid for this supplier.']);
  exit;
}

$conn->begin_transaction();
try {
  // Insert order header with Pending Approval status (waiting for supplier confirmation)
  $status = 'Pending Approval';
  $today  = date('Y-m-d');
  $stmt = $conn->prepare("INSERT INTO orders (SupplierID, OrderDate, Status) VALUES (?, ?, ?)");
  $stmt->bind_param('iss', $supplierId, $today, $status);
  if (!$stmt->execute()) throw new Exception('Insert order failed');
  $orderId = $stmt->insert_id;
  $stmt->close();

  // Insert details - don't add to inventory yet
  $stmtD = $conn->prepare("INSERT INTO orderdetails (OrderID, SupplierItemID, Quantity, Status) VALUES (?, ?, ?, ?)");
  foreach ($validItems as $it) {
    $sid = $it['supplier_item_id'];
    $qty = $it['quantity'];
    $dStatus = 'Pending Approval';
    
    $stmtD->bind_param('iiis', $orderId, $sid, $qty, $dStatus);
    if (!$stmtD->execute()) throw new Exception('Insert detail failed');
  }
  $stmtD->close();

  $conn->commit();
  echo json_encode(['success'=>true,'order_id'=>$orderId]);
} catch (Exception $e) {
  $conn->rollback();
  echo json_encode(['success'=>false,'error'=>$e->getMessage()]);
}

$conn->close();
?>
