<?php
// Debug script to check what orders_database.php is outputting

// Load the orders_database.php functions and display the output
ob_start();
include 'orders_database.php';
$output = ob_get_clean();

// Display it as HTML to see the actual buttons generated
echo '<html><head><title>Debug Orders</title><style>';
echo 'body { font-family: monospace; white-space: pre-wrap; background: #f0f0f0; padding: 20px; }';
echo 'tr { border: 1px solid #ccc; }';
echo 'td { padding: 5px; border: 1px solid #ddd; }';
echo 'button { padding: 5px 10px; cursor: pointer; }';
echo '.action-dropdown { border: 2px solid red; }';
echo '.action-dropdown a { display: block; padding: 10px; background: #fff; }';
echo '</style></head><body>';

echo '<h2>Raw HTML Output:</h2>';
echo htmlspecialchars($output);

echo '<h2>Rendered HTML:</h2>';
echo $output;

echo '</body></html>';
?>
