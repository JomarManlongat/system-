<?php 
session_name('INVENTORY_SESSION');
session_start();

// Authentication check
if (!isset($_SESSION['UserID']) || empty($_SESSION['UserID'])) {
    header('Location: ../login/index.php');
    exit;
}

// Admin role check - check both 'Role' and 'roles' session variables
$userRole = $_SESSION['Role'] ?? $_SESSION['roles'] ?? '';
$is_admin = (strtolower($userRole) === 'admin');
$is_staff = (strtolower($userRole) === 'staff');

// Only admin can access this page
if (!$is_admin && !$is_staff) {
    header('Location: ../login/index.php');
    exit;
}

include '../nocache.php'; 
?>
<?php include __DIR__ . '/dashboard/counting.php'; ?>
<?php
// Get logged-in user's full name and extract first name only
$full_name = isset($_SESSION['user_name']) && !empty($_SESSION['user_name']) 
    ? $_SESSION['user_name'] 
    : (isset($_SESSION['username']) ? $_SESSION['username'] : 'User');

// Extract first name (everything before the first space)
$logged_username = explode(' ', trim($full_name))[0];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Management - Lunera Hotel</title>
    <link rel="stylesheet" type="text/css" href="admin_inv_man.css">
    <link rel="icon" href="../logos/moon.png" type="image/png">
    <!-- Consolidated responsive styles now inside admin_inv_man.css -->
</head>
<body>
    <?php $nav_context='admin'; include __DIR__ . '/includes/nav.php'; ?>
    <div id="content" style="margin-left:300px; padding:20px; flex:1;">
        <div id="dashboard" class="page">
            <div class="header-page-admin">
                <h2> Dashboard</h2>
            </div>
            <div>
                <div class="dashboard-boxes">
                        <a href="" id="total-items">
                            <h2 class="h2-dashboard-boxes">Total Items</h2>
                            <img src="../logos/box1.png" alt="" class="boxes">
                            <h1><?php echo $total_amount ; ?></h1>
                            <p>Across all locations</p>
                        </a>
                        <a href="" id="low-stocks-alerts" >
                            <h2 class="h2-dashboard-boxes"> Low Stocks Alerts</h2>
                            <img src="../logos/box2.png" alt="" class="boxes">
                            <h1><?php echo $total_low_stock ; ?></h1>
                            <p>Items below minimum stocks</p>
                         </a>
                        <a href="" id="expired-items" >
                            <h2 class="h2-dashboard-boxes"> Expired Items</h2>
                            <img src="../logos/box3.png" alt="" class="boxes">
                            <h1><?php echo $total_expired ; ?></h1>
                            <p>Items past expiry date</p>
                        </a>
                </div>
                <div class="whole-overview">
                    <div id="recent-notifications">
                        <h1 id="text-notification">Recent Notifications</h1>
                        <div id="notification_new">
                            <ul id="notifications_list">
                            <?php include("dashboard/dashboard_notifications.php"); ?>
                            </ul>
                        </div>
                    </div>
                    <div id="quick-stats">
                        <h1> Quick Stats</h1>
                        <div class="logo-quick-stats">
                            <div class="div-for-quickstats">
                                <img src="../logos/damage.png" alt="" class="logo-quick-statsss">
                                <h3 class="h2" style="font-size: 22px; color: black"> <?php echo $total_damaged ; ?> </h3>
                                <p class="p">Damaged Items</p>
                            </div>
                            <div class="div-for-quickstats">
                                <img src="../logos/users-logo.png" alt="" class="logo-quick-statsss">
                                <h2 class="h2" style="font-size: 26px;"> <?php echo $total_users ; ?> </h2>
                                <p class="p">Registered Users</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div id="inventory" class="page">
            <div class="header-page-admin">
                <h2> Inventory</h2>
            </div>
            <div style="display:flex; gap:8px; align-items:center; margin-bottom:12px;">
                <?php
                $show_back_btn = false;
                // Detect whether this session was arrived from the Restaurant SSO gateway
                $sess_loc = $_SESSION['user_location'] ?? $_SESSION['sso_source'] ?? '';
                $sess_role = strtolower($_SESSION['Role'] ?? $_SESSION['roles'] ?? '');
                // Show back button only when user actually came from the Restaurant and is not an admin monitor
                if ($sess_loc === 'restaurant' || $sess_loc === 'Restaurant') {
                    if ($sess_role !== 'admin') $show_back_btn = true;
                }
                if ($show_back_btn):
                ?>
                <button id="backToRestaurantBtn" class="btn" style="background:#667eea;color:#fff;border-radius:4px;padding:8px 12px;">← Back to Restaurant</button>
                <?php endif; ?>
            </div>
            <div class="whole_box">
                <div class="inventory_functions">
                    <div id="for_form_inventory">
                        <form method="POST" id="form_filters">
                             <input type="search" name="search" id="search_bar_inventory"
                                placeholder=" Search Items by name or ID ...">
                            <select name="location" id="location">
                                <option value="All">All Locations</option>
                                <option value="Restaurant">Restaurant</option>
                                <option value="Room">Room</option>
                            </select>

                        </form>
                    </div>
                    <?php if ($is_staff): ?>
                    <button class="blue_design" onclick="openUsage()">Record Usage</button>
                    <?php endif; ?>

                </div>

                <div class="inventory_table">
                    <table>
                        <thead>
                            <tr>
                                <th>Item ID</th>
                                <th>Item Name</th>
                                <th>Stock</th>
                                <th>Supplier</th>
                                <th>Location</th>
                                <th>Expiry Date</th>
                                <th>Condition</th>
                                <?php if ($is_staff): ?>
                                <th style="text-align:center">Actions</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody id="inventory_table_body">
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div id="orders" class="page">
            <div class="header-page-admin">
                <h2> Order</h2>
            </div>
            <div class="whole_box">
                <div class="orders_design">
                    <!-- Optional search, keeps design minimal; hidden by default if not styled -->
                    <!-- <input type="search" id="search_bar_orders" class="search_bar" placeholder=" Search orders by ID, supplier or status ..."> -->
                    <button class="blue_design" id="orderss"> New Order</button>
                </div>
                <div class="inventory_table">
                    <table>
                        <thead>
                            <tr>
                                <th>Order ID</th>
                                <th>Supplier</th>
                                    <th>Location</th>
                                    <th>Items</th>
                                <th>Total</th>
                                <th>Status</th>
                                <th>Date</th>
                                <th style="text-align:center">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="orders_table_body"></tbody>
                    </table>
                </div>
            </div>
        </div>

        <div id="transactions" class="page">
            <div class="header-page-admin">
                <h2> Transactions</h2>
            </div>
            <div class="whole_box">
                <div class="inventory_functions">
                    <div id="for_form_inventory">
                        <input type="search" id="search_bar_transactions" placeholder=" Search by Item Name or ID...">
                    </div>
                </div>
                <div class="inventory_table">
                    <table>
                        <thead>
                            <tr>
                                <th style="width:90px;">Transaction ID</th>
                                <th style="width:70px;">Item ID</th>
                                <th>Item Name</th>
                                <th style="width:70px;">Quantity</th>
                                <th style="width:110px;">Type</th>
                                <th style="width:120px;">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="transactions_table_body"></tbody>
                    </table>
                </div>
            </div>
        </div>

        <div id="reports" class="page">
            <div class="header-page-admin">
                <h2> Reports</h2>
            </div>
            <div class="whole_box">
                <div class="reports-header">
                    <div>
                        <h1>Comprehensive Report Dashboard</h1>
                        <p class="muted">Select a report type and apply filters to view data.</p>
                    </div>
                    <button id="reports_print_btn" class="btn btn-print" type="button">
                        <span style="margin-right: 4px;">🖨</span> Print
                    </button>
                </div>

                <div class="reports-filters">
                    <!-- First row: Always visible -->
                    <div class="filter-row-primary">
                        <div class="filter-item" style="flex: 0 0 200px;">
                            <label>Report Type</label>
                            <select id="report_type" class="filter-select">
                                <option value="inventory">Inventory</option>
                                <option value="transactions" selected>Transactions</option>
                                <option value="alerts">Alerts</option>
                                <option value="issues">Issues</option>
                                <option value="users">Users List</option>
                            </select>
                        </div>
                        <div class="filter-item" style="flex: 1 1 auto; min-width: 200px;">
                            <label>Search</label>
                            <input id="report_search" class="filter-input" type="search" placeholder="Search..." />
                        </div>
                        <div class="filter-item" style="flex: 0 0 120px;">
                            <label>Top</label>
                            <input id="show_top" type="number" min="1" class="filter-input" placeholder="e.g. 10" />
                        </div>
                    </div>

                    <!-- Second row: Dynamic filters (show/hide based on report type) -->
                    <div class="filter-row-secondary">
                        <div class="filter-item" style="flex: 0 0 200px;">
                            <label>Location</label>
                            <select id="general_location_filter" class="filter-select">
                                <option value="All" selected>All Locations</option>
                                <option value="Restaurant">Restaurant</option>
                                <option value="Room">Room</option>
                            </select>
                        </div>
                        <div class="filter-item" id="date_range_filter" style="display:none; flex: 1 1 auto;">
                            <label>Date Range</label>
                            <div class="date-range">
                                <input id="date_from" type="date" class="filter-input" />
                                <span class="date-sep">–</span>
                                <input id="date_to" type="date" class="filter-input" />
                            </div>
                        </div>
                        <div class="filter-item" id="location_filter_wrapper" style="display:none; flex: 0 0 200px;">
                            <label>Supplier Location</label>
                            <select id="location_filter" class="filter-select">
                                <option value="All" selected>All Locations</option>
                                <option value="Restaurant">Restaurant</option>
                                <option value="Room">Room</option>
                            </select>
                        </div>
                        <div class="filter-item" id="transaction_type_filter" style="display:none; flex: 0 0 200px;">
                            <label>Transaction Type</label>
                            <select id="transaction_type" class="filter-select">
                                <option value="all" selected>All Types</option>
                                <option value="Stock Added">Stock Added</option>
                                <option value="Usage Recorded">Usage Recorded</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="reports-table-title" id="reports_table_title">Transactions <span id="reports_scope_badge" class="scope-badge" style="margin-left:12px; font-size:13px; padding:4px 8px; border-radius:12px; background:#eef; color:#334; display:inline-block;">Scope</span></div>
                <div class="inventory_table reports_table">
                    <table id="reports_table">
                        <thead id="reports_table_head">
                            <tr>
                                <th style="width:50px;">ID</th>
                                <th>Item</th>
                                <th style="width:60px;">Qty</th>
                                <th style="width:120px;">Type</th>
                                <th style="width:120px;">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="reports_table_body"></tbody>
                    </table>
                </div>

                <div class="reports-notes">
                    <label for="report_notes">Report Notes</label>
                    <textarea id="report_notes" placeholder="Type your notes for this report here..."></textarea>
                </div>
            </div>
        </div>

        <div id="alerts" class="page">
            <div class="header-page-admin">
                <h2> Alerts</h2>
            </div>
            <div class="whole_box">
                <div class="alerts-option">
                    <select id="alerts_type_filter" class="alerts_options">
                        <option value="all">All Types</option>
                        <option value="Low Stock">Low Stock</option>
                        <option value="Expiry Soon">Expiry Soon</option>
                    </select>
                </div>
                <div class="inventory_table">
                    <table>
                        <thead>
                            <tr>
                                <th>Alert ID</th>
                                <th>Type</th>
                                <th>Item Name</th>
                                <th>Details</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody id="alerts_table_body"></tbody>
                    </table>
                </div>
            </div>
        </div>

        <div id="issues" class="page">
            <div class="header-page-admin">
                <h2> Issues</h2>
            </div>
            <div class="whole_box">
                <div class="alerts-option">
                    <select id="issues_filter" class="issues_options">
                        <option value="all"> All Issues </option>
                        <option value="damaged"> Damaged </option>
                        <option value="expired"> Expired </option>
                        <option value="out of stock"> Out of Stock </option>
                    </select>
                </div>
                <div class="inventory_table">
                    <table>
                        <thead>
                            <tr>
                                <th>Item ID</th>
                                <th>Item Name</th>
                                <th>Location</th>
                                <th>Stock</th>
                                <th>Expiry Date</th>
                                <th>Condition</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody id="issues_table_body"></tbody>
                    </table>
                </div>
            </div>
        </div>

        <div id="suppliers" class="page">
            <div class="header-page-admin">
                <h2> Suppliers</h2>
            </div>
            <div class="whole_box">
                <div class="inventory_functions">
                    <div id="for_form_inventory">
                        <form method="POST" id="form_suppliers_filters">
                            <input type="search" name="search" id="search_bar_suppliers" 
                                placeholder=" Search suppliers...">
                        </form>
                    </div>
                    <?php if ($is_staff): ?>
                    <button class="blue_design" onclick="openAddSupplierModal()">New Supplier</button>
                    <?php endif; ?>
                </div>
                <div id="suppliers_cards_container" class="suppliers-cards-grid">
                    <!-- Supplier cards will be loaded here -->
                </div>
            </div>
        </div>

        <div id="users" class="page">
            <div class="header-page-admin">
                <h2> Manage Users</h2>
            </div>
            <div class="whole_box">
                <div class="inventory_functions">
                    <div id="for_form_inventory">
                        <form method="POST" id="form_users_filters">
                            <input type="search" name="search" id="search_bar_users"
                                placeholder=" Search by username, name or ID ...">
                        </form>
                    </div>
                    <button class="blue_design" onclick="openAddUserModal()">Add User</button>
                </div>
                <div class="inventory_table">
                    <table>
                        <thead>
                            <tr>
                                <th>User ID</th>
                                <th>Username</th>
                                <th>Role</th>
                                <th>Name</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="users_table_body">
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div id="settings" class="page">
            <div class="header-page-admin">
                <h2> Settings</h2>
            </div>
            <div class="whole_box">
                <div class="settings-container">
                    
                    <!-- Appearance Settings -->
                    <div class="settings-section">
                        <div class="settings-section-header">
                            <h3>🎨 Appearance</h3>
                            <p class="settings-description">Customize the look and feel of your dashboard</p>
                        </div>
                        <div class="settings-item">
                            <div class="settings-item-info">
                                <label>Theme</label>
                                <span class="settings-item-desc">Choose your preferred color scheme</span>
                            </div>
                            <div class="theme-options">
                                <button class="theme-btn active" data-theme="light">
                                    <span class="theme-icon">☀️</span>
                                    <span>Light</span>
                                </button>
                                <button class="theme-btn" data-theme="dark">
                                    <span class="theme-icon">🌙</span>
                                    <span>Dark</span>
                                </button>
                                <button class="theme-btn" data-theme="auto">
                                    <span class="theme-icon">🔄</span>
                                    <span>Auto</span>
                                </button>
                            </div>
                        </div>
                        <div class="settings-item">
                            <div class="settings-item-info">
                                <label>Compact Mode</label>
                                <span class="settings-item-desc">Reduce spacing for more content visibility</span>
                            </div>
                            <label class="toggle-switch">
                                <input type="checkbox" id="compact_mode">
                                <span class="toggle-slider"></span>
                            </label>
                        </div>
                    </div>

                    <!-- Notification Settings -->
                    <div class="settings-section">
                        <div class="settings-section-header">
                            <h3>🔔 Notifications</h3>
                            <p class="settings-description">Manage how you receive alerts and updates</p>
                        </div>
                        <div class="settings-item">
                            <div class="settings-item-info">
                                <label>Low Stock Alerts</label>
                                <span class="settings-item-desc">Get notified when items are running low</span>
                            </div>
                            <label class="toggle-switch">
                                <input type="checkbox" id="low_stock_alerts" checked>
                                <span class="toggle-slider"></span>
                            </label>
                        </div>
                        <div class="settings-item">
                            <div class="settings-item-info">
                                <label>Expiry Alerts</label>
                                <span class="settings-item-desc">Get notified about expiring items</span>
                            </div>
                            <label class="toggle-switch">
                                <input type="checkbox" id="expiry_alerts" checked>
                                <span class="toggle-slider"></span>
                            </label>
                        </div>
                        <div class="settings-item">
                            <div class="settings-item-info">
                                <label>Order Updates</label>
                                <span class="settings-item-desc">Receive notifications about order status changes</span>
                            </div>
                            <label class="toggle-switch">
                                <input type="checkbox" id="order_updates" checked>
                                <span class="toggle-slider"></span>
                            </label>
                        </div>
                        <div class="settings-item">
                            <div class="settings-item-info">
                                <label>Sound Notifications</label>
                                <span class="settings-item-desc">Play sound for important alerts</span>
                            </div>
                            <label class="toggle-switch">
                                <input type="checkbox" id="sound_notifications">
                                <span class="toggle-slider"></span>
                            </label>
                        </div>
                    </div>

                    <!-- System Settings -->
                    <div class="settings-section">
                        <div class="settings-section-header">
                            <h3>⚙️ System</h3>
                            <p class="settings-description">Advanced system preferences</p>
                        </div>
                        <div class="settings-item">
                            <div class="settings-item-info">
                                <label>Cache</label>
                                <span class="settings-item-desc">Clear cached data to free up space</span>
                            </div>
                            <button class="settings-btn-secondary" onclick="clearCache()">🗑️ Clear Cache</button>
                        </div>
                        <div class="settings-item">
                            <div class="settings-item-info">
                                <label>System Version</label>
                                <span class="settings-item-desc">Inventory Management System v1.0.0 (November 2025)</span>
                            </div>
                            <button class="settings-btn-secondary" onclick="checkUpdates()">🔄 Check Updates</button>
                        </div>
                    </div>

                    <!-- Settings Footer -->
                    <div class="settings-footer">
                        <button class="settings-btn-reset" onclick="resetSettings()">
                            <span>↺</span> Reset to Defaults
                        </button>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <?php include __DIR__ . '/inventory/record_usage_modal.php'; ?>
    <?php include __DIR__ . '/users/user_modals.php'; ?>
    <?php include __DIR__ . '/suppliers/supplier_modals.php'; ?>
    <?php include __DIR__ . '/suppliers/supplier_order_modal.php'; ?>
    <?php include __DIR__ . '/suppliers/supplier_items_modal.php'; ?>
    <?php include __DIR__ . '/orders/order_modals.php'; ?>
    
    <!-- Confirmation Modal -->
    <div id="confirmationModal" class="modal" style="display:none;">
        <div class="modal-content" style="max-width: 450px; text-align: center; padding: 30px;">
            <h2 id="confirmationModalTitle" style="margin: 0 0 16px 0; font-size: 22px; color: #1f2937;">Confirm Action</h2>
            <p id="confirmationModalMessage" style="font-size: 16px; color: #6b7280; margin: 0 0 28px 0; line-height: 1.5;"></p>
            <div style="display: flex; gap: 12px; justify-content: center;">
                <button class="white-btn" onclick="closeConfirmationModal(false)" style="padding: 12px 32px; font-size: 15px;">Cancel</button>
                <button class="blue_design" onclick="closeConfirmationModal(true)" style="padding: 12px 32px; font-size: 15px;">Confirm</button>
            </div>
        </div>
    </div>
    
    <!-- Transaction Details Modal -->
    <div id="transactionDetailsModal" class="modal" style="display:none;">
        <div class="modal-content" style="max-width: 600px; padding: 24px;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px; border-bottom:2px solid #e5e7eb; padding-bottom:12px;">
                <h2 style="margin:0; font-size:20px; color:#1f2937;">Transaction Details</h2>
                <button onclick="closeTransactionDetailsModal()" style="background:none; border:none; font-size:24px; cursor:pointer; color:#9ca3af; line-height:1;">&times;</button>
            </div>
            <div id="transactionDetailsContent" style="font-size:14px;">
                <div style="display:grid; grid-template-columns: 140px 1fr; gap:12px; margin-bottom:20px;">
                    <div style="font-weight:600; color:#4b5563;">Transaction ID:</div>
                    <div id="detail_trans_id" style="color:#1f2937;"></div>
                    
                    <div style="font-weight:600; color:#4b5563;">Item ID:</div>
                    <div id="detail_item_id" style="color:#1f2937;"></div>
                    
                    <div style="font-weight:600; color:#4b5563;">Item Name:</div>
                    <div id="detail_item_name" style="color:#1f2937;"></div>
                    
                    <div style="font-weight:600; color:#4b5563;">Quantity:</div>
                    <div id="detail_quantity" style="color:#1f2937;"></div>
                    
                    <div style="font-weight:600; color:#4b5563;">Type:</div>
                    <div id="detail_type" style="color:#1f2937;"></div>
                    
                    <div style="font-weight:600; color:#4b5563;">User:</div>
                    <div id="detail_user" style="color:#1f2937;"></div>
                    
                    <div style="font-weight:600; color:#4b5563;">Date/Time:</div>
                    <div id="detail_datetime" style="color:#1f2937;"></div>
                </div>
                
                <div id="delivery_details" style="display:none; border-top:2px solid #e5e7eb; padding-top:16px; margin-top:16px;">
                    <h3 id="delivery_section_title" style="font-size:16px; color:#1f2937; margin:0 0 12px 0;">Delivery Information</h3>
                    <div style="display:grid; grid-template-columns: 180px 1fr; gap:12px;">
                        <div id="received_by_label" style="font-weight:600; color:#4b5563;">Received By:</div>
                        <div id="detail_received_by" style="color:#1f2937;"></div>
                        
                        <div style="font-weight:600; color:#4b5563;">Date:</div>
                        <div id="detail_received_date" style="color:#1f2937;"></div>
                        
                        <div style="font-weight:600; color:#4b5563;">Time:</div>
                        <div id="detail_received_time" style="color:#1f2937;"></div>
                        
                        <div style="font-weight:600; color:#4b5563;">Recorded By:</div>
                        <div id="detail_recorded_by" style="color:#1f2937;"></div>
                        
                        <div style="font-weight:600; color:#4b5563;">Description:</div>
                        <div id="detail_description" style="color:#1f2937; white-space:pre-wrap;"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="inventory/record_usage.js"></script>
    <script src="users/users_management.js"></script>
    <script src="suppliers/suppliers_management.js"></script>
    <script src="orders/orders_management.js?v=<?php echo time(); ?>"></script>
    <script src="admin_int_man.js"></script>
    <script>
    // Ensure Back to Restaurant button navigates same-tab to the restaurant admin
    document.addEventListener('DOMContentLoaded', function(){
        var backBtn = document.getElementById('backToRestaurantBtn');
        if (backBtn) {
            backBtn.addEventListener('click', function(){
                // use replace so we don't leave multiple history entries when toggling
                window.location.replace('/system/HotelLuneraRestaurant/index.php');
            });
        }

        // Reports scope badge setup based on server-side session
        try {
            var badge = document.getElementById('reports_scope_badge');
            if (badge) {
                // session values injected from PHP
                var sessionRole = '<?php echo addslashes(strtolower($_SESSION['Role'] ?? $_SESSION['roles'] ?? '')); ?>';
                var sessionLocation = '<?php echo addslashes($_SESSION['user_location'] ?? ''); ?>';
                
                // Make role available globally for other scripts
                window.userRole = sessionRole;
                window.isAdmin = (sessionRole === 'admin');
                window.isStaff = (sessionRole === 'staff');

                var label = 'Scope';
                var bg = '#eef';
                var color = '#334';

                if (sessionRole === 'admin') {
                    label = 'All (admin)';
                    bg = '#6b5cff';
                    color = '#fff';
                } else {
                    if (!sessionLocation || sessionLocation === 'NULL') {
                        label = 'Both Locations';
                        bg = '#cbd5e1';
                        color = '#0f172a';
                    } else if (sessionLocation.toLowerCase() === 'restaurant') {
                        label = 'Restaurant';
                        bg = '#d1fae5';
                        color = '#065f46';
                    } else if (sessionLocation.toLowerCase() === 'room') {
                        label = 'Room';
                        bg = '#e0f2fe';
                        color = '#0369a1';
                    } else {
                        // any other explicit label
                        label = sessionLocation;
                        bg = '#f3f4f6';
                        color = '#111827';
                    }
                }

                badge.textContent = label;
                badge.style.background = bg;
                badge.style.color = color;
            }
        } catch (e) {
            console.error('Failed to set scope badge', e);
        }
    });
    </script>
</body>
</html>