<!-- View Supplier Items Modal (Admin View) -->
<div id="viewSupplierItemsModal" class="modal" style="display:none;">
  <div class="modal-content" style="max-width: 900px; width: 90%;">
    <div class="modal-header" style="display: flex; justify-content: space-between; align-items: center; padding-bottom: 16px; border-bottom: 2px solid #e5e7eb;">
      <h3 id="supplier_items_title" style="margin: 0; font-size: 20px; font-weight: 600; color: #111827;">Supplier Items</h3>
      <span class="close" onclick="closeSupplierItemsModal()" style="cursor: pointer; font-size: 28px; color: #6b7280;">&times;</span>
    </div>

    <div style="margin-top: 20px;">
      <div id="supplier_items_info" style="background: #f9fafb; padding: 16px; border-radius: 8px; margin-bottom: 20px;">
        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px;">
          <div>
            <span style="font-weight: 600; color: #374151;">Supplier:</span>
            <span id="supplier_name_display" style="color: #111827; margin-left: 8px;"></span>
          </div>
          <div>
            <span style="font-weight: 600; color: #374151;">Total Items:</span>
            <span id="supplier_items_count" style="color: #111827; margin-left: 8px;">0</span>
          </div>
        </div>
      </div>

      <div class="inventory_table" style="margin: 0;">
        <table style="width: 100%; border-collapse: collapse;">
          <thead>
            <tr style="background: #f3f4f6;">
              <th style="padding: 12px; text-align: left; font-weight: 600; color: #374151; border-bottom: 2px solid #e5e7eb;">Item Name</th>
              <th style="padding: 12px; text-align: left; font-weight: 600; color: #374151; border-bottom: 2px solid #e5e7eb;">Measurement</th>
              <th style="padding: 12px; text-align: right; font-weight: 600; color: #374151; border-bottom: 2px solid #e5e7eb;">Price</th>
            </tr>
          </thead>
          <tbody id="supplier_items_tbody">
            <tr>
              <td colspan="3" style="text-align: center; color: #6b7280; padding: 24px;">
                Loading items...
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <div id="no_items_message" style="display: none; text-align: center; padding: 40px; color: #6b7280;">
        <svg style="width: 64px; height: 64px; margin: 0 auto 16px; opacity: 0.5;" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"></path>
        </svg>
        <p style="font-size: 16px; margin: 0;">No items found for this supplier</p>
      </div>
    </div>

    <div class="modal-actions" style="margin-top: 24px; display: flex; justify-content: flex-end;">
      <button type="button" class="cancel-btn" onclick="closeSupplierItemsModal()" style="padding: 10px 24px;">Close</button>
    </div>
  </div>
</div>
