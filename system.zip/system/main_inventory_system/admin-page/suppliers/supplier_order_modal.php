<!-- Supplier Create New Order Modal -->
<div id="supplierCreateOrderModal" class="modal" style="display:none;">
  <div class="order-dialog" style="max-width:700px; width:90%; background:white; border-radius:10px; box-shadow:0 20px 25px -5px rgba(0,0,0,0.1), 0 10px 10px -5px rgba(0,0,0,0.04);">
    <div class="modal-header" style="display:flex; justify-content:space-between; align-items:center; padding:20px 24px; border-bottom:1px solid #e5e7eb;">
      <h2 class="dialog-title" style="margin:0; font-size:20px; font-weight:600; color:#111827;">Create New Order</h2>
      <span class="close" onclick="closeSupplierCreateOrderModal()" style="font-size:28px; color:#9ca3af; cursor:pointer; line-height:1; font-weight:300; transition:color 0.2s;">&times;</span>
    </div>

    <div style="padding:24px;">
      <div class="title-group" style="margin-bottom:20px;">
        <p class="dialog-desc" style="color:#6b7280; font-size:14px; margin:0; line-height:1.5;">Add items to order from this supplier.</p>
      </div>

      <div class="form-group" style="margin-bottom:20px;">
        <label for="supplier_order_supplier_name" class="dialog-desc" style="display:block; margin-bottom:8px; color:#374151; font-weight:600; font-size:13px;">Supplier</label>
        <input type="text" id="supplier_order_supplier_name" class="input-select" style="width:60%; padding:10px 14px; background:#f9fafb; cursor:not-allowed; border:1px solid #d1d5db; border-radius:6px; font-size:14px; color:#1f2937; font-weight:500;" readonly />
        <input type="hidden" id="supplier_order_supplier_id" />
      </div>

      <div class="form-group" style="margin-top:20px;">
        <label class="dialog-desc" style="display:block; margin-bottom:10px; color:#374151; font-weight:600; font-size:13px;">Items</label>
        <div id="supplier_order_items_container" style="margin-bottom:10px; max-height:280px; overflow-y:auto; padding-right:4px;"></div>
        <button class="white-btn" type="button" style="margin-top:10px; padding:10px 18px; width:100%; border:2px dashed #cbd5e1; background:white; border-radius:6px; cursor:pointer; font-size:13px; font-weight:500; color:#64748b; transition:all 0.2s;" onclick="addSupplierOrderItemRow()">+ Add Item</button>
      </div>

      <div class="actions-row" style="display:flex; gap:10px; justify-content:flex-end; margin-top:24px; padding-top:18px; border-top:1px solid #e5e7eb;">
        <button class="white-btn" type="button" onclick="closeSupplierCreateOrderModal()" style="padding:10px 24px; border:1px solid #d1d5db; background:white; border-radius:6px; cursor:pointer; font-size:14px; font-weight:500; color:#374151; transition:all 0.2s;">Cancel</button>
        <button class="blue_design" id="supplier_create_order_btn" type="button" onclick="submitSupplierOrder()" style="padding:10px 24px; background:#2563eb; color:white; border:none; border-radius:6px; cursor:pointer; font-size:14px; font-weight:500; transition:all 0.2s; box-shadow:0 1px 2px 0 rgba(0,0,0,0.05);">Create Order</button>
      </div>
    </div>
  </div>
</div>

<!-- Supplier View Orders Modal -->
<div id="supplierOrdersModal" class="modal" style="display:none;">
  <div class="order-dialog" style="max-width:1000px; width:95%; background:white; border-radius:10px; box-shadow:0 20px 25px -5px rgba(0,0,0,0.1), 0 10px 10px -5px rgba(0,0,0,0.04);">
    <div class="modal-header" style="display:flex; justify-content:space-between; align-items:center; padding:20px 24px; border-bottom:1px solid #e5e7eb;">
      <h2 id="supplier_orders_title" class="dialog-title" style="margin:0; font-size:20px; font-weight:600; color:#111827;">Orders for Supplier</h2>
      <span class="close" onclick="closeSupplierOrdersModal()" style="font-size:28px; color:#9ca3af; cursor:pointer; line-height:1; font-weight:300; transition:color 0.2s;">&times;</span>
    </div>

    <div style="padding:24px;">
      <div class="order-table-wrapper" style="max-height:500px; overflow-y:auto;">
        <table class="order-table" style="width:100%;">
          <thead>
            <tr>
              <th>Order ID</th>
              <th>Date</th>
              <th>Status</th>
              <th>Total Items</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody id="supplier_orders_tbody">
            <!-- Orders will be loaded here -->
          </tbody>
        </table>
      </div>
      
      <div style="display:flex; justify-content:flex-end; margin-top:20px; padding-top:16px; border-top:1px solid #e5e7eb;">
        <button class="white-btn" type="button" onclick="closeSupplierOrdersModal()" style="padding:10px 24px; border:1px solid #d1d5db; background:white; border-radius:6px; cursor:pointer; font-size:14px; font-weight:500; color:#374151;">Close</button>
      </div>
    </div>
  </div>
</div>

<script>
window.closeSupplierOrdersModal = function() {
  const modal = document.getElementById('supplierOrdersModal');
  if (modal) modal.style.display = 'none';
};
</script>
