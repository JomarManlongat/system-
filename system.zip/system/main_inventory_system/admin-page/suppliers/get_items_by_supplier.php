<?php
session_name('INVENTORY_SESSION');
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../../login/database-account.php';

$supplier_id = $_GET['supplier_id'] ?? '';

if (empty($supplier_id)) {
    echo json_encode(['success' => false, 'error' => 'Supplier ID is required']);
    exit;
}

try {
    $stmt = $conn->prepare("SELECT SupplierItemID, SupplierID, ItemName, Measurement, Price FROM supplieritems WHERE SupplierID = ? ORDER BY ItemName ASC");
    $stmt->bind_param('i', $supplier_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $items = [];
    while ($row = $result->fetch_assoc()) {
        $items[] = $row;
    }
    
    echo json_encode([
        'success' => true,
        'items' => $items,
        'count' => count($items)
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Failed to fetch items: ' . $e->getMessage()
    ]);
}

$conn->close();
exit;
