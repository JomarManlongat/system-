// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
  initSuppliersPage();
});

// Detect if we're in staff or admin context - determine base path based on current location
function getSupplierPath(relativePath) {
  // When in staff-page/staff_inv_man.php, location includes 'staff-page' and relative paths start with 'suppliers/'
  // When in admin-page/admin_inv_man.php, location includes 'admin-page' and relative paths start with 'suppliers/'
  // Both cases use: ../admin-page/suppliers/* OR suppliers/* depending on context
  if (window.location.pathname.includes('/staff-page/')) {
    return '../admin-page/suppliers/' + relativePath;
  }
  return 'suppliers/' + relativePath;
}

function getOrderPath(relativePath) {
  // Similar logic for orders
  if (window.location.pathname.includes('/staff-page/')) {
    return '../admin-page/orders/' + relativePath;
  }
  return 'orders/' + relativePath;
}

function initSuppliersPage() {
  loadSuppliersCards();
  setupSupplierForms();
  setupSupplierSearch();
}

// Load and render supplier cards
function loadSuppliersCards(searchQuery = '') {
  console.log('Loading suppliers...');
  const url = searchQuery 
    ? `${getSupplierPath('suppliers_database.php')}?search=${encodeURIComponent(searchQuery)}`
    : getSupplierPath('suppliers_database.php');

  fetch(url)
    .then(response => {
      console.log('Response status:', response.status);
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      return response.json();
    })
    .then(suppliers => {
      console.log('Suppliers received:', suppliers);
      // Check if it's an error object
      if (suppliers.error) {
        console.error('Error from server:', suppliers.error);
        renderSupplierCards([]);
      } else {
        renderSupplierCards(suppliers);
      }
    })
    .catch(error => {
      console.error('Error loading suppliers:', error);
      const container = document.getElementById('suppliers_cards_container');
      if (container) {
        container.innerHTML = '<div class="no-suppliers" style="color: #dc3545;">Failed to load suppliers. Please refresh the page.</div>';
      }
    });
}

// Render supplier cards
function renderSupplierCards(suppliers) {
  const container = document.getElementById('suppliers_cards_container');
  if (!container) return;

  if (!suppliers || suppliers.length === 0) {
    container.innerHTML = '<div class="no-suppliers">No suppliers found</div>';
    return;
  }

  container.innerHTML = suppliers.map(supplier => {
    const isAdmin = window.isAdmin || false;
    const isStaff = window.isStaff || false;
    
    // Admin view: Only "See Items List" button
    if (isAdmin && !isStaff) {
      return `
    <div class="supplier-card" data-supplier-id="${supplier.SupplierID}">
      <div class="supplier-card-header">
        <h3>${escapeHtml(supplier.SupplierName)}</h3>
      </div>
      
      <div class="supplier-card-body">
        <div class="supplier-info-row">
          <span class="info-label">📍 Address</span>
          <span class="info-value">${escapeHtml(supplier.ContactPerson)}</span>
        </div>
        <div class="supplier-info-row">
          <span class="info-label">📞 Contact Number</span>
          <span class="info-value">${escapeHtml(supplier.Phone)}</span>
        </div>
        ${supplier.Email ? `
        <div class="supplier-info-row">
          <span class="info-label">✉️ Email</span>
          <span class="info-value">${escapeHtml(supplier.Email)}</span>
        </div>
        ` : ''}
        ${supplier.Facebook ? `
        <div class="supplier-info-row">
          <span class="info-label">📘 Facebook</span>
          <span class="info-value">${escapeHtml(supplier.Facebook)}</span>
        </div>
        ` : ''}
      </div>
      
      <div class="supplier-card-footer">
        <button class="btn-primary" onclick="viewSupplierItems(${supplier.SupplierID}, '${escapeHtml(supplier.SupplierName).replace(/'/g, "\\'")}')">See Items List</button>
      </div>
    </div>
  `;
    }
    
    // Staff view: Full functionality with edit/delete/order buttons
    const editButton = `<div class="action-item" onclick="openEditSupplier(${supplier.SupplierID})">Edit</div>`;
    const deleteButton = `<div class="action-item delete-action" onclick="deleteSupplier(${supplier.SupplierID}, '${escapeHtml(supplier.SupplierName).replace(/'/g, "\\'")}')">Remove</div>`;
    
    const actionMenu = `
      <div class="supplier-card-actions">
        <button class="action-menu-btn" onclick="toggleSupplierMenu(event, ${supplier.SupplierID})">⋮</button>
        <div class="action-dropdown" id="supplier_menu_${supplier.SupplierID}" style="display:none;">
          ${editButton}
          ${deleteButton}
        </div>
      </div>
    `;
    
    const orderButtons = `
      <div class="supplier-card-footer">
        <button class="btn-secondary" onclick="viewSupplierOrders(${supplier.SupplierID})">View Orders</button>
        <button class="btn-primary" onclick="newSupplierOrder(${supplier.SupplierID})">New Order</button>
      </div>
    `;
    
    return `
    <div class="supplier-card" data-supplier-id="${supplier.SupplierID}">
      ${actionMenu}
      
      <div class="supplier-card-header">
        <h3>${escapeHtml(supplier.SupplierName)}</h3>
      </div>
      
      <div class="supplier-card-body">
        <div class="supplier-info-row">
          <span class="info-label">📍 Address</span>
          <span class="info-value">${escapeHtml(supplier.ContactPerson)}</span>
        </div>
        <div class="supplier-info-row">
          <span class="info-label">📞 Contact Number</span>
          <span class="info-value">${escapeHtml(supplier.Phone)}</span>
        </div>
        ${supplier.Email ? `
        <div class="supplier-info-row">
          <span class="info-label">✉️ Email</span>
          <span class="info-value">${escapeHtml(supplier.Email)}</span>
        </div>
        ` : ''}
        ${supplier.Facebook ? `
        <div class="supplier-info-row">
          <span class="info-label">📘 Facebook</span>
          <span class="info-value">${escapeHtml(supplier.Facebook)}</span>
        </div>
        ` : ''}
      </div>
      
      ${orderButtons}
    </div>
  `;
  }).join('');
}

// Toggle action menu
function toggleSupplierMenu(event, supplierId) {
  event.stopPropagation();
  const menu = document.getElementById(`supplier_menu_${supplierId}`);
  
  // Close all other menus
  document.querySelectorAll('.action-dropdown').forEach(m => {
    if (m !== menu) m.style.display = 'none';
  });

  if (menu.style.display === 'none') {
    const btn = event.target;
    const rect = btn.getBoundingClientRect();
    menu.style.position = 'fixed';
    menu.style.top = `${rect.bottom + 5}px`;
    menu.style.left = `${rect.left - 120}px`;
    menu.style.display = 'block';
  } else {
    menu.style.display = 'none';
  }
}

// Close menus when clicking outside
document.addEventListener('click', function() {
  document.querySelectorAll('.action-dropdown').forEach(menu => {
    menu.style.display = 'none';
  });
});

// Setup search
function setupSupplierSearch() {
  const searchBar = document.getElementById('search_bar_suppliers');
  if (!searchBar) return;

  let debounceTimer;
  searchBar.addEventListener('input', function() {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => {
      loadSuppliersCards(this.value.trim());
    }, 300);
  });
}

// Modal functions
window.openAddSupplierModal = function() {
  const modal = document.getElementById('addSupplierModal');
  if (modal) {
    // Clear all inputs
    document.getElementById('add_supplier_name').value = '';
    document.getElementById('add_contact_person').value = '';
    document.getElementById('add_phone').value = '';
    document.getElementById('add_email').value = '';
    document.getElementById('add_facebook').value = '';
    document.getElementById('add_supplier_location').value = '';
    document.getElementById('add_supplier_message').textContent = '';
    modal.style.display = 'flex';
  }
};

window.closeAddSupplierModal = function() {
  const modal = document.getElementById('addSupplierModal');
  if (modal) {
    modal.style.display = 'none';
    // Reset to step 1
    document.getElementById('addSupplierForm').style.display = 'block';
    document.getElementById('addSupplierItemsSection').style.display = 'none';
    document.getElementById('add_supplier_modal_title').textContent = 'Add New Supplier - Step 1';
    // Clear all inputs
    document.getElementById('add_supplier_name').value = '';
    document.getElementById('add_contact_person').value = '';
    document.getElementById('add_phone').value = '';
    document.getElementById('add_email').value = '';
    document.getElementById('add_facebook').value = '';
    document.getElementById('add_supplier_location').value = '';
    document.getElementById('supplier_items_container').innerHTML = '';
    
    // Reset modal width
    const modalContent = document.getElementById('add_supplier_modal_content');
    if (modalContent) {
      modalContent.classList.remove('expanded');
      modalContent.style.maxWidth = '600px';
      modalContent.style.width = '';
    }
  }
};

// Step 1 to Step 2: Go to supplier items
window.goToSupplierItems = function(e) {
  if (e) {
    e.preventDefault();
    e.stopPropagation();
  }
  
  const nameEl = document.getElementById('add_supplier_name');
  const contactEl = document.getElementById('add_contact_person');
  const phoneEl = document.getElementById('add_phone');
  const locationEl = document.getElementById('add_supplier_location');
  const msg = document.getElementById('add_supplier_message');
  
  const name = (nameEl && nameEl.value) ? nameEl.value.trim() : '';
  const contact = (contactEl && contactEl.value) ? contactEl.value.trim() : '';
  const phone = (phoneEl && phoneEl.value) ? phoneEl.value.trim() : '';
  const location = (locationEl && locationEl.value) ? locationEl.value.trim() : '';

  // Validate
  if (!name || !contact || !phone || !location) {
    if (msg) {
      msg.textContent = 'Please fill all required fields';
      msg.style.color = '#dc3545';
      msg.style.display = 'block';
    }
    return false;
  }

  if (msg) {
    msg.textContent = '';
    msg.style.display = 'none';
  }
  
  // Switch to step 2
  const form = document.getElementById('addSupplierForm');
  const itemsSection = document.getElementById('addSupplierItemsSection');
  const title = document.getElementById('add_supplier_modal_title');
  
  if (form) form.style.display = 'none';
  if (itemsSection) itemsSection.style.display = 'block';
  if (title) title.textContent = 'Add New Supplier - Step 2';
  
  // Expand modal
  const modalContent = document.getElementById('add_supplier_modal_content');
  if (modalContent) {
    modalContent.classList.add('expanded');
    modalContent.style.maxWidth = '850px';
    modalContent.style.width = '90%';
  }
  
  // Add initial item row if empty
  const container = document.getElementById('supplier_items_container');
  if (container && container.children.length === 0) {
    addSupplierItemRow();
  }
  
  return false;
};

// Back to step 1
window.backToSupplierInfo = function() {
  const form = document.getElementById('addSupplierForm');
  const itemsSection = document.getElementById('addSupplierItemsSection');
  const title = document.getElementById('add_supplier_modal_title');
  const msg = document.getElementById('add_supplier_items_message');
  
  if (form) form.style.display = 'block';
  if (itemsSection) itemsSection.style.display = 'none';
  if (title) title.textContent = 'Add New Supplier - Step 1';
  if (msg) msg.textContent = '';
  
  // Shrink modal back
  const modalContent = document.getElementById('add_supplier_modal_content');
  if (modalContent) {
    modalContent.classList.remove('expanded');
    modalContent.style.maxWidth = '600px';
    modalContent.style.width = '600px';
  }
};

// Add item row
let itemRowCounter = 0;
let cachedMeasurements = null;

// Fetch measurements from database
async function getMeasurements() {
  if (cachedMeasurements) return cachedMeasurements;
  
  try {
    const response = await fetch(getSupplierPath('get_measurements.php'));
    const data = await response.json();
    if (data.success) {
      cachedMeasurements = data.measurements;
      return cachedMeasurements;
    }
  } catch (error) {
    console.error('Error fetching measurements:', error);
  }
  
  // Fallback measurements
  return ['kg', 'g', 'L', 'mL', 'pcs', 'box', 'pack', 'dozen', 'sack', 'can', 'bottle'];
}

window.addSupplierItemRow = async function() {
  const container = document.getElementById('supplier_items_container');
  const rowId = ++itemRowCounter;
  
  // Get measurements for dropdown
  const measurements = await getMeasurements();
  const measurementOptions = measurements.map(m => `<option value="${m}">${m}</option>`).join('');
  
  const row = document.createElement('div');
  row.className = 'supplier-item-row';
  row.id = `item_row_${rowId}`;
  row.style.cssText = 'display:grid;grid-template-columns:2fr 1fr 1fr auto;gap:12px;margin-bottom:16px;align-items:end;';
  
  row.innerHTML = `
    <div>
      <label style="display:block;font-size:14px;margin-bottom:6px;color:#555;font-weight:500;">Item Name</label>
      <input type="text" class="item-name" required style="width:100%;padding:10px 12px;border:1px solid #ddd;border-radius:4px;font-size:14px;" />
    </div>
    <div>
      <label style="display:block;font-size:14px;margin-bottom:6px;color:#555;font-weight:500;">Unit</label>
      <select class="item-measurement" required style="width:100%;padding:10px 12px;border:1px solid #ddd;border-radius:4px;font-size:14px;">
        <option value="">Select unit</option>
        ${measurementOptions}
      </select>
    </div>
    <div>
      <label style="display:block;font-size:14px;margin-bottom:6px;color:#555;font-weight:500;">Price</label>
      <input type="number" class="item-price" placeholder="0.00" step="0.01" min="0" required style="width:100%;padding:10px 12px;border:1px solid #ddd;border-radius:4px;font-size:14px;" />
    </div>
    <button type="button" onclick="removeSupplierItemRow(${rowId})" style="padding:10px 14px;background:#dc3545;color:white;border:none;border-radius:4px;cursor:pointer;height:42px;font-size:18px;font-weight:bold;">×</button>
  `;
  
  container.appendChild(row);
};

window.removeSupplierItemRow = function(rowId) {
  const row = document.getElementById(`item_row_${rowId}`);
  if (row) row.remove();
};

// Submit supplier with items
window.submitSupplierWithItems = function(e) {
  if (e) {
    e.preventDefault();
    e.stopPropagation();
  }
  
  const btn = document.getElementById('add_supplier_submit_btn');
  const msg = document.getElementById('add_supplier_items_message');
  
  if (!btn) {
    console.error('Submit button not found');
    return false;
  }
  
  if (!msg) {
    console.error('Message element not found');
    return false;
  }
  
  btn.disabled = true;
  btn.textContent = 'Adding...';
  msg.textContent = '';
  msg.style.display = 'none';

  // Get supplier data with null checks
  const nameEl = document.getElementById('add_supplier_name');
  const contactEl = document.getElementById('add_contact_person');
  const phoneEl = document.getElementById('add_phone');
  const emailEl = document.getElementById('add_email');
  const facebookEl = document.getElementById('add_facebook');
  const locationEl = document.getElementById('add_supplier_location');

  if (!nameEl || !contactEl || !phoneEl || !locationEl) {
    msg.textContent = 'Form elements not found';
    msg.style.color = '#dc3545';
    msg.style.display = 'block';
    btn.disabled = false;
    btn.textContent = 'Add Supplier';
    return false;
  }

  const supplierData = {
    action: 'add',
    supplier_name: nameEl.value.trim(),
    contact_person: contactEl.value.trim(),
    phone: phoneEl.value.trim(),
    email: emailEl ? emailEl.value.trim() : '',
    facebook: facebookEl ? facebookEl.value.trim() : '',
    location: locationEl.value
  };

  // Get items data
  const items = [];
  document.querySelectorAll('.supplier-item-row').forEach(row => {
    const name = row.querySelector('.item-name').value.trim();
    const measurement = row.querySelector('.item-measurement').value.trim();
    const price = row.querySelector('.item-price').value.trim();
    
    if (name && measurement && price) {
      items.push({ name, measurement, price });
    }
  });

  if (items.length === 0) {
    msg.textContent = 'Please add at least one item';
    msg.style.color = '#dc3545';
    msg.style.display = 'block';
    btn.disabled = false;
    btn.textContent = 'Add Supplier';
    return;
  }

  supplierData.items = JSON.stringify(items);

  const formData = new FormData();
  Object.keys(supplierData).forEach(key => formData.append(key, supplierData[key]));

  fetch(getSupplierPath('manage_suppliers.php'), {
    method: 'POST',
    body: formData
  })
    .then(response => response.json())
    .then(data => {
      btn.disabled = false;
      btn.textContent = 'Add Supplier';

      if (data.success) {
        showNotification('Supplier and items added successfully!', 'success');
        closeAddSupplierModal();
        loadSuppliersCards();
      } else {
        msg.textContent = data.error || 'Failed to add supplier';
        msg.style.color = '#dc3545';
        msg.style.display = 'block';
      }
    })
    .catch(error => {
      console.error('Error:', error);
      btn.disabled = false;
      btn.textContent = 'Add Supplier';
      msg.textContent = 'An error occurred';
      msg.style.color = '#dc3545';
      msg.style.display = 'block';
    });
};

window.openEditSupplier = function(supplierId) {
  // Close action menu
  document.querySelectorAll('.action-dropdown').forEach(m => m.style.display = 'none');

  // Fetch supplier data
  fetch('suppliers/suppliers_database.php')
    .then(response => response.json())
    .then(suppliers => {
      const supplier = suppliers.find(s => s.SupplierID == supplierId);
      if (!supplier) {
        showNotification('Supplier not found', 'error');
        return;
      }

      // Populate edit form
      document.getElementById('edit_supplier_id').value = supplier.SupplierID;
      document.getElementById('edit_supplier_name').value = supplier.SupplierName;
      document.getElementById('edit_contact_person').value = supplier.ContactPerson;
      document.getElementById('edit_phone').value = supplier.Phone;
      document.getElementById('edit_email').value = supplier.Email || '';
      document.getElementById('edit_facebook').value = supplier.Facebook || '';
      document.getElementById('edit_supplier_location').value = supplier.Location;
      document.getElementById('edit_supplier_message').textContent = '';

      // Reset to step 1
      document.getElementById('editSupplierForm').style.display = 'block';
      document.getElementById('editSupplierItemsSection').style.display = 'none';
      document.getElementById('edit_supplier_modal_title').textContent = 'Edit Supplier - Step 1';

      // Show modal
      document.getElementById('editSupplierModal').style.display = 'flex';
    })
    .catch(error => {
      console.error('Error fetching supplier:', error);
      showNotification('Failed to load supplier data', 'error');
    });
}

window.goToEditSupplierItems = function(e) {
  if (e) {
    e.preventDefault();
    e.stopPropagation();
  }
  
  // Validate step 1
  const nameEl = document.getElementById('edit_supplier_name');
  const addressEl = document.getElementById('edit_contact_person');
  const phoneEl = document.getElementById('edit_phone');
  const locationEl = document.getElementById('edit_supplier_location');
  const msgEl = document.getElementById('edit_supplier_message');
  
  const name = (nameEl && nameEl.value) ? nameEl.value.trim() : '';
  const address = (addressEl && addressEl.value) ? addressEl.value.trim() : '';
  const phone = (phoneEl && phoneEl.value) ? phoneEl.value.trim() : '';
  const location = (locationEl && locationEl.value) ? locationEl.value.trim() : '';
  
  if (!name || !address || !phone || !location) {
    if (msgEl) {
      msgEl.textContent = 'Please fill in all required fields';
      msgEl.style.color = '#dc3545';
      msgEl.style.display = 'block';
    }
    return false;
  }
  
  if (msgEl) {
    msgEl.textContent = '';
    msgEl.style.display = 'none';
  }
  
  // Expand modal for step 2
  const modalContent = document.getElementById('edit_supplier_modal_content');
  if (modalContent) {
    modalContent.classList.add('expanded');
    modalContent.style.maxWidth = '850px';
    modalContent.style.width = '90%';
  }
  
  // Move to step 2
  const form = document.getElementById('editSupplierForm');
  const itemsSection = document.getElementById('editSupplierItemsSection');
  const title = document.getElementById('edit_supplier_modal_title');
  
  if (form) form.style.display = 'none';
  if (itemsSection) itemsSection.style.display = 'block';
  if (title) title.textContent = 'Edit Supplier - Step 2';
  
  // Load existing items
  loadEditSupplierItems();
  
  return false;
};

window.backToEditSupplierInfo = function() {
  // Shrink modal back to step 1 size
  const modalContent = document.getElementById('edit_supplier_modal_content');
  if (modalContent) {
    modalContent.classList.remove('expanded');
    modalContent.style.maxWidth = '600px';
    modalContent.style.width = '600px';
  }
  
  const itemsSection = document.getElementById('editSupplierItemsSection');
  const form = document.getElementById('editSupplierForm');
  const title = document.getElementById('edit_supplier_modal_title');
  const msg = document.getElementById('edit_supplier_items_message');
  
  if (itemsSection) itemsSection.style.display = 'none';
  if (form) form.style.display = 'block';
  if (title) title.textContent = 'Edit Supplier - Step 1';
  if (msg) msg.textContent = '';
};

function loadEditSupplierItems() {
  const supplierId = document.getElementById('edit_supplier_id').value;
  
  fetch(getSupplierPath(`get_items_by_supplier.php?supplier_id=${supplierId}`))
    .then(r => r.json())
    .then(data => {
      const container = document.getElementById('edit_supplier_items_container');
      container.innerHTML = '';
      
      if (data.success && data.items && data.items.length > 0) {
        data.items.forEach(item => {
          addEditSupplierItemRow(item);
        });
      } else {
        // Add one empty row
        addEditSupplierItemRow();
      }
    })
    .catch(err => {
      console.error('Error loading items:', err);
      addEditSupplierItemRow();
    });
}

window.addEditSupplierItemRow = async function(item = null) {
  const container = document.getElementById('edit_supplier_items_container');
  if (!container) return;
  
  const rowId = item?.SupplierItemID || Date.now();
  const row = document.createElement('div');
  row.className = 'supplier-item-row';
  row.id = 'edit_item_row_' + rowId;
  row.style.cssText = 'display:flex; gap:10px; margin-bottom:12px; align-items:center;';
  
  // Fetch measurements
  let measurementOptions = '';
  try {
    const response = await fetch('suppliers/get_measurements.php');
    const data = await response.json();
    if (data.success && data.measurements) {
      measurementOptions = data.measurements.map(m => 
        `<option value="${m}" ${item?.Measurement === m ? 'selected' : ''}>${m}</option>`
      ).join('');
    }
  } catch (err) {
    console.error('Error fetching measurements:', err);
  }
  
  row.innerHTML = `
    <input type="hidden" class="edit-item-id" value="${item?.SupplierItemID || ''}" />
    <input type="text" class="edit-item-name" placeholder="Item name" value="${item?.ItemName || ''}" style="flex:2.5; padding:10px 12px; border:1px solid #d1d5db; border-radius:6px; font-size:14px;" />
    <select class="edit-item-measurement" style="flex:1; padding:10px 12px; border:1px solid #d1d5db; border-radius:6px; font-size:14px;">
      <option value="">Unit</option>
      ${measurementOptions}
    </select>
    <input type="number" class="edit-item-price" placeholder="Price" value="${item?.Price || ''}" step="0.01" min="0" style="flex:1; padding:10px 12px; border:1px solid #d1d5db; border-radius:6px; font-size:14px;" />
    <button type="button" onclick="removeEditItemRow(${rowId})" style="padding:10px 14px; background:#dc3545; color:white; border:none; border-radius:6px; cursor:pointer; font-weight:500; font-size:16px;">×</button>
  `;
  
  container.appendChild(row);
};

window.removeEditItemRow = function(rowId) {
  const row = document.getElementById('edit_item_row_' + rowId);
  if (row) row.remove();
};

window.submitEditSupplierWithItems = function() {
  const btn = document.getElementById('edit_supplier_submit_btn');
  const msg = document.getElementById('edit_supplier_items_message');
  
  if (!btn || !msg) {
    console.error('Button or message element not found');
    return false;
  }
  
  btn.disabled = true;
  btn.textContent = 'Updating...';
  msg.textContent = '';
  msg.style.display = 'none';

  // Get supplier data with null checks
  const idEl = document.getElementById('edit_supplier_id');
  const nameEl = document.getElementById('edit_supplier_name');
  const contactEl = document.getElementById('edit_contact_person');
  const phoneEl = document.getElementById('edit_phone');
  const emailEl = document.getElementById('edit_email');
  const facebookEl = document.getElementById('edit_facebook');
  const locationEl = document.getElementById('edit_supplier_location');

  if (!idEl || !nameEl || !contactEl || !phoneEl || !locationEl) {
    msg.textContent = 'Form elements not found';
    msg.style.color = '#dc3545';
    msg.style.display = 'block';
    btn.disabled = false;
    btn.textContent = 'Update Supplier';
    return false;
  }

  const supplierData = {
    action: 'edit',
    supplier_id: idEl.value,
    supplier_name: nameEl.value.trim(),
    contact_person: contactEl.value.trim(),
    phone: phoneEl.value.trim(),
    email: emailEl ? emailEl.value.trim() : '',
    facebook: facebookEl ? facebookEl.value.trim() : '',
    location: locationEl.value
  };

  // Get items data
  const items = [];
  document.querySelectorAll('#edit_supplier_items_container .supplier-item-row').forEach(row => {
    const id = row.querySelector('.edit-item-id').value;
    const name = row.querySelector('.edit-item-name').value.trim();
    const measurement = row.querySelector('.edit-item-measurement').value.trim();
    const price = row.querySelector('.edit-item-price').value.trim();
    
    if (name && measurement && price) {
      items.push({ id, name, measurement, price });
    }
  });

  supplierData.items = JSON.stringify(items);

  const formData = new FormData();
  Object.keys(supplierData).forEach(key => formData.append(key, supplierData[key]));

  fetch(getSupplierPath('manage_suppliers.php'), {
    method: 'POST',
    body: formData
  })
    .then(response => response.json())
    .then(data => {
      btn.disabled = false;
      btn.textContent = 'Update Supplier';

      if (data.success) {
        showNotification('Supplier and items updated successfully!', 'success');
        closeEditSupplierModal();
        loadSuppliersCards();
      } else {
        msg.textContent = data.error || 'Failed to update supplier';
        msg.style.color = '#dc3545';
        msg.style.display = 'block';
      }
    })
    .catch(error => {
      console.error('Error:', error);
      btn.disabled = false;
      btn.textContent = 'Update Supplier';
      msg.textContent = 'An error occurred';
      msg.style.color = '#dc3545';
      msg.style.display = 'block';
    });
};

window.closeEditSupplierModal = function() {
  const modal = document.getElementById('editSupplierModal');
  if (modal) {
    modal.style.display = 'none';
    
    // Reset to step 1
    document.getElementById('editSupplierForm').style.display = 'block';
    document.getElementById('editSupplierItemsSection').style.display = 'none';
    document.getElementById('edit_supplier_modal_title').textContent = 'Edit Supplier - Step 1';
    document.getElementById('edit_supplier_message').textContent = '';
    document.getElementById('edit_supplier_items_message').textContent = '';
    document.getElementById('edit_supplier_items_container').innerHTML = '';
    
    // Reset modal width
    const modalContent = document.getElementById('edit_supplier_modal_content');
    if (modalContent) {
      modalContent.classList.remove('expanded');
      modalContent.style.maxWidth = '600px';
      modalContent.style.width = '';
    }
  }
};

// Delete supplier with confirmation
window.deleteSupplier = function(supplierId, supplierName) {
  // Close action menu
  document.querySelectorAll('.action-dropdown').forEach(m => m.style.display = 'none');
  
  // Open delete modal
  openDeleteSupplierModal(supplierId, supplierName);
};

window.openDeleteSupplierModal = function(supplierId, supplierName) {
  // Set delete data
  document.getElementById('delete_supplier_id').value = supplierId;
  document.getElementById('delete_supplier_display').textContent = supplierName;
  document.getElementById('delete_supplier_password').value = '';
  document.getElementById('delete_supplier_message').textContent = '';

  // Show modal
  document.getElementById('deleteSupplierModal').style.display = 'flex';
};

window.closeDeleteSupplierModal = function() {
  const modal = document.getElementById('deleteSupplierModal');
  if (modal) modal.style.display = 'none';
  document.getElementById('delete_supplier_password').value = '';
  document.getElementById('delete_supplier_message').textContent = '';
};

window.submitDeleteSupplier = function() {
  const btn = document.getElementById('delete_supplier_btn');
  const msg = document.getElementById('delete_supplier_message');
  const password = document.getElementById('delete_supplier_password').value;
  const supplierId = document.getElementById('delete_supplier_id').value;
  
  if (!password) {
    msg.textContent = 'Please enter your password';
    msg.style.color = '#dc3545';
    return;
  }
  
  btn.disabled = true;
  btn.textContent = 'Deleting...';
  msg.textContent = '';
  
  const formData = new FormData();
  formData.append('action', 'delete');
  formData.append('supplier_id', supplierId);
  formData.append('password', password);

  fetch(getSupplierPath('manage_suppliers.php'), {
    method: 'POST',
    body: formData
  })
    .then(response => {
      return response.text().then(text => {
        try {
          return JSON.parse(text);
        } catch (e) {
          console.error('JSON parse error:', e);
          throw new Error('Invalid JSON response: ' + text);
        }
      });
    })
    .then(data => {
      btn.disabled = false;
      btn.textContent = 'Delete Supplier';
      
      if (data.success) {
        showNotification('Supplier deleted successfully!', 'success');
        closeDeleteSupplierModal();
        loadSuppliersCards();
      } else {
        msg.textContent = data.error || 'Failed to delete supplier';
        msg.style.color = '#dc3545';
      }
    })
    .catch(error => {
      console.error('Delete error:', error);
      btn.disabled = false;
      btn.textContent = 'Delete Supplier';
      msg.textContent = 'An error occurred: ' + error.message;
      msg.style.color = '#dc3545';
    });
};

// Setup form handlers
function setupSupplierForms() {
  // Note: Add Supplier now uses goToSupplierItems() and submitSupplierWithItems() functions
  // No form submit handler needed for Add Supplier

  // Edit Supplier Form
  const editForm = document.getElementById('editSupplierForm');
  if (editForm) {
    editForm.addEventListener('submit', function(e) {
      e.preventDefault();
      const btn = document.getElementById('edit_supplier_btn');
      const msg = document.getElementById('edit_supplier_message');
      
      btn.disabled = true;
      btn.textContent = 'Updating...';
      msg.textContent = '';

      const formData = new FormData(editForm);
      formData.append('action', 'edit');

      fetch(getSupplierPath('manage_suppliers.php'), {
        method: 'POST',
        body: formData
      })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          showNotification(data.message, 'success');
          closeEditSupplierModal();
          loadSuppliersCards();
        } else {
          msg.textContent = data.message;
          msg.style.color = '#dc3545';
        }
      })
      .catch(error => {
        console.error('Error updating supplier:', error);
        msg.textContent = 'An error occurred. Please try again.';
        msg.style.color = '#dc3545';
      })
      .finally(() => {
        btn.disabled = false;
        btn.textContent = 'Update Supplier';
      });
    });
  }

  // Delete Supplier Form
  const deleteForm = document.getElementById('deleteSupplierForm');
  if (deleteForm) {
    deleteForm.addEventListener('submit', function(e) {
      e.preventDefault();
      const btn = document.getElementById('delete_supplier_btn');
      const msg = document.getElementById('delete_supplier_message');
      
      btn.disabled = true;
      btn.textContent = 'Deleting...';
      msg.textContent = '';

      const formData = new FormData(deleteForm);
      formData.append('action', 'delete');

      fetch(getSupplierPath('manage_suppliers.php'), {
        method: 'POST',
        body: formData
      })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          showNotification(data.message, 'success');
          closeDeleteSupplierModal();
          loadSuppliersCards();
        } else {
          msg.textContent = data.message;
          msg.style.color = '#dc3545';
        }
      })
      .catch(error => {
        console.error('Error deleting supplier:', error);
        msg.textContent = 'An error occurred. Please try again.';
        msg.style.color = '#dc3545';
      })
      .finally(() => {
        btn.disabled = false;
        btn.textContent = 'Delete Supplier';
      });
    });
  }
}

// Notification helper
function showNotification(message, type) {
  const notification = document.createElement('div');
  notification.className = 'centered-notification';
  notification.textContent = message;
  notification.style.background = type === 'success' ? '#4CAF50' : '#dc3545';
  notification.style.color = '#fff';
  notification.style.padding = '16px 24px';
  notification.style.borderRadius = '8px';
  notification.style.position = 'fixed';
  notification.style.top = '50%';
  notification.style.left = '50%';
  notification.style.transform = 'translate(-50%, -50%)';
  notification.style.zIndex = '99999';
  notification.style.fontSize = '14px';
  notification.style.fontWeight = '600';
  notification.style.boxShadow = '0 4px 12px rgba(0,0,0,0.3)';
  notification.style.animation = 'fadeIn 0.3s ease';

  document.body.appendChild(notification);

  setTimeout(() => {
    notification.style.animation = 'fadeOut 0.3s ease';
    setTimeout(() => notification.remove(), 300);
  }, 2000);
}

// Escape HTML helper
function escapeHtml(text) {
  if (!text) return '';
  const map = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;'
  };
  return text.toString().replace(/[&<>"']/g, m => map[m]);
}

// Button handlers for View Orders and New Order
window.viewSupplierOrders = function(supplierId) {
  // Open a modal listing orders for this supplier (no redirect)
  const modal = document.getElementById('supplierOrdersModal');
  const tbody = document.getElementById('supplier_orders_tbody');
  const title = document.getElementById('supplier_orders_title');
  if (!modal || !tbody) return;

  // Set title (fetch supplier name for display only)
  fetch(getOrderPath('get_suppliers.php'))
    .then(r => r.json())
    .then(d => {
      let name = 'Supplier';
      if (d.success && Array.isArray(d.suppliers)) {
        const f = d.suppliers.find(s => s.SupplierID == supplierId);
        if (f) name = f.SupplierName;
      }
      if (title) title.textContent = `Orders for ${name}`;
    })
    .catch(() => {});

  // Load orders filtered by supplier using existing endpoint
  const fd = new FormData();
  fd.append('supplier_id', supplierId);
  fetch(getOrderPath('orders_database.php'), { method: 'POST', body: fd })
    .then(r => r.text())
    .then(html => { tbody.innerHTML = html; })
    .catch(() => { tbody.innerHTML = '<tr><td colspan="7" style="color:#c00; padding:16px; text-align:center;">Failed to load orders.</td></tr>'; });

  modal.style.display = 'flex';
};

window.newSupplierOrder = function(supplierId) {
  // Open the supplier-specific Create Order modal
  fetch(getOrderPath('get_suppliers.php'))
    .then(r => r.json())
    .then(d => {
      let supplierName = 'Supplier';
      if (d.success && Array.isArray(d.suppliers)) {
        const found = d.suppliers.find(s => s.SupplierID == supplierId);
        if (found) supplierName = found.SupplierName;
      }
      
      // Set the supplier info in the modal
      const nameInput = document.getElementById('supplier_order_supplier_name');
      const idInput = document.getElementById('supplier_order_supplier_id');
      if (nameInput) nameInput.value = supplierName;
      if (idInput) idInput.value = supplierId;
      
      // Load supplier items
      loadSupplierOrderItems(supplierId);
      
      // Show the modal
      const modal = document.getElementById('supplierCreateOrderModal');
      if (modal) modal.style.display = 'flex';
    })
    .catch(() => showNotification('Failed to load supplier', 'error'));
}

window.closeSupplierCreateOrderModal = function() {
  const modal = document.getElementById('supplierCreateOrderModal');
  if (modal) {
    modal.style.display = 'none';
    const container = document.getElementById('supplier_order_items_container');
    if (container) container.innerHTML = '';
  }
};

let supplierOrderItems = [];

function loadSupplierOrderItems(supplierId) {
  // Clear existing rows
  const container = document.getElementById('supplier_order_items_container');
  if (container) container.innerHTML = '';
  
  fetch(getOrderPath('get_items_by_supplier.php?supplier_id=' + supplierId))
    .then(r => r.json())
    .then(data => {
      supplierOrderItems = data.success ? data.items : [];
      if (supplierOrderItems.length > 0) {
        addSupplierOrderItemRow(); // Add first row with loaded items
      } else {
        showNotification('No items found for this supplier', 'warning');
      }
    })
    .catch(() => showNotification('Failed to load items', 'error'));
}

window.addSupplierOrderItemRow = function() {
  const container = document.getElementById('supplier_order_items_container');
  if (!container) return;
  
  const rowId = Date.now();
  const row = document.createElement('div');
  row.className = 'order-item-row';
  row.id = 'supplier_order_row_' + rowId;
  row.style.cssText = 'display:grid; grid-template-columns:4fr 0.6fr 0.6fr 40px; gap:8px; margin-bottom:10px; align-items:center; padding:12px; background:#f9fafb; border-radius:6px; border:1px solid #e5e7eb;';
  
  let itemOptions = '<option value="">Select item</option>';
  supplierOrderItems.forEach(item => {
    itemOptions += `<option value="${item.SupplierItemID}" data-unit="${item.Measurement}" data-price="${item.Price}">${item.ItemName} (${item.Measurement})</option>`;
  });
  
  row.innerHTML = `
    <select class="supplier-order-item-select input-select" onchange="updateSupplierOrderPrice(${rowId})" style="padding:9px 12px; border:1px solid #d1d5db; border-radius:6px; font-size:13px; background:white;">
      ${itemOptions}
    </select>
    <input type="text" class="supplier-order-price input-select" readonly style="padding:9px 8px; background:#f3f4f6; border:1px solid #d1d5db; border-radius:6px; font-size:13px; cursor:not-allowed; color:#6b7280; text-align:center;" placeholder="Price" />
    <input type="number" class="supplier-order-qty input-select" placeholder="Qty" min="1" value="1" style="padding:9px 8px; border:1px solid #d1d5db; border-radius:6px; font-size:13px; background:white; text-align:center;" />
    <button type="button" class="delete-row-btn" onclick="removeSupplierOrderRow(${rowId})" style="background:#ef4444; color:white; border:none; border-radius:6px; width:40px; height:40px; cursor:pointer; font-size:18px; font-weight:300; transition:background 0.2s; display:flex; align-items:center; justify-content:center; flex-shrink:0;">&times;</button>
  `;
  
  container.appendChild(row);
};

window.updateSupplierOrderPrice = function(rowId) {
  const row = document.getElementById('supplier_order_row_' + rowId);
  if (!row) return;
  
  const select = row.querySelector('.supplier-order-item-select');
  const priceInput = row.querySelector('.supplier-order-price');
  
  if (select && priceInput) {
    const selectedOption = select.options[select.selectedIndex];
    const price = selectedOption.getAttribute('data-price') || '';
    priceInput.value = price ? '₱' + parseFloat(price).toFixed(2) : '';
  }
};

window.removeSupplierOrderRow = function(rowId) {
  const row = document.getElementById('supplier_order_row_' + rowId);
  if (row) row.remove();
};

window.submitSupplierOrder = function() {
  const btn = document.getElementById('supplier_create_order_btn');
  const supplierId = document.getElementById('supplier_order_supplier_id').value;
  
  if (!supplierId) {
    showNotification('Supplier not selected', 'error');
    return;
  }
  
  // Collect items
  const items = [];
  const rows = document.querySelectorAll('#supplier_order_items_container .order-item-row');
  
  if (rows.length === 0) {
    showNotification('Please add at least one item', 'error');
    return;
  }
  
  rows.forEach(row => {
    const itemSelect = row.querySelector('.supplier-order-item-select');
    const qtyInput = row.querySelector('.supplier-order-qty');
    
    if (itemSelect && qtyInput) {
      const itemValue = itemSelect.value ? itemSelect.value.trim() : '';
      const qtyValue = qtyInput.value ? parseInt(qtyInput.value) : 0;
      
      if (itemValue && qtyValue > 0) {
        items.push({
          supplier_item_id: itemValue,
          quantity: qtyValue
        });
      }
    }
  });
  
  if (items.length === 0) {
    showNotification('Please select items and enter quantities', 'error');
    return;
  }
  
  btn.disabled = true;
  btn.textContent = 'Creating...';
  
  // API call to create order
  const formData = new FormData();
  formData.append('supplier_id', supplierId);
  formData.append('items', JSON.stringify(items));
  
  console.log('Sending to server - supplier_id:', supplierId, 'items:', JSON.stringify(items));
  
  fetch(getOrderPath('submit_order.php'), {
    method: 'POST',
    body: formData
  })
  .then(response => response.json())
  .then(data => {
    console.log('Response from server:', data);
    if (data.success) {
      showNotification('Order created successfully', 'success');
      closeSupplierCreateOrderModal();
      // Optionally reload orders if on orders page
      if (typeof loadOrdersTable === 'function') {
        loadOrdersTable();
      }
    } else {
      showNotification(data.error || 'Failed to create order', 'error');
    }
  })
  .catch(error => {
    console.error('Error:', error);
    showNotification('Failed to create order', 'error');
  })
  .finally(() => {
    btn.disabled = false;
    btn.textContent = 'Create Order';
  });
}

// View Supplier Items (Admin feature)
function viewSupplierItems(supplierId, supplierName) {
  const modal = document.getElementById('viewSupplierItemsModal');
  if (!modal) return;
  
  // Set supplier name
  document.getElementById('supplier_name_display').textContent = supplierName;
  
  // Show loading state
  const tbody = document.getElementById('supplier_items_tbody');
  const noItemsMsg = document.getElementById('no_items_message');
  tbody.innerHTML = '<tr><td colspan="3" style="text-align:center;color:#6b7280;padding:24px;">Loading items...</td></tr>';
  noItemsMsg.style.display = 'none';
  
  // Open modal
  modal.style.display = 'flex';
  
  // Fetch items
  fetch(getSupplierPath(`get_items_by_supplier.php?supplier_id=${supplierId}`))
    .then(response => response.json())
    .then(data => {
      if (data.success && data.items && data.items.length > 0) {
        document.getElementById('supplier_items_count').textContent = data.count || data.items.length;
        
        tbody.innerHTML = data.items.map(item => `
          <tr style="border-bottom: 1px solid #e5e7eb;">
            <td style="padding: 12px; color: #111827;">${escapeHtml(item.ItemName)}</td>
            <td style="padding: 12px; color: #6b7280;">${escapeHtml(item.Measurement)}</td>
            <td style="padding: 12px; text-align: right; color: #111827; font-weight: 500;">₱${parseFloat(item.Price).toFixed(2)}</td>
          </tr>
        `).join('');
      } else {
        document.getElementById('supplier_items_count').textContent = '0';
        tbody.innerHTML = '';
        noItemsMsg.style.display = 'block';
      }
    })
    .catch(error => {
      console.error('Error loading items:', error);
      tbody.innerHTML = '<tr><td colspan="3" style="text-align:center;color:#dc3545;padding:24px;">Failed to load items</td></tr>';
    });
}

// Close Supplier Items Modal
function closeSupplierItemsModal() {
  const modal = document.getElementById('viewSupplierItemsModal');
  if (modal) {
    modal.style.display = 'none';
  }
}
  
  const formData = new FormData();
  formData.append('action', 'create');
  formData.append('supplier_id', supplierId);
  formData.append('items', JSON.stringify(items));
  
  fetch(getOrderPath('submit_order.php'), {
    method: 'POST',
    body: formData
  })
    .then(r => r.json())
    .then(data => {
      btn.disabled = false;
      btn.textContent = 'Create Order';
      
      if (data.success) {
        showNotification('Order created successfully!', 'success');
        closeSupplierCreateOrderModal();
        // Refresh orders if on orders page
        if (typeof loadOrders === 'function') loadOrders();
      } else {
        showNotification(data.error || 'Failed to create order', 'error');
      }
    })
    .catch(() => {
      btn.disabled = false;
      btn.textContent = 'Create Order';
      showNotification('An error occurred', 'error');
    });
};

window.closeSupplierOrdersModal = function() {
  const modal = document.getElementById('supplierOrdersModal');
  if (modal) modal.style.display = 'none';
};
