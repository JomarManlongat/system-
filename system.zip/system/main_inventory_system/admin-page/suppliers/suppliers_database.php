<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
session_name('INVENTORY_SESSION');
session_start();
require(__DIR__ . "/../../login/database-account.php");

// Check connection
if (!$conn) {
    header('Content-Type: application/json');
    echo json_encode([]);
    exit;
}

$search = $_GET['search'] ?? '';

try {
    if (!empty($search)) {
        $query = "SELECT * FROM suppliers 
                  WHERE SupplierName LIKE ? OR Location LIKE ? OR address LIKE ?
                  ORDER BY SupplierName ASC";
        $stmt = $conn->prepare($query);
        $searchParam = "%$search%";
        $stmt->bind_param("sss", $searchParam, $searchParam, $searchParam);
        $stmt->execute();
        $result = $stmt->get_result();
    } else {
        $query = "SELECT * FROM suppliers ORDER BY SupplierName ASC";
        $result = $conn->query($query);
    }

    if (!$result) {
        header('Content-Type: application/json');
        echo json_encode(['error' => $conn->error]);
        exit;
    }

    $suppliers = [];
    while ($row = $result->fetch_assoc()) {
        // Map your database columns to what the frontend expects
        $suppliers[] = [
            'SupplierID' => $row['SupplierID'],
            'SupplierName' => $row['SupplierName'],
            'ContactPerson' => $row['address'],
            'Phone' => $row['contact_no'],
            'Email' => $row['gmail'] ?? '',
            'Facebook' => $row['facebookpage'] ?? '',
            'Location' => $row['Location']
        ];
    }

    // Return as JSON for JavaScript to render
    header('Content-Type: application/json');
    echo json_encode($suppliers);
} catch (Exception $e) {
    header('Content-Type: application/json');
    echo json_encode([]);
}
exit;
