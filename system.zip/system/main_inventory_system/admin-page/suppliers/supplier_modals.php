<!-- Add Supplier Modal -->
<div id="addSupplierModal" class="modal" style="display:none;">
  <div class="modal-content" id="add_supplier_modal_content" style="max-width: 600px;">
    <div class="modal-header">
      <h3 id="add_supplier_modal_title">Add New Supplier - Step 1</h3>
      <span class="close" onclick="closeAddSupplierModal()">&times;</span>
    </div>

    <!-- Step 1: Supplier Basic Info -->
    <div id="addSupplierForm" class="user-form" style="display:block;">
      <label for="add_supplier_name">Supplier Name</label>
      <input type="text" id="add_supplier_name" name="supplier_name" required />

      <label for="add_contact_person">Address</label>
      <input type="text" id="add_contact_person" name="contact_person" required />

      <label for="add_phone">Contact Number</label>
      <input type="text" id="add_phone" name="phone" required />

      <label for="add_email">Email</label>
      <input type="text" id="add_email" name="email" />

      <label for="add_facebook">Facebook</label>
      <input type="text" id="add_facebook" name="facebook" placeholder="Facebook page or profile" />

      <label for="add_supplier_location">Location</label>
      <select id="add_supplier_location" name="location" required>
        <option value="">Select location</option>
        <option value="Restaurant">Restaurant</option>
        <option value="Room">Room</option>
      </select>

      <div id="add_supplier_message" class="user_message"></div>

      <div class="modal-actions">
        <button type="button" class="cancel-btn" onclick="closeAddSupplierModal()">Cancel</button>
        <button type="button" class="save-btn" id="add_supplier_next_btn" onclick="window.goToSupplierItems()">Next: Add Items</button>
      </div>
    </div>

    <!-- Step 2: Supplier Items -->
    <div id="addSupplierItemsSection" style="display:none;">
      <p style="margin:0 0 20px 0;color:#555;font-size:15px;">Add products that this supplier offers:</p>
      
      <div id="supplier_items_container">
        <!-- Item rows will be added here -->
      </div>

      <button type="button" class="white-btn" onclick="addSupplierItemRow()" style="margin-bottom:20px;width:100%;padding:12px;">+ Add Item</button>

      <div id="add_supplier_items_message" class="user_message"></div>

      <div class="modal-actions">
        <button type="button" class="cancel-btn" onclick="backToSupplierInfo()">Back</button>
        <button type="button" class="save-btn" id="add_supplier_submit_btn" onclick="window.submitSupplierWithItems()">Add Supplier</button>
      </div>
    </div>
  </div>
</div>

<!-- Supplier Orders Modal -->
<div id="supplierOrdersModal" class="modal" style="display:none;">
  <div class="modal-content" style="max-width: 1200px; width: 95%;">
    <div class="modal-header">
      <h3 id="supplier_orders_title">Supplier Orders</h3>
      <span class="close" onclick="closeSupplierOrdersModal()">&times;</span>
    </div>

    <div class="inventory_table" style="margin-left:0; width:100%;">
      <table>
        <thead>
          <tr>
            <th>Order ID</th>
            <th>Supplier</th>
            <th>Location</th>
            <th>Items</th>
            <th>Total</th>
            <th>Status</th>
            <th>Date</th>
            <th style="text-align:center; width:100px;">Actions</th>
          </tr>
        </thead>
        <tbody id="supplier_orders_tbody">
          <tr><td colspan="8" style="text-align:center;color:#666;padding:16px">Loading...</td></tr>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Edit Supplier Modal -->
<div id="editSupplierModal" class="modal" style="display:none;">
  <div class="modal-content" id="edit_supplier_modal_content" style="max-width: 600px;">
    <div class="modal-header">
      <h3 id="edit_supplier_modal_title">Edit Supplier - Step 1</h3>
      <span class="close" onclick="closeEditSupplierModal()">&times;</span>
    </div>

    <!-- Step 1: Supplier Basic Info -->
    <div id="editSupplierForm" class="user-form" style="display:block;">
      <input type="hidden" id="edit_supplier_id" name="supplier_id" />

      <label for="edit_supplier_name">Supplier Name</label>
      <input type="text" id="edit_supplier_name" name="supplier_name" required />

      <label for="edit_contact_person">Address</label>
      <input type="text" id="edit_contact_person" name="contact_person" required />

      <label for="edit_phone">Contact Number</label>
      <input type="text" id="edit_phone" name="phone" required />

      <label for="edit_email">Email</label>
      <input type="text" id="edit_email" name="email" />

      <label for="edit_facebook">Facebook</label>
      <input type="text" id="edit_facebook" name="facebook" placeholder="Facebook page or profile" />

      <label for="edit_supplier_location">Location</label>
      <select id="edit_supplier_location" name="location" required>
        <option value="">Select location</option>
        <option value="Restaurant">Restaurant</option>
        <option value="Room">Room</option>
      </select>

      <div id="edit_supplier_message" class="user_message"></div>

      <div class="modal-actions">
        <button type="button" class="cancel-btn" onclick="closeEditSupplierModal()">Cancel</button>
        <button type="button" class="save-btn" id="edit_supplier_next_btn" onclick="window.goToEditSupplierItems()">Next: Edit Items</button>
      </div>
    </div>

    <!-- Step 2: Supplier Items -->
    <div id="editSupplierItemsSection" style="display:none;">
      <p style="margin:0 0 20px 0;color:#555;font-size:15px;">Edit products from this supplier:</p>
      
      <div id="edit_supplier_items_container" style="max-height:300px; overflow-y:auto; margin-bottom:12px;">
        <!-- Item rows will be loaded here -->
      </div>

      <button type="button" class="white-btn" onclick="addEditSupplierItemRow()" style="margin-bottom:20px;width:100%;padding:12px;">+ Add Item</button>

      <div id="edit_supplier_items_message" class="user_message"></div>

      <div class="modal-actions">
        <button type="button" class="cancel-btn" onclick="backToEditSupplierInfo()">Back</button>
        <button type="button" class="save-btn" id="edit_supplier_submit_btn" onclick="window.submitEditSupplierWithItems()">Update Supplier</button>
      </div>
    </div>
  </div>
</div>

<!-- Delete Supplier Confirmation Modal -->
<div id="deleteSupplierModal" class="modal" style="display:none;">
  <div class="modal-content" style="max-width: 500px; border-radius: 12px;">
    <div class="modal-header" style="border-bottom: 2px solid #f0f0f0; padding-bottom: 16px;">
      <h3 style="color: #dc3545; margin: 0; font-size: 20px;"> Delete Supplier</h3>
      <span class="close" onclick="closeDeleteSupplierModal()" style="font-size: 28px; color: #999;">&times;</span>
    </div>

    <div class="user-form" style="padding: 24px 0;">
      <input type="hidden" id="delete_supplier_id" name="supplier_id" />
      
      <div style="background: #fff3cd; border-left: 4px solid #ffc107; padding: 16px; margin-bottom: 20px; border-radius: 6px;">
        <p style="margin: 0 0 8px 0; color: #856404; font-size: 14px; font-weight: 600;">
          You are about to delete:
        </p>
        <p style="margin: 0; color: #333; font-size: 16px; font-weight: 700;" id="delete_supplier_display"></p>
      </div>
      
      <div style="background: #f8d7da; border-left: 4px solid #dc3545; padding: 16px; margin-bottom: 24px; border-radius: 6px;">
        <p style="margin: 0; color: #721c24; font-size: 13px; font-weight: 600; line-height: 1.5;">
           This will permanently delete:
        </p>
        <ul style="margin: 8px 0 0 0; padding-left: 20px; color: #721c24; font-size: 13px;">
          <li>The supplier record</li>
          <li>All products from this supplier</li>
          <li>All inventory items from this supplier</li>
        </ul>
        <p style="margin: 8px 0 0 0; color: #721c24; font-size: 13px; font-weight: 700;">
          This action cannot be undone!
        </p>
      </div>

      <label for="delete_supplier_password" style="display: block; margin-bottom: 8px; font-weight: 600; color: #333;">Enter your password to confirm</label>
      <input type="password" id="delete_supplier_password" name="password" placeholder="Your password" required style="width: 100%; padding: 12px; border: 2px solid #ddd; border-radius: 6px; font-size: 14px;" />

      <div id="delete_supplier_message" class="user_message" style="margin-top: 12px;"></div>

      <div class="modal-actions" style="margin-top: 24px; display: flex; gap: 12px;">
        <button type="button" class="cancel-btn" onclick="closeDeleteSupplierModal()" style="flex: 1; padding: 12px; font-size: 15px; border-radius: 6px;">Cancel</button>
        <button type="button" class="delete-btn" id="delete_supplier_btn" onclick="submitDeleteSupplier()" style="flex: 1; padding: 12px; font-size: 15px; font-weight: 600; border-radius: 6px;">Delete Supplier</button>
      </div>
    </div>
  </div>
</div>
