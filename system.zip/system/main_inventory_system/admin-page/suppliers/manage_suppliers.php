<?php
session_name('INVENTORY_SESSION');
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../../login/database-account.php';

$action = $_POST['action'] ?? '';

// Add Supplier
if ($action === 'add') {
    $supplier_name = trim($_POST['supplier_name'] ?? '');
    $contact_person = trim($_POST['contact_person'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $facebook = trim($_POST['facebook'] ?? '');
    $location = trim($_POST['location'] ?? '');
    $items_json = trim($_POST['items'] ?? '');

    if (empty($supplier_name) || empty($contact_person) || empty($phone) || empty($location)) {
        echo json_encode(['success' => false, 'error' => 'Supplier Name, Address, Phone, and Location are required']);
        exit;
    }

    // Check if supplier name already exists
    $check = $conn->prepare("SELECT SupplierID FROM suppliers WHERE SupplierName = ?");
    $check->bind_param('s', $supplier_name);
    $check->execute();
    if ($check->get_result()->num_rows > 0) {
        echo json_encode(['success' => false, 'error' => 'Supplier name already exists']);
        exit;
    }

    // Start transaction
    $conn->begin_transaction();
    
    try {
        // Insert supplier
        $stmt = $conn->prepare("INSERT INTO suppliers (SupplierName, address, contact_no, gmail, facebookpage, Location) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param('ssssss', $supplier_name, $contact_person, $phone, $email, $facebook, $location);
        
        if (!$stmt->execute()) {
            throw new Exception('Failed to add supplier: ' . $conn->error);
        }
        
        $supplier_id = $conn->insert_id;
        
        // Insert supplier items if provided
        if (!empty($items_json)) {
            $items = json_decode($items_json, true);
            if (is_array($items) && count($items) > 0) {
                $item_stmt = $conn->prepare("INSERT INTO supplieritems (SupplierID, ItemName, Measurement, Price, InitialStock, DefaultMinimumStock) VALUES (?, ?, ?, ?, 0, 0)");
                
                foreach ($items as $item) {
                    $item_name = trim($item['name'] ?? '');
                    $measurement = trim($item['measurement'] ?? '');
                    $price = floatval($item['price'] ?? 0);
                    
                    if (!empty($item_name) && !empty($measurement)) {
                        $item_stmt->bind_param('issd', $supplier_id, $item_name, $measurement, $price);
                        if (!$item_stmt->execute()) {
                            throw new Exception('Failed to add item: ' . $item_name . ' - ' . $item_stmt->error);
                        }
                    }
                }
                $item_stmt->close();
            }
        }
        
        $conn->commit();
        echo json_encode(['success' => true, 'message' => 'Supplier and items added successfully']);
        
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    
    exit;
}

// Edit Supplier
if ($action === 'edit') {
    $supplier_id = trim($_POST['supplier_id'] ?? '');
    $supplier_name = trim($_POST['supplier_name'] ?? '');
    $contact_person = trim($_POST['contact_person'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $facebook = trim($_POST['facebook'] ?? '');
    $location = trim($_POST['location'] ?? '');
    $items_json = trim($_POST['items'] ?? '');

    if (empty($supplier_id) || empty($supplier_name) || empty($contact_person) || empty($phone) || empty($location)) {
        echo json_encode(['success' => false, 'error' => 'All required fields must be filled']);
        exit;
    }

    // Check if supplier name is taken by another supplier
    $check = $conn->prepare("SELECT SupplierID FROM suppliers WHERE SupplierName = ? AND SupplierID != ?");
    $check->bind_param('ss', $supplier_name, $supplier_id);
    $check->execute();
    if ($check->get_result()->num_rows > 0) {
        echo json_encode(['success' => false, 'error' => 'Supplier name already exists']);
        exit;
    }

    // Start transaction
    $conn->begin_transaction();
    
    try {
        // Update supplier
        $stmt = $conn->prepare("UPDATE suppliers SET SupplierName = ?, address = ?, contact_no = ?, gmail = ?, facebookpage = ?, Location = ? WHERE SupplierID = ?");
        $stmt->bind_param('sssssss', $supplier_name, $contact_person, $phone, $email, $facebook, $location, $supplier_id);
        
        if (!$stmt->execute()) {
            throw new Exception('Failed to update supplier: ' . $conn->error);
        }
        
        // Update supplier items if provided
        if (!empty($items_json)) {
            $items = json_decode($items_json, true);
            if (is_array($items)) {
                // Get existing item IDs
                $existing_ids = [];
                foreach ($items as $item) {
                    if (!empty($item['id'])) {
                        $existing_ids[] = intval($item['id']);
                    }
                }
                
                // Update or insert items
                foreach ($items as $item) {
                    $item_name = trim($item['name'] ?? '');
                    $measurement = trim($item['measurement'] ?? '');
                    $price = floatval($item['price'] ?? 0);
                    $item_id = !empty($item['id']) ? intval($item['id']) : null;
                    
                    if (!empty($item_name) && !empty($measurement)) {
                        if ($item_id) {
                            // Update existing item
                            $update_stmt = $conn->prepare("UPDATE supplieritems SET ItemName = ?, Measurement = ?, Price = ? WHERE SupplierItemID = ? AND SupplierID = ?");
                            $update_stmt->bind_param('ssdii', $item_name, $measurement, $price, $item_id, $supplier_id);
                            if (!$update_stmt->execute()) {
                                throw new Exception('Failed to update item: ' . $item_name);
                            }
                            $update_stmt->close();
                        } else {
                            // Insert new item
                            $insert_stmt = $conn->prepare("INSERT INTO supplieritems (SupplierID, ItemName, Measurement, Price, InitialStock, DefaultMinimumStock) VALUES (?, ?, ?, ?, 0, 0)");
                            $insert_stmt->bind_param('issd', $supplier_id, $item_name, $measurement, $price);
                            if (!$insert_stmt->execute()) {
                                throw new Exception('Failed to add item: ' . $item_name);
                            }
                            $insert_stmt->close();
                        }
                    }
                }
                
                // Delete items that are no longer in the list (only if they're not referenced)
                if (count($existing_ids) > 0) {
                    $placeholders = implode(',', array_fill(0, count($existing_ids), '?'));
                    $delete_stmt = $conn->prepare("DELETE FROM supplieritems WHERE SupplierID = ? AND SupplierItemID NOT IN ($placeholders) AND SupplierItemID NOT IN (SELECT DISTINCT SupplierItemID FROM items WHERE SupplierItemID IS NOT NULL)");
                    $types = 'i' . str_repeat('i', count($existing_ids));
                    $params = array_merge([$supplier_id], $existing_ids);
                    $delete_stmt->bind_param($types, ...$params);
                    $delete_stmt->execute();
                    $delete_stmt->close();
                }
            }
        }
        
        $conn->commit();
        echo json_encode(['success' => true, 'message' => 'Supplier and items updated successfully']);
        
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    
    exit;
}

// Delete Supplier
if ($action === 'delete') {
    $supplier_id = trim($_POST['supplier_id'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $current_user_id = $_SESSION['UserID'] ?? '';

    // Debug logging
    error_log('Delete supplier request - UserID: ' . $current_user_id . ', SupplierID: ' . $supplier_id);

    if (empty($supplier_id)) {
        echo json_encode(['success' => false, 'error' => 'Supplier ID is required', 'debug' => 'supplier_id empty']);
        exit;
    }

    if (empty($password)) {
        echo json_encode(['success' => false, 'error' => 'Password is required', 'debug' => 'password empty']);
        exit;
    }

    if (empty($current_user_id)) {
        echo json_encode(['success' => false, 'error' => 'You must be logged in', 'debug' => 'user not logged in']);
        exit;
    }

    // Verify the current user's password
    $verify_stmt = $conn->prepare("SELECT Password FROM users WHERE UserID = ?");
    $verify_stmt->bind_param('s', $current_user_id);
    $verify_stmt->execute();
    $result = $verify_stmt->get_result();
    
    if ($result->num_rows === 0) {
        echo json_encode(['success' => false, 'error' => 'Current user not found', 'debug' => ['user_id' => $current_user_id]]);
        exit;
    }
    
    $user_data = $result->fetch_assoc();
    
    // Check if password is hashed or plain text
    $stored_password = $user_data['Password'];
    $password_matches = false;
    
    if (substr($stored_password, 0, 4) === '$2y$' || substr($stored_password, 0, 4) === '$2a$') {
        // Password is hashed, use password_verify
        $password_matches = password_verify($password, $stored_password);
    } else {
        // Password is plain text, use direct comparison
        $password_matches = ($password === $stored_password);
    }
    
    if (!$password_matches) {
        echo json_encode(['success' => false, 'error' => 'Incorrect password', 'debug' => 'password verification failed']);
        exit;
    }

    // Password verified, proceed with deletion
    // Start transaction to delete in correct order: items -> supplieritems -> supplier
    $conn->begin_transaction();
    
    try {
        // Step 1: Delete all items that reference supplieritems of this supplier
        $delete_items_sql = "DELETE items FROM items 
                            INNER JOIN supplieritems ON items.SupplierItemID = supplieritems.SupplierItemID 
                            WHERE supplieritems.SupplierID = ?";
        $delete_items_stmt = $conn->prepare($delete_items_sql);
        $delete_items_stmt->bind_param('i', $supplier_id);
        $delete_items_stmt->execute();
        $items_deleted = $delete_items_stmt->affected_rows;
        
        // Step 2: Delete all supplieritems associated with this supplier
        $delete_supplieritems_stmt = $conn->prepare("DELETE FROM supplieritems WHERE SupplierID = ?");
        $delete_supplieritems_stmt->bind_param('i', $supplier_id);
        $delete_supplieritems_stmt->execute();
        $supplieritems_deleted = $delete_supplieritems_stmt->affected_rows;
        
        // Step 3: Delete the supplier
        $delete_supplier_stmt = $conn->prepare("DELETE FROM suppliers WHERE SupplierID = ?");
        $delete_supplier_stmt->bind_param('i', $supplier_id);
        $delete_supplier_stmt->execute();
        
        if ($delete_supplier_stmt->affected_rows > 0) {
            $conn->commit();
            echo json_encode([
                'success' => true, 
                'message' => 'Supplier deleted successfully',
                'details' => [
                    'items_deleted' => $items_deleted,
                    'supplier_items_deleted' => $supplieritems_deleted
                ]
            ]);
        } else {
            $conn->rollback();
            echo json_encode(['success' => false, 'error' => 'Supplier not found or already deleted']);
        }
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => 'Failed to delete supplier: ' . $e->getMessage()]);
    }
    exit;
}

echo json_encode(['success' => false, 'error' => 'Invalid action']);
exit;
