<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
session_name('INVENTORY_SESSION');
session_start();
require __DIR__ . '/../../login/database-account.php';
header('Content-Type: application/json; charset=utf-8');

if (!$conn) { 
    echo json_encode(['success'=>false,'error'=>'DB']); 
    exit; 
}

// Get the enum values from items table Measurement column
$measurements = ['Box', 'Pack', 'Sack', 'Pcs', 'Sets', 'Bottle'];

$conn->close();
echo json_encode(['success'=>true,'measurements'=>$measurements]);
