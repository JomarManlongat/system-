<?php
header('Content-Type: application/json');

// Define cache directory (adjust based on your setup)
$cacheDir = __DIR__ . '/../../cache';

// Create cache directory if it doesn't exist
if (!is_dir($cacheDir)) {
    mkdir($cacheDir, 0755, true);
}

$deletedFiles = 0;
$errors = [];

// Clear cache files
if (is_dir($cacheDir)) {
    $files = glob($cacheDir . '/*');
    foreach ($files as $file) {
        if (is_file($file)) {
            if (unlink($file)) {
                $deletedFiles++;
            } else {
                $errors[] = basename($file);
            }
        }
    }
}

// Also clear session files if needed
session_name('INVENTORY_SESSION');
session_start();
session_regenerate_id(true);

if (count($errors) === 0) {
    echo json_encode([
        'ok' => true,
        'message' => "Cache cleared successfully. {$deletedFiles} file(s) deleted."
    ]);
} else {
    echo json_encode([
        'ok' => false,
        'error' => 'Failed to delete some cache files: ' . implode(', ', $errors)
    ]);
}
?>
