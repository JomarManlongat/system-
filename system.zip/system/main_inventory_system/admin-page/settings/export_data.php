<?php
require_once '../../login/database-account.php';

$format = $_GET['format'] ?? 'csv';
$timestamp = date('Y-m-d_His');

// Use database variable from included file
$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Export transactions data
$sql = "SELECT 
    t.TransactionID, t.ItemID, i.ItemName, t.Type, 
    t.Quantity, t.UserID, u.UserName, t.TransactionDate
FROM transactions t
LEFT JOIN items i ON t.ItemID = i.ItemID
LEFT JOIN supplieritems si ON i.ItemID = si.ItemID
LEFT JOIN users u ON t.UserID = u.UserID
ORDER BY t.TransactionDate DESC
LIMIT 1000";

$result = $conn->query($sql);

if ($format === 'csv') {
    header('Content-Type: text/csv');
    header("Content-Disposition: attachment; filename=inventory_export_{$timestamp}.csv");
    
    $output = fopen('php://output', 'w');
    
    // CSV headers
    fputcsv($output, ['Transaction ID', 'Item ID', 'Item Name', 'Type', 'Quantity', 'User ID', 'User Name', 'Date & Time']);
    
    // CSV data
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            fputcsv($output, [
                $row['TransactionID'],
                $row['ItemID'],
                $row['ItemName'],
                $row['Type'],
                $row['Quantity'],
                $row['UserID'],
                $row['UserName'] ?? 'N/A',
                $row['TransactionDate']
            ]);
        }
    }
    
    fclose($output);
} elseif ($format === 'excel') {
    // Simple HTML table for Excel (can be opened in Excel)
    header('Content-Type: application/vnd.ms-excel');
    header("Content-Disposition: attachment; filename=inventory_export_{$timestamp}.xls");
    
    echo '<table border="1">';
    echo '<tr><th>Transaction ID</th><th>Item ID</th><th>Item Name</th><th>Type</th><th>Quantity</th><th>User ID</th><th>User Name</th><th>Date & Time</th></tr>';
    
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo '<tr>';
            echo '<td>' . htmlspecialchars($row['TransactionID']) . '</td>';
            echo '<td>' . htmlspecialchars($row['ItemID']) . '</td>';
            echo '<td>' . htmlspecialchars($row['ItemName']) . '</td>';
            echo '<td>' . htmlspecialchars($row['Type']) . '</td>';
            echo '<td>' . htmlspecialchars($row['Quantity']) . '</td>';
            echo '<td>' . htmlspecialchars($row['UserID']) . '</td>';
            echo '<td>' . htmlspecialchars($row['UserName'] ?? 'N/A') . '</td>';
            echo '<td>' . htmlspecialchars($row['TransactionDate']) . '</td>';
            echo '</tr>';
        }
    }
    
    echo '</table>';
} elseif ($format === 'pdf') {
    // Redirect to PDF generator (requires library like TCPDF or FPDF)
    header('Content-Type: text/plain');
    echo 'PDF export requires additional library setup. Coming soon!';
}

$conn->close();
?>
