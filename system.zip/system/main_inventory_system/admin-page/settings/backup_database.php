<?php
require_once '../../login/database-account.php';

$timestamp = date('Y-m-d_His');
$backupFile = "backup_inventory_{$timestamp}.sql";

// Path to mysqldump (adjust based on your XAMPP installation)
$mysqldumpPath = 'C:\\xampp\\mysql\\bin\\mysqldump.exe';

// Check if mysqldump exists
if (!file_exists($mysqldumpPath)) {
    die('Error: mysqldump not found. Please check the path.');
}

// Backup directory (create if not exists)
$backupDir = __DIR__ . '/../../backups';
if (!is_dir($backupDir)) {
    mkdir($backupDir, 0755, true);
}

$backupFullPath = $backupDir . '/' . $backupFile;

// Execute mysqldump
$command = "\"{$mysqldumpPath}\" -u {$username} -p{$password} -h {$servername} {$database} > \"{$backupFullPath}\"";
exec($command, $output, $returnVar);

if ($returnVar === 0 && file_exists($backupFullPath)) {
    // Send file to browser for download
    header('Content-Type: application/sql');
    header("Content-Disposition: attachment; filename={$backupFile}");
    header('Content-Length: ' . filesize($backupFullPath));
    readfile($backupFullPath);
    
    // Optional: delete backup file after download
    unlink($backupFullPath);
} else {
    die('Error: Backup failed. Please check database credentials and permissions.');
}
?>
