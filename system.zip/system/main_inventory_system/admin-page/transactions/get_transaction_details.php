<?php
error_reporting(0);
ini_set('display_errors', 0);
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../../login/database-account.php';

$transId = isset($_POST['transaction_id']) ? trim($_POST['transaction_id']) : '';

if (empty($transId)) {
    echo json_encode(['success' => false, 'error' => 'Invalid transaction ID']);
    exit;
}

try {
    // Check if transactions table has the new columns
    $hasNewCols = false;
    $hasDateTimeCols = false;
    $checkCols = $conn->query("SHOW COLUMNS FROM transactions LIKE 'ReceivedBy'");
    if ($checkCols && $checkCols->num_rows > 0) {
        $hasNewCols = true;
    }
    
    // Check for ReceivedDate and ReceivedTime columns
    $checkDateCol = $conn->query("SHOW COLUMNS FROM transactions LIKE 'ReceivedDate'");
    if ($checkDateCol && $checkDateCol->num_rows > 0) {
        $hasDateTimeCols = true;
    }
    
    // Detect datetime column
    $txnDateCol = 'DateTime';
    $chkTxnDate = $conn->query("SHOW COLUMNS FROM transactions LIKE 'TransactionDate'");
    if ($chkTxnDate && $chkTxnDate->num_rows > 0) {
        $txnDateCol = 'TransactionDate';
    }
    
    // Build query based on available columns
    if ($hasNewCols && $hasDateTimeCols) {
        $sql = "SELECT t.TransactionID, t.ItemID, t.Quantity, t.Type, t.UserID,
                       t.".$txnDateCol." AS TxnDate,
                       t.ReceivedBy, t.RecordedBy, t.Description, t.ReceivedDate, t.ReceivedTime,
                       si.ItemName, u.Name AS UserName
                FROM transactions t
                LEFT JOIN items i ON i.ItemID = t.ItemID
                LEFT JOIN supplieritems si ON i.SupplierItemID = si.SupplierItemID
                LEFT JOIN users u ON u.UserID = t.UserID
                WHERE t.TransactionID = ?";
    } else if ($hasNewCols) {
        $sql = "SELECT t.TransactionID, t.ItemID, t.Quantity, t.Type, t.UserID,
                       t.".$txnDateCol." AS TxnDate,
                       t.ReceivedBy, t.RecordedBy, t.Description,
                       si.ItemName, u.Name AS UserName
                FROM transactions t
                LEFT JOIN items i ON i.ItemID = t.ItemID
                LEFT JOIN supplieritems si ON i.SupplierItemID = si.SupplierItemID
                LEFT JOIN users u ON u.UserID = t.UserID
                WHERE t.TransactionID = ?";
    } else {
        $sql = "SELECT t.TransactionID, t.ItemID, t.Quantity, t.Type, t.UserID,
                       t.".$txnDateCol." AS TxnDate,
                       si.ItemName, u.Name AS UserName
                FROM transactions t
                LEFT JOIN items i ON i.ItemID = t.ItemID
                LEFT JOIN supplieritems si ON i.SupplierItemID = si.SupplierItemID
                LEFT JOIN users u ON u.UserID = t.UserID
                WHERE t.TransactionID = ?";
    }
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('s', $transId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        // Format date/time nicely
        $dateTime = $row['TxnDate'];
        $formattedDate = '';
        $formattedTime = '';
        if ($dateTime) {
            $timestamp = strtotime($dateTime);
            if ($timestamp) {
                $formattedDate = date('F j, Y', $timestamp); // e.g., "December 8, 2025"
                $formattedTime = date('g:i A', $timestamp);   // e.g., "11:43 PM"
            }
        }
        
        // Format ReceivedDate and ReceivedTime if available
        $receivedDateFormatted = null;
        $receivedTimeFormatted = null;
        if ($hasDateTimeCols && isset($row['ReceivedDate']) && $row['ReceivedDate']) {
            $timestamp = strtotime($row['ReceivedDate']);
            if ($timestamp) {
                $receivedDateFormatted = date('F j, Y', $timestamp);
            }
        }
        if ($hasDateTimeCols && isset($row['ReceivedTime']) && $row['ReceivedTime']) {
            $timestamp = strtotime($row['ReceivedTime']);
            if ($timestamp) {
                $receivedTimeFormatted = date('g:i A', $timestamp);
            }
        }
        
        $response = [
            'success' => true,
            'transaction' => [
                'id' => $row['TransactionID'],
                'item_id' => $row['ItemID'],
                'item_name' => $row['ItemName'] ?? 'N/A',
                'quantity' => $row['Quantity'],
                'type' => $row['Type'],
                'user' => $row['UserName'] ?? 'N/A',
                'date_time' => $dateTime,
                'formatted_date' => $formattedDate,
                'formatted_time' => $formattedTime,
                'received_by' => $hasNewCols && isset($row['ReceivedBy']) ? $row['ReceivedBy'] : null,
                'recorded_by' => $hasNewCols && isset($row['RecordedBy']) ? $row['RecordedBy'] : null,
                'description' => $hasNewCols && isset($row['Description']) ? $row['Description'] : null,
                'received_date' => $receivedDateFormatted,
                'received_time' => $receivedTimeFormatted
            ]
        ];
        echo json_encode($response);
    } else {
        echo json_encode(['success' => false, 'error' => 'Transaction not found']);
    }
    
    $stmt->close();
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>
