<?php
require __DIR__ . '/../../login/database-account.php';
header('Content-Type: text/html; charset=utf-8');

$typeFilter = isset($_POST['type']) ? trim($_POST['type']) : 'all';

function esc($v){ return htmlspecialchars((string)$v ?? '', ENT_QUOTES, 'UTF-8'); }
function fmt_date($d){ if(!$d) return 'N/A'; $t=strtotime($d); return $t? date('n/j/Y g:i A', $t): esc($d); }

// Query alerts table directly
$sql = "SELECT a.AlertID, a.Type, a.ItemID, a.Details, a.CreatedAt
        FROM alerts a";

$where = [];
$params = [];
$types = '';

if ($typeFilter !== 'all') {
  $where[] = 'a.Type = ?';
  $params[] = $typeFilter;
  $types .= 's';
}

if (!empty($where)) {
  $sql .= ' WHERE ' . implode(' AND ', $where);
}

$sql .= ' ORDER BY a.AlertID DESC LIMIT 200';

$stmt = $conn->prepare($sql);
if ($params) { $stmt->bind_param($types, ...$params); }
$stmt->execute();
$result = $stmt->get_result();

if (!$result || $result->num_rows === 0) {
  echo '<tr><td colspan="5" style="text-align:center;color:#666;padding:16px">No alerts found.</td></tr>';
  exit;
}

function clamp2($s){ return '<div class="clamp-2">'.esc($s).'</div>'; }

while ($row = $result->fetch_assoc()) {
  $alertId = esc($row['AlertID']);
  $type = $row['Type'] ? esc($row['Type']) : '-';
  $itemId = $row['ItemID'];
  
  // Get ItemName from items table
  $itemNameSql = "SELECT ItemName FROM items WHERE ItemID = ?";
  $itemStmt = $conn->prepare($itemNameSql);
  $itemStmt->bind_param('i', $itemId);
  $itemStmt->execute();
  $itemResult = $itemStmt->get_result();
  $itemRow = $itemResult->fetch_assoc();
  $itemName = $itemRow ? esc($itemRow['ItemName']) : '-';
  $itemStmt->close();
  
  $details = $row['Details'] ? esc($row['Details']) : '-';
  $createdAt = fmt_date($row['CreatedAt']);

  echo '<tr>'
     . '<td>'.clamp2($alertId).'</td>'
     . '<td>'.clamp2($type).'</td>'
     . '<td>'.clamp2($itemName).'</td>'
     . '<td>'.clamp2($details).'</td>'
     . '<td>'.clamp2($createdAt).'</td>'
     . '</tr>';
}
