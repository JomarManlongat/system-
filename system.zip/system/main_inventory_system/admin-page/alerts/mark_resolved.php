<?php
require __DIR__ . '/../../login/database-account.php';
header('Content-Type: application/json');

$alertId = isset($_POST['alert_id']) ? (int)$_POST['alert_id'] : 0;
if ($alertId <= 0) { 
  echo json_encode(['ok'=>false,'error'=>'Missing alert_id']); 
  exit; 
}

$stmt = $conn->prepare("UPDATE alerts SET Status = 'Resolved' WHERE AlertID = ?");
$stmt->bind_param('i', $alertId);
$ok = $stmt->execute();

if ($ok && $stmt->affected_rows > 0) {
  echo json_encode(['ok'=>true]);
} else {
  echo json_encode(['ok'=>false,'error'=>'Update failed or alert not found']);
}
