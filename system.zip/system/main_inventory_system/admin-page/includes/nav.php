<?php
// Shared navigation/sidebar for admin and staff pages
// Requires $logged_username to be defined in the including file
// Optional: $nav_context = 'admin' | 'staff' to control which links render
$nav_context = isset($nav_context) ? $nav_context : 'admin';

// Location no longer used; allow all items/menus regardless of location
$user_location = 'All';

// Determine if current session belongs to an admin (various session keys used across apps)
$is_admin = false;
if (isset($_SESSION['role']) && strtolower($_SESSION['role']) === 'admin') $is_admin = true;
if (isset($_SESSION['Role']) && strtolower($_SESSION['Role']) === 'admin') $is_admin = true;
if (isset($_SESSION['roles']) && strtolower($_SESSION['roles']) === 'admin') $is_admin = true;

// Determine user's role string
$user_role = $_SESSION['role'] ?? $_SESSION['Role'] ?? $_SESSION['roles'] ?? '';
$is_staff = strtolower(trim($user_role)) === 'staff';
?>
<div class="pages-menu" id="mobileMenu">
    <div class="title-inventory-management">
        <h2 class="int-management"><img src="../logos/moon.png" alt="website-logo" id="logo-image-title" height="auto" width="26px">Lunera Hotel</h2>
    </div>
    <div class="nav-area-top">
        <nav>
            <ul class="pages-top">
                <?php if ($nav_context === 'admin' && $is_admin): ?>
                <li><a href="#" data-page="dashboard"><img src="../logos/dashboard-logo.png" alt="logo-1" class="logo-top" id="logo-dashboard" height="19px" width="19px">Dashboard</a></li>
                <?php endif; ?>
                <li><a href="#" data-page="inventory"><img src="../logos/Inventory-logo.png" alt="logo-2" class="logo-top" height="19px" width="19px">Inventory</a></li>
                <?php if ($is_staff): ?>
                <li><a href="#" data-page="orders"><img src="../logos/order-logo.png" alt="logo-3" class="logo-top" height="19px" width="19px">Orders</a></li>
                <li><a href="#" data-page="suppliers"><img src="../logos/suppliers-logo.png" alt="logo-8" class="logo-top" height="19px" width="19px">Suppliers</a></li>
                <?php endif; ?>
                <?php if ($is_admin): ?>
                    <li><a href="#" data-page="transactions"><img src="../logos/transaction-logo.png" alt="logo-4" class="logo-top" height="19px" width="19px">Transactions</a></li>
                    <li><a href="#" data-page="reports"><img src="../logos/reports-logo.png" alt="logo-5" class="logo-top" height="19px" width="19px">Reports</a></li>
                    <li><a href="#" data-page="alerts"><img src="../logos/alerts-logo.png" alt="logo-6" class="logo-top" height="19px" width="19px">Alerts</a></li>
                    <li><a href="#" data-page="issues"><img src="../logos/issues-logo.png" alt="logo-7" class="logo-top" height="19px" width="19px">Issues</a></li>
                    <li><a href="#" data-page="users"><img src="../logos/users-logo.png" alt="logo-9" class="logo-top" height="19px" width="19px">Manage Users</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
    <div class="nav-area-bottom">
        <ul class="pages-bottom">
            <?php 
                        // Show Restaurant back button only when the user is a staff member who arrived via the
                        // Restaurant SSO gateway (clicked the button in the Restaurant app).
                        // We prefer an explicit SSO flag (`sso_source` / `return_to_restaurant`) instead of
                        // the user's assigned location so that directly navigating to Inventory doesn't
                        // surface a Back button.
                        $show_back = false;
                        $came_from_restaurant = false;
                        if (isset($_SESSION['sso_source']) && strtolower($_SESSION['sso_source']) === 'restaurant') {
                            $came_from_restaurant = true;
                        }
                        if (isset($_SESSION['return_to_restaurant']) && $_SESSION['return_to_restaurant'] === true) {
                            $came_from_restaurant = true;
                        }
                        // Show back button ONLY for admins who arrived via Restaurant SSO.
                        // Staff users now excluded per updated requirement.
                        if ($came_from_restaurant && $is_admin) {
                            $show_back = true;
                        }
            if ($show_back):
            ?>
            <li>
                <a href="<?php echo ($nav_context === 'admin' ? '../..' : '../../..'); ?>/HotelLuneraRestaurant/admin/admin.php" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border-radius: 5px;">
                    <span class="span-nav-bottom">← Restaurant</span>
                    <img src="../logos/moon.png" alt="back-to-restaurant" class="logo-bottom" height="19px" width="19px">
                </a>
            </li>
            <?php endif; ?>
            <?php if ($nav_context === 'admin'): ?>
            <li>
                <a href="#" data-page="settings">
                    <span class="span-nav-bottom">Settings</span>
                    <img id="settings-logo" src="../logos/setting-logo.png" alt="logo-10" class="logo-bottom" height="19px" width="19px">
                </a>
            </li>
            <?php endif; ?>
            <li>
                <a href="#" id="logout_btn">
                    <span class="span-nav-bottom"><?php echo htmlspecialchars($logged_username ?? 'User'); ?></span>
                    <img id="logout-logo" src="../logos/logout-logo.png" alt="logo-11" class="logo-bottom" height="19px" width="19px">
                </a>
            </li>
        </ul>
    </div>
</div>
