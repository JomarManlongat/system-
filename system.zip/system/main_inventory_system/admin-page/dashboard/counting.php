<?php
require(__DIR__ . "/../../login/database-account.php");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Correct SQL (no space in COUNT) - only count items with stock and not expired
$sql = "SELECT COUNT(*) AS total_amount FROM items WHERE Stock > 0 AND (ExpiryDate IS NULL OR ExpiryDate >= CURDATE())";
$result = $conn->query($sql);

$total_amount = 0; // default value

if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    // use the alias exactly as written in SQL (total_amount)
    if (isset($row["total_amount"])) {
        $total_amount = $row["total_amount"];
    }
}

$sql = "SELECT COUNT(*) AS total_low_stock FROM items WHERE Stock > 0 AND Stock <= 20";
$result = $conn->query($sql);

$total_low_stock = 0; // default
if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    if (isset($row["total_low_stock"])) {
        $total_low_stock = $row["total_low_stock"];
    }
}

/* ---------------------------
   EXPIRED ITEMS
   (count from alerts table, not issues)
---------------------------- */
$sql = "SELECT COUNT(*) AS total_expired FROM alerts WHERE Type = 'Expired' AND Status = 'Pending'";
$result = $conn->query($sql);

$total_expired = 0;
if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    if (isset($row["total_expired"])) {
        $total_expired = $row["total_expired"];
    }
}

/* ---------------------------
   DAMAGED ITEMS
   (assume you have a column `status` or `condition` = 'Damaged')
---------------------------- */
$sql = "SELECT COUNT(*) AS total_damaged FROM issues WHERE Conditions = 'Damaged'";
$result = $conn->query($sql);

$total_damaged = 0;
if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    if (isset($row["total_damaged"])) {
        $total_damaged = $row["total_damaged"];
    }
}

/* ---------------------------
   REGISTERED USERS
   (count rows from users table)
---------------------------- */
$sql = "SELECT COUNT(*) AS total_users FROM users";
$result = $conn->query($sql);

$total_users = 0;
if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    if (isset($row["total_users"])) {
        $total_users = $row["total_users"];
    }
}

/* ---------------------------
   SUPPLIERS
   (count rows from suppliers table)
---------------------------- */
$sql = "SELECT COUNT(*) AS total_suppliers FROM suppliers";
$result = $conn->query($sql);

$total_suppliers = 0;
if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    if (isset($row["total_suppliers"])) {
        $total_suppliers = $row["total_suppliers"];
    }
}

// Don't close connection - it's needed by other parts of the page (modals, etc.)
// $conn->close();
?>