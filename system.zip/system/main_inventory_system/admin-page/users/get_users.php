<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../../login/database-account.php';

// Detect correct column names
$usernameField = 'Username';
$nameField = 'Name';
$roleField = 'Role';

// Check if Username column exists
$chk = $conn->query("SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME='users' AND COLUMN_NAME='Username'");
if (!$chk || $chk->num_rows === 0) { $usernameField = 'UserName'; }

// Check if Role column exists
$chk2 = $conn->query("SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME='users' AND COLUMN_NAME='Role'");
if (!$chk2 || $chk2->num_rows === 0) { $roleField = 'Position'; }

// Get all active users
$sql = "SELECT UserID, $usernameField AS Username, $nameField AS Name, $roleField AS Role FROM users ORDER BY $nameField ASC";
$result = $conn->query($sql);

$users = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $users[] = [
            'user_id' => $row['UserID'],
            'user_name' => $row['Name'],
            'username' => $row['Username'],
            'position' => $row['Role'] ?? ''
        ];
    }
}

$conn->close();

echo json_encode([
    'success' => true,
    'users' => $users
]);
?>
