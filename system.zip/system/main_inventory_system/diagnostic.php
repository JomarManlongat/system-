<?php
require __DIR__ . '/login/database-account.php';

echo "=== SYSTEM DIAGNOSTIC ===\n\n";

// 1. Check approve_order.php file exists
echo "1. Files Check:\n";
$files = [
  'admin-page/orders/approve_order.php',
  'staff-page/orders/approve_order.php',
  'admin-page/orders/receive_order_new.php',
  'staff-page/orders/receive_order.php',
  'admin-page/orders/orders_database.php',
  'admin-page/orders/orders_management.js'
];
foreach ($files as $f) {
  $path = __DIR__ . '/' . $f;
  echo "  " . (file_exists($path) ? "✓" : "✗") . " $f\n";
}

// 2. Check database schema
echo "\n2. Database Schema:\n";
$result = $conn->query("SELECT OrderID, Status FROM orders WHERE OrderID = 16 LIMIT 1");
if ($row = $result->fetch_assoc()) {
  echo "  Order 16 Status: " . $row['Status'] . "\n";
}

$result = $conn->query("SHOW COLUMNS FROM orderdetails WHERE Field = 'Status'");
if ($row = $result->fetch_assoc()) {
  echo "  OrderDetails Status column: " . $row['Type'] . "\n";
}

// 3. Test approve operation
echo "\n3. Test Approve Operation:\n";
$testOrderId = 17; // Use the latest test order
$checkStatus = $conn->query("SELECT Status FROM orders WHERE OrderID = $testOrderId");
if ($row = $checkStatus->fetch_assoc()) {
  echo "  Before: Order $testOrderId Status = " . $row['Status'] . "\n";
  
  // Try to update
  $newStatus = 'To Be Recorded';
  $stmt = $conn->prepare("UPDATE orders SET Status = ? WHERE OrderID = ?");
  $stmt->bind_param('si', $newStatus, $testOrderId);
  if ($stmt->execute()) {
    echo "  ✓ Update executed successfully\n";
    $checkAfter = $conn->query("SELECT Status FROM orders WHERE OrderID = $testOrderId");
    if ($row = $checkAfter->fetch_assoc()) {
      echo "  After: Order $testOrderId Status = " . $row['Status'] . "\n";
    }
  } else {
    echo "  ✗ Update failed: " . $stmt->error . "\n";
  }
  $stmt->close();
}

$conn->close();
?>
