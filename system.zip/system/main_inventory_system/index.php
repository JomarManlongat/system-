<?php
// Inventory Management System - Main Entry Point
// This file ensures users are directed to login first

session_name('INVENTORY_SESSION');
session_start();

// If user is already logged in, redirect to appropriate dashboard
if (isset($_SESSION['user_id'])) {
    // Redirect to admin or staff dashboard based on role
    $role = $_SESSION['role'] ?? '';
    
    if ($role === 'admin' || $role === 'Admin') {
        header("Location: admin-page/admin_inv_man.php");
    } else {
        header("Location: staff-page/staff_inv_man.php");
    }
    exit();
}

// If not logged in, redirect to login page
header("Location: login/login.php");
exit();
?>
