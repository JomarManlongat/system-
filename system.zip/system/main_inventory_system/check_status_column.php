<?php
require __DIR__ . '/login/database-account.php';

// Check both tables
echo "=== ORDERS TABLE STATUS COLUMN ===\n";
$result = $conn->query("SHOW COLUMNS FROM orders LIKE 'Status'");
while ($row = $result->fetch_assoc()) {
  echo json_encode($row, JSON_PRETTY_PRINT) . "\n";
}

echo "\n=== ORDERDETAILS TABLE STATUS COLUMN ===\n";
$result = $conn->query("SHOW COLUMNS FROM orderdetails LIKE 'Status'");
while ($row = $result->fetch_assoc()) {
  echo json_encode($row, JSON_PRETTY_PRINT) . "\n";
}

$conn->close();
?>
