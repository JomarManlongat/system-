<?php
require __DIR__ . '/login/database-account.php';

// Modify the orderdetails Status enum to include 'To Be Recorded'
$sql = "ALTER TABLE orderdetails MODIFY Status ENUM('Pending Approval','To Be Recorded','In Transit','Received','Shipped') NULL DEFAULT 'Pending Approval'";

echo "Executing: " . $sql . "\n";
if ($conn->query($sql)) {
  echo "✓ Successfully updated orderdetails.Status enum\n";
} else {
  echo "✗ Error: " . $conn->error . "\n";
}

// Also update the orders table to include 'To Be Recorded' in any similar constraints
// (Though it's varchar(50) so should be fine)
$sql2 = "SELECT Status FROM orders WHERE Status NOT IN ('Pending Approval', 'To Be Recorded', 'In Transit', 'Received', 'Shipped', 'Completed', 'Cancelled') LIMIT 5";
$result = $conn->query($sql2);
if ($result && $result->num_rows > 0) {
  echo "\nFound non-standard statuses in orders table:\n";
  while ($row = $result->fetch_assoc()) {
    echo "  - " . $row['Status'] . "\n";
  }
}

echo "\n=== UPDATED SCHEMA ===\n";
$result = $conn->query("SHOW COLUMNS FROM orderdetails LIKE 'Status'");
while ($row = $result->fetch_assoc()) {
  echo json_encode($row, JSON_PRETTY_PRINT) . "\n";
}

$conn->close();
?>
