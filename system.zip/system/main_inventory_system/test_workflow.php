<?php
require __DIR__ . '/login/database-account.php';

echo "=== ORDERS WORKFLOW TEST ===\n\n";

// 1. Create an order
echo "1. Creating order with Fresh Food Wholesale...\n";
$_POST['supplier_id'] = '71';
$_POST['items'] = json_encode([
  ['supplier_item_id' => '505', 'quantity' => '3']
]);

// Capture output
ob_start();
require __DIR__ . '/admin-page/orders/submit_order.php';
$output = ob_get_clean();
$result = json_decode($output, true);

if ($result['success']) {
  $orderId = $result['order_id'];
  echo "✓ Order created: ORD" . str_pad($orderId, 3, '0', STR_PAD_LEFT) . "\n";
  
  // Check order status
  $check = $conn->query("SELECT Status FROM orders WHERE OrderID = $orderId");
  if ($row = $check->fetch_assoc()) {
    echo "  Status: " . $row['Status'] . "\n";
  }
  
  // 2. Approve the order
  echo "\n2. Approving the order...\n";
  $_POST = [];
  $_POST['order_id'] = $orderId;
  
  ob_start();
  require __DIR__ . '/admin-page/orders/approve_order.php';
  $output = ob_get_clean();
  $result = json_decode($output, true);
  
  if ($result['success']) {
    echo "✓ Order approved\n";
    
    // Check order status again
    $check = $conn->query("SELECT Status FROM orders WHERE OrderID = $orderId");
    if ($row = $check->fetch_assoc()) {
      echo "  Status: " . $row['Status'] . "\n";
    }
    
    // Check orderdetails status
    $check = $conn->query("SELECT Status FROM orderdetails WHERE OrderID = $orderId");
    if ($row = $check->fetch_assoc()) {
      echo "  OrderDetails Status: " . $row['Status'] . "\n";
    }
  } else {
    echo "✗ Approval failed: " . $result['error'] . "\n";
  }
} else {
  echo "✗ Order creation failed: " . $result['error'] . "\n";
}

$conn->close();
?>
