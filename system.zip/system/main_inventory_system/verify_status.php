<?php
require __DIR__ . '/login/database-account.php';

$result = $conn->query("SELECT OrderID, Status FROM orders WHERE OrderID = 16");
while ($row = $result->fetch_assoc()) {
  echo "Order ID: " . $row['OrderID'] . " | Status: " . $row['Status'] . "\n";
}

$result = $conn->query("SELECT OrderDetailID, OrderID, Status FROM orderdetails WHERE OrderID = 16");
echo "\nOrder Details:\n";
while ($row = $result->fetch_assoc()) {
  echo "  Detail ID: " . $row['OrderDetailID'] . " | Order: " . $row['OrderID'] . " | Status: " . $row['Status'] . "\n";
}

$conn->close();
?>
