// Orders page loader - keeps existing design, only injects rows
(function(){
  // Use absolute path from web root
  const ORDERS_PATH = '/system/main_inventory_system/staff-page/orders/';
  
  // Helper to safely parse JSON responses
  function fetchJSON(url, options = {}) {
    return fetch(url, options)
      .then(r => {
        if (!r.ok) throw new Error('HTTP ' + r.status);
        return r.text();
      })
      .then(text => {
        try {
          return JSON.parse(text);
        } catch(e) {
          console.error('JSON parse error:', e, 'Response:', text.substring(0, 200));
          throw new Error('Invalid JSON response');
        }
      });
  }
  
  // Lightweight notification (reuse global if available)
  function notify(msg, type = 'success') {
    if (typeof window.showNotification === 'function') {
      window.showNotification(msg, type);
      return;
    }
    const el = document.createElement('div');
    el.textContent = msg;
    el.style.cssText = `
      position: fixed; top: 16px; right: 16px;
      background: ${type === 'success' ? '#28a745' : '#dc3545'};
      color: #fff; padding: 10px 14px; border-radius: 6px;
      box-shadow: 0 6px 16px rgba(0,0,0,0.2); z-index: 10000; opacity: 0; transform: translateY(-6px);
      transition: all .2s ease;
    `;
    document.body.appendChild(el);
    requestAnimationFrame(() => { el.style.opacity = '1'; el.style.transform = 'translateY(0)'; });
    setTimeout(() => { el.style.opacity = '0'; el.style.transform = 'translateY(-6px)'; setTimeout(() => el.remove(), 200); }, 1600);
  }

  // Close all action dropdowns helper
  function closeAllDropdowns() {
    document.querySelectorAll('.action-dropdown').forEach(d => d.style.display = 'none');
  }

  // Expose action handlers
  window.viewOrder = function(orderId) {
    closeAllDropdowns();
    openViewOrderModal(orderId);
  };

  window.receiveOrder = function(orderId) {
    closeAllDropdowns();
    openReceiveOrderModal(orderId);
  };

  window.cancelOrder = function(orderId) {
    closeAllDropdowns();
    if (confirm('Are you sure you want to cancel order #' + orderId + '?')) {
      const formData = new FormData();
      formData.append('order_id', orderId);
      
      fetchJSON(ORDERS_PATH + 'cancel_order.php', {
        method: 'POST',
        body: formData
      })
      .then(data => {
        if (data.success) {
          notify('Order cancelled successfully', 'success');
          loadOrders();
        } else {
          notify(data.error || 'Failed to cancel order', 'error');
        }
      })
      .catch(err => {
        console.error('Error cancelling order:', err);
        notify('Failed to cancel order', 'error');
      });
    }
  };

  window.approveOrder = function(orderId) {
    closeAllDropdowns();
    if (typeof window.showConfirmationModal === 'function') {
      window.showConfirmationModal(
        'Are you sure you want to approve this order?\n\nThe order status will change to "To Be Recorded" and items will be ready for delivery recording.',
        'Confirm Approval'
      ).then(confirmed => {
        if (confirmed) {
          const formData = new FormData();
          formData.append('order_id', orderId);

          fetchJSON(ORDERS_PATH + 'approve_order.php', {
            method: 'POST',
            body: formData
          })
          .then(data => {
            if (data.success) {
              notify('Order approved successfully! Status changed to "To Be Recorded".', 'success');
              loadOrders();
            } else {
              notify(data.error || 'Failed to approve order', 'error');
            }
          })
          .catch(err => {
            console.error('Error approving order:', err);
            notify('Failed to approve order', 'error');
          });
        }
      });
    } else {
      // Fallback to browser confirm
      if (confirm('Are you sure you want to approve this order?')) {
        const formData = new FormData();
        formData.append('order_id', orderId);

        fetchJSON(ORDERS_PATH + 'approve_order.php', {
          method: 'POST',
          body: formData
        })
        .then(data => {
          if (data.success) {
            notify('Order approved successfully! Status changed to "To Be Recorded".', 'success');
            loadOrders();
          } else {
            notify(data.error || 'Failed to approve order', 'error');
          }
        })
        .catch(err => {
          console.error('Error approving order:', err);
          notify('Failed to approve order', 'error');
        });
      }
    }
  };

  // ================= Create Order Modal =================
  function setCreateBtnState() {
    const supplierId = document.getElementById('order_supplier_select')?.value || '';
    const hasItems = document.querySelectorAll('#order_items_container .item-row').length > 0;
    const btn = document.getElementById('create_order_btn');
    if (btn) btn.disabled = !(supplierId && hasItems);
  }

  window.openCreateOrderModal = function(supplierId = null, supplierName = null) {
    const modal = document.getElementById('createOrderModal');
    if (!modal) return;
    const container = document.getElementById('order_items_container');
    if (container) container.innerHTML = '';
    const supplierSelect = document.getElementById('order_supplier_select');
    if (supplierId && supplierSelect) {
      // Lock supplier select to this supplier only
      supplierSelect.innerHTML = `<option value="${supplierId}">${supplierName || 'Supplier'}</option>`;
      supplierSelect.value = supplierId;
      supplierSelect.disabled = true;
    } else {
      if (supplierSelect) supplierSelect.disabled = false;
      loadSuppliersForOrder();
    }
    addOrderItemRow();
    setCreateBtnState();
    modal.style.display = 'flex';
  };

  window.closeCreateOrderModal = function() {
    const modal = document.getElementById('createOrderModal');
    if (modal) modal.style.display = 'none';
  };

  function loadSuppliersForOrder() {
  fetch(ORDERS_PATH + 'get_suppliers.php')
      .then(r => r.json())
      .then(d => {
        const sel = document.getElementById('order_supplier_select');
        if (!sel) return;
        sel.innerHTML = '<option value="">Select a supplier</option>';
        if (d.success && Array.isArray(d.suppliers)) {
          d.suppliers.forEach(s => {
            const opt = document.createElement('option');
            opt.value = s.SupplierID; opt.textContent = s.SupplierName;
            sel.appendChild(opt);
          });
        }
        sel.onchange = () => {
          document.querySelectorAll('#order_items_container select[data-role="item"]').forEach(select => {
            loadSupplierItems(sel.value, select, select.getAttribute('data-selected'));
          });
          setCreateBtnState();
        };
      });
  }

  function loadSupplierItems(supplierId, selectEl, selectedId = '') {
    const fd = new FormData(); fd.append('supplier_id', supplierId || '0');
  fetch(ORDERS_PATH + 'get_items_by_supplier.php', { method:'POST', body: fd })
      .then(r => r.json())
      .then(d => {
        selectEl.innerHTML = '<option value="">Select or type item...</option>';
        if (d.success && Array.isArray(d.items)) {
          d.items.forEach(it => {
            const opt = document.createElement('option');
            opt.value = it.SupplierItemID;
            opt.textContent = it.ItemName;
            opt.setAttribute('data-measure', it.Measurement || 'pcs');
            selectEl.appendChild(opt);
          });
        }
        if (selectedId) selectEl.value = selectedId;
        const updateUnit = () => {
          const selOpt = selectEl.options[selectEl.selectedIndex];
          const row = selectEl.closest('.item-row');
          const unit = row.querySelector('select[data-role="unit"]');
          const measure = selOpt ? (selOpt.getAttribute('data-measure') || 'pcs') : 'pcs';
          // Replace options to lock the measurement to DB value
          unit.innerHTML = `<option value="${measure}">${measure}</option>`;
          unit.value = measure;
          setCreateBtnState();
        };
        selectEl.onchange = updateUnit;
        updateUnit();
      });
  }

  window.addOrderItemRow = function() {
    const container = document.getElementById('order_items_container');
    const row = document.createElement('div');
    row.className = 'item-row';
    row.innerHTML = `
      <select class="input-select" data-role="item"></select>
      <input class="input-number" type="number" min="1" value="1" />
      <select class="input-select" data-role="unit" disabled>
        <option value="pcs">pcs</option>
      </select>
      <button class="remove-btn" type="button">Remove</button>
    `;
    container.appendChild(row);
    const supplierId = document.getElementById('order_supplier_select')?.value || '';
    const itemSelect = row.querySelector('select[data-role="item"]');
    loadSupplierItems(supplierId, itemSelect);
    row.querySelector('.remove-btn').onclick = () => { row.remove(); setCreateBtnState(); };
    row.querySelector('.input-number').oninput = () => setCreateBtnState();
    setCreateBtnState();
  };

  window.submitNewOrder = function() {
    const supplierId = document.getElementById('order_supplier_select')?.value;
    const rows = Array.from(document.querySelectorAll('#order_items_container .item-row'));
    const items = [];
    rows.forEach(r => {
      const itemId = r.querySelector('select[data-role="item"]').value;
      const qty = parseInt(r.querySelector('.input-number').value, 10) || 0;
      if (itemId && qty > 0) items.push({ supplier_item_id: itemId, quantity: qty });
    });
    if (!supplierId || items.length === 0) return;

    const btn = document.getElementById('create_order_btn');
    if (btn) btn.disabled = true;

    const fd = new FormData();
    fd.append('supplier_id', supplierId);
    fd.append('items', JSON.stringify(items));

  fetch(ORDERS_PATH + 'submit_order.php', { method:'POST', body: fd })
      .then(r => r.json())
      .then(d => {
        if (btn) btn.disabled = false;
        if (d.success) {
          closeCreateOrderModal();
          notify('Order created successfully', 'success');
          reloadOrders();
        } else {
          notify(d.error || 'Failed to create order', 'error');
        }
      })
      .catch(() => { if (btn) btn.disabled = false; notify('Request failed', 'error'); });
  };

  // View Order Modal
  window.openViewOrderModal = function(orderId) {
    const modal = document.getElementById('viewOrderModal');
    if (!modal) return;

    // Extract numeric ID if it's in ORD001 format
    const numericId = orderId.toString().replace(/\D/g, '');

    const fd = new FormData();
    fd.append('order_id', numericId);

  fetch(ORDERS_PATH + 'get_order_details.php', { method: 'POST', body: fd })
      .then(r => r.json())
      .then(data => {
        if (data.success && data.order) {
          const o = data.order;
          const orderStatus = o.status ? o.status.toLowerCase() : '';
          
          document.getElementById('view_order_title').textContent = `Order Details: ${o.id}`;
          document.getElementById('view_order_info').textContent = `From ${o.supplier} on ${o.date}`;
          
          const tbody = document.getElementById('view_order_items_body');
          tbody.innerHTML = '';
          
          o.items.forEach(item => {
            const tr = document.createElement('tr');
            tr.style.borderBottom = '1px solid #e9ecef';
            
            // Determine status display
            let statusDisplay = 'Not Received';
            if (orderStatus === 'cancelled') {
              statusDisplay = 'Cancelled';
            } else if (item.received && parseInt(item.received) > 0) {
              statusDisplay = 'Received';
            }
            
            tr.innerHTML = `
              <td style="padding:12px;">${escapeHtml(item.item)}</td>
              <td style="padding:12px;">${escapeHtml(item.unit)}</td>
              <td style="padding:12px;text-align:center;">${item.ordered}</td>
              <td style="padding:12px;text-align:center;">${statusDisplay}</td>
            `;
            tbody.appendChild(tr);
          });
          
          modal.style.display = 'flex';
        } else {
          notify(data.error || 'Failed to load order details', 'error');
        }
      })
      .catch(() => notify('Request failed', 'error'));
  };

  window.closeViewOrderModal = function() {
    const modal = document.getElementById('viewOrderModal');
    if (modal) modal.style.display = 'none';
  };

  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  function loadOrders() {
    const tbody = document.getElementById('orders_table_body');
    if (!tbody) return;

    const searchEl = document.getElementById('search_bar_orders');
    const fd = new FormData();
    if (searchEl && searchEl.value) fd.append('search', searchEl.value);
    // Optional supplier filter from URL
    const params = new URLSearchParams(window.location.search);
    const sid = params.get('supplier_id');
    if (sid) fd.append('supplier_id', sid);

    fetch(ORDERS_PATH + 'orders_database.php', { method: 'POST', body: fd })
      .then(r => r.text())
      .then(html => { tbody.innerHTML = html; })
      .catch(() => { tbody.innerHTML = '<tr><td colspan="8" style="color:#c00">Failed to load orders.</td></tr>'; });
  }

  // Expose reload for future use
  window.reloadOrders = loadOrders;

  // Live search if field exists
  document.addEventListener('DOMContentLoaded', () => {
    loadOrders();
    const newBtn = document.getElementById('orderss');
    if (newBtn) newBtn.addEventListener('click', openCreateOrderModal);
    const searchEl = document.getElementById('search_bar_orders');
    if (searchEl) {
      let t = null;
      searchEl.addEventListener('input', () => {
        clearTimeout(t); t = setTimeout(loadOrders, 250);
      });
    }

    // Check for supplier_id or new_order in URL or sessionStorage
    const urlParams = new URLSearchParams(window.location.search);
    const supplierId = urlParams.get('supplier_id');
    const newOrder = urlParams.get('new_order');
    if (newOrder && supplierId) {
      // Try to get supplier name from suppliers endpoint
      fetch(ORDERS_PATH + 'get_suppliers.php')
        .then(r => r.text())
        .then(text => {
          try {
            const d = JSON.parse(text);
            let supplierName = 'Supplier';
            if (d.success && Array.isArray(d.suppliers)) {
              const found = d.suppliers.find(s => s.SupplierID == supplierId);
              if (found) supplierName = found.SupplierName;
            }
            openCreateOrderModal(supplierId, supplierName);
          } catch(e) {
            console.error('JSON parse error in get_suppliers:', e, text);
            openCreateOrderModal(supplierId, 'Supplier');
          }
        })
        .catch(err => {
          console.error('Error fetching suppliers:', err);
          openCreateOrderModal(supplierId, 'Supplier');
        });
    } else if (sessionStorage.getItem('new_order_supplier_id')) {
      // Fallback for sessionStorage
      const sid = sessionStorage.getItem('new_order_supplier_id');
      fetch(ORDERS_PATH + 'get_suppliers.php')
        .then(r => r.text())
        .then(text => {
          try {
            const d = JSON.parse(text);
            let supplierName = 'Supplier';
            if (d.success && Array.isArray(d.suppliers)) {
              const found = d.suppliers.find(s => s.SupplierID == sid);
              if (found) supplierName = found.SupplierName;
            }
            openCreateOrderModal(sid, supplierName);
            sessionStorage.removeItem('new_order_supplier_id');
          } catch(e) {
            console.error('JSON parse error in get_suppliers:', e, text);
            openCreateOrderModal(sid, 'Supplier');
            sessionStorage.removeItem('new_order_supplier_id');
          }
        })
        .catch(err => {
          console.error('Error fetching suppliers:', err);
          openCreateOrderModal(sid, 'Supplier');
          sessionStorage.removeItem('new_order_supplier_id');
        });
    }

    // Close modal when clicking outside
    window.addEventListener('click', (e) => {
      const modal = document.getElementById('viewOrderModal');
      if (e.target === modal) closeViewOrderModal();
      const modal2 = document.getElementById('createOrderModal');
      if (e.target === modal2) closeCreateOrderModal();
      const modal3 = document.getElementById('receiveOrderModal');
      if (e.target === modal3) closeReceiveOrderModal();
      const modal4 = document.getElementById('reportIssueModal');
      if (e.target === modal4) closeReportIssueModal();
    });
  });

  // ================= Receive Order Modal =================
  let currentReceiveOrderId = null;
  let receiveItemsData = [];

  window.openReceiveOrderModal = function(orderId) {
    currentReceiveOrderId = orderId;
    const modal = document.getElementById('receiveOrderModal');
    const title = document.getElementById('receive_order_title');
    if (title) title.textContent = `Record Delivery: ${orderId}`;
    
    // Load order details
    fetch(ORDERS_PATH + 'get_order_details.php?order_id=' + orderId)
      .then(r => r.json())
      .then(data => {
        if (data.success && Array.isArray(data.items)) {
          receiveItemsData = data.items.map(item => ({
            supplierItemId: item.supplier_item_id,
            itemName: item.item_name,
            ordered: item.quantity,
            expiryDate: ''
          }));
          renderReceiveItems();
        }
      })
      .catch(err => {
        console.error('Error loading order details:', err);
        if (typeof window.showNotification === 'function') {
          window.showNotification('Failed to load order details', 'error');
        } else {
          alert('Failed to load order details');
        }
      });
    
    if (modal) modal.style.display = 'flex';
  };

  window.closeReceiveOrderModal = function() {
    const modal = document.getElementById('receiveOrderModal');
    if (modal) modal.style.display = 'none';
    currentReceiveOrderId = null;
    receiveItemsData = [];
  };

  // No user dropdown needed; receiver name is free-text

  function renderReceiveItems() {
    const tbody = document.getElementById('receive_order_items_body');
    if (!tbody) return;
    
    tbody.innerHTML = '';
    receiveItemsData.forEach((item, index) => {
      const tr = document.createElement('tr');
      tr.style.borderBottom = '1px solid #e5e7eb';
      
      tr.innerHTML = `
        <td style="padding: 16px; color: #111827; font-weight: 500;">${escapeHtml(item.itemName)}</td>
        <td style="padding: 16px; text-align: center; color: #6b7280;">${item.ordered}</td>
        <td style="padding: 16px; text-align: center;">
          <input type="date" 
                 value="${item.expiryDate}"
                 onchange="updateExpiryDate(${index}, this.value)"
                 style="padding: 8px 10px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 14px;">
        </td>
        <td style="padding: 16px; text-align: center;">
          <button type="button" 
                  onclick="openReportIssueForItem(${index})"
                  style="padding: 8px 16px; background: #ef4444; color: white; border: none; border-radius: 6px; cursor: pointer; font-size: 14px; font-weight: 500; display: inline-flex; align-items: center; gap: 6px;">
            <span style="font-size: 16px;">⚠</span> Report Issue
          </button>
        </td>
      `;
      tbody.appendChild(tr);
    });
  }

  window.updateExpiryDate = function(index, value) {
    receiveItemsData[index].expiryDate = value;
  };

  window.openReportIssueForItem = function(index) {
    currentIssueItemIndex = index;
    const item = receiveItemsData[index];
    const modal = document.getElementById('reportIssueModal');
    const title = document.getElementById('report_issue_title');
    const qtyInput = document.getElementById('return_quantity');
    
    if (title) title.textContent = `Report Issue for ${item.itemName}`;
    if (qtyInput) {
      qtyInput.max = item.ordered;
      qtyInput.value = Math.min(1, item.ordered);
    }
    
    if (modal) modal.style.display = 'flex';
  };

  window.closeReportIssueModal = function() {
    const modal = document.getElementById('reportIssueModal');
    if (modal) modal.style.display = 'none';
    currentIssueItemIndex = null;
    document.getElementById('return_quantity').value = 1;
    document.getElementById('return_reason').value = '';
  };

  window.submitIssueReport = function() {
    if (currentIssueItemIndex === null) return;
    
    const qty = parseInt(document.getElementById('return_quantity').value) || 0;
    const reason = document.getElementById('return_reason').value.trim();
    
    if (qty <= 0) {
      notify('Please enter a valid return quantity', 'error');
      return;
    }
    
    if (!reason) {
      notify('Please provide a reason for return', 'error');
      return;
    }
    
    const item = receiveItemsData[currentIssueItemIndex];
    item.issues.push({ quantity: qty, reason: reason });
    
    // Update accept and return quantities
    const totalReturn = item.issues.reduce((sum, issue) => sum + issue.quantity, 0);
    item.accept = item.ordered - totalReturn;
    item.return = totalReturn;
    
    renderReceiveItems();
    closeReportIssueModal();
    notify('Issue reported successfully', 'success');
  };

  window.confirmDelivery = function() {
    const receivedBy = document.getElementById('received_by_input')?.value.trim() || '';
    const receivedDate = document.getElementById('received_date_input')?.value.trim() || '';
    const receivedTime = document.getElementById('received_time_input')?.value.trim() || '';
    const recordedBy = document.getElementById('recorded_by_input')?.value || '';
    const description = document.getElementById('receive_description')?.value.trim() || '';
    
    if (!receivedBy) {
      notify('Please enter who received the delivery', 'error');
      return;
    }
    if (!receivedDate) {
      notify('Please enter the date received', 'error');
      return;
    }
    if (!receivedTime) {
      notify('Please enter the time received', 'error');
      return;
    }
    
    const formData = new FormData();
    formData.append('order_id', currentReceiveOrderId);
    formData.append('received_by', receivedBy);
    formData.append('received_date', receivedDate);
    formData.append('received_time', receivedTime);
    formData.append('recorded_by', recordedBy);
    formData.append('description', description);
    formData.append('items', JSON.stringify(receiveItemsData));
    
    fetch(ORDERS_PATH + 'receive_order.php', {
      method: 'POST',
      body: formData
    })
    .then(r => {
      if (!r.ok) {
        throw new Error('Server returned ' + r.status);
      }
      return r.text();
    })
    .then(text => {
      try {
        const data = JSON.parse(text);
        if (data.success) {
          notify(data.message || 'Order received successfully!', 'success');
          closeReceiveOrderModal();
          loadOrders();
        } else {
          notify(data.error || 'Failed to receive order', 'error');
        }
      } catch(e) {
        console.error('JSON parse error:', e);
        console.error('Response text:', text);
        notify('Server error: Invalid response', 'error');
      }
    })
    .catch(err => {
      console.error(err);
      notify('Network error. Please try again.', 'error');
    });
  };

  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  // Toggle action menu for order actions
  window.toggleActionMenu = function(event, btn) {
    event.stopPropagation();
    const dropdown = btn.nextElementSibling;
    
    // Close all other dropdowns
    document.querySelectorAll('.action-dropdown').forEach(d => {
      if (d !== dropdown) d.style.display = 'none';
    });
    
    if (dropdown.style.display === 'block') {
      dropdown.style.display = 'none';
    } else {
      dropdown.style.display = 'block';
    }
  };

  // Close dropdowns when clicking outside
  document.addEventListener('click', () => {
    document.querySelectorAll('.action-dropdown').forEach(d => {
      d.style.display = 'none';
    });
  });

})();