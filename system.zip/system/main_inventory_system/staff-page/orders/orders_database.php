<?php
// Staff page orders database - uses admin orders database
require(__DIR__ . "/../../admin-page/orders/orders_database.php");
?>
