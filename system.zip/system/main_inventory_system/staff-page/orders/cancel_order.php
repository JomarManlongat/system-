<?php
// Staff page cancel order - uses admin cancel order
require(__DIR__ . "/../../admin-page/orders/cancel_order.php");
?>
