<?php
// Staff page get items by supplier - uses admin get items by supplier
require(__DIR__ . "/../../admin-page/orders/get_items_by_supplier.php");
?>
