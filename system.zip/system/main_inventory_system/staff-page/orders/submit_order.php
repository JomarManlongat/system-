<?php
// Staff page submit order - uses admin submit order
require(__DIR__ . "/../../admin-page/orders/submit_order.php");
?>
