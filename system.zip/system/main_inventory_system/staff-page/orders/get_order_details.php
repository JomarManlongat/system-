<?php
// Staff page get order details - uses admin get order details
require(__DIR__ . "/../../admin-page/orders/get_order_details.php");
?>
