<?php
// Staff page get suppliers - uses admin get suppliers
require(__DIR__ . "/../../admin-page/orders/get_suppliers.php");
?>
