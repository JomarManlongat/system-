<?php
// Staff page receive order - uses admin receive order NEW version
require(__DIR__ . "/../../admin-page/orders/receive_order_new.php");
?>
