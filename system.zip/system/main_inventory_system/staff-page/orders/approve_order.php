<?php
// Staff page approve order - uses admin approve order
require(__DIR__ . "/../../admin-page/orders/approve_order.php");
?>
