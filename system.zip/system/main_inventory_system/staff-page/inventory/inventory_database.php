<?php
// Staff page inventory database - uses admin inventory database
require(__DIR__ . "/../../admin-page/inventory/inventory_database.php");
?>
