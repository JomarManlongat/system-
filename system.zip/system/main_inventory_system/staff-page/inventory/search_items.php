<?php
// Staff page search items - uses admin search items
require(__DIR__ . "/../../admin-page/inventory/search_items.php");
?>
