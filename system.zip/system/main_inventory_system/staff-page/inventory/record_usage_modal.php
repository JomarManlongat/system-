<?php
// Staff page record usage modal - uses admin record usage modal
require(__DIR__ . "/../../admin-page/inventory/record_usage_modal.php");
?>
