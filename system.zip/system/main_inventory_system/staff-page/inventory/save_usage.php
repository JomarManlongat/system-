<?php
// Staff page save usage - uses admin save usage
require(__DIR__ . "/../../admin-page/inventory/save_usage.php");
?>
