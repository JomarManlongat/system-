<?php
// Staff proxy to admin get_measurements
require(__DIR__ . "/../../admin-page/suppliers/get_measurements.php");
