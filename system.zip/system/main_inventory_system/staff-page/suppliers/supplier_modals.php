<?php
// Staff page supplier modals - uses admin supplier modals
require(__DIR__ . "/../../admin-page/suppliers/supplier_modals.php");
