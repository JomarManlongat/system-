<?php
// Staff proxy to admin manage_suppliers
require(__DIR__ . "/../../admin-page/suppliers/manage_suppliers.php");
