<?php
// Staff page add supplier - uses admin add supplier
require(__DIR__ . "/../../admin-page/suppliers/add_supplier.php");
