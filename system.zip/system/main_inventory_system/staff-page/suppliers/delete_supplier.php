<?php
// Staff page delete supplier - uses admin delete supplier
require(__DIR__ . "/../../admin-page/suppliers/delete_supplier.php");
