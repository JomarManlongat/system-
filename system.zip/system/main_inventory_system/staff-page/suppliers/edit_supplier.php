<?php
// Staff page edit supplier - uses admin edit supplier
require(__DIR__ . "/../../admin-page/suppliers/edit_supplier.php");
