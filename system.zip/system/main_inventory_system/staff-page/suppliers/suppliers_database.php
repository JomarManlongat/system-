<?php
// Staff page suppliers database - uses admin suppliers database
require(__DIR__ . "/../../admin-page/suppliers/suppliers_database.php");
