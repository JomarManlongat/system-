<?php
// Staff proxy to admin get_items_by_supplier
require(__DIR__ . "/../../admin-page/suppliers/get_items_by_supplier.php");
