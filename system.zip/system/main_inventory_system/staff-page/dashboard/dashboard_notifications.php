<?php
require(__DIR__ . "/../../login/database-account.php");

// Fetch recent notifications from both notifications table and alerts table
// First, check if notifications table exists
$hasNotifications = $conn->query("SHOW TABLES LIKE 'notifications'");
$notifications = [];

if ($hasNotifications && $hasNotifications->num_rows > 0) {
    $query = "SELECT title, message, type, created_at FROM notifications ORDER BY created_at DESC LIMIT 5";
    $result = $conn->query($query);
    while ($row = $result->fetch_assoc()) {
        $notifications[] = [
            'title' => $row['title'],
            'message' => $row['message'],
            'type' => $row['type'],
            'created_at' => $row['created_at']
        ];
    }
}

// Fetch recent alerts (Pending status only)
$alertQuery = "SELECT a.Type, a.Details, a.Status, si.ItemName, a.AlertID
               FROM alerts a
               LEFT JOIN items i ON i.ItemID = a.ItemID
               LEFT JOIN supplieritems si ON i.SupplierItemID = si.SupplierItemID
               WHERE a.Status = 'Pending'
               ORDER BY a.AlertID DESC
               LIMIT 10";
$alertResult = $conn->query($alertQuery);

if ($alertResult) {
    while ($row = $alertResult->fetch_assoc()) {
        $itemName = $row['ItemName'] ?: 'Unknown Item';
        $alertType = $row['Type'];
        $details = $row['Details'];
        
        $notifications[] = [
            'title' => $alertType . ' - ' . $itemName,
            'message' => $details,
            'type' => 'alert',
            'created_at' => null // Alerts don't have timestamp in current schema
        ];
    }
}

// Sort by created_at if available, or keep order
if (empty($notifications)) {
    echo "<li class='notification' style='text-align:center;color:#999;padding:20px;'>No recent notifications</li>";
} else {
    // Limit to 10 most recent
    $notifications = array_slice($notifications, 0, 10);
    
    foreach ($notifications as $notif) {
        $type = strtolower(trim($notif['type']));
        $statusClass = "status";
        $statusLabel = ucfirst($type);

        // Map type → badge class/label
        if ($type === "pending") {
            $statusClass .= " pending";
            $statusLabel = "Pending";
        } elseif ($type === "resolved") {
            $statusClass .= " resolved";
            $statusLabel = "Resolved";
        } elseif ($type === "added") {
            $statusClass .= " added";
            $statusLabel = "Added";
        } elseif ($type === "alert") {
            $statusClass .= " pending";
            $statusLabel = "Alert";
        } else {
            $statusClass .= " pending";
            $statusLabel = "Pending";
        }

        echo "
        <li class='notification'>
            <div class='details'>
                <p class='title'>".htmlspecialchars($notif['title'])."</p>
                <p class='subtitle'>".htmlspecialchars($notif['message'])."</p>
            </div>
            <div class='$statusClass'>$statusLabel</div>
        </li>";
    }
}
?>
