<?php
// Staff page issues database - uses admin issues database
require(__DIR__ . "/../../admin-page/issues/issues_database.php");
?>
