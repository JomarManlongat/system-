<?php
// Staff page return to supplier - uses admin return to supplier
require(__DIR__ . "/../../admin-page/issues/return_to_supplier.php");
?>
