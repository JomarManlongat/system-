<?php
// Staff page reports database - uses admin reports database
require(__DIR__ . "/../../admin-page/reports/reports_database.php");
?>
