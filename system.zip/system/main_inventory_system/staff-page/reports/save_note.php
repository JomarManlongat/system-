<?php
// Staff page save note - uses admin save note
require(__DIR__ . "/../../admin-page/reports/save_note.php");
?>
