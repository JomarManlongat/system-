<?php
// Staff page get locations - uses admin get locations
require(__DIR__ . "/../../admin-page/reports/get_locations.php");
?>
