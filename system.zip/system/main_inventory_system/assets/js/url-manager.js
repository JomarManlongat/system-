/**
 * URL Navigation Manager
 * Handles clean URL updates when navigating between pages
 * Usage: Call updateURL('pageName') whenever page changes
 */

(function() {
    'use strict';

    // Configuration based on system type
    const config = {
        isInventory: window.location.pathname.includes('/main_inventory_system/'),
        isRestaurant: window.location.pathname.includes('/HotelLuneraRestaurant/'),
        baseUrl: getBaseUrl()
    };

    function getBaseUrl() {
        const pathname = window.location.pathname;
        if (pathname.includes('/main_inventory_system/')) {
            return '/system/main_inventory_system/';
        } else if (pathname.includes('/HotelLuneraRestaurant/')) {
            return '/system/HotelLuneraRestaurant/';
        }
        return '/';
    }

    /**
     * Update URL based on page name
     * @param {string} pageName - The page name (e.g., 'inventory', 'dashboard', 'orders')
     * @param {boolean} replaceState - If true, replaces history; if false, pushes new state
     */
    window.updateURL = function(pageName, replaceState = false) {
        if (!pageName || typeof pageName !== 'string') {
            console.warn('Invalid page name:', pageName);
            return;
        }

        // Clean page name (remove .php if included, lowercase, trim)
        const cleanPageName = pageName
            .replace(/\.php$/i, '')
            .toLowerCase()
            .trim();

        // Build new URL
        let newUrl = config.baseUrl + cleanPageName;

        // Get current query parameters (except 'page' parameter)
        const params = new URLSearchParams(window.location.search);
        params.delete('page');

        // Append remaining parameters if any
        const queryString = params.toString();
        if (queryString) {
            newUrl += '?' + queryString;
        }

        // Update browser history and URL
        const method = replaceState ? 'replaceState' : 'pushState';
        window.history[method](
            { page: cleanPageName },
            `${cleanPageName.charAt(0).toUpperCase() + cleanPageName.slice(1)} - Hotel Lunera`,
            newUrl
        );

        // Store in sessionStorage for reference
        sessionStorage.setItem('currentPage', cleanPageName);

        console.log(`[URL Update] Page: ${cleanPageName}, URL: ${newUrl}`);
    };

    /**
     * Get current page name from URL
     * @returns {string} Current page name
     */
    window.getCurrentPage = function() {
        const pathname = window.location.pathname;
        const baseUrl = config.baseUrl;
        
        if (pathname === baseUrl || pathname === baseUrl + 'index') {
            return 'login'; // Redirects to login anyway
        }

        // Extract page name from URL
        const pageName = pathname
            .replace(baseUrl, '')
            .split('?')[0]
            .split('/')[0]
            .toLowerCase();

        return pageName || 'login';
    };

    /**
     * Initialize URL on page load
     */
    window.initializeURL = function(defaultPage = null) {
        const currentPage = window.getCurrentPage();
        
        if (defaultPage && (currentPage === '' || currentPage === 'login')) {
            window.updateURL(defaultPage, true);
        } else if (currentPage && currentPage !== 'login') {
            // Ensure current page is in sessionStorage
            sessionStorage.setItem('currentPage', currentPage);
        }
    };

    /**
     * Navigate to a page and update URL
     * @param {string} pageName - Page to navigate to
     */
    window.navigateTo = function(pageName) {
        window.updateURL(pageName);
        // Page should load via your existing navigation system
        // If using AJAX, this just updates the URL
    };

    /**
     * Handle back/forward browser navigation
     */
    window.addEventListener('popstate', function(event) {
        const page = event.state?.page || window.getCurrentPage();
        sessionStorage.setItem('currentPage', page);
        console.log(`[Navigation] Navigated to: ${page}`);
    });

    // Initialize on page load
    document.addEventListener('DOMContentLoaded', function() {
        window.initializeURL();
        console.log('[URL Manager] Initialized');
    });

})();
