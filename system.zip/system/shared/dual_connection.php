<?php
/**
 * Dual Database Connection
 * Connects to both hotel_restaurant and inventory_managementdb databases
 * Used for cross-system operations and synchronization
 */

$servername = "localhost";
$username = "root";
$password = "Jojenjusjmjai09";

// Connection to Restaurant Database
$conn_restaurant = new mysqli($servername, $username, $password, "hotel_restaurant");
if ($conn_restaurant->connect_error) {
    die("Restaurant DB Connection failed: " . $conn_restaurant->connect_error);
}

// Connection to Inventory Database
$conn_inventory = new mysqli($servername, $username, $password, "inventory_managementdb");
if ($conn_inventory->connect_error) {
    die("Inventory DB Connection failed: " . $conn_inventory->connect_error);
}

// Helper function to execute queries on both databases
function execute_on_both($query_restaurant, $query_inventory) {
    global $conn_restaurant, $conn_inventory;
    
    $result1 = $conn_restaurant->query($query_restaurant);
    $result2 = $conn_inventory->query($query_inventory);
    
    return ['restaurant' => $result1, 'inventory' => $result2];
}
?>
