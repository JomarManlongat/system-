<?php
/**
 * SSO Bridge - Single Sign-On between Restaurant and Inventory Systems
 * Allows restaurant users to seamlessly access inventory system without separate login
 * 
 * IMPORTANT: This file must handle BOTH session contexts
 */

// First, start the RESTAURANT session to get user credentials
session_name('RESTAURANT_SESSION');
session_start();

// Check if user is coming from restaurant system
if (!isset($_SESSION['sso_source'])) {
    $_SESSION['sso_source'] = 'direct';
}

// Function to authenticate from restaurant to inventory
function authenticate_restaurant_user() {
    // Check if user is logged in to RESTAURANT system
    if (isset($_SESSION['role']) && isset($_SESSION['username'])) {
        $restaurant_role = $_SESSION['role'];
        $restaurant_username = $_SESSION['username'];
        $restaurant_user_id = $_SESSION['user_id'] ?? null;
        
        // Map restaurant role to inventory role
        $inventory_role = 'staff'; // Default
        if ($restaurant_role === 'admin') {
            $inventory_role = 'admin';
        }
        
        // Check if corresponding inventory user exists
        require_once __DIR__ . '/../main_inventory_system/login/database-account.php';
        
        $stmt = $conn->prepare("SELECT UserID, username, Name, Roles FROM users WHERE username = ? LIMIT 1");
        $stmt->bind_param('s', $restaurant_username);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            // User exists in inventory system
            $user = $result->fetch_assoc();
            
            // Close RESTAURANT session and switch to INVENTORY session
            session_write_close();
            session_name('INVENTORY_SESSION');
            session_start();
            
            // Set inventory session variables
            $_SESSION['UserID'] = $user['UserID'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['user_name'] = $user['Name'];
            $_SESSION['roles'] = $user['Roles'];
            $_SESSION['Role'] = $user['Roles'];
            $_SESSION['sso_authenticated'] = true;
            $_SESSION['return_to_restaurant'] = true;
            
            return true;
        } else {
            // Create inventory user automatically
            $hashed_password = password_hash('temp_' . $restaurant_username, PASSWORD_DEFAULT);
            $insert = $conn->prepare("INSERT INTO users (username, password, Name, Roles, Status) VALUES (?, ?, ?, ?, 'Active')");
            $name = ucfirst($restaurant_username);
            $insert->bind_param('ssss', $restaurant_username, $hashed_password, $name, $inventory_role);
            
            if ($insert->execute()) {
                $new_user_id = $conn->insert_id;
                
                // Close RESTAURANT session and switch to INVENTORY session
                session_write_close();
                session_name('INVENTORY_SESSION');
                session_start();
                
                // Set inventory session variables
                $_SESSION['UserID'] = $new_user_id;
                $_SESSION['username'] = $restaurant_username;
                $_SESSION['user_name'] = $name;
                $_SESSION['roles'] = $inventory_role;
                $_SESSION['Role'] = $inventory_role;
                $_SESSION['sso_authenticated'] = true;
                $_SESSION['return_to_restaurant'] = true;
                
                return true;
            }
        }
    }
    
    return false;
}

// Function to check if user should return to restaurant
function should_return_to_restaurant() {
    // Must check INVENTORY session since that's what would be active when this is called
    if (session_status() === PHP_SESSION_NONE || session_name() !== 'INVENTORY_SESSION') {
        session_write_close();
        session_name('INVENTORY_SESSION');
        session_start();
    }
    return isset($_SESSION['return_to_restaurant']) && $_SESSION['return_to_restaurant'] === true;
}
?>
