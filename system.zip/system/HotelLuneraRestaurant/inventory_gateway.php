<?php
/**
 * Inventory Access Gateway for Restaurant System
 * Allows restaurant users to access inventory system in same tab with SSO
 */

session_name('RESTAURANT_SESSION');
session_start();
require_once __DIR__ . '/../shared/sso_bridge.php';

// Check if user is logged in to restaurant
if (!isset($_SESSION['role']) || !isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

// Authenticate user for inventory system
if (authenticate_restaurant_user()) {
    // Authentication successful, sessions have been switched to INVENTORY by sso_bridge
    // Mark that user came from restaurant (should already be set by authenticate_restaurant_user)
    $_SESSION['sso_source'] = 'restaurant';
    // Do not override an existing explicit user location (set at login).
    if (!isset($_SESSION['user_location']) || empty($_SESSION['user_location'])) {
        $_SESSION['user_location'] = 'Restaurant';
    }
    
    // Redirect to inventory system based on role
    $inventory_role = $_SESSION['Role'] ?? 'staff';
    
    if (strtolower($inventory_role) === 'admin') {
        header("Location: ../main_inventory_system/admin-page/admin_inv_man.php");
    } else {
        header("Location: ../main_inventory_system/staff-page/staff_inv_man.php");
    }
    exit;
} else {
    // SSO failed, show error
    $error_message = "Unable to authenticate with inventory system. Please contact administrator.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accessing Inventory System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .loading-container {
            text-align: center;
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
        }
        .spinner {
            border: 4px solid #f3f3f3;
            border-top: 4px solid #667eea;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            animation: spin 1s linear infinite;
            margin: 0 auto 20px;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        .error {
            color: #dc3545;
            margin-top: 20px;
        }
        .back-btn {
            margin-top: 20px;
            padding: 10px 20px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }
        .back-btn:hover {
            background: #5568d3;
        }
    </style>
</head>
<body>
    <div class="loading-container">
        <?php if (isset($error_message)): ?>
            <div class="error">
                <h2>❌ Authentication Failed</h2>
                <p><?php echo htmlspecialchars($error_message); ?></p>
                <a href="admin/admin.php" class="back-btn">← Back to Restaurant Dashboard</a>
            </div>
        <?php else: ?>
            <div class="spinner"></div>
            <h2>Accessing Inventory System...</h2>
            <p>Please wait while we authenticate your session.</p>
        <?php endif; ?>
    </div>
</body>
</html>
