-- Quick Setup Guide for Ingredient Management System
-- Execute this in phpMyAdmin or MySQL command line

-- 1. First, make sure you're using the correct database
USE hotel_restaurant;

-- 2. Check if new tables were created successfully
SHOW TABLES LIKE '%ingredient%';
-- Expected output: current_ingredients_stock, ingredient_usage_log, menu_ingredients, stock_transfer_log

-- 3. Verify sample ingredients were inserted
SELECT COUNT(*) as total_ingredients FROM current_ingredients_stock;
-- Expected: 35 ingredients

-- 4. View all available ingredients
SELECT id, ingredient_name, unit, current_quantity, min_quantity 
FROM current_ingredients_stock 
ORDER BY ingredient_name;

-- 5. Check which menu items need ingredients assigned
SELECT m.id, m.name, m.category,
       COALESCE(COUNT(mi.id), 0) as ingredient_count
FROM menu m
LEFT JOIN menu_ingredients mi ON mi.menu_id = m.id
GROUP BY m.id, m.name, m.category
ORDER BY ingredient_count ASC, m.name;
-- Items with ingredient_count = 0 need ingredients assigned

-- 6. Example: Assign ingredients to a menu item (Iced Cola - ID 35)
-- Delete this section after testing, this is just an example
/*
INSERT INTO menu_ingredients (menu_id, ingredient_id, quantity_required) VALUES
(35, (SELECT id FROM current_ingredients_stock WHERE ingredient_name = 'Cola Syrup'), 0.05),
(35, (SELECT id FROM current_ingredients_stock WHERE ingredient_name = 'Sugar'), 0.03),
(35, (SELECT id FROM current_ingredients_stock WHERE ingredient_name = 'Ice'), 0.20);
*/

-- 7. View ingredient requirements for all menu items
SELECT m.name as menu_item, 
       cis.ingredient_name, 
       mi.quantity_required,
       cis.unit
FROM menu m
JOIN menu_ingredients mi ON mi.menu_id = m.id
JOIN current_ingredients_stock cis ON cis.id = mi.ingredient_id
ORDER BY m.name, cis.ingredient_name;

-- 8. Check for low stock items
SELECT ingredient_name, 
       current_quantity, 
       min_quantity,
       unit,
       (min_quantity - current_quantity) as shortage
FROM current_ingredients_stock
WHERE current_quantity <= min_quantity
ORDER BY shortage DESC;

-- 9. View recent ingredient usage
SELECT iul.usage_date,
       cis.ingredient_name,
       iul.quantity_used,
       cis.unit,
       iul.order_id,
       iul.notes
FROM ingredient_usage_log iul
JOIN current_ingredients_stock cis ON cis.id = iul.ingredient_id
ORDER BY iul.usage_date DESC
LIMIT 20;

-- 10. View stock transfer history
SELECT stl.transfer_date,
       cis.ingredient_name,
       stl.quantity_transferred,
       cis.unit,
       stl.transferred_by,
       stl.notes
FROM stock_transfer_log stl
JOIN current_ingredients_stock cis ON cis.id = stl.ingredient_id
ORDER BY stl.transfer_date DESC
LIMIT 20;

-- 11. Calculate total value of inventory (if you add cost_per_unit later)
-- This is a placeholder for future enhancement
/*
SELECT SUM(current_quantity * cost_per_unit) as total_inventory_value
FROM current_ingredients_stock;
*/

-- 12. Test the stock transfer process (example)
-- This simulates receiving stock from main inventory system
/*
-- Add 10kg of Rice
CALL receive_stock_manual('Rice', 10.00, 'Test Transfer', 'Initial stock test');

-- Create a stored procedure for easy stock transfers
DELIMITER //
CREATE PROCEDURE receive_stock_manual(
    IN p_ingredient_name VARCHAR(100),
    IN p_quantity DECIMAL(10,2),
    IN p_transferred_by VARCHAR(100),
    IN p_notes VARCHAR(255)
)
BEGIN
    DECLARE v_ingredient_id INT;
    
    -- Get ingredient ID
    SELECT id INTO v_ingredient_id 
    FROM current_ingredients_stock 
    WHERE ingredient_name = p_ingredient_name;
    
    IF v_ingredient_id IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Ingredient not found';
    END IF;
    
    -- Update stock
    UPDATE current_ingredients_stock 
    SET current_quantity = current_quantity + p_quantity
    WHERE id = v_ingredient_id;
    
    -- Log transfer
    INSERT INTO stock_transfer_log (ingredient_id, quantity_transferred, transferred_by, notes)
    VALUES (v_ingredient_id, p_quantity, p_transferred_by, p_notes);
    
    SELECT 'Stock transferred successfully' as message;
END //
DELIMITER ;
*/

-- 13. Verify the system is ready
SELECT 'System Ready!' as status,
       (SELECT COUNT(*) FROM current_ingredients_stock) as total_ingredients,
       (SELECT COUNT(*) FROM menu) as total_menu_items,
       (SELECT COUNT(*) FROM menu_ingredients) as menu_items_with_ingredients,
       (SELECT COUNT(*) FROM current_ingredients_stock WHERE current_quantity <= min_quantity) as low_stock_items;

-- All done! Your ingredient management system is ready to use.
