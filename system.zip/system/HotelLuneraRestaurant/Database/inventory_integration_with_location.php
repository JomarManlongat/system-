<?php
/**
 * INTEGRATION GUIDE FOR MAIN INVENTORY SYSTEM
 * 
 * This file should be placed in your main_inventory_system
 * Call this function when a staff records usage from inventory.
 * 
 * IMPORTANT: This assumes your inventory system has a 'user_location' field
 * that indicates whether the user is in 'restaurant' or 'room' or other areas.
 */

/**
 * Transfer stock to Hotel Restaurant based on user location
 * 
 * @param string $ingredient_name Name of the ingredient
 * @param float $quantity Quantity to transfer
 * @param string $user_location User's location ('restaurant' or 'room')
 * @param string $transferred_by Username or name of person recording usage
 * @param string $notes Optional notes
 * @return array Response from the API
 */
function recordUsageAndTransfer($ingredient_name, $quantity, $user_location, $transferred_by, $notes = '') {
    // Restaurant API endpoint
    $api_url = 'http://localhost/HotelLuneraRestaurant/admin/receive_stock.php';
    
    // Prepare data including user location
    $data = [
        'ingredient_name' => $ingredient_name,
        'quantity' => $quantity,
        'user_location' => $user_location, // IMPORTANT: Pass the user's location
        'transferred_by' => $transferred_by,
        'notes' => $notes
    ];
    
    // Initialize cURL
    $ch = curl_init($api_url);
    
    // Set cURL options
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    
    // Execute request
    $response = curl_exec($ch);
    
    // Check for errors
    if (curl_errno($ch)) {
        $error = curl_error($ch);
        curl_close($ch);
        return [
            'status' => 'error',
            'message' => 'Connection error: ' . $error
        ];
    }
    
    curl_close($ch);
    
    // Decode JSON response
    $result = json_decode($response, true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        return [
            'status' => 'error',
            'message' => 'Invalid response from restaurant API'
        ];
    }
    
    return $result;
}

/**
 * EXAMPLE USAGE IN YOUR INVENTORY SYSTEM
 * 
 * When staff records usage, call this function:
 */

// Example 1: Staff in RESTAURANT location records usage
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['record_usage'])) {
    
    // Get data from your form
    $ingredient_name = $_POST['ingredient_name'] ?? '';
    $quantity = floatval($_POST['quantity'] ?? 0);
    $user_location = $_POST['user_location'] ?? 'unknown'; // From your user table
    $transferred_by = $_SESSION['username'] ?? 'Unknown';
    
    // Validate
    if (empty($ingredient_name) || $quantity <= 0) {
        $error = 'Please provide valid ingredient name and quantity';
    } else {
        // Record the usage in YOUR inventory system first
        // ... your code to update inventory_managementdb ...
        
        // Then try to transfer to restaurant if user is in restaurant location
        $result = recordUsageAndTransfer(
            $ingredient_name, 
            $quantity, 
            $user_location,  // Pass the user's location
            $transferred_by, 
            'Staff usage recorded'
        );
        
        // Handle the response
        if ($result['status'] === 'success') {
            $success = 'Usage recorded and transferred to restaurant: ' . $quantity . ' units of ' . $ingredient_name;
        } elseif ($result['status'] === 'skipped') {
            // This is normal - user is not in restaurant location
            $info = 'Usage recorded in inventory. Not transferred to restaurant (User location: ' . $user_location . ')';
        } else {
            $error = 'Usage recorded in inventory, but transfer failed: ' . ($result['message'] ?? 'Unknown error');
        }
    }
}

/**
 * INTEGRATION FLOW:
 * 
 * 1. Staff logs in to inventory system
 * 2. System knows staff location (restaurant or room)
 * 3. Staff records usage of ingredients
 * 4. System saves to inventory_managementdb
 * 5. System calls recordUsageAndTransfer() with location
 * 6. If location = 'restaurant': Stock transfers to hotel_restaurant database
 * 7. If location = 'room' or other: Stock stays in inventory system only
 */

/**
 * DATABASE STRUCTURE ASSUMPTION:
 * 
 * In your inventory_managementdb, you should have:
 * 
 * users table:
 * - user_id
 * - username
 * - location (VARCHAR: 'restaurant', 'room', 'kitchen', etc.)
 * 
 * usage_records table (or similar):
 * - id
 * - item_name
 * - quantity
 * - user_id
 * - recorded_at
 * - transferred_to_restaurant (BOOLEAN: 1 if transferred, 0 if not)
 */

/**
 * SAMPLE FORM FOR YOUR INVENTORY SYSTEM:
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Record Ingredient Usage</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input, select { width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px; }
        button { background: #800000; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; }
        .success { background: #d4edda; color: #155724; padding: 12px; border-radius: 4px; margin-bottom: 15px; }
        .error { background: #f8d7da; color: #721c24; padding: 12px; border-radius: 4px; margin-bottom: 15px; }
        .info { background: #d1ecf1; color: #0c5460; padding: 12px; border-radius: 4px; margin-bottom: 15px; }
    </style>
</head>
<body>
    <h1>Record Ingredient Usage</h1>
    
    <?php if (isset($success)): ?>
        <div class="success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>
    
    <?php if (isset($error)): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    
    <?php if (isset($info)): ?>
        <div class="info"><?= htmlspecialchars($info) ?></div>
    <?php endif; ?>
    
    <form method="POST">
        <div class="form-group">
            <label>Staff Name/Username:</label>
            <input type="text" name="username" value="<?= $_SESSION['username'] ?? '' ?>" readonly>
        </div>
        
        <div class="form-group">
            <label>Your Location:</label>
            <select name="user_location" required>
                <option value="">-- Select Location --</option>
                <option value="restaurant">Restaurant</option>
                <option value="room">Room Service</option>
                <option value="kitchen">Main Kitchen</option>
                <option value="bar">Bar</option>
            </select>
            <small>If 'Restaurant' is selected, stock will auto-transfer to restaurant system</small>
        </div>
        
        <div class="form-group">
            <label>Ingredient Name:</label>
            <input type="text" name="ingredient_name" required placeholder="e.g., Rice, Sugar, Oil">
        </div>
        
        <div class="form-group">
            <label>Quantity Used:</label>
            <input type="number" name="quantity" step="0.01" min="0.01" required>
        </div>
        
        <button type="submit" name="record_usage">Record Usage</button>
    </form>
    
    <div style="margin-top: 30px; padding: 15px; background: #f9f9f9; border-left: 4px solid #800000;">
        <h3>How it works:</h3>
        <ul>
            <li>Select your location (Restaurant or Room)</li>
            <li>Enter ingredient and quantity used</li>
            <li>Click "Record Usage"</li>
            <li><strong>If location = Restaurant:</strong> Stock transfers to restaurant database automatically</li>
            <li><strong>If location = Room:</strong> Stock stays in main inventory only (for room service system)</li>
        </ul>
    </div>
</body>
</html>

<?php
/**
 * RESPONSE TYPES YOU'LL RECEIVE:
 * 
 * Success (transferred to restaurant):
 * {
 *     "status": "success",
 *     "message": "Stock transferred successfully to restaurant",
 *     "new_quantity": 75.50,
 *     "user_location": "restaurant"
 * }
 * 
 * Skipped (not restaurant location):
 * {
 *     "status": "skipped",
 *     "message": "Transfer skipped - user location is not restaurant (location: room)",
 *     "user_location": "room"
 * }
 * 
 * Error (ingredient not found or other error):
 * {
 *     "status": "error",
 *     "message": "Ingredient not found in restaurant inventory"
 * }
 */

/**
 * IMPORTANT NOTES:
 * 
 * 1. The ingredient name must EXACTLY match what's in the restaurant database
 *    (case-sensitive matching)
 * 
 * 2. User location must be 'restaurant' (case-insensitive) for transfer to happen
 * 
 * 3. If transfer fails, the usage is still recorded in YOUR system
 * 
 * 4. You can log all transfer attempts in your database for audit trail
 * 
 * 5. The restaurant system will automatically:
 *    - Update ingredient quantities
 *    - Log the transfer
 *    - Calculate costs when orders are processed
 */

/**
 * TESTING THE INTEGRATION:
 * 
 * Test 1: Record usage with location = 'restaurant'
 * Expected: Stock should appear in hotel_restaurant.current_ingredients_stock
 * 
 * Test 2: Record usage with location = 'room'
 * Expected: Stock stays only in inventory_managementdb, not transferred
 * 
 * Test 3: Record usage with wrong ingredient name
 * Expected: Returns error "Ingredient not found"
 * 
 * Test 4: Check stock_transfer_log table
 * Expected: All successful restaurant transfers should be logged
 */
?>
