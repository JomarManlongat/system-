<?php
/**
 * Stock Transfer Integration Example
 * 
 * This file demonstrates how the main_inventory_system should call
 * the Hotel Restaurant API to transfer stock.
 * 
 * Place this in your main_inventory_system and call it when transferring stock.
 */

/**
 * Transfer stock to Hotel Restaurant
 * 
 * @param string $ingredient_name Name of the ingredient
 * @param float $quantity Quantity to transfer
 * @param string $transferred_by Username or name of person transferring
 * @param string $notes Optional notes
 * @return array Response from the API
 */
function transferStockToRestaurant($ingredient_name, $quantity, $transferred_by, $notes = '') {
    // Restaurant API endpoint
    $api_url = 'http://localhost/HotelLuneraRestaurant/admin/receive_stock.php';
    
    // Prepare data
    $data = [
        'ingredient_name' => $ingredient_name,
        'quantity' => $quantity,
        'transferred_by' => $transferred_by,
        'notes' => $notes
    ];
    
    // Initialize cURL
    $ch = curl_init($api_url);
    
    // Set cURL options
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    
    // Execute request
    $response = curl_exec($ch);
    
    // Check for errors
    if (curl_errno($ch)) {
        $error = curl_error($ch);
        curl_close($ch);
        return [
            'status' => 'error',
            'message' => 'Connection error: ' . $error
        ];
    }
    
    curl_close($ch);
    
    // Decode JSON response
    $result = json_decode($response, true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        return [
            'status' => 'error',
            'message' => 'Invalid response from restaurant API'
        ];
    }
    
    return $result;
}

/**
 * Example usage in your stock transfer form handler
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['transfer_to_restaurant'])) {
    // Get form data
    $ingredient_name = $_POST['ingredient_name'] ?? '';
    $quantity = floatval($_POST['quantity'] ?? 0);
    $transferred_by = $_SESSION['username'] ?? 'Unknown';
    $notes = $_POST['notes'] ?? 'Stock transfer from main inventory';
    
    // Validate
    if (empty($ingredient_name) || $quantity <= 0) {
        $error = 'Please provide valid ingredient name and quantity';
    } else {
        // Transfer stock
        $result = transferStockToRestaurant($ingredient_name, $quantity, $transferred_by, $notes);
        
        if ($result['status'] === 'success') {
            $success = 'Successfully transferred ' . $quantity . ' units of ' . $ingredient_name . ' to restaurant';
            
            // TODO: Update your own inventory database here
            // Deduct the transferred quantity from main inventory
            
        } else {
            $error = 'Transfer failed: ' . ($result['message'] ?? 'Unknown error');
        }
    }
}

/**
 * Example: Get list of ingredients that restaurant uses
 * This helps you know which items can be transferred
 */
function getRestaurantIngredients() {
    $api_url = 'http://localhost/HotelLuneraRestaurant/admin/get_ingredients.php';
    
    $ch = curl_init($api_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    $result = json_decode($response, true);
    
    if ($result && $result['status'] === 'success') {
        return $result['ingredients'];
    }
    
    return [];
}

/**
 * Example: Bulk transfer multiple ingredients
 */
function bulkTransferStock($transfers, $transferred_by) {
    $results = [];
    
    foreach ($transfers as $transfer) {
        $result = transferStockToRestaurant(
            $transfer['ingredient_name'],
            $transfer['quantity'],
            $transferred_by,
            $transfer['notes'] ?? ''
        );
        
        $results[] = [
            'ingredient' => $transfer['ingredient_name'],
            'quantity' => $transfer['quantity'],
            'result' => $result
        ];
    }
    
    return $results;
}

/**
 * Example usage of bulk transfer:
 * 
 * $transfers = [
 *     ['ingredient_name' => 'Rice', 'quantity' => 50, 'notes' => 'Weekly restock'],
 *     ['ingredient_name' => 'Sugar', 'quantity' => 25, 'notes' => 'Weekly restock'],
 *     ['ingredient_name' => 'Oil', 'quantity' => 10, 'notes' => 'Weekly restock']
 * ];
 * 
 * $results = bulkTransferStock($transfers, $_SESSION['username']);
 */

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transfer Stock to Restaurant</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background: #f5f5f5;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 {
            color: #333;
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
        }
        input, select, textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
            box-sizing: border-box;
        }
        button {
            background: #800000;
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
        }
        button:hover {
            background: #600000;
        }
        .message {
            padding: 12px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        .success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Transfer Stock to Restaurant</h1>
        
        <?php if (isset($success)): ?>
            <div class="message success"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>
        
        <?php if (isset($error)): ?>
            <div class="message error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="form-group">
                <label for="ingredient_name">Ingredient Name:</label>
                <input type="text" id="ingredient_name" name="ingredient_name" required 
                       placeholder="e.g., Rice, Sugar, Oil">
                <small style="color: #666;">Must match exactly with restaurant ingredient name</small>
            </div>
            
            <div class="form-group">
                <label for="quantity">Quantity:</label>
                <input type="number" id="quantity" name="quantity" step="0.01" min="0.01" required>
                <small style="color: #666;">Amount to transfer (in ingredient's unit)</small>
            </div>
            
            <div class="form-group">
                <label for="notes">Notes (Optional):</label>
                <textarea id="notes" name="notes" rows="3" placeholder="e.g., Weekly restock, Emergency refill"></textarea>
            </div>
            
            <button type="submit" name="transfer_to_restaurant">Transfer Stock</button>
        </form>
        
        <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd;">
            <h3>Available Restaurant Ingredients:</h3>
            <div style="max-height: 200px; overflow-y: auto; background: #f9f9f9; padding: 10px; border-radius: 4px;">
                <?php
                $ingredients = getRestaurantIngredients();
                if (!empty($ingredients)) {
                    echo '<ul style="margin: 0; padding-left: 20px;">';
                    foreach ($ingredients as $ing) {
                        echo '<li>' . htmlspecialchars($ing['ingredient_name']) . 
                             ' (' . htmlspecialchars($ing['unit']) . ') - ' .
                             'Current: ' . htmlspecialchars($ing['current_quantity']) . '</li>';
                    }
                    echo '</ul>';
                } else {
                    echo '<p style="color: #666;">Could not load ingredients. Check API connection.</p>';
                }
                ?>
            </div>
        </div>
    </div>
</body>
</html>
