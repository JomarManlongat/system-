<?php
session_name('RESTAURANT_SESSION');
session_start();
include 'connection.php';
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Not logged in']);
    exit;
}
$user_id = intval($_SESSION['user_id']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $order_item_id = intval($_POST['order_item_id'] ?? 0);
    $action = $_POST['action'] ?? '';

    if ($order_item_id > 0 && in_array($action, ['add', 'minus', 'delete'], true)) {
        // Ensure the item belongs to the current user's pending order
        $sql = "SELECT oi.id, oi.quantity FROM order_items oi
                JOIN orders o ON o.id = oi.order_id
                WHERE oi.id=? AND o.user_id=? AND o.status='pending' LIMIT 1";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('ii', $order_item_id, $user_id);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($res && $res->num_rows > 0) {
            $row = $res->fetch_assoc();
            $quantity = (int)$row['quantity'];

            if ($action === 'add') {
                $quantity++;
                $upd = $conn->prepare("UPDATE order_items SET quantity=? WHERE id=?");
                $upd->bind_param('ii', $quantity, $order_item_id);
                $upd->execute();
            } elseif ($action === 'minus') {
                if ($quantity > 1) {
                    $quantity--;
                    $upd = $conn->prepare("UPDATE order_items SET quantity=? WHERE id=?");
                    $upd->bind_param('ii', $quantity, $order_item_id);
                    $upd->execute();
                } else {
                    $del = $conn->prepare("DELETE FROM order_items WHERE id=?");
                    $del->bind_param('i', $order_item_id);
                    $del->execute();
                }
            } elseif ($action === 'delete') {
                $del = $conn->prepare("DELETE FROM order_items WHERE id=?");
                $del->bind_param('i', $order_item_id);
                $del->execute();
            }

            echo json_encode(['status' => 'success']);
            exit;
        }
    }
}

echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
