/**
 * URL Navigation Manager for Restaurant System
 * Handles clean URL updates when navigating between pages
 */

(function() {
    'use strict';

    const config = {
        baseUrl: '/system/HotelLuneraRestaurant/'
    };

    /**
     * Update URL based on page name
     * @param {string} pageName - The page name (e.g., 'menu', 'orders', 'admin')
     * @param {boolean} replaceState - If true, replaces history; if false, pushes new state
     */
    window.updateURL = function(pageName, replaceState = false) {
        if (!pageName || typeof pageName !== 'string') {
            console.warn('Invalid page name:', pageName);
            return;
        }

        // Clean page name
        const cleanPageName = pageName
            .replace(/\.php$/i, '')
            .toLowerCase()
            .trim();

        // Build new URL
        let newUrl = config.baseUrl + cleanPageName;

        // Get current query parameters
        const params = new URLSearchParams(window.location.search);
        params.delete('page');

        // Append remaining parameters if any
        const queryString = params.toString();
        if (queryString) {
            newUrl += '?' + queryString;
        }

        // Update browser history and URL
        const method = replaceState ? 'replaceState' : 'pushState';
        window.history[method](
            { page: cleanPageName },
            `${cleanPageName.charAt(0).toUpperCase() + cleanPageName.slice(1)} - Hotel Lunera Restaurant`,
            newUrl
        );

        // Store in sessionStorage
        sessionStorage.setItem('currentPage', cleanPageName);

        console.log(`[URL Update] Page: ${cleanPageName}, URL: ${newUrl}`);
    };

    /**
     * Get current page name from URL
     * @returns {string} Current page name
     */
    window.getCurrentPage = function() {
        const pathname = window.location.pathname;
        
        if (pathname === config.baseUrl || pathname === config.baseUrl + 'index') {
            return 'menu'; // Default to menu
        }

        // Extract page name from URL
        const pageName = pathname
            .replace(config.baseUrl, '')
            .split('?')[0]
            .split('/')[0]
            .toLowerCase();

        return pageName || 'menu';
    };

    /**
     * Initialize URL on page load
     */
    window.initializeURL = function(defaultPage = 'menu') {
        const currentPage = window.getCurrentPage();
        
        if (currentPage === '' || currentPage === 'index') {
            window.updateURL(defaultPage, true);
        } else {
            sessionStorage.setItem('currentPage', currentPage);
        }
    };

    /**
     * Navigate to a page and update URL
     * @param {string} pageName - Page to navigate to
     */
    window.navigateTo = function(pageName) {
        window.updateURL(pageName);
    };

    /**
     * Handle back/forward browser navigation
     */
    window.addEventListener('popstate', function(event) {
        const page = event.state?.page || window.getCurrentPage();
        sessionStorage.setItem('currentPage', page);
        console.log(`[Navigation] Navigated to: ${page}`);
    });

    // Initialize on page load
    document.addEventListener('DOMContentLoaded', function() {
        window.initializeURL();
        console.log('[URL Manager] Initialized for Restaurant System');
    });

})();
