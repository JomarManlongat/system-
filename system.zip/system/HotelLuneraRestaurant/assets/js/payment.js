/**
 * Payment page script
 * Location: /assets/js/payment.js
 * Responsibilities:
 *  - Show/hide notification modal for flash messages
 */

document.addEventListener('DOMContentLoaded', () => {
  const modal = document.getElementById('notificationModal');
  const titleEl = document.getElementById('notificationTitle');
  const messageEl = document.getElementById('notificationMessage');
  const closeBtn = document.getElementById('notificationCloseBtn');
  const okBtn = document.getElementById('notificationOkBtn');

  function showNotification(message, title = 'Notification') {
    if (!modal) return;
    titleEl.textContent = title;
    messageEl.textContent = message;
    modal.style.display = 'flex';
  }

  function closeNotification() {
    if (!modal) return;
    modal.style.display = 'none';
  }

  closeBtn?.addEventListener('click', closeNotification);
  okBtn?.addEventListener('click', closeNotification);
  modal?.addEventListener('click', (e) => {
    if (e.target === modal) closeNotification();
  });

  // Flash messages via data attributes
  const flash = document.getElementById('paymentFlash');
  if (flash) {
    const success = flash.getAttribute('data-success') || '';
    const error = flash.getAttribute('data-error') || '';
    if (success) showNotification(success, 'Success');
    else if (error) showNotification(error, 'Error');
  }
});
