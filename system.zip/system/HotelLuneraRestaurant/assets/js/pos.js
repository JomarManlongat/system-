/**
 * POS (Cashier) UI Script
 * Location: /assets/js/pos.js
 * Responsibilities:
 *  - Order interactions (add/update/load)
 *  - Payment modals and cash validation
 *  - Receipt rendering and printing
 */

// -- Order interactions --
function addToOrder(menuId, category) {
  let sugarLevel = "100%";
  if (category === "Beverages") {
      sugarLevel = document.getElementById('sugar_level_' + menuId)?.value || "100%";
  }
  fetch('add_to_order.php', {
      method: 'POST',
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      body: 'menu_id=' + menuId + '&sugar_level=' + encodeURIComponent(sugarLevel)
  }).then(res => res.json()).then(data => {
      if (data.status === 'success') loadOrders();
      else alert(data.message);
  });
}

function loadOrders() {
  fetch('fetch_order.php').then(res => res.text()).then(html => {
      document.querySelector('.order-list').innerHTML = html;
  });
}

function updateOrder(orderItemId, action) {
  const body = new URLSearchParams();
  body.append('order_item_id', orderItemId);
  body.append('action', action);
  
  fetch('update_order.php', {
      method: 'POST',
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      body: body.toString()
  }).then(res => res.json()).then(data => {
      if (data.status === 'success') {
          loadOrders(); // Refresh the order panel
      } else {
          alert(data.message || 'Failed to update order');
      }
  }).catch(err => {
      console.error(err);
      alert('Error updating order');
  });
}

// -- Payment modals --
function openPaymentPopup() {
  document.getElementById('paymentModal').style.display = 'flex';
}
function closePaymentPopup() {
  document.getElementById('paymentModal').style.display = 'none';
}
function selectPayment(method) {
  closePaymentPopup();
  if (method === 'Cash') {
      document.getElementById('cashModal').style.display = 'flex';
  } else {
      showReceipt(method);
  }
}
function closeCashModal() {
  document.getElementById('cashModal').style.display = 'none';
}
// -- Cash validation and flow --
function processCashPayment() {
  const amount = parseFloat(document.getElementById('cashAmount').value);
  
  // Get the total from the current order
  const totalText = document.querySelector('.order-list')?.textContent || '';
  const totalMatch = totalText.match(/Total:\s*₱([\d,]+\.?\d*)/);
  const orderTotal = totalMatch ? parseFloat(totalMatch[1].replace(/,/g, '')) : 0;
  
  if (isNaN(amount) || amount <= 0) {
      alert("Please enter a valid cash amount.");
      return;
  }
  
  if (amount < orderTotal) {
      alert("Insufficient payment. Amount tendered is less than the total order.");
      return;
  }
  
  closeCashModal();
  showReceipt('Cash', amount);
}

// ✅ UPDATED showReceipt (now shows sugar level properly)
// -- Receipt rendering & sale finalization --
async function showReceipt(method, cashAmount = 0) {
  const cashierName = document.querySelector('meta[name="cashier-name"]')?.content || 'Cashier';
  const res = await fetch('fetch_order.php');
  const html = await res.text();

  const temp = document.createElement('div');
  temp.innerHTML = html;
  const items = temp.querySelectorAll('.order-item');
  let lines = '', total = 0;

  items.forEach(item => {
      const name = item.querySelector('.item-name')?.textContent.trim();
      const price = parseFloat((item.querySelector('.item-price')?.textContent || '').replace('₱','')) || 0;
      const qty = parseInt(item.querySelector('.qty-display')?.textContent) || 1;
      const sugarInfo = item.querySelector('.sugar-info')?.textContent.replace('Sugar Level:','').trim() || '';
      const sub = price * qty;
      total += sub;
      lines += `
          <tr>
              <td>${qty}x</td>
              <td>${name}${sugarInfo ? `<div class='sugar-note'>Sugar: ${sugarInfo}</div>` : ''}</td>
              <td class='right'>₱${sub.toFixed(2)}</td>
          </tr>`;
  });

  let extraRows = '';
  if (method === 'Cash' && cashAmount > 0) {
      const diff = cashAmount - total;
      extraRows = `
          <tr><td colspan='2'>Cash</td><td class='right'>₱${cashAmount.toFixed(2)}</td></tr>
          <tr><td colspan='2'>Change</td><td class='right'>₱${diff.toFixed(2)}</td></tr>`;
  }

  // Finalize sale first to get order id
  const body = new URLSearchParams();
  body.append('payment_method', method);
  try {
      const resp = await fetch('clear_order.php', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: body.toString() });
      const j = await resp.json();
      if (j.status !== 'success') {
          alert(j.message || 'Failed to finalize order');
      }
  } catch (e) {
      console.error(e);
  }

  const now = new Date();
  const ts = now.toLocaleString();
  const receiptHTML = `
      <div id='receiptPaper' class='receipt-paper'>
          <div class='receipt-header'>
              <div class='brand'>LUNERA RESTAURANT</div>
              <div class='muted'>Hotel Lunera • POS Receipt</div>
          </div>
          <div class='meta'>
              <div>Date/Time: ${ts}</div>
              <div>Cashier: ${cashierName}</div>
              <div>Payment: ${method}</div>
          </div>
          <table class='items'>
              <tbody>
                  ${lines || `<tr><td colspan='3' class='center muted'>No items</td></tr>`}
              </tbody>
          </table>
          <div class='totals'>
              <div class='row'><span>Total</span><span>₱${total.toFixed(2)}</span></div>
          </div>
          ${extraRows ? `<table class='extras'><tbody>${extraRows}</tbody></table>` : ''}
          <div class='thankyou'>Thank you for dining with us!</div>
      </div>`;

  document.getElementById('receiptContent').innerHTML = receiptHTML;
  document.getElementById('receiptModal').style.display = 'flex';

  // Refresh current order panel (now empty)
  setTimeout(loadOrders, 400);
}

function closeReceipt() {
  document.getElementById('receiptModal').style.display = 'none';
}

// -- Bootstrap
document.addEventListener('DOMContentLoaded', loadOrders);

// Print Receipt button handler
document.addEventListener('click', (e) => {
  if (e.target && e.target.id === 'printReceiptBtn') {
      window.print();
  }
});

// Auto-close receipt after print is confirmed/completed
window.addEventListener('afterprint', () => {
  const receiptModal = document.getElementById('receiptModal');
  if (receiptModal && receiptModal.style.display === 'flex') {
      receiptModal.style.display = 'none';
      loadOrders(); // Reload for next order
  }
});
