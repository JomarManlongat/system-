<?php
// Use separate session name for restaurant system to prevent session collision with inventory
session_name('RESTAURANT_SESSION');
session_start();
include("connection.php");

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    // Convert password to MD5 hash para tumugma sa database
    $hashed_password = md5($password);

    $stmt = $conn->prepare("SELECT * FROM login WHERE username=? AND password=? LIMIT 1");
    if (!$stmt) {
        die("Database query failed: " . $conn->error);
    }

    $stmt->bind_param("ss", $username, $hashed_password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];

        // Redirect based on role
        if ($user['role'] === 'admin') {
            header("Location: admin/admin.php");
        } else {
            header("Location: index.php");
        }
        exit();
    } else {
        $error = "Invalid username or password!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lunera Hotel - Restaurant Login</title>
    <link rel="stylesheet" href="assets/css/login.css">
</head>
<body>
    <div class="main-container">
        <!-- Login Card (Center) -->
        <div class="login-container">
            <div class="login-card">
                <div class="login-header">
                    <div class="hotel-name">LUNERA HOTEL</div>
                    <div class="restaurant-label">Restaurant Management System</div>
                </div>
                
                <div class="login-body">
                    <div class="welcome-text">
                        <h2>Welcome Back</h2>
                        <p>Please sign in to continue</p>
                    </div>

                    <?php if ($error != ""): ?>
                        <div class="error-message">
                            <?= htmlspecialchars($error) ?>
                        </div>
                    <?php endif; ?>

                    <form method="POST">
                        <div class="form-group">
                            <label>Username</label>
                            <div class="input-wrapper">
                                <input type="text" name="username" placeholder="Enter your username" required autocomplete="username">
                            </div>
                        </div>

                        <div class="form-group">
                            <label>Password</label>
                            <div class="input-wrapper">
                                <input type="password" name="password" placeholder="Enter your password" required autocomplete="current-password">
                            </div>
                        </div>

                        <button type="submit" class="btn-login">Sign In</button>
                    </form>
                </div>

                <div class="login-footer">
                    © 2025 Lunera Hotel. All rights reserved.
                </div>
            </div>
        </div>
    </div>
</body>
</html>
