<?php
session_name('RESTAURANT_SESSION');
session_start();
include 'connection.php';
header('Content-Type: application/json');

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
  echo json_encode(['status'=>'error','message'=>'Unauthorized']);
  exit;
}

// Get period from request (today, week, month, year)
$period = $_GET['period'] ?? 'today';

// Determine date range based on period
$dateCondition = '';
switch($period) {
    case 'today':
        $dateCondition = "DATE(iul.usage_date) = CURDATE()";
        break;
    case 'week':
        $weekStart = date('Y-m-d', strtotime('monday this week'));
        $dateCondition = "DATE(iul.usage_date) >= '$weekStart'";
        break;
    case 'month':
        $month = date('Y-m');
        $dateCondition = "DATE_FORMAT(iul.usage_date, '%Y-%m') = '$month'";
        break;
    case 'year':
        $year = date('Y');
        $dateCondition = "YEAR(iul.usage_date) = $year";
        break;
    default:
        $dateCondition = "1=1"; // All time
}

// Calculate total ingredient cost for the period
$query = "SELECT 
    SUM(iul.quantity_used * cis.cost_per_unit) as total_cost
    FROM ingredient_usage_log iul
    JOIN current_ingredients_stock cis ON cis.id = iul.ingredient_id
    WHERE $dateCondition";

$result = $conn->query($query);
$totalCost = 0;

if ($result) {
    $row = $result->fetch_assoc();
    $totalCost = floatval($row['total_cost'] ?? 0);
}

// Get revenue for the same period
$revenueCondition = str_replace('iul.usage_date', 'o.order_date', $dateCondition);
$revenueQuery = "SELECT IFNULL(SUM(oi.quantity * m.price), 0) AS total_revenue
    FROM orders o
    JOIN order_items oi ON oi.order_id = o.id
    JOIN menu m ON m.id = oi.menu_id
    WHERE o.status = 'completed' AND $revenueCondition";

$revenueResult = $conn->query($revenueQuery);
$totalRevenue = 0;

if ($revenueResult) {
    $row = $revenueResult->fetch_assoc();
    $totalRevenue = floatval($row['total_revenue'] ?? 0);
}

// Calculate actual profit
$actualProfit = $totalRevenue - $totalCost;
$profitMargin = $totalRevenue > 0 ? ($actualProfit / $totalRevenue) * 100 : 0;

echo json_encode([
    'status' => 'success',
    'period' => $period,
    'total_revenue' => $totalRevenue,
    'total_cost' => $totalCost,
    'actual_profit' => $actualProfit,
    'profit_margin' => $profitMargin
]);

$conn->close();
?>
