<?php
session_name('RESTAURANT_SESSION');
session_start();
include 'connection.php';
header('Content-Type: application/json');

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

// Get all menu items with their ingredient requirements
$query = "SELECT DISTINCT m.id as menu_id, m.name, m.status
    FROM menu m
    LEFT JOIN menu_ingredients mi ON mi.menu_id = m.id
    LEFT JOIN current_ingredients_stock cis ON cis.id = mi.ingredient_id
    WHERE m.status = 'available'";

$result = $conn->query($query);
$itemsToDisable = [];

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $menuId = $row['menu_id'];
        
        // Check if any ingredient is depleted or insufficient for this menu item
        $checkQuery = "SELECT mi.ingredient_id, mi.quantity_required, 
            cis.ingredient_name, cis.current_quantity
            FROM menu_ingredients mi
            JOIN current_ingredients_stock cis ON cis.id = mi.ingredient_id
            WHERE mi.menu_id = $menuId";
        
        $checkResult = $conn->query($checkQuery);
        $hasInsufficientStock = false;
        $depletedIngredients = [];
        
        if ($checkResult) {
            while ($ing = $checkResult->fetch_assoc()) {
                // Check if stock is 0 or less than required for even 1 serving
                if ($ing['current_quantity'] <= 0 || $ing['current_quantity'] < $ing['quantity_required']) {
                    $hasInsufficientStock = true;
                    $depletedIngredients[] = $ing['ingredient_name'] . ' (need ' . $ing['quantity_required'] . ', have ' . $ing['current_quantity'] . ')';
                }
            }
        }
        
        if ($hasInsufficientStock) {
            $itemsToDisable[] = [
                'menu_id' => $menuId,
                'name' => $row['name'],
                'depleted_ingredients' => $depletedIngredients
            ];
            
            // Auto-disable the menu item
            $conn->query("UPDATE menu SET status = 'unavailable' WHERE id = $menuId");
        }
    }
}

// Also check for items with no ingredients assigned
$noIngredientsQuery = "SELECT m.id as menu_id, m.name 
    FROM menu m
    LEFT JOIN menu_ingredients mi ON mi.menu_id = m.id
    WHERE m.status = 'available' AND mi.id IS NULL";

$noIngResult = $conn->query($noIngredientsQuery);
if ($noIngResult && $noIngResult->num_rows > 0) {
    while ($row = $noIngResult->fetch_assoc()) {
        $itemsToDisable[] = [
            'menu_id' => $row['menu_id'],
            'name' => $row['name'],
            'depleted_ingredients' => ['No ingredients assigned']
        ];
        // Keep these available - they might be non-ingredient items
    }
}

echo json_encode([
    'status' => 'success',
    'disabled_count' => count($itemsToDisable),
    'disabled_items' => $itemsToDisable
]);

$conn->close();
?>
