<?php
// Direct test without session/auth to isolate the issue
error_reporting(E_ALL);
ini_set('display_errors', '1');

echo "<h2>Debug: Testing get_menu_ingredients.php logic</h2>";

include 'connection.php';

$menu_id = 15; // Testing with menu_id 15 (Baked Oysters)

echo "<h3>Step 1: Query menu_ingredients</h3>";
$stmt = $conn->prepare("SELECT id, ingredient_id, ingredient_name, quantity_required FROM menu_ingredients WHERE menu_id = ? ORDER BY ingredient_name");
$stmt->bind_param('i', $menu_id);
$stmt->execute();
$mres = $stmt->get_result();

echo "<p>Found rows: " . $mres->num_rows . "</p>";

$ingredients = [];

if ($mres) {
  while ($mi = $mres->fetch_assoc()) {
    echo "<h4>Processing row:</h4>";
    echo "<pre>" . print_r($mi, true) . "</pre>";
    
    $ingredient_id = intval($mi['ingredient_id'] ?? 0);
    $ingredient_name = $mi['ingredient_name'] ?? null;
    $quantity_required = floatval($mi['quantity_required'] ?? 0);

    echo "<p>ingredient_id: $ingredient_id, ingredient_name: $ingredient_name, quantity_required: $quantity_required</p>";

    $detail = [
      'menu_ingredient_id' => intval($mi['id']),
      'ingredient_id' => $ingredient_id > 0 ? $ingredient_id : null,
      'ingredient_name' => $ingredient_name,
      'quantity_required' => $quantity_required,
      'unit' => null,
      'available_quantity' => 0
    ];

    // Try to fetch current ingredient row by id
    if ($ingredient_id > 0) {
      echo "<p>Trying to lookup ingredient by ID: $ingredient_id</p>";
      $q = $conn->prepare("SELECT id, ingredient_name, unit, quantity FROM current_ingredients_stock WHERE id = ? LIMIT 1");
      if ($q) {
        $q->bind_param('i', $ingredient_id);
        $q->execute();
        $r = $q->get_result();
        if ($r && $row = $r->fetch_assoc()) {
          echo "<p style='color:green'>✓ Found in current stock by ID:</p>";
          echo "<pre>" . print_r($row, true) . "</pre>";
          
          $detail['ingredient_name'] = $row['ingredient_name'];
          $detail['unit'] = $row['unit'] ?? null;
          $detail['available_quantity'] = floatval($row['quantity'] ?? 0);
          $ingredients[] = $detail;
          $q->close();
          
          echo "<p style='color:blue'>Added to ingredients array (continue loop)</p>";
          continue; // resolved by id
        } else {
          echo "<p style='color:orange'>⚠ Not found in current stock by ID $ingredient_id</p>";
        }
        $q->close();
      }
    } else {
      echo "<p>No valid ingredient_id, will try by name</p>";
    }

    // If not found by id, try to resolve by saved ingredient_name
    if ($ingredient_name) {
      echo "<p>Trying to lookup ingredient by name: '$ingredient_name'</p>";
      $safe = $conn->real_escape_string($ingredient_name);
      $aq = $conn->query("SELECT SUM(quantity) AS total_qty, unit FROM current_ingredients_stock WHERE ingredient_name = '$safe' GROUP BY unit LIMIT 1");
      if ($aq && $ar = $aq->fetch_assoc()) {
        echo "<p style='color:green'>✓ Found in current stock by name:</p>";
        echo "<pre>" . print_r($ar, true) . "</pre>";
        
        $detail['available_quantity'] = floatval($ar['total_qty'] ?? 0);
        $detail['unit'] = $ar['unit'] ?? null;
      } else {
        echo "<p style='color:red'>✗ Not found in current stock by name '$ingredient_name'</p>";
      }
    }

    echo "<p style='color:blue'>Adding detail to ingredients array:</p>";
    echo "<pre>" . print_r($detail, true) . "</pre>";
    $ingredients[] = $detail;
  }
}

echo "<h3>Final Result:</h3>";
echo "<p>Total ingredients collected: " . count($ingredients) . "</p>";
echo "<pre>" . print_r($ingredients, true) . "</pre>";

echo "<h3>JSON Output:</h3>";
$json = json_encode(['status' => 'success', 'ingredients' => $ingredients]);
echo "<textarea style='width:100%;height:200px;'>$json</textarea>";

if (json_last_error() !== JSON_ERROR_NONE) {
  echo "<p style='color:red'>JSON Error: " . json_last_error_msg() . "</p>";
}

$stmt->close();
$conn->close();
?>
