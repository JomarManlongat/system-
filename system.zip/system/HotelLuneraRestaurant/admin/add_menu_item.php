<?php
session_name('RESTAURANT_SESSION');
session_start();
include 'connection.php';
header('Content-Type: application/json');

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
  echo json_encode(['status'=>'error','message'=>'Unauthorized']);
  exit;
}

$name = trim($_POST['name'] ?? '');
$category = trim($_POST['category'] ?? '');
$price = floatval($_POST['price'] ?? 0);
$description = trim($_POST['description'] ?? '');
$sugar_levels = trim($_POST['sugar_levels'] ?? '');

if ($name === '') {
  echo json_encode(['status'=>'error','message'=>'Name required']); exit;
}

$image = trim($_POST['image'] ?? 'noimage.jpg');
if ($image === '') $image = 'noimage.jpg';

$stmt = $conn->prepare("INSERT INTO menu (name, description, price, image, status, category, sugar_levels) VALUES (?, ?, ?, ?, 'Available', ?, ?)");
$stmt->bind_param('sdssss', $name, $description, $price, $image, $category, $sugar_levels);
if ($stmt->execute()) {
  $new_menu_id = $conn->insert_id;
  echo json_encode(['status'=>'success', 'menu_id'=>$new_menu_id]);
} else {
  echo json_encode(['status'=>'error','message'=>'DB error']);
}
