/**
 * Admin Dashboard Script
 * Location: /admin/assets/js/admin.js
 * Responsibilities:
 *  - Notifications and CRUD helpers
 *  - Chart rendering for revenue/cost analysis
 *  - Menu management and ingredient tracking
 */

// Verify Chart.js loaded
window.addEventListener('load', function() {
  if (typeof Chart === 'undefined') {
    console.error('Chart.js failed to load!');
    alert('Chart library failed to load. Please check your internet connection and refresh.');
  } else {
    console.log('Chart.js loaded successfully, version:', Chart.version);
  }
});
// End of initial checks

document.addEventListener('DOMContentLoaded', ()=> {
  // Custom notification modal to replace alert()
  const notificationModal = document.getElementById('notificationModal');
  const notificationTitle = document.getElementById('notificationTitle');
  const notificationMessage = document.getElementById('notificationMessage');
  const notificationCloseBtn = document.getElementById('notificationCloseBtn');
  const notificationOkBtn = document.getElementById('notificationOkBtn');

  function showNotification(message, title = 'Notification') {
    if (!notificationModal) return alert(message); // fallback
    notificationTitle.textContent = title;
    notificationMessage.textContent = message;
    notificationModal.style.display = 'block';
    notificationModal.setAttribute('aria-hidden', 'false');
  }

  function closeNotification() {
    if (!notificationModal) return;
    notificationModal.style.display = 'none';
    notificationModal.setAttribute('aria-hidden', 'true');
  }

  notificationCloseBtn?.addEventListener('click', closeNotification);
  notificationOkBtn?.addEventListener('click', closeNotification);
  notificationModal?.addEventListener('click', (e) => {
    if (e.target === notificationModal) closeNotification();
  });

  // No modal-based counters (edit handled via prompts)

  // Toggle status events
  document.querySelectorAll('.toggle-status').forEach(chk => {
    chk.addEventListener('change', function(){
      const tr = this.closest('tr');
      const id = tr.getAttribute('data-id');
      const status = this.checked ? '1' : '0';

      fetch('update_status.php', {
        method: 'POST',
        headers: {'Content-Type':'application/x-www-form-urlencoded'},
        body: 'id=' + encodeURIComponent(id) + '&status=' + encodeURIComponent(status)
      }).then(r => r.json()).then(json => {
        if (json.status !== 'success') {
          showNotification('Update failed', 'Error');
          this.checked = !this.checked;
        }
      }).catch(e => {
        console.error(e);
        this.checked = !this.checked;
      });
    });
  });

  // Add Menu Item button - open modal and submit via AJAX
  const addModal = document.getElementById('addModal');
  const btnAdd = document.getElementById('btnAdd');
  const addCloseBtn = document.getElementById('addCloseBtn');
  const addForm = document.getElementById('addForm');

  function openAddModal(){
    if (!addModal) return;
    addModal.style.display = 'block';
    addModal.setAttribute('aria-hidden','false');
    // Reset form fields
    addForm?.reset();
  }
  function closeAddModal(){
    if (!addModal) return;
    addModal.style.display = 'none';
    addModal.setAttribute('aria-hidden','true');
  }
  btnAdd?.addEventListener('click', openAddModal);
  addCloseBtn?.addEventListener('click', closeAddModal);
  window.addEventListener('keydown', (e)=>{ if (e.key === 'Escape') closeAddModal(); });
  addModal?.addEventListener('click', (e)=>{
    if (e.target === addModal) closeAddModal();
  });

  addForm?.addEventListener('submit', function(e){
    e.preventDefault();
    const name = document.getElementById('add_name').value.trim();
    if (!name) return showNotification('Name is required', 'Error');
    const description = document.getElementById('add_description').value.trim();
    const price = document.getElementById('add_price').value.trim();
    const category = document.getElementById('add_category').value;
    const image = (document.getElementById('add_image').value.trim() || 'noimage.jpg');

    const form = new URLSearchParams();
    form.append('name', name);
    form.append('description', description);
    form.append('price', price);
    form.append('category', category);
    form.append('image', image);
    form.append('sugar_levels', ''); // Always empty - sugar levels selected at cashier

    fetch('add_menu_item.php', {
      method: 'POST',
      headers: {'Content-Type':'application/x-www-form-urlencoded'},
      body: form.toString()
    }).then(r => r.json()).then(j=>{
      if (j.status === 'success') {
        closeAddModal();
        // Open ingredient modal for the new menu item
        openIngredientModal(j.menu_id, name);
      } else {
        showNotification('Add failed: ' + (j.message||''), 'Error');
      }
    }).catch(err => {
      console.error(err);
      showNotification('Error adding item', 'Error');
    });
  });

  // Edit buttons - open edit modal with pre-filled data
  const editModal = document.getElementById('editModal');
  const editCloseBtn = document.getElementById('editCloseBtn');
  const editCancelBtn = document.getElementById('editCancelBtn');
  const editDeleteBtn = document.getElementById('editDeleteBtn');
  const editForm = document.getElementById('editForm');
  let currentEditId = null;

  function openEditModal(itemData){
    if (!editModal) return;
    currentEditId = itemData.id;
    // Fill form with existing data
    document.getElementById('edit_id').value = itemData.id;
    document.getElementById('edit_name').value = itemData.name;
    document.getElementById('edit_description').value = itemData.description || '';
    document.getElementById('edit_price').value = itemData.price;
    document.getElementById('edit_image').value = itemData.image || 'noimage.jpg';
    document.getElementById('edit_category').value = itemData.category;
    
    editModal.style.display = 'block';
    editModal.setAttribute('aria-hidden','false');
  }
  
  function closeEditModal(){
    if (!editModal) return;
    editModal.style.display = 'none';
    editModal.setAttribute('aria-hidden','true');
    currentEditId = null;
  }
  
  editCloseBtn?.addEventListener('click', closeEditModal);
  editCancelBtn?.addEventListener('click', closeEditModal);
  window.addEventListener('keydown', (e)=>{ if (e.key === 'Escape') closeEditModal(); });
  editModal?.addEventListener('click', (e)=>{
    if (e.target === editModal) closeEditModal();
  });

  // Edit form submit
  editForm?.addEventListener('submit', function(e){
    e.preventDefault();
    const id = document.getElementById('edit_id').value;
    const description = document.getElementById('edit_description').value.trim();
    const price = document.getElementById('edit_price').value.trim();
    const category = document.getElementById('edit_category').value;
    const image = document.getElementById('edit_image').value.trim() || 'noimage.jpg';
    const name = document.getElementById('edit_name').value.trim();

    const form = new URLSearchParams();
    form.append('id', id);
    form.append('description', description);
    form.append('price', price);
    form.append('category', category);
    form.append('image', image);
    form.append('sugar_levels', ''); // Always empty - sugar levels selected at cashier

    fetch('edit_menu_item.php', {
      method: 'POST',
      headers: {'Content-Type':'application/x-www-form-urlencoded'},
      body: form.toString()
    }).then(r => r.json()).then(j => {
      if (j.status === 'success') {
        closeEditModal();
        // Open ingredient modal for editing
        openIngredientModal(id, name);
      } else {
        showNotification('Update failed: ' + (j.message || ''), 'Error');
      }
    }).catch(err => {
      console.error(err);
      showNotification('Error updating item', 'Error');
    });
  });

  // Delete button in edit modal
  editDeleteBtn?.addEventListener('click', function(){
    if (!currentEditId) return;
    openDeleteModal(currentEditId);
  });

  // Delete confirmation modal
  const deleteModal = document.getElementById('deleteModal');
  const deleteCloseBtn = document.getElementById('deleteCloseBtn');
  const deleteCancelBtn = document.getElementById('deleteCancelBtn');
  const deleteForm = document.getElementById('deleteForm');
  let deleteItemId = null;

  function openDeleteModal(itemId){
    if (!deleteModal) return;
    deleteItemId = itemId;
    deleteModal.style.display = 'block';
    deleteModal.setAttribute('aria-hidden','false');
    document.getElementById('delete_password').value = '';
  }

  function closeDeleteModal(){
    if (!deleteModal) return;
    deleteModal.style.display = 'none';
    deleteModal.setAttribute('aria-hidden','true');
    deleteItemId = null;
  }

  deleteCloseBtn?.addEventListener('click', closeDeleteModal);
  deleteCancelBtn?.addEventListener('click', closeDeleteModal);
  deleteModal?.addEventListener('click', (e)=>{
    if (e.target === deleteModal) closeDeleteModal();
  });

  deleteForm?.addEventListener('submit', function(e){
    e.preventDefault();
    if (!deleteItemId) return;
    
    const password = document.getElementById('delete_password').value;
    if (!password) return showNotification('Password is required', 'Error');

    const form = new URLSearchParams();
    form.append('id', deleteItemId);
    form.append('password', password);

    fetch('delete_menu_item.php', {
      method: 'POST',
      headers: {'Content-Type':'application/x-www-form-urlencoded'},
      body: form.toString()
    }).then(r => r.json()).then(j => {
      if (j.status === 'success') {
        closeDeleteModal();
        closeEditModal();
        showNotification('Item deleted successfully!', 'Success');
        setTimeout(() => location.reload(), 1500);
      } else {
        showNotification('Delete failed: ' + (j.message || ''), 'Error');
      }
    }).catch(err => {
      console.error(err);
      showNotification('Error deleting item', 'Error');
    });
  });

  // Wire up edit buttons to open modal
  document.querySelectorAll('.edit-btn').forEach(btn => {
    btn.addEventListener('click', function() {
      const tr = this.closest('tr');
      const id = tr.getAttribute('data-id');

      // Fetch current item for defaults (robust JSON parse)
      fetch('get_menu_item.php?id=' + id)
        .then(async r => {
          const text = await r.text();
          try {
            const data = JSON.parse(text);
            if (data.status !== 'success') {
              showNotification(data.message || 'Failed to load item', 'Error');
              return null;
            }
            return data.item;
          } catch (e) {
            console.error('Invalid JSON from get_menu_item.php:', text);
            showNotification('Failed to fetch item', 'Error');
            return null;
          }
        })
        .then(item => { if (item) openEditModal(item); })
        .catch(err => { console.error(err); showNotification('Failed to fetch item', 'Error'); });
    });
  });



  // Chart Modal
  const chartModal = document.getElementById('chartModal');
  const chartCloseBtn = document.getElementById('chartCloseBtn');
  const chartCanvas = document.getElementById('profitChart');
  let profitChartInstance = null;

  function openChartModal(period) {
    const chartData = window.chartData;
    
    if (!chartModal || !chartData || !chartData[period]) {
      console.error('Chart modal error:', { chartModal, chartData, period });
      return;
    }
    
    const data = chartData[period];
    console.log('Opening chart for period:', period, data);
    
    document.getElementById('chartTitle').textContent = data.title;
    document.getElementById('chartSubtitle').textContent = data.subtitle;
    
    chartModal.style.display = 'block';
    chartModal.setAttribute('aria-hidden', 'false');
    
    // Destroy existing chart if any
    if (profitChartInstance) {
      profitChartInstance.destroy();
    }
    
    // Verify Chart.js is loaded
    if (typeof Chart === 'undefined') {
      console.error('Chart.js is not loaded!');
      alert('Chart library is not loaded. Please refresh the page.');
      return;
    }
    
    // Create new chart with both revenue and cost
    const ctx = chartCanvas.getContext('2d');
    
    try {
      profitChartInstance = new Chart(ctx, {
        type: 'bar',
        data: {
          labels: data.labels,
          datasets: [
            {
              label: 'Revenue',
              data: data.profit,
              backgroundColor: 'rgba(40, 167, 69, 0.8)',
              borderColor: 'rgba(40, 167, 69, 1)',
              borderWidth: 1,
              borderRadius: 6
            },
            {
              label: 'Ingredient Cost',
              data: data.loss || [],
              backgroundColor: 'rgba(220, 53, 69, 0.8)',
              borderColor: 'rgba(220, 53, 69, 1)',
              borderWidth: 1,
              borderRadius: 6
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              display: true,
              position: 'bottom'
            },
            tooltip: {
              callbacks: {
                label: function(context) {
                  const label = context.dataset.label || '';
                  return label + ': ₱' + context.parsed.y.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2});
                }
              }
            }
          },
          scales: {
            y: {
              beginAtZero: true,
              ticks: {
                callback: function(value) {
                  return '₱' + value.toLocaleString();
                }
              }
            }
          }
        }
      });
      
      console.log('Chart created successfully');
    } catch (error) {
      console.error('Error creating chart:', error);
      alert('Error creating chart: ' + error.message);
    }
  }

  function closeChartModal() {
    if (!chartModal) return;
    chartModal.style.display = 'none';
    chartModal.setAttribute('aria-hidden', 'true');
    if (profitChartInstance) {
      profitChartInstance.destroy();
      profitChartInstance = null;
    }
  }

  chartCloseBtn?.addEventListener('click', closeChartModal);
  chartModal?.addEventListener('click', (e) => {
    if (e.target === chartModal) closeChartModal();
  });
  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeChartModal();
  });

  // Make openChartModal available globally for onclick
  window.openChartModal = openChartModal;

  // Attach click listeners to metric cards (use data-period) to ensure click works
  try {
    document.querySelectorAll('.card-clickable[data-period]').forEach(el => {
      el.addEventListener('click', function(e) {
        const p = el.getAttribute('data-period');
        if (p) openChartModal(p);
      });
    });
  } catch (err) {
    console.error('Failed to attach card click handlers:', err);
  }

  // --- Profit Monitoring AJAX Pagination ---
  // Handles:
  //  - Filter form (date range)
  //  - Reset to last 7 days
  //  - Next/Previous page navigation
  const profitFilterForm = document.getElementById('profitFilterForm');
  const profitResetBtn = document.getElementById('profitResetBtn');
  
  // Handle filter form submission
  profitFilterForm?.addEventListener('submit', (e) => {
    e.preventDefault();
    const dateFrom = document.getElementById('date_from')?.value || '';
    const dateTo = document.getElementById('date_to')?.value || '';
    loadProfitData(1, dateFrom, dateTo);
  });
  
  // Handle reset button
  profitResetBtn?.addEventListener('click', (e) => {
    e.preventDefault();
    const defaultDateFrom = new Date();
    defaultDateFrom.setDate(defaultDateFrom.getDate() - 6);
    const defaultDateTo = new Date();
    
    document.getElementById('date_from').value = defaultDateFrom.toISOString().split('T')[0];
    document.getElementById('date_to').value = defaultDateTo.toISOString().split('T')[0];
    
    loadProfitData(1, document.getElementById('date_from').value, document.getElementById('date_to').value);
  });
  
  // Handle pagination clicks
  document.addEventListener('click', (e) => {
    if (e.target && e.target.classList.contains('profit-page-btn')) {
      e.preventDefault();
      const targetPage = e.target.getAttribute('data-page');
      const dateFrom = document.getElementById('date_from')?.value || '';
      const dateTo = document.getElementById('date_to')?.value || '';
      
      loadProfitData(targetPage, dateFrom, dateTo);
    }
  });

  function loadProfitData(page, dateFrom, dateTo) {
    // Fetch profits JSON and replace table + pagination
    const tbody = document.getElementById('profitTableBody');
    const pagination = document.getElementById('profitPagination');
    
    if (!tbody || !pagination) return;
    
    // Show loading state
    tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:#666;">Loading...</td></tr>';
    
    // Fetch data
    fetch(`fetch_profits.php?page=${page}&date_from=${encodeURIComponent(dateFrom)}&date_to=${encodeURIComponent(dateTo)}`)
      .then(r => r.json())
      .then(data => {
        if (!data.success) {
          tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:#f44;">Error loading data</td></tr>';
          return;
        }
        
        // Update table body
        if (data.rows.length === 0) {
          tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:#666;">No records in this date range.</td></tr>';
        } else {
          tbody.innerHTML = data.rows.map(p => {
            const profitDate = new Date(p.profit_date);
            const formattedDate = profitDate.getFullYear() + '-' + 
              String(profitDate.getMonth() + 1).padStart(2, '0') + '-' + 
              String(profitDate.getDate()).padStart(2, '0') + ' ' +
              String(profitDate.getHours()).padStart(2, '0') + ':' +
              String(profitDate.getMinutes()).padStart(2, '0') + ':' +
              String(profitDate.getSeconds()).padStart(2, '0');
            
            return `<tr>
              <td>${p.id}</td>
              <td>#${p.order_id}</td>
              <td>${p.cashier || 'Unknown'}</td>
              <td>₱${parseFloat(p.total_amount).toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
              <td>${p.payment_method || 'N/A'}</td>
              <td>${formattedDate}</td>
            </tr>`;
          }).join('');
        }
        
        // Update pagination
        updatePagination(data.page, data.totalPages, data.totalRows, data.dateFrom, data.dateTo);
      })
      .catch(err => {
        console.error('Error loading profit data:', err);
        tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:#f44;">Network error</td></tr>';
      });
  }

  function updatePagination(page, totalPages, totalRows, dateFrom, dateTo) {
    // Rebuild pagination controls dynamically
    const pagination = document.getElementById('profitPagination');
    if (!pagination) return;
    
    pagination.setAttribute('data-page', page);
    pagination.setAttribute('data-total-pages', totalPages);
    pagination.setAttribute('data-total-rows', totalRows);
    
    if (totalPages <= 1) {
      pagination.innerHTML = '';
      return;
    }
    
    let html = '';
    
    if (page > 1) {
      html += `<a href="#" class="btn small profit-page-btn" data-page="${page - 1}">← Previous</a>`;
    }
    
    html += `<span class="page-info">Page ${page} of ${totalPages} (${totalRows} records)</span>`;
    
    if (page < totalPages) {
      html += `<a href="#" class="btn small profit-page-btn" data-page="${parseInt(page) + 1}">Next →</a>`;
    }
    
    pagination.innerHTML = html;
  }

  // --- Category Filter for Menu Management ---
  const categoryButtons = document.querySelectorAll('.category-btn');
  const menuTableRows = document.querySelectorAll('.menu-table tbody tr');

  categoryButtons.forEach(btn => {
    btn.addEventListener('click', function() {
      // Remove active from all buttons
      categoryButtons.forEach(b => b.classList.remove('active'));
      
      // Add active to clicked button
      this.classList.add('active');
      
      // Get selected category
      const selectedCategory = this.getAttribute('data-category');
      
      // Filter table rows
      menuTableRows.forEach(row => {
        const rowCategory = row.getAttribute('data-category');
        
        if (selectedCategory === 'all' || rowCategory === selectedCategory) {
          row.style.display = '';
        } else {
          row.style.display = 'none';
        }
      });
    });
  });

  // --- Ingredient Management System ---
  const ingredientModal = document.getElementById('ingredientModal');
  const ingredientCloseBtn = document.getElementById('ingredientCloseBtn');
  const ingredientForm = document.getElementById('ingredientForm');
  const ingredientsList = document.getElementById('ingredientsList');
  const addIngredientRowBtn = document.getElementById('addIngredientRow');
  let currentMenuIdForIngredients = null;
  let availableIngredients = [];

  // Load available ingredients on page load (with helper to ensure readiness)
  function loadAvailableIngredients() {
    return fetch('get_ingredients.php')
      .then(r => r.json())
      .then(data => {
        if (data.status === 'success') {
          availableIngredients = data.ingredients || [];
        } else {
          availableIngredients = [];
        }
      })
      .catch(err => { console.error('Error loading ingredients:', err); availableIngredients = []; });
  }

  loadAvailableIngredients();

  // Check low stock on page load
  checkLowStock();

  async function openIngredientModal(menuId, menuName) {
    if (!ingredientModal) return;
    currentMenuIdForIngredients = menuId;
    document.getElementById('ingredientModalTitle').textContent = 'Set Ingredients for: ' + menuName;
    
    // Ensure available ingredients are loaded before rendering options
    if (!Array.isArray(availableIngredients) || availableIngredients.length === 0) {
      await loadAvailableIngredients();
    }

    // Load existing ingredients for this menu item
    fetch('get_menu_ingredients_logged.php', {
      method: 'POST',
      headers: {'Content-Type':'application/x-www-form-urlencoded'},
      body: 'menu_id=' + menuId
    })
    .then(async r => {
      const text = await r.text();
      console.log('Raw response from get_menu_ingredients:', text);
      try {
        return JSON.parse(text);
      } catch (e) {
        console.error('Failed to parse JSON. Raw response:', text);
        throw new Error('Invalid JSON response from server');
      }
    })
    .then(data => {
      console.log('get_menu_ingredients response:', data);
      if (data.status === 'success') {
        console.log('Rendering ingredients:', data.ingredients);
        renderIngredientRows(data.ingredients);
        ingredientModal.style.display = 'block';
        ingredientModal.setAttribute('aria-hidden','false');
      } else {
        console.error('Failed to load ingredients:', data.message);
        showNotification('Failed to load ingredients: ' + (data.message || 'Unknown error'), 'Error');
        renderIngredientRows([]);
        ingredientModal.style.display = 'block';
        ingredientModal.setAttribute('aria-hidden','false');
      }
    })
    .catch(err => {
      console.error('Error fetching ingredients:', err);
      showNotification('Error loading ingredients. Check console for details.', 'Error');
      renderIngredientRows([]);
      ingredientModal.style.display = 'block';
      ingredientModal.setAttribute('aria-hidden','false');
    });
  }

  function closeIngredientModal() {
    if (!ingredientModal) return;
    ingredientModal.style.display = 'none';
    ingredientModal.setAttribute('aria-hidden','true');
    currentMenuIdForIngredients = null;
  }

  function renderIngredientRows(existingIngredients) {
    console.log('renderIngredientRows called with:', existingIngredients);
    console.log('availableIngredients:', availableIngredients);
    ingredientsList.innerHTML = '';
    
    if (existingIngredients.length === 0) {
      console.log('No existing ingredients, adding empty row');
      addIngredientRow();
    } else {
      console.log('Rendering', existingIngredients.length, 'ingredient rows');
      existingIngredients.forEach(ing => {
        console.log('Adding row for ingredient:', ing);
        addIngredientRow(ing);
      });
    }
  }

  function addIngredientRow(data = null) {
    const row = document.createElement('div');
    row.className = 'ingredient-row';
    
    let optionsHtml = '<option value="">-- Select Ingredient --</option>';
    availableIngredients.forEach(ing => {
      const selected = data && data.ingredient_id == ing.id ? 'selected' : '';
      optionsHtml += `<option value="${ing.id}" ${selected}>${ing.ingredient_name} (${ing.unit}) - Available: ${ing.current_quantity}</option>`;
    });
    // If we have an existing ingredient_name without a valid id, show it as a placeholder option
    if (data && (!data.ingredient_id || data.ingredient_id === null) && data.ingredient_name) {
      optionsHtml += `<option value="" selected disabled>(Saved) ${data.ingredient_name} — not in current stock list</option>`;
    }
    
    const quantity = data ? data.quantity_required : '';
    
    row.innerHTML = `
      <select class="ingredient-select" required>
        ${optionsHtml}
      </select>
      <input type="number" class="ingredient-quantity" placeholder="Quantity" step="0.01" min="0.01" value="${quantity}" required>
      <button type="button" class="btn-remove-ingredient" onclick="this.parentElement.remove()">Remove</button>
    `;
    
    ingredientsList.appendChild(row);
  }

  addIngredientRowBtn?.addEventListener('click', () => addIngredientRow());
  ingredientCloseBtn?.addEventListener('click', closeIngredientModal);
  
  const ingredientCancelBtn = document.getElementById('ingredientCancelBtn');
  ingredientCancelBtn?.addEventListener('click', () => {
    closeIngredientModal();
    showNotification('Menu item saved without ingredients. You can add ingredients later by editing the item.', 'Info');
    // Don't auto-reload, let user manually refresh if needed
  });
  
  ingredientModal?.addEventListener('click', (e) => {
    if (e.target === ingredientModal) closeIngredientModal();
  });

  ingredientForm?.addEventListener('submit', function(e) {
    e.preventDefault();
    
    const rows = ingredientsList.querySelectorAll('.ingredient-row');
    const ingredients = [];
    
    rows.forEach(row => {
      const select = row.querySelector('.ingredient-select');
      const quantity = row.querySelector('.ingredient-quantity');
      
      if (select.value && quantity.value) {
        ingredients.push({
          ingredient_id: select.value,
          quantity: quantity.value
        });
      }
    });
    
    if (ingredients.length === 0) {
      showNotification('Please add at least one ingredient', 'Error');
      return;
    }
    
    const form = new URLSearchParams();
    form.append('menu_id', currentMenuIdForIngredients);
    form.append('ingredients', JSON.stringify(ingredients));
    
    fetch('save_menu_ingredients.php', {
      method: 'POST',
      headers: {'Content-Type':'application/x-www-form-urlencoded'},
      body: form.toString()
    })
    .then(r => r.json())
    .then(data => {
      if (data.status === 'success') {
        closeIngredientModal();
        showNotification('Ingredients saved successfully!', 'Success');
        setTimeout(() => location.reload(), 1500);
      } else {
        showNotification('Failed to save ingredients: ' + (data.message || ''), 'Error');
      }
    })
    .catch(err => {
      console.error(err);
      showNotification('Error saving ingredients', 'Error');
    });
  });

  // Make openIngredientModal available globally
  window.openIngredientModal = openIngredientModal;

  // Check for low stock ingredients
  function checkLowStock() {
    fetch('check_low_stock.php')
      .then(r => r.json())
      .then(data => {
        if (data.status === 'success' && data.count > 0) {
          const lowStockDiv = document.getElementById('lowStockAlert');
          if (lowStockDiv) {
            lowStockDiv.style.display = 'block';
            lowStockDiv.querySelector('.low-stock-count').textContent = data.count;
            
            const list = lowStockDiv.querySelector('.low-stock-list');
            list.innerHTML = data.low_stock.map(item => 
              `<li>${item.ingredient_name}: ${item.current_quantity} ${item.unit} (Min: ${item.min_quantity})</li>`
            ).join('');
          }
        }
      })
      .catch(err => console.error('Error checking low stock:', err));
  }

  // Check stock availability and auto-disable items with depleted ingredients
  function checkStockAvailability() {
    fetch('check_stock_availability.php')
      .then(r => r.json())
      .then(data => {
        if (data.status === 'success' && data.disabled_count > 0) {
          console.log('Auto-disabled ' + data.disabled_count + ' menu items due to depleted ingredients');
          
          // Just log, don't show intrusive notifications or auto-reload
          // User can manually refresh to see changes
        }
      })
      .catch(err => console.error('Error checking stock availability:', err));
  }

  // Run checks on page load
  checkLowStock();
  checkStockAvailability();
  
  // Re-check low stock every 60 seconds (not too aggressive)
  setInterval(checkLowStock, 60000);
  // Don't auto-check stock availability repeatedly to avoid constant reloads

  // Ensure any inventory links do NOT open in a new tab.
  // Remove target="_blank" and force same-tab navigation for inventory anchors.
  try {
    document.querySelectorAll('a.btn-inventory, a[href*="main_inventory_system"]').forEach(function(a) {
      if (a.getAttribute('target') === '_blank') a.removeAttribute('target');
      a.addEventListener('click', function(e) {
        // If the anchor has an href, navigate in same tab
        if (this.href) {
          e.preventDefault();
          window.location.href = this.href;
        }
      });
    });
  } catch (err) {
    console.error('Error forcing same-tab inventory links:', err);
  }



  // --- Ingredient Stock & Cost Modal ---
  const ingredientStockModal = document.getElementById('ingredientStockModal');
  const ingredientStockCloseBtn = document.getElementById('ingredientStockCloseBtn');

  window.openIngredientStockModal = function() {
    if (!ingredientStockModal) return;
    
    ingredientStockModal.style.display = 'block';
    ingredientStockModal.setAttribute('aria-hidden','false');
    
    // Load ingredient stock data
    loadIngredientStockData();
  };

  window.closeIngredientStockModal = function() {
    if (!ingredientStockModal) return;
    ingredientStockModal.style.display = 'none';
    ingredientStockModal.setAttribute('aria-hidden','true');
  };

  ingredientStockCloseBtn?.addEventListener('click', closeIngredientStockModal);
  ingredientStockModal?.addEventListener('click', (e) => {
    if (e.target === ingredientStockModal) closeIngredientStockModal();
  });

  // Ensure the "View Ingredient Stock" button always opens the modal
  try {
    const btnViewIngredients = document.getElementById('btnViewIngredients');
    if (btnViewIngredients) {
      btnViewIngredients.addEventListener('click', function(e) {
        e.preventDefault();
        if (typeof openIngredientStockModal === 'function') openIngredientStockModal();
        else console.error('openIngredientStockModal not defined');
      });
    }
  } catch (err) {
    console.error('Failed to attach View Ingredients button handler:', err);
  }

  function loadIngredientStockData() {
    const contentDiv = document.getElementById('ingredientStockContent');
    contentDiv.innerHTML = '<div style="text-align: center; padding: 20px;"><p>Loading...</p></div>';
    
    // Load both ingredient stock and cost analysis
    Promise.all([
      fetch('get_ingredient_stock_costs.php').then(r => r.json()),
      fetch('calculate_actual_profit.php?period=today').then(r => r.json())
    ])
    .then(([stockData, profitData]) => {
      if (stockData.status === 'success') {
        renderIngredientStockTable(stockData.ingredients, stockData.total_inventory_value);
      }
      
      if (profitData.status === 'success') {
        updateCostAnalysis(profitData);
      }
    })
    .catch(err => {
      console.error(err);
      contentDiv.innerHTML = '<div style="color: #dc3545; padding: 20px; text-align: center;">Network error</div>';
    });
  }

  function updateCostAnalysis(data) {
    document.getElementById('todayCost').textContent = '₱' + parseFloat(data.total_cost).toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2});
    document.getElementById('todayRevenue').textContent = '₱' + parseFloat(data.total_revenue).toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2});
    
    const profit = parseFloat(data.actual_profit);
    const profitElement = document.getElementById('todayProfit');
    profitElement.textContent = '₱' + profit.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2});
    profitElement.style.color = profit >= 0 ? '#28a745' : '#dc3545';
    
    const margin = parseFloat(data.profit_margin);
    const marginElement = document.getElementById('profitMargin');
    marginElement.textContent = margin.toFixed(1) + '%';
    marginElement.style.color = margin >= 50 ? '#28a745' : margin >= 30 ? '#2d7a3e' : margin >= 0 ? '#ffc107' : '#dc3545';
  }

  function renderIngredientStockTable(ingredients, totalValue) {
    const contentDiv = document.getElementById('ingredientStockContent');
    const totalValueSpan = document.getElementById('totalInventoryValue');
    
    let html = `
      <div style="max-height: 500px; overflow-y: auto;">
        <table style="width: 100%; border-collapse: collapse;">
          <thead style="position: sticky; top: 0; background: #800000; color: white; z-index: 10;">
            <tr>
              <th style="padding: 12px; text-align: left; border-bottom: 2px solid #600000;">Ingredient</th>
              <th style="padding: 12px; text-align: center; border-bottom: 2px solid #600000;">Quantity</th>
              <th style="padding: 12px; text-align: center; border-bottom: 2px solid #600000;">Unit</th>
              <th style="padding: 12px; text-align: right; border-bottom: 2px solid #600000;">Cost/Unit</th>
              <th style="padding: 12px; text-align: right; border-bottom: 2px solid #600000;">Total Value</th>
              <th style="padding: 12px; text-align: center; border-bottom: 2px solid #600000;">Status</th>
            </tr>
          </thead>
          <tbody>
    `;
    
    ingredients.forEach((ing, index) => {
      const bgColor = index % 2 === 0 ? '#f9f9f9' : '#ffffff';
      const isLowStock = parseFloat(ing.current_quantity) <= parseFloat(ing.min_quantity);
      const statusBadge = isLowStock 
        ? '<span style="background: #dc3545; color: white; padding: 4px 8px; border-radius: 4px; font-size: 11px;">LOW</span>'
        : '<span style="background: #28a745; color: white; padding: 4px 8px; border-radius: 4px; font-size: 11px;">OK</span>';
      
      html += `
        <tr style="background: ${bgColor}; ${isLowStock ? 'border-left: 3px solid #dc3545;' : ''}">
          <td style="padding: 10px; border-bottom: 1px solid #ddd;">${ing.ingredient_name}</td>
          <td style="padding: 10px; text-align: center; border-bottom: 1px solid #ddd; ${isLowStock ? 'color: #dc3545; font-weight: bold;' : ''}">${ing.current_quantity}</td>
          <td style="padding: 10px; text-align: center; border-bottom: 1px solid #ddd;">${ing.unit}</td>
          <td style="padding: 10px; text-align: right; border-bottom: 1px solid #ddd;">₱${parseFloat(ing.cost_per_unit).toFixed(2)}</td>
          <td style="padding: 10px; text-align: right; border-bottom: 1px solid #ddd; font-weight: bold;">₱${parseFloat(ing.total_value).toFixed(2)}</td>
          <td style="padding: 10px; text-align: center; border-bottom: 1px solid #ddd;">${statusBadge}</td>
        </tr>
      `;
    });
    
    html += `
          </tbody>
        </table>
      </div>
    `;
    
    contentDiv.innerHTML = html;
    totalValueSpan.textContent = '₱' + parseFloat(totalValue).toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2});
  }

});
