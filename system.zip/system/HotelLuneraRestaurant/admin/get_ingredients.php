<?php
session_name('RESTAURANT_SESSION');
session_start();
include 'connection.php';
header('Content-Type: application/json');

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
  echo json_encode(['status'=>'error','message'=>'Unauthorized']);
  exit;
}

// Get all available ingredients
$query = "SELECT id, ingredient_name, unit, current_quantity, cost_per_unit FROM current_ingredients_stock ORDER BY ingredient_name";
$result = $conn->query($query);

$ingredients = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $ingredients[] = $row;
    }
}

echo json_encode(['status' => 'success', 'ingredients' => $ingredients]);

$conn->close();
?>
