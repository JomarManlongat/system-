<?php
session_name('RESTAURANT_SESSION');
session_start();
include '../connection.php';

// Check if admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

// Get parameters
$dateFrom = isset($_GET['date_from']) ? $_GET['date_from'] : date('Y-m-d', strtotime('-6 days'));
$dateTo = isset($_GET['date_to']) ? $_GET['date_to'] : date('Y-m-d');
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$perPage = 10;
$offset = ($page - 1) * $perPage;

// Count for pagination (filtered by date range)
$resCount = $conn->query("SELECT COUNT(*) AS cnt FROM profits WHERE DATE(profit_date) BETWEEN '$dateFrom' AND '$dateTo'");
$totalRows = $resCount ? ($resCount->fetch_assoc()['cnt'] ?? 0) : 0;
$totalPages = ceil($totalRows / $perPage);

// Fetch profit rows (filtered by date range + pagination)
$resProfits = $conn->query("SELECT p.id, p.order_id, l.username AS cashier, p.total_amount, p.payment_method, p.profit_date
    FROM profits p
    LEFT JOIN login l ON l.id = p.cashier_id
    WHERE DATE(p.profit_date) BETWEEN '$dateFrom' AND '$dateTo'
    ORDER BY p.profit_date DESC
    LIMIT $perPage OFFSET $offset");

$rows = [];
if ($resProfits && $resProfits->num_rows > 0) {
    while ($p = $resProfits->fetch_assoc()) {
        $rows[] = $p;
    }
}

// Return JSON response
echo json_encode([
    'success' => true,
    'rows' => $rows,
    'page' => $page,
    'totalPages' => $totalPages,
    'totalRows' => $totalRows,
    'dateFrom' => $dateFrom,
    'dateTo' => $dateTo
]);
?>
