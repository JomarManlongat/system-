<?php
// Quick diagnostic script to check menu_ingredients table
error_reporting(E_ALL);
ini_set('display_errors', '1');

session_name('RESTAURANT_SESSION');
session_start();
include 'connection.php';

echo "<h2>Testing menu_ingredients table</h2>";

// Check if table exists
$result = $conn->query("SHOW TABLES LIKE 'menu_ingredients'");
if ($result->num_rows > 0) {
    echo "<p style='color:green'>✓ Table 'menu_ingredients' exists</p>";
    
    // Show table structure
    echo "<h3>Table Structure:</h3>";
    $cols = $conn->query("DESCRIBE menu_ingredients");
    echo "<table border='1' cellpadding='5'><tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th></tr>";
    while ($col = $cols->fetch_assoc()) {
        echo "<tr><td>{$col['Field']}</td><td>{$col['Type']}</td><td>{$col['Null']}</td><td>{$col['Key']}</td><td>{$col['Default']}</td></tr>";
    }
    echo "</table>";
    
    // Show sample data
    echo "<h3>Sample Data (first 5 rows):</h3>";
    $data = $conn->query("SELECT * FROM menu_ingredients LIMIT 5");
    if ($data->num_rows > 0) {
        echo "<table border='1' cellpadding='5'><tr><th>ID</th><th>menu_id</th><th>ingredient_id</th><th>ingredient_name</th><th>quantity_required</th></tr>";
        while ($row = $data->fetch_assoc()) {
            echo "<tr><td>{$row['id']}</td><td>{$row['menu_id']}</td><td>" . ($row['ingredient_id'] ?? 'NULL') . "</td><td>" . ($row['ingredient_name'] ?? 'NULL') . "</td><td>" . ($row['quantity_required'] ?? 'NULL') . "</td></tr>";
        }
        echo "</table>";
    } else {
        echo "<p>No data in table yet</p>";
    }
    
    // Test specific query for menu_id 15
    echo "<h3>Test Query for menu_id=15:</h3>";
    $stmt = $conn->prepare("SELECT id, ingredient_id, ingredient_name, quantity_required FROM menu_ingredients WHERE menu_id = ?");
    $test_id = 15;
    $stmt->bind_param('i', $test_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        echo "<p>Found {$result->num_rows} ingredients for menu_id=15</p>";
        while ($row = $result->fetch_assoc()) {
            echo "<pre>" . print_r($row, true) . "</pre>";
        }
    } else {
        echo "<p>No ingredients found for menu_id=15 (this is OK if you haven't added any yet)</p>";
    }
    
} else {
    echo "<p style='color:red'>✗ Table 'menu_ingredients' does NOT exist!</p>";
    echo "<p>Creating table...</p>";
    
    $create = $conn->query("
        CREATE TABLE IF NOT EXISTS menu_ingredients (
            id INT AUTO_INCREMENT PRIMARY KEY,
            menu_id INT NOT NULL,
            ingredient_id INT NULL,
            ingredient_name VARCHAR(255) NULL,
            quantity_required DECIMAL(10,2) NOT NULL,
            FOREIGN KEY (menu_id) REFERENCES menu(id) ON DELETE CASCADE,
            INDEX idx_menu_id (menu_id)
        )
    ");
    
    if ($create) {
        echo "<p style='color:green'>✓ Table created successfully!</p>";
    } else {
        echo "<p style='color:red'>✗ Failed to create table: " . $conn->error . "</p>";
    }
}

$conn->close();
?>
