<?php
session_name('RESTAURANT_SESSION');
session_start();
include 'connection.php';
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
  echo json_encode(['status'=>'error','message'=>'Unauthorized']); exit;
}

$id = intval($_POST['id'] ?? 0);
$password = $_POST['password'] ?? '';

if ($id <= 0 || $password === '') { echo json_encode(['status'=>'error','message'=>'Missing data']); exit; }

// Verify current user is admin and password matches
$stmt = $conn->prepare("SELECT id, password, role FROM login WHERE id = ? LIMIT 1");
$stmt->bind_param('i', $_SESSION['user_id']);
$stmt->execute();
$res = $stmt->get_result();
if ($res->num_rows === 0) { echo json_encode(['status'=>'error','message'=>'User not found']); exit; }
$user = $res->fetch_assoc();
if ($user['role'] !== 'admin') { echo json_encode(['status'=>'error','message'=>'Not admin']); exit; }

if ($user['password'] !== md5($password)) { echo json_encode(['status'=>'error','message'=>'Invalid password']); exit; }

// Delete item
$stmt = $conn->prepare("DELETE FROM menu WHERE id = ?");
$stmt->bind_param('i', $id);
if ($stmt->execute()) echo json_encode(['status'=>'success']);
else echo json_encode(['status'=>'error','message'=>'DB error']);

$stmt->close();
$conn->close();
?>
