<?php
session_name('RESTAURANT_SESSION');
session_start();
include 'connection.php';
header('Content-Type: application/json');

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
  echo json_encode(['status'=>'error','message'=>'Unauthorized']);
  exit;
}

// Get ingredients with low stock
$query = "SELECT id, ingredient_name, unit, current_quantity, min_quantity 
          FROM current_ingredients_stock 
          WHERE current_quantity <= min_quantity
          ORDER BY ingredient_name";
          
$result = $conn->query($query);

$lowStock = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $lowStock[] = $row;
    }
}

echo json_encode(['status' => 'success', 'low_stock' => $lowStock, 'count' => count($lowStock)]);

$conn->close();
?>
