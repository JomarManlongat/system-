<?php
session_name('RESTAURANT_SESSION');
session_start();
include 'connection.php';
header('Content-Type: application/json');

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
  echo json_encode(['status'=>'error','message'=>'Unauthorized']);
  exit;
}

// Get all ingredients with their costs
$query = "SELECT id, ingredient_name, unit, current_quantity, min_quantity, cost_per_unit,
          (current_quantity * cost_per_unit) as total_value
          FROM current_ingredients_stock 
          ORDER BY ingredient_name";
$result = $conn->query($query);

$ingredients = [];
$totalInventoryValue = 0;

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $ingredients[] = $row;
        $totalInventoryValue += floatval($row['total_value']);
    }
}

echo json_encode([
    'status' => 'success', 
    'ingredients' => $ingredients,
    'total_inventory_value' => $totalInventoryValue
]);

$conn->close();
?>
