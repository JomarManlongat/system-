<?php
session_name('RESTAURANT_SESSION');
session_start();
include 'connection.php';
header('Content-Type: application/json');

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
  echo json_encode(['status'=>'error','message'=>'Unauthorized']); exit;
}

$id = intval($_POST['id'] ?? 0);
$description = trim($_POST['description'] ?? '');
$price = floatval($_POST['price'] ?? 0);
$category = trim($_POST['category'] ?? '');
$image = trim($_POST['image'] ?? 'noimage.jpg');
$sugar_levels = trim($_POST['sugar_levels'] ?? '');

if ($id <= 0) { echo json_encode(['status'=>'error','message'=>'Invalid id']); exit; }

if ($image === '') $image = 'noimage.jpg';

$stmt = $conn->prepare("UPDATE menu SET description = ?, price = ?, category = ?, image = ?, sugar_levels = ? WHERE id = ?");
if (!$stmt) { echo json_encode(['status'=>'error','message'=>'DB prepare failed']); exit; }
$stmt->bind_param('sdsssi', $description, $price, $category, $image, $sugar_levels, $id);
if ($stmt->execute()) {
  echo json_encode(['status'=>'success']);
} else {
  echo json_encode(['status'=>'error','message'=>'DB error']);
}

$stmt->close();
$conn->close();
?>
