<?php
// Complete Restaurant Setup Executor
// ===================================

header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 0);

try {
    // Auto-detect password
    $connectionFile = __DIR__ . '/connection.php';
    $password = '';
    
    if (file_exists($connectionFile)) {
        $content = file_get_contents($connectionFile);
        if (preg_match('/\$password\s*=\s*["\']([^"\']*)["\']/', $content, $matches)) {
            $password = $matches[1];
        }
    }

    // Database credentials
    $host = 'localhost';
    $username = 'root';
    
    // Read the complete setup SQL file
    $sqlFile = __DIR__ . '/../../database/SETUP_RESTAURANT_COMPLETE.sql';
    
    if (!file_exists($sqlFile)) {
        throw new Exception("Setup SQL file not found: " . $sqlFile);
    }

    $sql = file_get_contents($sqlFile);
    
    // Split SQL by database switches
    $sections = [];
    $currentDB = null;
    $currentSQL = '';
    
    $lines = explode("\n", $sql);
    foreach ($lines as $line) {
        $trimmed = trim($line);
        
        // Detect USE database statements
        if (preg_match('/^USE\s+(\w+);/i', $trimmed, $matches)) {
            if ($currentDB && $currentSQL) {
                $sections[] = ['db' => $currentDB, 'sql' => $currentSQL];
            }
            $currentDB = $matches[1];
            $currentSQL = '';
            continue;
        }
        
        // Skip comments and empty lines
        if (empty($trimmed) || strpos($trimmed, '--') === 0) {
            continue;
        }
        
        $currentSQL .= $line . "\n";
    }
    
    // Add last section
    if ($currentDB && $currentSQL) {
        $sections[] = ['db' => $currentDB, 'sql' => $currentSQL];
    }

    $stats = [
        'suppliers' => 0,
        'supplier_items' => 0,
        'ingredients' => 0,
        'mappings' => 0
    ];
    
    $executedStatements = 0;
    $errors = [];

    // Execute each section with its database
    foreach ($sections as $section) {
        $dbName = $section['db'];
        $sectionSQL = $section['sql'];
        
        // Create connection for this database
        $conn = new mysqli($host, $username, $password, $dbName);
        
        if ($conn->connect_error) {
            throw new Exception("Connection failed to $dbName: " . $conn->connect_error);
        }
        
        $conn->set_charset("utf8mb4");
        $conn->begin_transaction();
        
        // Split into individual statements
        $statements = array_filter(
            array_map('trim', explode(';', $sectionSQL)),
            function($stmt) {
                return !empty($stmt) && stripos($stmt, 'USE ') !== 0;
            }
        );
        
        foreach ($statements as $statement) {
            if (empty($statement)) continue;
            
            // Execute statement
            if (!$conn->multi_query($statement . ';')) {
                $errors[] = "Error in $dbName: " . $conn->error;
                if (count($errors) > 10) break;
            } else {
                $executedStatements++;
                // Clear results
                while ($conn->more_results() && $conn->next_result()) {
                    if ($res = $conn->store_result()) {
                        $res->free();
                    }
                }
            }
        }
        
        if (!empty($errors)) {
            $conn->rollback();
            $conn->close();
            throw new Exception("SQL errors:\n" . implode("\n", array_slice($errors, 0, 5)));
        }
        
        $conn->commit();
        $conn->close();
    }

    // Get final stats from both databases
    $invConn = new mysqli($host, $username, $password, 'inventory_managementdb');
    $restConn = new mysqli($host, $username, $password, 'hotel_restaurant');
    
    if (!$invConn->connect_error) {
        $result = $invConn->query("SELECT COUNT(*) as cnt FROM suppliers WHERE Location IN ('Restaurant','Both')");
        if ($result) {
            $stats['suppliers'] = $result->fetch_assoc()['cnt'];
        }
        
        $result = $invConn->query("
            SELECT COUNT(*) as cnt 
            FROM supplieritems si
            JOIN suppliers s ON si.SupplierID = s.SupplierID
            WHERE s.Location IN ('Restaurant','Both')
        ");
        if ($result) {
            $stats['supplier_items'] = $result->fetch_assoc()['cnt'];
        }
        
        $invConn->close();
    }
    
    if (!$restConn->connect_error) {
        $result = $restConn->query("SELECT COUNT(*) as cnt FROM current_ingredients_stock");
        if ($result) {
            $stats['ingredients'] = $result->fetch_assoc()['cnt'];
        }
        
        $result = $restConn->query("SELECT COUNT(*) as cnt FROM menu_ingredients");
        if ($result) {
            $stats['mappings'] = $result->fetch_assoc()['cnt'];
        }
        
        $restConn->close();
    }

    echo json_encode([
        'success' => true,
        'message' => "Executed $executedStatements SQL statements successfully.",
        'stats' => $stats
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>
