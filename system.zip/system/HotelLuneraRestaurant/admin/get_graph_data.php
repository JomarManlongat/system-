<?php
session_name('RESTAURANT_SESSION');
session_start();
include 'connection.php';

// Only admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

header('Content-Type: application/json');

$period = isset($_GET['period']) ? $_GET['period'] : 'today';

$response = [
    'status' => 'success',
    'period' => $period,
    'labels' => [],
    'revenue' => [],
    'cost' => []
];

try {
    switch ($period) {
        case 'today':
            // Today's data by 3-hour intervals
            $today = date('Y-m-d');
            $intervals = [
                ['08:00:00', '10:59:59', '8 AM'],
                ['11:00:00', '13:59:59', '11 AM'],
                ['14:00:00', '16:59:59', '2 PM'],
                ['17:00:00', '19:59:59', '5 PM'],
                ['20:00:00', '22:59:59', '8 PM'],
                ['23:00:00', '23:59:59', '11 PM'],
                ['00:00:00', '01:59:59', '2 AM'],
                ['02:00:00', '04:59:59', '5 AM']
            ];
            
            foreach ($intervals as $int) {
                $response['labels'][] = $int[2];
                
                // Get revenue for this interval
                $sqlRev = "SELECT IFNULL(SUM(oi.quantity * m.price), 0) AS total
                    FROM orders o
                    JOIN order_items oi ON oi.order_id = o.id
                    JOIN menu m ON m.id = oi.menu_id
                    WHERE DATE(o.order_date) = '$today' 
                    AND TIME(o.order_date) BETWEEN '{$int[0]}' AND '{$int[1]}'
                    AND o.status = 'completed'";
                $resRev = $conn->query($sqlRev);
                $revenue = $resRev ? floatval($resRev->fetch_assoc()['total'] ?? 0) : 0;
                $response['revenue'][] = $revenue;
                
                // Get cost for this interval
                $sqlCost = "SELECT IFNULL(SUM(iul.quantity_used * cis.cost_per_unit), 0) AS total_cost
                    FROM ingredient_usage_log iul
                    JOIN current_ingredients_stock cis ON cis.id = iul.ingredient_id
                    WHERE DATE(iul.usage_date) = '$today'
                    AND TIME(iul.usage_date) BETWEEN '{$int[0]}' AND '{$int[1]}'";
                $resCost = $conn->query($sqlCost);
                $cost = $resCost ? floatval($resCost->fetch_assoc()['total_cost'] ?? 0) : 0;
                $response['cost'][] = $cost;
            }
            break;
            
        case 'week':
            // This week's data by day
            $weekStart = date('Y-m-d', strtotime('monday this week'));
            $days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
            
            for ($i = 0; $i < 7; $i++) {
                $date = date('Y-m-d', strtotime("$weekStart +$i day"));
                $response['labels'][] = $days[$i];
                
                // Revenue
                $sqlRev = "SELECT IFNULL(SUM(oi.quantity * m.price), 0) AS total
                    FROM orders o
                    JOIN order_items oi ON oi.order_id = o.id
                    JOIN menu m ON m.id = oi.menu_id
                    WHERE DATE(o.order_date) = '$date' AND o.status = 'completed'";
                $resRev = $conn->query($sqlRev);
                $revenue = $resRev ? floatval($resRev->fetch_assoc()['total'] ?? 0) : 0;
                $response['revenue'][] = $revenue;
                
                // Cost
                $sqlCost = "SELECT IFNULL(SUM(iul.quantity_used * cis.cost_per_unit), 0) AS total_cost
                    FROM ingredient_usage_log iul
                    JOIN current_ingredients_stock cis ON cis.id = iul.ingredient_id
                    WHERE DATE(iul.usage_date) = '$date'";
                $resCost = $conn->query($sqlCost);
                $cost = $resCost ? floatval($resCost->fetch_assoc()['total_cost'] ?? 0) : 0;
                $response['cost'][] = $cost;
            }
            break;
            
        case 'month':
            // This month by week
            $year = date('Y');
            $month = date('m');
            $firstDay = "$year-$month-01";
            $lastDay = date('Y-m-t', strtotime($firstDay));
            $weekCount = ceil((date('d', strtotime($lastDay)) + date('w', strtotime($firstDay))) / 7);
            
            for ($w = 0; $w < $weekCount; $w++) {
                $response['labels'][] = "Week " . ($w + 1);
                
                $weekStartDay = strtotime("$firstDay +".($w * 7)." days");
                $weekEndDay = min(strtotime("+6 days", $weekStartDay), strtotime($lastDay));
                $wStart = date('Y-m-d', $weekStartDay);
                $wEnd = date('Y-m-d', $weekEndDay);
                
                // Revenue
                $sqlRev = "SELECT IFNULL(SUM(oi.quantity * m.price), 0) AS total
                    FROM orders o
                    JOIN order_items oi ON oi.order_id = o.id
                    JOIN menu m ON m.id = oi.menu_id
                    WHERE DATE(o.order_date) BETWEEN '$wStart' AND '$wEnd'
                    AND o.status = 'completed'";
                $resRev = $conn->query($sqlRev);
                $revenue = $resRev ? floatval($resRev->fetch_assoc()['total'] ?? 0) : 0;
                $response['revenue'][] = $revenue;
                
                // Cost
                $sqlCost = "SELECT IFNULL(SUM(iul.quantity_used * cis.cost_per_unit), 0) AS total_cost
                    FROM ingredient_usage_log iul
                    JOIN current_ingredients_stock cis ON cis.id = iul.ingredient_id
                    WHERE DATE(iul.usage_date) BETWEEN '$wStart' AND '$wEnd'";
                $resCost = $conn->query($sqlCost);
                $cost = $resCost ? floatval($resCost->fetch_assoc()['total_cost'] ?? 0) : 0;
                $response['cost'][] = $cost;
            }
            break;
            
        case 'year':
            // This year by month
            $year = date('Y');
            $months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
            
            for ($m = 1; $m <= 12; $m++) {
                $monthStr = str_pad($m, 2, '0', STR_PAD_LEFT);
                $response['labels'][] = $months[$m - 1];
                
                // Revenue
                $sqlRev = "SELECT IFNULL(SUM(oi.quantity * m.price), 0) AS total
                    FROM orders o
                    JOIN order_items oi ON oi.order_id = o.id
                    JOIN menu m ON m.id = oi.menu_id
                    WHERE YEAR(o.order_date) = '$year' 
                    AND MONTH(o.order_date) = '$m'
                    AND o.status = 'completed'";
                $resRev = $conn->query($sqlRev);
                $revenue = $resRev ? floatval($resRev->fetch_assoc()['total'] ?? 0) : 0;
                $response['revenue'][] = $revenue;
                
                // Cost
                $sqlCost = "SELECT IFNULL(SUM(iul.quantity_used * cis.cost_per_unit), 0) AS total_cost
                    FROM ingredient_usage_log iul
                    JOIN current_ingredients_stock cis ON cis.id = iul.ingredient_id
                    WHERE YEAR(iul.usage_date) = '$year'
                    AND MONTH(iul.usage_date) = '$m'";
                $resCost = $conn->query($sqlCost);
                $cost = $resCost ? floatval($resCost->fetch_assoc()['total_cost'] ?? 0) : 0;
                $response['cost'][] = $cost;
            }
            break;
            
        default:
            throw new Exception('Invalid period');
    }
    
    echo json_encode($response);
    
} catch (Exception $e) {
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
}
?>
