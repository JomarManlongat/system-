<?php
// Step 1 Executor - Populate Inventory Items
// ==========================================

header('Content-Type: application/json');

// Database credentials
$host = 'localhost';
$username = 'root';
$password = '';
$inv_database = 'inventory_managementdb';

try {
    // Auto-detect password from connection.php
    $connectionFile = __DIR__ . '/connection.php';
    if (file_exists($connectionFile)) {
        $content = file_get_contents($connectionFile);
        if (preg_match('/\$password\s*=\s*["\']([^"\']*)["\']/', $content, $matches)) {
            $password = $matches[1];
        }
    }

    // Create connection to inventory database
    $conn = new mysqli($host, $username, $password, $inv_database);

    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }

    $conn->set_charset("utf8mb4");

    // Start transaction
    $conn->begin_transaction();

    // Read and execute the inventory SQL script
    $sqlFile = __DIR__ . '/../../database/POPULATE_INVENTORY_RESTAURANT_ITEMS.sql';
    
    if (!file_exists($sqlFile)) {
        throw new Exception("SQL file not found: " . $sqlFile);
    }

    $sql = file_get_contents($sqlFile);
    
    // Remove comments and split by semicolon
    $sql = preg_replace('/--.*$/m', '', $sql);
    $sql = preg_replace('/\/\*.*?\*\//s', '', $sql);
    
    $statements = array_filter(
        array_map('trim', explode(';', $sql)),
        function($stmt) {
            return !empty($stmt) && stripos($stmt, 'USE ') !== 0;
        }
    );

    $executedCount = 0;
    $errors = [];

    foreach ($statements as $statement) {
        if (empty($statement)) continue;
        
        if (!$conn->query($statement)) {
            $errors[] = "Error in statement: " . substr($statement, 0, 100) . "... - " . $conn->error;
            if (count($errors) > 5) {
                break; // Stop after 5 errors
            }
        } else {
            $executedCount++;
        }
    }

    if (!empty($errors)) {
        $conn->rollback();
        throw new Exception("SQL execution errors:\n" . implode("\n", $errors));
    }

    // Get statistics
    $stats = [];
    
    // Count suppliers
    $result = $conn->query("SELECT COUNT(*) as count FROM suppliers WHERE Location IN ('Restaurant', 'Both')");
    $stats['suppliers'] = $result->fetch_assoc()['count'];
    
    // Count items with Restaurant location
    $result = $conn->query("SELECT COUNT(*) as count FROM items WHERE Location = 'Restaurant'");
    $stats['items'] = $result->fetch_assoc()['count'];
    
    // Count supplier items
    $result = $conn->query("
        SELECT COUNT(*) as count 
        FROM supplieritems si
        JOIN suppliers s ON si.SupplierID = s.SupplierID
        WHERE s.Location IN ('Restaurant', 'Both')
    ");
    $stats['supplier_items'] = $result->fetch_assoc()['count'];
    
    // Commit transaction
    $conn->commit();
    $conn->close();

    echo json_encode([
        'success' => true,
        'suppliers' => $stats['suppliers'],
        'items' => $stats['items'],
        'supplier_items' => $stats['supplier_items'],
        'statements_executed' => $executedCount
    ]);

} catch (Exception $e) {
    if (isset($conn) && $conn->ping()) {
        $conn->rollback();
        $conn->close();
    }
    
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>
