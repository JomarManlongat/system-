<?php
// Log all requests to a file for debugging
$logFile = __DIR__ . '/debug_log.txt';
$logData = [
    'timestamp' => date('Y-m-d H:i:s'),
    'method' => $_SERVER['REQUEST_METHOD'],
    'session' => $_SESSION ?? 'NO SESSION',
    'post' => $_POST,
    'get' => $_GET,
    'headers' => getallheaders()
];
file_put_contents($logFile, print_r($logData, true) . "\n\n", FILE_APPEND);

// Now include the actual script
ob_start();

error_reporting(E_ALL);
ini_set('display_errors', '0');

try {
  session_name('RESTAURANT_SESSION');
  session_start();
  
  ob_clean();
  
  header('Content-Type: application/json');
  
  include 'connection.php';
  
  file_put_contents($logFile, "After connection, session role: " . ($_SESSION['role'] ?? 'NONE') . "\n\n", FILE_APPEND);
  
  if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    $response = ['status'=>'error','message'=>'Unauthorized', 'session_role' => $_SESSION['role'] ?? 'NONE'];
    file_put_contents($logFile, "Auth failed: " . print_r($response, true) . "\n\n", FILE_APPEND);
    echo json_encode($response);
    exit;
  }

  $menu_id = intval($_POST['menu_id'] ?? 0);
  
  file_put_contents($logFile, "menu_id: $menu_id\n\n", FILE_APPEND);

  if ($menu_id <= 0) {
    echo json_encode(['status'=>'error','message'=>'Invalid menu ID']);
    exit;
  }

  $stmt = $conn->prepare("SELECT id, ingredient_id, ingredient_name, quantity_required FROM menu_ingredients WHERE menu_id = ? ORDER BY ingredient_name");
  
  if (!$stmt) {
    echo json_encode(['status'=>'error','message'=>'Database prepare error: ' . $conn->error]);
    exit;
  }
  
  $stmt->bind_param('i', $menu_id);
  $stmt->execute();
  $mres = $stmt->get_result();
  
  file_put_contents($logFile, "Query returned " . $mres->num_rows . " rows\n\n", FILE_APPEND);

  $ingredients = [];
  
  if ($mres) {
    while ($mi = $mres->fetch_assoc()) {
      $ingredient_id = intval($mi['ingredient_id'] ?? 0);
      $ingredient_name = $mi['ingredient_name'] ?? null;
      $quantity_required = floatval($mi['quantity_required'] ?? 0);

      $detail = [
        'menu_ingredient_id' => intval($mi['id']),
        'ingredient_id' => $ingredient_id > 0 ? $ingredient_id : null,
        'ingredient_name' => $ingredient_name,
        'quantity_required' => $quantity_required,
        'unit' => null,
        'available_quantity' => 0
      ];

      if ($ingredient_id > 0) {
        $q = $conn->prepare("SELECT id, ingredient_name, unit, current_quantity FROM current_ingredients_stock WHERE id = ? LIMIT 1");
        if ($q) {
          $q->bind_param('i', $ingredient_id);
          $q->execute();
          $r = $q->get_result();
          if ($r && $row = $r->fetch_assoc()) {
            $detail['ingredient_name'] = $row['ingredient_name'];
            $detail['unit'] = $row['unit'] ?? null;
            $detail['available_quantity'] = floatval($row['current_quantity'] ?? 0);
            $ingredients[] = $detail;
            $q->close();
            continue;
          }
          $q->close();
        }
      }

      if ($ingredient_name) {
        $safe = $conn->real_escape_string($ingredient_name);
        $aq = $conn->query("SELECT SUM(current_quantity) AS total_qty, unit FROM current_ingredients_stock WHERE ingredient_name = '$safe' GROUP BY unit LIMIT 1");
        if ($aq && $ar = $aq->fetch_assoc()) {
          $detail['available_quantity'] = floatval($ar['total_qty'] ?? 0);
          $detail['unit'] = $ar['unit'] ?? null;
        }
      }

      $ingredients[] = $detail;
    }
  }

  $stmt->close();
  $conn->close();
  
  file_put_contents($logFile, "Final ingredients count: " . count($ingredients) . "\n" . print_r($ingredients, true) . "\n\n", FILE_APPEND);
  
  ob_clean();
  $response = ['status' => 'success', 'ingredients' => $ingredients];
  $json = json_encode($response);
  
  file_put_contents($logFile, "JSON response: $json\n\n" . str_repeat("=", 80) . "\n\n", FILE_APPEND);
  
  echo $json;
  
} catch (Exception $e) {
  ob_clean();
  $error = ['status'=>'error','message'=>'Exception: ' . $e->getMessage()];
  file_put_contents($logFile, "Exception: " . print_r($error, true) . "\n\n", FILE_APPEND);
  echo json_encode($error);
} catch (Error $e) {
  ob_clean();
  $error = ['status'=>'error','message'=>'Error: ' . $e->getMessage()];
  file_put_contents($logFile, "Error: " . print_r($error, true) . "\n\n", FILE_APPEND);
  echo json_encode($error);
}

ob_end_flush();
exit;
?>
