<?php
session_name('RESTAURANT_SESSION');
session_start();

// Check authentication first
if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    session_destroy();
    header("Location: ../login.php");
    exit;
}

include 'connection.php';

// Only admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}


// --- Profit cards queries ---
// 1) Today's revenue and profit/loss calculation
$today = $conn->real_escape_string(date('Y-m-d'));

// Get today's revenue
$resToday = $conn->query("SELECT IFNULL(SUM(oi.quantity * m.price),0) AS total
    FROM orders o
    JOIN order_items oi ON oi.order_id=o.id
    JOIN menu m ON m.id=oi.menu_id
    WHERE DATE(o.order_date)= '$today' AND o.status='completed'");
$todayTotal = $resToday->fetch_assoc()['total'] ?? 0;

// Get today's ingredient cost
$resTodayCost = $conn->query("SELECT IFNULL(SUM(iul.quantity_used * cis.cost_per_unit), 0) AS total_cost
    FROM ingredient_usage_log iul
    JOIN current_ingredients_stock cis ON cis.id = iul.ingredient_id
    WHERE DATE(iul.usage_date) = CURDATE()");
$todayCost = $resTodayCost ? ($resTodayCost->fetch_assoc()['total_cost'] ?? 0) : 0;
$todayProfit = $todayTotal - $todayCost;

// 2) This week's revenue (Mon-Sun)
$weekStart = date('Y-m-d', strtotime('monday this week'));
$resWeek = $conn->query("SELECT IFNULL(SUM(oi.quantity * m.price),0) AS total
    FROM orders o
    JOIN order_items oi ON oi.order_id=o.id
    JOIN menu m ON m.id=oi.menu_id
    WHERE DATE(o.order_date) >= '$weekStart' AND o.status='completed'");
$weekTotal = $resWeek->fetch_assoc()['total'] ?? 0;

// Get week's cost
$resWeekCost = $conn->query("SELECT IFNULL(SUM(iul.quantity_used * cis.cost_per_unit), 0) AS total_cost
    FROM ingredient_usage_log iul
    JOIN current_ingredients_stock cis ON cis.id = iul.ingredient_id
    WHERE DATE(iul.usage_date) >= '$weekStart'");
$weekCost = $resWeekCost ? ($resWeekCost->fetch_assoc()['total_cost'] ?? 0) : 0;
$weekProfit = $weekTotal - $weekCost;

// 3) This month's revenue
$month = date('Y-m');
$resMonth = $conn->query("SELECT IFNULL(SUM(oi.quantity * m.price),0) AS total
    FROM orders o
    JOIN order_items oi ON oi.order_id=o.id
    JOIN menu m ON m.id=oi.menu_id
    WHERE DATE_FORMAT(o.order_date, '%Y-%m') = '$month' AND o.status='completed'");
$monthTotal = $resMonth->fetch_assoc()['total'] ?? 0;

// Get month's cost
$resMonthCost = $conn->query("SELECT IFNULL(SUM(iul.quantity_used * cis.cost_per_unit), 0) AS total_cost
    FROM ingredient_usage_log iul
    JOIN current_ingredients_stock cis ON cis.id = iul.ingredient_id
    WHERE DATE_FORMAT(iul.usage_date, '%Y-%m') = '$month'");
$monthCost = $resMonthCost ? ($resMonthCost->fetch_assoc()['total_cost'] ?? 0) : 0;
$monthProfit = $monthTotal - $monthCost;

// 4) This year's revenue
$year = date('Y');
$resYear = $conn->query("SELECT IFNULL(SUM(oi.quantity * m.price),0) AS total
    FROM orders o
    JOIN order_items oi ON oi.order_id=o.id
    JOIN menu m ON m.id=oi.menu_id
    WHERE YEAR(o.order_date) = $year AND o.status='completed'");
$yearTotal = $resYear->fetch_assoc()['total'] ?? 0;

// Get year's cost
$resYearCost = $conn->query("SELECT IFNULL(SUM(iul.quantity_used * cis.cost_per_unit), 0) AS total_cost
    FROM ingredient_usage_log iul
    JOIN current_ingredients_stock cis ON cis.id = iul.ingredient_id
    WHERE YEAR(iul.usage_date) = $year");
$yearCost = $resYearCost ? ($resYearCost->fetch_assoc()['total_cost'] ?? 0) : 0;
$yearProfit = $yearTotal - $yearCost;

// --- Best sellers (top 5) ---
$resBest = $conn->query("SELECT m.name, SUM(oi.quantity) AS sold
    FROM order_items oi
    JOIN menu m ON m.id = oi.menu_id
    JOIN orders o ON o.id = oi.order_id
    WHERE o.status='completed'
    GROUP BY oi.menu_id
    ORDER BY sold DESC
    LIMIT 5");

// --- Total menu items ---
$resCount = $conn->query("SELECT COUNT(*) AS cnt FROM menu");
$totalMenu = $resCount->fetch_assoc()['cnt'] ?? 0;

// --- Fetch menu rows for management table ---
$resMenu = $conn->query("SELECT * FROM menu ORDER BY category, name");

// --- Chart data for Today's Profit/Loss (3-hour intervals) ---
$todayChartData = [];
$todayLossData = [];
$intervals = ['08:00:00', '11:00:00', '14:00:00', '17:00:00', '20:00:00', '23:00:00', '02:00:00', '05:00:00'];
$labels = ['8 AM', '11 AM', '2 PM', '5 PM', '8 PM', '11 PM', '2 AM', '5 AM'];
foreach($intervals as $idx => $time) {
    $nextIdx = ($idx + 1) % count($intervals);
    $nextTime = $intervals[$nextIdx];
    
    // Calculate revenue
    $sqlRevenue = "SELECT IFNULL(SUM(oi.quantity * m.price), 0) AS total
        FROM orders o
        JOIN order_items oi ON oi.order_id = o.id
        JOIN menu m ON m.id = oi.menu_id
        WHERE o.status = 'completed'
        AND DATE(o.order_date) = CURDATE()
        AND TIME(o.order_date) >= '$time'
        AND TIME(o.order_date) < '$nextTime'";
    $resRevenue = $conn->query($sqlRevenue);
    $revenue = $resRevenue ? floatval($resRevenue->fetch_assoc()['total'] ?? 0) : 0;
    
    // Calculate cost
    $sqlCost = "SELECT IFNULL(SUM(iul.quantity_used * cis.cost_per_unit), 0) AS total_cost
        FROM ingredient_usage_log iul
        JOIN current_ingredients_stock cis ON cis.id = iul.ingredient_id
        WHERE DATE(iul.usage_date) = CURDATE()
        AND TIME(iul.usage_date) >= '$time'
        AND TIME(iul.usage_date) < '$nextTime'";
    $resCost = $conn->query($sqlCost);
    $cost = $resCost ? floatval($resCost->fetch_assoc()['total_cost'] ?? 0) : 0;
    
    $profit = $revenue - $cost;
    $todayChartData[] = $revenue;
    $todayLossData[] = $cost;
}

// --- Chart data for This Week's Profit (daily) ---
$weekChartData = [];
$weekLossData = [];
$weekLabels = [];
for($i = 0; $i < 7; $i++) {
    $date = date('Y-m-d', strtotime("monday this week +$i days"));
    $weekLabels[] = date('D', strtotime($date));
    
    // Get revenue
    $sqlRevenue = "SELECT IFNULL(SUM(oi.quantity * m.price), 0) AS total
        FROM orders o
        JOIN order_items oi ON oi.order_id = o.id
        JOIN menu m ON m.id = oi.menu_id
        WHERE o.status = 'completed' AND DATE(o.order_date) = '$date'";
    $resRevenue = $conn->query($sqlRevenue);
    $revenue = $resRevenue ? floatval($resRevenue->fetch_assoc()['total'] ?? 0) : 0;
    
    // Get cost
    $sqlCost = "SELECT IFNULL(SUM(iul.quantity_used * cis.cost_per_unit), 0) AS total_cost
        FROM ingredient_usage_log iul
        JOIN current_ingredients_stock cis ON cis.id = iul.ingredient_id
        WHERE DATE(iul.usage_date) = '$date'";
    $resCost = $conn->query($sqlCost);
    $cost = $resCost ? floatval($resCost->fetch_assoc()['total_cost'] ?? 0) : 0;
    
    $weekChartData[] = $revenue;
    $weekLossData[] = $cost;
}

// --- Chart data for This Month's Profit (weekly) ---
$monthChartData = [];
$monthLossData = [];
$monthLabels = [];
$firstDay = date('Y-m-01');
$lastDay = date('Y-m-t');
$weekNum = 1;
$currentStart = $firstDay;
while(strtotime($currentStart) <= strtotime($lastDay)) {
    $weekEnd = date('Y-m-d', min(strtotime($currentStart) + 6*86400, strtotime($lastDay)));
    $monthLabels[] = "Week $weekNum";
    
    // Get revenue
    $sqlRevenue = "SELECT IFNULL(SUM(oi.quantity * m.price), 0) AS total
        FROM orders o
        JOIN order_items oi ON oi.order_id = o.id
        JOIN menu m ON m.id = oi.menu_id
        WHERE o.status = 'completed'
        AND DATE(o.order_date) BETWEEN '$currentStart' AND '$weekEnd'";
    $resRevenue = $conn->query($sqlRevenue);
    $revenue = $resRevenue ? floatval($resRevenue->fetch_assoc()['total'] ?? 0) : 0;
    
    // Get cost
    $sqlCost = "SELECT IFNULL(SUM(iul.quantity_used * cis.cost_per_unit), 0) AS total_cost
        FROM ingredient_usage_log iul
        JOIN current_ingredients_stock cis ON cis.id = iul.ingredient_id
        WHERE DATE(iul.usage_date) BETWEEN '$currentStart' AND '$weekEnd'";
    $resCost = $conn->query($sqlCost);
    $cost = $resCost ? floatval($resCost->fetch_assoc()['total_cost'] ?? 0) : 0;
    
    $monthChartData[] = $revenue;
    $monthLossData[] = $cost;
    $currentStart = date('Y-m-d', strtotime($weekEnd) + 86400);
    $weekNum++;
}

// --- Chart data for This Year's Profit (monthly) ---
$yearChartData = [];
$yearLossData = [];
$yearLabels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
for($m = 1; $m <= 12; $m++) {
    $monthStr = str_pad($m, 2, '0', STR_PAD_LEFT);
    
    // Get revenue
    $sqlRevenue = "SELECT IFNULL(SUM(oi.quantity * m.price), 0) AS total
        FROM orders o
        JOIN order_items oi ON oi.order_id = o.id
        JOIN menu m ON m.id = oi.menu_id
        WHERE o.status = 'completed'
        AND DATE_FORMAT(o.order_date, '%Y-%m') = '" . date('Y') . "-$monthStr'";
    $resRevenue = $conn->query($sqlRevenue);
    $revenue = $resRevenue ? floatval($resRevenue->fetch_assoc()['total'] ?? 0) : 0;
    
    // Get cost
    $sqlCost = "SELECT IFNULL(SUM(iul.quantity_used * cis.cost_per_unit), 0) AS total_cost
        FROM ingredient_usage_log iul
        JOIN current_ingredients_stock cis ON cis.id = iul.ingredient_id
        WHERE DATE_FORMAT(iul.usage_date, '%Y-%m') = '" . date('Y') . "-$monthStr'";
    $resCost = $conn->query($sqlCost);
    $cost = $resCost ? floatval($resCost->fetch_assoc()['total_cost'] ?? 0) : 0;
    
    $yearChartData[] = $revenue;
    $yearLossData[] = $cost;
}

// --- Profit Monitoring data ---
// Date range filter (default: last 7 days)
$dateFrom = isset($_GET['date_from']) ? $_GET['date_from'] : date('Y-m-d', strtotime('-6 days'));
$dateTo = isset($_GET['date_to']) ? $_GET['date_to'] : date('Y-m-d');

// Pagination
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$perPage = 10;
$offset = ($page - 1) * $perPage;

// Totals (always show today and all-time, not filtered)
$resProfitToday = $conn->query("SELECT IFNULL(SUM(total_amount),0) AS total FROM profits WHERE DATE(profit_date)=CURDATE()");
$profitToday = $resProfitToday ? ($resProfitToday->fetch_assoc()['total'] ?? 0) : 0;

$resProfitAll = $conn->query("SELECT IFNULL(SUM(total_amount),0) AS total FROM profits");
$profitAll = $resProfitAll ? ($resProfitAll->fetch_assoc()['total'] ?? 0) : 0;

// Count for pagination (filtered by date range)
$resCount = $conn->query("SELECT COUNT(*) AS cnt FROM profits WHERE DATE(profit_date) BETWEEN '$dateFrom' AND '$dateTo'");
$totalRows = $resCount ? ($resCount->fetch_assoc()['cnt'] ?? 0) : 0;
$totalPages = ceil($totalRows / $perPage);

// Recent profit rows (filtered by date range + pagination)
$resProfits = $conn->query("SELECT p.id, p.order_id, l.username AS cashier, p.total_amount, p.payment_method, p.profit_date
    FROM profits p
    LEFT JOIN login l ON l.id = p.cashier_id
    WHERE DATE(p.profit_date) BETWEEN '$dateFrom' AND '$dateTo'
    ORDER BY p.profit_date DESC
    LIMIT $perPage OFFSET $offset");

?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Admin Dashboard - Lunera</title>
<!-- Admin dashboard styles: see /admin/admin-dashboard.css for sections and editing tips -->
<link rel="stylesheet" href="admin-dashboard.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
</head>
<body>
<header class="admin-header">
    <div class="logo">LUNERA</div>
    <div class="header-actions">
        <a class="btn" href="../logout.php">Logout</a>
    </div>
</header>

<main class="container">
    <section class="cards">
        <div class="card card-clickable" data-period="today" style="<?= $todayProfit < 0 ? 'background: linear-gradient(135deg, #dc3545 0%, #c82333 100%); color: white;' : '' ?>">
            <div class="card-title">Today's Revenue</div>
            <div class="card-value">₱<?= number_format($todayTotal,2) ?></div>
            <div style="font-size: 12px; margin-top: 5px; opacity: 0.9;"><?= $todayProfit < 0 ? '⚠️ Loss: ₱' . number_format(abs($todayProfit),2) : 'Profit: ₱' . number_format($todayProfit,2) ?></div>
        </div>
        <div class="card card-clickable" data-period="week" style="<?= $weekProfit < 0 ? 'background: linear-gradient(135deg, #dc3545 0%, #c82333 100%); color: white;' : '' ?>">
            <div class="card-title">This Week</div>
            <div class="card-value">₱<?= number_format($weekTotal,2) ?></div>
            <div style="font-size: 12px; margin-top: 5px; opacity: 0.9;"><?= $weekProfit < 0 ? '⚠️ Loss: ₱' . number_format(abs($weekProfit),2) : 'Profit: ₱' . number_format($weekProfit,2) ?></div>
        </div>
        <div class="card card-clickable" data-period="month" style="<?= $monthProfit < 0 ? 'background: linear-gradient(135deg, #dc3545 0%, #c82333 100%); color: white;' : '' ?>">
            <div class="card-title">This Month</div>
            <div class="card-value">₱<?= number_format($monthTotal,2) ?></div>
            <div style="font-size: 12px; margin-top: 5px; opacity: 0.9;"><?= $monthProfit < 0 ? '⚠️ Loss: ₱' . number_format(abs($monthProfit),2) : 'Profit: ₱' . number_format($monthProfit,2) ?></div>
        </div>
        <div class="card card-clickable" data-period="year" style="<?= $yearProfit < 0 ? 'background: linear-gradient(135deg, #dc3545 0%, #c82333 100%); color: white;' : '' ?>">
            <div class="card-title">This Year</div>
            <div class="card-value">₱<?= number_format($yearTotal,2) ?></div>
            <div style="font-size: 12px; margin-top: 5px; opacity: 0.9;"><?= $yearProfit < 0 ? '⚠️ Loss: ₱' . number_format(abs($yearProfit),2) : 'Profit: ₱' . number_format($yearProfit,2) ?></div>
        </div>
    </section>

    <section class="grid">
        <div class="left">
            <div class="panel">
                <div class="panel-header">
                    <h3>Menu Management</h3>
                    <button id="btnAdd" class="btn primary">Add Menu Item</button>
                </div>
                
                <!-- Category Filter Buttons -->
                <div class="category-filter">
                    <button class="category-btn active" data-category="all">All Items</button>
                    <button class="category-btn" data-category="Main Courses">Main Courses</button>
                    <button class="category-btn" data-category="Appetizers">Appetizers</button>
                    <button class="category-btn" data-category="Dessert">Dessert</button>
                    <button class="category-btn" data-category="Beverages">Beverages</button>
                </div>
                
                <table class="menu-table">
                    <thead>
                        <tr>
                            <th>PK</th><th>Name</th><th>Category</th><th>Status</th><th>Price</th><th>Action</th>
                        </tr>
                    </thead>
                    <tbody id="menuTbody">
                        <?php while($m = $resMenu->fetch_assoc()): 
                            $isUnavailable = strtolower($m['status']) !== 'available';
                            $rowStyle = $isUnavailable ? 'style="background-color: #ffe6e6; opacity: 0.7;"' : '';
                        ?>
                        <tr data-id="<?= $m['id'] ?>" data-category="<?= htmlspecialchars($m['category']) ?>" <?= $rowStyle ?>>
                            <td><?= $m['id'] ?></td>
                            <td>
                                <?= htmlspecialchars($m['name']) ?>
                                <?php if ($isUnavailable): ?>
                                    <span style="color: #dc3545; font-size: 11px; margin-left: 5px;">⚠️ OUT OF STOCK</span>
                                <?php endif; ?>
                            </td>
                            <td><?= htmlspecialchars($m['category']) ?></td>
                            <td>
                                <label class="switch">
                                  <input class="toggle-status" type="checkbox" <?= strtolower($m['status']) === 'available' ? 'checked' : '' ?>>
                                  <span class="slider"></span>
                                </label>
                            </td>
                            <td>₱<?= number_format($m['price'],2) ?></td>
                            <td><button class="btn small edit-btn">Edit</button></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="right">
            <div class="panel">
                <h3>Best Sellers</h3>
                <ul class="best-list">
                    <?php while($b = $resBest->fetch_assoc()): ?>
                        <li><?= htmlspecialchars($b['name']) ?> <span class="right"><?= intval($b['sold']) ?></span></li>
                    <?php endwhile; ?>
                </ul>
            </div>

            <div class="panel small" style="margin-top:12px;">
                <h4>Total Menu Items</h4>
                <div class="big"><?= intval($totalMenu) ?></div>
                <button id="btnViewIngredients" class="btn primary" onclick="openIngredientStockModal()" style="width: 100%; margin-top: 12px; font-size: 13px;">
                    View Ingredient Stock & Costs
                </button>
            </div>
        </div>
    </section>

    <!-- Profit Monitoring Panel -->
    <section class="panel profit-panel" style="margin-top:18px;">
        <div class="profit-header">
            <h3>Profit Monitoring</h3>
            <div class="profit-summary">
                <div class="profit-card">
                    <div class="profit-title">Today's Total</div>
                    <div class="profit-value">₱<?= number_format($profitToday, 2) ?></div>
                </div>
                <div class="profit-card">
                    <div class="profit-title">All Time</div>
                    <div class="profit-value">₱<?= number_format($profitAll, 2) ?></div>
                </div>
            </div>
        </div>

        <!-- Date Range Filter -->
        <form method="get" class="profit-filter" id="profitFilterForm">
            <div class="filter-group">
                <label for="date_from">From:</label>
                <input type="date" id="date_from" name="date_from" value="<?= htmlspecialchars($dateFrom) ?>" required>
            </div>
            <div class="filter-group">
                <label for="date_to">To:</label>
                <input type="date" id="date_to" name="date_to" value="<?= htmlspecialchars($dateTo) ?>" required>
            </div>
            <button type="submit" class="btn primary">Filter</button>
            <a href="#" id="profitResetBtn" class="btn">Reset</a>
        </form>

        <div class="profit-table-wrap">
            <table class="profit-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Order ID</th>
                        <th>Cashier</th>
                        <th>Amount</th>
                        <th>Payment Method</th>
                        <th>Date & Time</th>
                    </tr>
                </thead>
                <tbody id="profitTableBody">
                    <?php if($resProfits && $resProfits->num_rows > 0): ?>
                        <?php while($p = $resProfits->fetch_assoc()): ?>
                            <tr>
                                <td><?= intval($p['id']) ?></td>
                                <td>#<?= intval($p['order_id']) ?></td>
                                <td><?= htmlspecialchars($p['cashier'] ?? 'Unknown') ?></td>
                                <td>₱<?= number_format($p['total_amount'], 2) ?></td>
                                <td><?= htmlspecialchars($p['payment_method'] ?? 'N/A') ?></td>
                                <td><?= date('Y-m-d H:i:s', strtotime($p['profit_date'])) ?></td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="6" style="text-align:center;color:#666;">No records in this date range.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <div id="profitPagination" class="pagination" data-page="<?= $page ?>" data-total-pages="<?= $totalPages ?>" data-total-rows="<?= $totalRows ?>">
            <?php if($totalPages > 1): ?>
                <?php if($page > 1): ?>
                    <a href="#" class="btn small profit-page-btn" data-page="<?= $page - 1 ?>">← Previous</a>
                <?php endif; ?>
                
                <span class="page-info">Page <?= $page ?> of <?= $totalPages ?> (<?= $totalRows ?> records)</span>
                
                <?php if($page < $totalPages): ?>
                    <a href="#" class="btn small profit-page-btn" data-page="<?= $page + 1 ?>">Next →</a>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </section>

    <!-- Edit modal removed - edit is handled via prompts -->

    <!-- Add New Menu Item Modal (copycat of provided design) -->
    <div id="addModal" class="modal" aria-hidden="true">
        <div class="modal-content modal-add modal-small">
            <span class="modal-close" id="addCloseBtn" title="Close">&times;</span>
            <h2>Add New Menu Item</h2>
            <p class="modal-subtitle">Fill out the form below to add a new item to the menu.</p>

            <form id="addForm">
                <div class="form-group">
                    <label for="add_name">Name</label>
                    <input type="text" id="add_name" name="name" required>
                    <small class="form-hint">This name will be used for tracking purposes.</small>
                </div>

                <div class="form-group">
                    <label for="add_description">Description <span class="char-limit">(Max 100 characters)</span></label>
                    <textarea id="add_description" name="description" rows="3"></textarea>
                    <small class="form-hint">Keep it short and clear.</small>
                </div>

                <div class="form-group">
                    <label for="add_price">Price</label>
                    <input type="number" id="add_price" name="price" step="0.01" required>
                </div>

                <div class="form-group">
                    <label for="add_image">Image filename</label>
                    <input type="text" id="add_image" name="image" placeholder="e.g. item.jpg">
                    <small class="form-hint">Enter the filename from the images folder. All image formats supported. Leave blank for noimage.jpg</small>
                </div>

                <div class="form-group">
                    <label for="add_category">Category</label>
                    <select id="add_category" name="category" required>
                        <option value="" selected disabled>Select a category</option>
                        <option value="Appetizers">Appetizers</option>
                        <option value="Main Courses">Main Courses</option>
                        <option value="Desserts">Desserts</option>
                        <option value="Beverages">Beverages</option>
                        <option value="Sides">Sides</option>
                    </select>
                </div>

                <div class="modal-actions" style="justify-content:flex-end;">
                    <button type="submit" class="btn btn-save">Add Item</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Edit Menu Item Modal (same design as Add) -->
    <div id="editModal" class="modal" aria-hidden="true">
        <div class="modal-content modal-add modal-small">
            <span class="modal-close" id="editCloseBtn" title="Close">&times;</span>
            <h2>Edit Menu Item</h2>
            <p class="modal-subtitle">Update the item information below.</p>

            <form id="editForm">
                <input type="hidden" id="edit_id" name="id">
                
                <div class="form-group">
                    <label for="edit_name">Name</label>
                    <input type="text" id="edit_name" name="name" disabled>
                    <small class="form-hint">Name cannot be changed for tracking purposes.</small>
                </div>

                <div class="form-group">
                    <label for="edit_description">Description <span class="char-limit">(Max 100 characters)</span></label>
                    <textarea id="edit_description" name="description" rows="3"></textarea>
                    <small class="form-hint">Keep it short and clear.</small>
                </div>

                <div class="form-group">
                    <label for="edit_price">Price</label>
                    <input type="number" id="edit_price" name="price" step="0.01" required>
                </div>

                <div class="form-group">
                    <label for="edit_image">Image filename <span class="required">*</span></label>
                    <input type="text" id="edit_image" name="image" placeholder="e.g. item.jpg" required>
                    <small class="form-hint">Enter the filename from the images folder. All image formats supported.</small>
                </div>

                <div class="form-group">
                    <label for="edit_category">Category</label>
                    <select id="edit_category" name="category" required>
                        <option value="" selected disabled>Select a category</option>
                        <option value="Appetizers">Appetizers</option>
                        <option value="Main Courses">Main Courses</option>
                        <option value="Desserts">Desserts</option>
                        <option value="Beverages">Beverages</option>
                        <option value="Sides">Sides</option>
                    </select>
                </div>

                <div class="modal-actions">
                    <button type="button" class="btn btn-delete" id="editDeleteBtn">Delete</button>
                    <div class="modal-actions-right">
                        <button type="button" class="btn btn-cancel" id="editCancelBtn">Cancel</button>
                        <button type="submit" class="btn btn-save">Save Changes</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div id="deleteModal" class="modal" aria-hidden="true">
        <div class="modal-content modal-small">
            <span class="modal-close" id="deleteCloseBtn" title="Close">&times;</span>
            <h2 style="text-align:center;margin-bottom:12px;">Confirm Deletion</h2>
            <p class="modal-subtitle" style="text-align:center;margin-bottom:18px;">Enter your admin password to confirm deletion:</p>

            <form id="deleteForm">
                <div class="form-group" style="display:flex;justify-content:center;">
                    <input type="password" id="delete_password" name="password" placeholder="Admin Password" required style="width:80%;padding:10px 16px;font-size:14px;text-align:center;border-radius:8px;">
                </div>

                <div class="modal-actions" style="justify-content:center;margin-top:18px;">
                    <button type="button" class="btn btn-cancel" id="deleteCancelBtn">Cancel</button>
                    <button type="submit" class="btn btn-delete">Confirm Delete</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Custom Notification Modal -->
    <div id="notificationModal" class="modal" aria-hidden="true">
        <div class="modal-content modal-small">
            <span class="modal-close" id="notificationCloseBtn" title="Close">&times;</span>
            <h2 id="notificationTitle" style="text-align:center;margin-bottom:12px;">Notification</h2>
            <p id="notificationMessage" class="modal-subtitle" style="text-align:center;margin-bottom:18px;"></p>
            <div class="modal-actions" style="justify-content:center;margin-top:18px;">
                <button type="button" class="btn btn-save" id="notificationOkBtn">OK</button>
            </div>
        </div>
    </div>

    <!-- Chart Modal for Revenue Breakdown -->
    <div id="chartModal" class="modal" aria-hidden="true">
        <div class="modal-content modal-chart">
            <span class="modal-close" id="chartCloseBtn" title="Close">&times;</span>
            <h2 id="chartTitle">Today's Profit/Loss</h2>
            <p id="chartSubtitle" class="modal-subtitle">Profit/Loss by hour.</p>
            <div class="chart-container">
                <canvas id="profitChart"></canvas>
            </div>
        </div>
    </div>

    <!-- Ingredient Management Modal -->
    <div id="ingredientModal" class="modal" aria-hidden="true">
        <div class="modal-content modal-add" style="max-width: 700px;">
            <span class="modal-close" id="ingredientCloseBtn" title="Close">&times;</span>
            <h2 id="ingredientModalTitle">Set Ingredients for Menu Item</h2>
            <p class="modal-subtitle">Define the ingredients and quantities needed for this menu item.</p>

            <form id="ingredientForm">
                <div id="ingredientsList" class="ingredients-list">
                    <!-- Dynamic ingredient rows will be added here -->
                </div>
                
                <button type="button" id="addIngredientRow" class="btn btn-secondary" style="margin-top: 12px;">
                    + Add Ingredient
                </button>

                <div class="modal-actions" style="justify-content:flex-end; margin-top: 20px;">
                    <button type="button" class="btn btn-cancel" id="ingredientCancelBtn">Skip</button>
                    <button type="submit" class="btn btn-save">Save Ingredients</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Ingredient Stock & Cost Modal -->
    <div id="ingredientStockModal" class="modal" aria-hidden="true">
        <div class="modal-content modal-add" style="max-width: 1000px;">
            <span class="modal-close" id="ingredientStockCloseBtn" title="Close">&times;</span>
            <h2>Current Ingredient Stock & Costs</h2>
            <p class="modal-subtitle">View all ingredients with their quantities, costs, and operational analysis.</p>

            <!-- Cost Analysis Summary -->
            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin: 20px 0; padding: 15px; background: #f9f9f9; border-radius: 8px; border: 1px solid #ddd;">
                <div style="text-align: center;">
                    <div style="font-size: 12px; color: #666; margin-bottom: 5px;">Today's Cost</div>
                    <div id="todayCost" style="font-size: 18px; font-weight: bold; color: #dc3545;">₱0.00</div>
                </div>
                <div style="text-align: center;">
                    <div style="font-size: 12px; color: #666; margin-bottom: 5px;">Today's Revenue</div>
                    <div id="todayRevenue" style="font-size: 18px; font-weight: bold; color: #28a745;">₱0.00</div>
                </div>
                <div style="text-align: center;">
                    <div style="font-size: 12px; color: #666; margin-bottom: 5px;">Today's Profit</div>
                    <div id="todayProfit" style="font-size: 18px; font-weight: bold; color: #800000;">₱0.00</div>
                </div>
                <div style="text-align: center;">
                    <div style="font-size: 12px; color: #666; margin-bottom: 5px;">Profit Margin</div>
                    <div id="profitMargin" style="font-size: 18px; font-weight: bold; color: #2d7a3e;">0%</div>
                </div>
            </div>

            <div id="ingredientStockContent" style="margin-top: 20px;">
                <div style="text-align: center; padding: 20px;">
                    <p>Loading ingredient data...</p>
                </div>
            </div>

            <div class="modal-actions" style="justify-content:space-between; margin-top: 20px; border-top: 2px solid #800000; padding-top: 15px;">
                <div style="font-size: 16px; font-weight: bold; color: #333;">
                    <span>Total Inventory Value: </span>
                    <span id="totalInventoryValue" style="color: #800000;">₱0.00</span>
                </div>
                <button type="button" class="btn btn-cancel" onclick="closeIngredientStockModal()">Close</button>
            </div>
        </div>
    </div>

    <!-- Low Stock Alert Box -->
    <section id="lowStockAlert" class="panel" style="margin-top: 20px; display: none; background: #fff3cd; border-left: 4px solid #ff6b6b;">
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <div>
                <h3 style="color: #d63031; margin-bottom: 8px;">
                    ⚠️ Low Stock Alert (<span class="low-stock-count">0</span> ingredients)
                </h3>
                <p style="margin-bottom: 12px; color: #666;">The following ingredients are running low and need restock:</p>
                <ul class="low-stock-list" style="list-style: disc; margin-left: 20px; color: #333;">
                    <!-- Dynamic low stock items will be added here -->
                </ul>
            </div>
        </div>
    </section>

    <script>
        // Chart data from PHP - make it globally available
        window.chartData = {
            today: {
                labels: <?= json_encode(['8 AM', '11 AM', '2 PM', '5 PM', '8 PM', '11 PM', '2 AM', '5 AM']) ?>,
                profit: <?= json_encode($todayChartData) ?>,
                loss: <?= json_encode($todayLossData) ?>,
                title: "Today's Revenue & Cost",
                subtitle: "Revenue (green) vs. Ingredient Cost (red) by 3-hour intervals."
            },
            week: {
                labels: <?= json_encode($weekLabels) ?>,
                profit: <?= json_encode($weekChartData) ?>,
                loss: <?= json_encode($weekLossData) ?>,
                title: "This Week's Revenue & Cost",
                subtitle: "Revenue (green) vs. Ingredient Cost (red) by day."
            },
            month: {
                labels: <?= json_encode($monthLabels) ?>,
                profit: <?= json_encode($monthChartData) ?>,
                loss: <?= json_encode($monthLossData) ?>,
                title: "This Month's Revenue & Cost",
                subtitle: "Revenue (green) vs. Ingredient Cost (red) by week."
            },
            year: {
                labels: <?= json_encode($yearLabels) ?>,
                profit: <?= json_encode($yearChartData) ?>,
                loss: <?= json_encode($yearLossData) ?>,
                title: "This Year's Revenue & Cost",
                subtitle: "Revenue (green) vs. Ingredient Cost (red) by month."
            }
        };
        console.log('Chart data initialized:', window.chartData);
    </script>
    
</main>

<script src="assets/js/admin.js"></script>
</body>
</html>
