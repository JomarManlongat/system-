<?php
// Capture and return all errors as JSON
error_reporting(E_ALL);
ini_set('display_errors', '0');

// Start output buffering to catch any stray output
ob_start();

try {
  session_name('RESTAURANT_SESSION');
  session_start();
  
  // Clear any output that might have leaked
  ob_clean();
  
  header('Content-Type: application/json');
  
  include 'connection.php';
  
  if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    echo json_encode(['status'=>'error','message'=>'Unauthorized']);
    exit;
  }

  $menu_id = intval($_POST['menu_id'] ?? 0);

  if ($menu_id <= 0) {
    echo json_encode(['status'=>'error','message'=>'Invalid menu ID']);
    exit;
  }

  // Get ingredients for this menu item
  $stmt = $conn->prepare("SELECT id, ingredient_id, ingredient_name, quantity_required FROM menu_ingredients WHERE menu_id = ? ORDER BY ingredient_name");
  
  if (!$stmt) {
    echo json_encode(['status'=>'error','message'=>'Database prepare error: ' . $conn->error]);
    exit;
  }
  
  $stmt->bind_param('i', $menu_id);
  $stmt->execute();
  $mres = $stmt->get_result();

    $ingredients = [];
  
  if ($mres) {
    while ($mi = $mres->fetch_assoc()) {
      $ingredient_id = intval($mi['ingredient_id'] ?? 0);
      $ingredient_name = $mi['ingredient_name'] ?? null;
      $quantity_required = floatval($mi['quantity_required'] ?? 0);

      $detail = [
        'menu_ingredient_id' => intval($mi['id']),
        'ingredient_id' => $ingredient_id > 0 ? $ingredient_id : null,
        'ingredient_name' => $ingredient_name,
        'quantity_required' => $quantity_required,
        'unit' => null,
        'available_quantity' => 0
      ];

      // Try to fetch current ingredient row by id
      if ($ingredient_id > 0) {
        $q = $conn->prepare("SELECT id, ingredient_name, unit, current_quantity FROM current_ingredients_stock WHERE id = ? LIMIT 1");
        if ($q) {
          $q->bind_param('i', $ingredient_id);
          $q->execute();
          $r = $q->get_result();
          if ($r && $row = $r->fetch_assoc()) {
            $detail['ingredient_name'] = $row['ingredient_name'];
            $detail['unit'] = $row['unit'] ?? null;
            $detail['available_quantity'] = floatval($row['current_quantity'] ?? 0);
            $ingredients[] = $detail;
            $q->close();
            continue; // resolved by id
          }
          $q->close();
        }
      }

      // If not found by id, try to resolve by saved ingredient_name
      if ($ingredient_name) {
        $safe = $conn->real_escape_string($ingredient_name);
        $aq = $conn->query("SELECT SUM(current_quantity) AS total_qty, unit FROM current_ingredients_stock WHERE ingredient_name = '$safe' GROUP BY unit LIMIT 1");
        if ($aq && $ar = $aq->fetch_assoc()) {
          $detail['available_quantity'] = floatval($ar['total_qty'] ?? 0);
          $detail['unit'] = $ar['unit'] ?? null;
        }
      }

      $ingredients[] = $detail;
    }
  }

  $stmt->close();
  $conn->close();
  
  // Clear output buffer and send JSON
  ob_clean();
  echo json_encode(['status' => 'success', 'ingredients' => $ingredients]);
  
} catch (Exception $e) {
  // Catch any uncaught errors and return as JSON
  ob_clean();
  echo json_encode(['status'=>'error','message'=>'Exception: ' . $e->getMessage()]);
} catch (Error $e) {
  // Catch PHP 7+ errors
  ob_clean();
  echo json_encode(['status'=>'error','message'=>'Error: ' . $e->getMessage()]);
}

ob_end_flush();
exit;
?>
