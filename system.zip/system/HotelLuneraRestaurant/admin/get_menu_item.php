<?php
session_name('RESTAURANT_SESSION');
session_start();
header('Content-Type: application/json');
include 'connection.php';

// Only admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

if (!isset($_GET['id'])) {
    echo json_encode(['status' => 'error', 'message' => 'No ID provided']);
    exit;
}

$id = intval($_GET['id']);

$stmt = $conn->prepare("SELECT id, name, description, price, category, image FROM menu WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $item = $result->fetch_assoc();
    echo json_encode(['status' => 'success', 'item' => $item]);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Item not found']);
}

$stmt->close();
$conn->close();
exit;
?>
