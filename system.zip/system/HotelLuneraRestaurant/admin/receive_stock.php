<?php
session_name('RESTAURANT_SESSION');
session_start();
include 'connection.php';
header('Content-Type: application/json');

// Allow both authenticated admin and API calls from inventory system
$is_api_call = !isset($_SESSION['role']);

if (!$is_api_call && (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin')) {
  echo json_encode(['status'=>'error','message'=>'Unauthorized']);
  exit;
}

// This endpoint receives stock transfer from main_inventory_system
$ingredient_name = trim($_POST['ingredient_name'] ?? '');
$quantity = floatval($_POST['quantity'] ?? 0);
$transferred_by = trim($_POST['transferred_by'] ?? 'Unknown');
$notes = trim($_POST['notes'] ?? '');
$user_location = trim($_POST['user_location'] ?? 'restaurant'); // Default to restaurant

if ($ingredient_name === '') {
  echo json_encode(['status'=>'error','message'=>'Ingredient name required']);
  exit;
}

if ($quantity <= 0) {
  echo json_encode(['status'=>'error','message'=>'Invalid quantity']);
  exit;
}

// Check if this transfer is for restaurant location only
if (strtolower($user_location) !== 'restaurant') {
  echo json_encode([
    'status' => 'skipped', 
    'message' => 'Transfer skipped - user location is not restaurant (location: ' . $user_location . ')',
    'user_location' => $user_location
  ]);
  exit;
}

// Start transaction
$conn->begin_transaction();

try {
    // Check if ingredient exists
    $checkStmt = $conn->prepare("SELECT id, current_quantity FROM current_ingredients_stock WHERE ingredient_name = ?");
    $checkStmt->bind_param('s', $ingredient_name);
    $checkStmt->execute();
    $result = $checkStmt->get_result();
    
    if ($result->num_rows === 0) {
        throw new Exception("Ingredient not found in restaurant inventory");
    }
    
    $row = $result->fetch_assoc();
    $ingredient_id = $row['id'];
    $current_qty = $row['current_quantity'];
    
    // Update stock
    $new_quantity = $current_qty + $quantity;
    $updateStmt = $conn->prepare("UPDATE current_ingredients_stock SET current_quantity = ? WHERE id = ?");
    $updateStmt->bind_param('di', $new_quantity, $ingredient_id);
    $updateStmt->execute();
    
    // Log the transfer
    $logStmt = $conn->prepare("INSERT INTO stock_transfer_log (ingredient_id, quantity_transferred, transferred_by, notes) VALUES (?, ?, ?, ?)");
    $logStmt->bind_param('idss', $ingredient_id, $quantity, $transferred_by, $notes);
    $logStmt->execute();
    
    $conn->commit();
    echo json_encode([
        'status' => 'success', 
        'message' => 'Stock transferred successfully to restaurant',
        'new_quantity' => $new_quantity,
        'user_location' => 'restaurant'
    ]);
    
} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}

$conn->close();
?>
