<?php
// Safe Step 2 Executor - Menu Ingredients Mapping
// ===============================================

header('Content-Type: application/json');

// Database credentials
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'hotel_restaurant';

try {
    // Auto-detect password from connection.php
    $connectionFile = __DIR__ . '/connection.php';
    if (file_exists($connectionFile)) {
        $content = file_get_contents($connectionFile);
        if (preg_match('/\$password\s*=\s*["\']([^"\']*)["\']/', $content, $matches)) {
            $password = $matches[1];
        }
    }

    // Create connection
    $conn = new mysqli($host, $username, $password, $database);

    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }

    $conn->set_charset("utf8mb4");

    // Start transaction
    $conn->begin_transaction();

    // Read and execute the safe SQL script
    $sqlFile = __DIR__ . '/../../database/POPULATE_MENU_INGREDIENTS_SAFE.sql';
    
    if (!file_exists($sqlFile)) {
        throw new Exception("SQL file not found: " . $sqlFile);
    }

    $sql = file_get_contents($sqlFile);
    
    // Remove comments and split by semicolon
    $sql = preg_replace('/--.*$/m', '', $sql);
    $sql = preg_replace('/\/\*.*?\*\//s', '', $sql);
    
    $statements = array_filter(
        array_map('trim', explode(';', $sql)),
        function($stmt) {
            return !empty($stmt) && stripos($stmt, 'USE ') !== 0;
        }
    );

    $executedCount = 0;
    $errors = [];

    foreach ($statements as $statement) {
        if (empty($statement)) continue;
        
        if (!$conn->query($statement)) {
            $errors[] = "Error in statement: " . substr($statement, 0, 100) . "... - " . $conn->error;
            if (count($errors) > 5) {
                break; // Stop after 5 errors
            }
        } else {
            $executedCount++;
        }
    }

    if (!empty($errors)) {
        $conn->rollback();
        throw new Exception("SQL execution errors:\n" . implode("\n", $errors));
    }

    // Get statistics
    $stats = [];
    
    // Count total menu items
    $result = $conn->query("SELECT COUNT(*) as count FROM menu");
    $stats['menu_items'] = $result->fetch_assoc()['count'];
    
    // Count total ingredient mappings
    $result = $conn->query("SELECT COUNT(*) as count FROM menu_ingredients");
    $stats['ingredients'] = $result->fetch_assoc()['count'];
    
    // Count unique ingredients used
    $result = $conn->query("SELECT COUNT(DISTINCT ingredient_name) as count FROM menu_ingredients WHERE ingredient_name IS NOT NULL");
    $stats['unique_ingredients'] = $result->fetch_assoc()['count'];
    
    // Breakdown by category
    $result = $conn->query("
        SELECT 
            m.category,
            COUNT(DISTINCT m.id) as menu_count,
            COUNT(mi.id) as ingredient_count,
            ROUND(AVG(ingredient_counts.cnt), 1) as avg_ingredients
        FROM menu m
        LEFT JOIN menu_ingredients mi ON m.id = mi.menu_id
        LEFT JOIN (
            SELECT menu_id, COUNT(*) as cnt
            FROM menu_ingredients
            GROUP BY menu_id
        ) ingredient_counts ON m.id = ingredient_counts.menu_id
        GROUP BY m.category
        ORDER BY m.category
    ");
    
    $breakdown = [];
    while ($row = $result->fetch_assoc()) {
        $breakdown[$row['category']] = [
            'menu_items' => (int)$row['menu_count'],
            'total_ingredients' => (int)$row['ingredient_count'],
            'avg_per_item' => (float)$row['avg_ingredients']
        ];
    }
    
    // Commit transaction
    $conn->commit();
    $conn->close();

    echo json_encode([
        'success' => true,
        'menu_items' => $stats['menu_items'],
        'ingredients' => $stats['ingredients'],
        'unique_ingredients' => $stats['unique_ingredients'],
        'breakdown' => $breakdown,
        'statements_executed' => $executedCount
    ]);

} catch (Exception $e) {
    if (isset($conn) && $conn->ping()) {
        $conn->rollback();
        $conn->close();
    }
    
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>
