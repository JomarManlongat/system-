<?php
session_name('RESTAURANT_SESSION');
session_start();
include 'connection.php';
header('Content-Type: application/json');

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
  echo json_encode(['status'=>'error','message'=>'Unauthorized']);
  exit;
}

$menu_id = intval($_POST['menu_id'] ?? 0);
$ingredients = json_decode($_POST['ingredients'] ?? '[]', true);

if ($menu_id <= 0) {
  echo json_encode(['status'=>'error','message'=>'Invalid menu ID']);
  exit;
}

if (!is_array($ingredients) || empty($ingredients)) {
  echo json_encode(['status'=>'error','message'=>'No ingredients provided']);
  exit;
}

// Start transaction
$conn->begin_transaction();

try {
  // Ensure menu_ingredients has an ingredient_name column to preserve a canonical name
  $colCheck = $conn->query("SHOW COLUMNS FROM menu_ingredients LIKE 'ingredient_name'");
  if (!$colCheck || $colCheck->num_rows === 0) {
    $conn->query("ALTER TABLE menu_ingredients ADD COLUMN ingredient_name VARCHAR(255) NULL AFTER ingredient_id");
  }

  // First, delete existing ingredients for this menu item
  $deleteStmt = $conn->prepare("DELETE FROM menu_ingredients WHERE menu_id = ?");
  $deleteStmt->bind_param('i', $menu_id);
  $deleteStmt->execute();

  // Insert new ingredients (store ingredient_name as a stable reference)
  $insertStmt = $conn->prepare("INSERT INTO menu_ingredients (menu_id, ingredient_id, ingredient_name, quantity_required) VALUES (?, ?, ?, ?)");

  foreach ($ingredients as $ing) {
    $ingredient_id = intval($ing['ingredient_id'] ?? 0);
    $quantity = floatval($ing['quantity'] ?? 0);
    $ing_name = null;

    if ($ingredient_id > 0) {
      $nstmt = $conn->prepare("SELECT ingredient_name FROM current_ingredients_stock WHERE id = ? LIMIT 1");
      if ($nstmt) {
        $nstmt->bind_param('i', $ingredient_id);
        $nstmt->execute();
        $nres = $nstmt->get_result();
        if ($nres && $nrow = $nres->fetch_assoc()) {
          $ing_name = $nrow['ingredient_name'];
        }
        $nstmt->close();
      }
    }

    if ($quantity > 0 && ($ingredient_id > 0 || $ing_name)) {
      // Use ingredient_name (can be null if not found)
      $insertStmt->bind_param('iisd', $menu_id, $ingredient_id, $ing_name, $quantity);
      $insertStmt->execute();
    }
  }
    
    $conn->commit();
    echo json_encode(['status' => 'success', 'message' => 'Ingredients saved successfully']);
    
} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['status' => 'error', 'message' => 'Database error: ' . $e->getMessage()]);
}

$conn->close();
?>
