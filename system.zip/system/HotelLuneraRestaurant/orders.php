<?php
session_name('RESTAURANT_SESSION');
session_start();
include("connection.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orders</title>
    <link rel="stylesheet" href="assets/css/orders.css">
</head>
<body>

<h2>📋 Current Orders</h2>
<table>
    <tr>
        <th>Order ID</th>
        <th>Menu Item</th>
        <th>Quantity</th>
        <th>Date</th>
        <th>Status</th>
    </tr>
    <?php
    $orders = $conn->query("
        SELECT o.id as order_id, m.name, oi.quantity, o.order_date, o.status
        FROM orders o
        JOIN order_items oi ON o.id = oi.order_id
        JOIN menu m ON oi.menu_id = m.id
        ORDER BY o.order_date DESC
    ");
    while ($row = $orders->fetch_assoc()) {
        echo "<tr>
            <td>".$row['order_id']."</td>
            <td>".$row['name']."</td>
            <td>".$row['quantity']."</td>
            <td>".$row['order_date']."</td>
            <td>".$row['status']."</td>
        </tr>";
    }
    ?>
</table>

<br>
<a href="index.php">⬅ Back to Dashboard</a>

</body>
</html>
