<?php
$servername = "localhost";
$username   = "root";
$password   = "Jojenjusjmjai09";
$db_name    = "hotel_restaurant";

$conn = new mysqli($servername, $username, $password, $db_name);if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
