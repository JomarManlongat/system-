<?php
session_name('RESTAURANT_SESSION');
session_start();
include 'connection.php';

// Ensure logged in cashier
if (!isset($_SESSION['user_id'])) {
    $_SESSION['payment_error'] = 'Not logged in';
    header('Location: login.php');
    exit;
}

$cashier_id = intval($_SESSION['user_id']);
$order_id = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;
$payment_method = isset($_POST['payment_method']) ? trim($_POST['payment_method']) : '';

if (!$order_id || $payment_method === '') {
    $_SESSION['payment_error'] = 'Invalid payment details';
    header('Location: payment.php');
    exit;
}

// Verify order exists and is pending
$resOrder = $conn->query("SELECT id, status FROM orders WHERE id=$order_id LIMIT 1");
if (!$resOrder || $resOrder->num_rows === 0) {
    $_SESSION['payment_error'] = 'Order not found';
    header('Location: payment.php');
    exit;
}
$order = $resOrder->fetch_assoc();
if ($order['status'] !== 'pending') {
    $_SESSION['payment_error'] = 'Order already processed';
    header('Location: orders.php');
    exit;
}

// Compute total
$resTotal = $conn->query("SELECT IFNULL(SUM(oi.quantity * m.price),0) AS total
    FROM order_items oi JOIN menu m ON m.id=oi.menu_id WHERE oi.order_id=$order_id");
$total = 0.00;
if ($resTotal) {
    $total = floatval($resTotal->fetch_assoc()['total'] ?? 0);
}
if ($total <= 0) {
    $_SESSION['payment_error'] = 'Order has no items';
    header('Location: payment.php');
    exit;
}

// Wrap in transaction
$conn->begin_transaction();
try {
    // Idempotency: ensure we only record profit once per order
    $chk = $conn->prepare("SELECT id FROM profits WHERE order_id=? LIMIT 1");
    $chk->bind_param('i', $order_id);
    $chk->execute();
    $exists = $chk->get_result();
    $hasProfit = $exists && $exists->num_rows > 0;

    if (!$hasProfit) {
        // Insert into profits
        $stmt = $conn->prepare("INSERT INTO profits (order_id, cashier_id, total_amount, payment_method) VALUES (?, ?, ?, ?)");
        $stmt->bind_param('iids', $order_id, $cashier_id, $total, $payment_method);
        if (!$stmt->execute()) {
            throw new Exception('Failed to record profit');
        }
    }

    // Check stock availability first (check total across all batches)
    $resCheckItems = $conn->query("SELECT oi.menu_id, oi.quantity, m.name as menu_name
        FROM order_items oi 
        JOIN menu m ON m.id = oi.menu_id
        WHERE oi.order_id = $order_id");
    
    if ($resCheckItems) {
        while ($item = $resCheckItems->fetch_assoc()) {
            $menu_id = $item['menu_id'];
            $order_qty = $item['quantity'];
            $menu_name = $item['menu_name'];
            
            // Check ingredients availability across ALL batches with same name
            $resCheckIng = $conn->query("SELECT DISTINCT mi.ingredient_id, mi.quantity_required, 
                cis.ingredient_name
                FROM menu_ingredients mi
                JOIN current_ingredients_stock cis ON cis.id = mi.ingredient_id
                WHERE mi.menu_id = $menu_id
                GROUP BY cis.ingredient_name");
            
            if ($resCheckIng) {
                while ($ing = $resCheckIng->fetch_assoc()) {
                    $needed = $ing['quantity_required'] * $order_qty;
                    $ingredient_name = $ing['ingredient_name'];
                    
                    // Get total available quantity across all batches
                    $totalQuery = $conn->query("SELECT get_total_ingredient_quantity('$ingredient_name') as total");
                    $totalRow = $totalQuery->fetch_assoc();
                    $available = floatval($totalRow['total'] ?? 0);
                    
                    if ($available < $needed) {
                        throw new Exception('Insufficient stock: ' . $ingredient_name . 
                            ' for ' . $menu_name . '. Need: ' . $needed . 'kg, Available: ' . $available . 'kg');
                    }
                }
            }
        }
    }
    
    // Deduct ingredients using smart procedure (auto-switches batches)
    $resOrderItems = $conn->query("SELECT oi.menu_id, oi.quantity 
        FROM order_items oi 
        WHERE oi.order_id = $order_id");
    
    if ($resOrderItems) {
        while ($item = $resOrderItems->fetch_assoc()) {
            $menu_id = $item['menu_id'];
            $quantity = $item['quantity'];
            
            // Get unique ingredients for this menu item
            $resIngredients = $conn->query("SELECT DISTINCT cis.ingredient_name, mi.quantity_required
                FROM menu_ingredients mi
                JOIN current_ingredients_stock cis ON cis.id = mi.ingredient_id
                WHERE mi.menu_id = $menu_id
                GROUP BY cis.ingredient_name");
            
            if ($resIngredients) {
                while ($ing = $resIngredients->fetch_assoc()) {
                    $ingredient_name = $ing['ingredient_name'];
                    $quantity_used = $ing['quantity_required'] * $quantity;
                    
                    // Use smart deduction procedure (handles multiple batches automatically)
                    $deductStmt = $conn->prepare("CALL deduct_ingredient_smart(?, ?, ?)");
                    $deductStmt->bind_param('sdi', $ingredient_name, $quantity_used, $order_id);
                    $deductStmt->execute();
                    
                    // Check if any ingredient with this name is now depleted
                    $totalQuery = $conn->query("SELECT get_total_ingredient_quantity('$ingredient_name') as total");
                    $totalRow = $totalQuery->fetch_assoc();
                    $remaining = floatval($totalRow['total'] ?? 0);
                    
                    if ($remaining <= 0) {
                        // Disable menu items that require this ingredient
                        $conn->query("UPDATE menu m
                            JOIN menu_ingredients mi ON mi.menu_id = m.id
                            JOIN current_ingredients_stock cis ON cis.id = mi.ingredient_id
                            SET m.status = 'unavailable'
                            WHERE cis.ingredient_name = '$ingredient_name'");
                    }
                }
            }
        }
    }

    // Mark order as completed and stamp date
    if (!$conn->query("UPDATE orders SET status='completed', order_date=NOW() WHERE id=$order_id")) {
        throw new Exception('Failed to complete order');
    }

    $conn->commit();

    $_SESSION['payment_success'] = 'Payment successful. Order completed.';
    header('Location: orders.php');
    exit;
} catch (Exception $e) {
    $conn->rollback();
    $_SESSION['payment_error'] = $e->getMessage();
    header('Location: payment.php');
    exit;
}
?>
