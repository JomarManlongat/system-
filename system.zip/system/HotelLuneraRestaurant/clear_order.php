<?php
session_name('RESTAURANT_SESSION');
session_start();
include 'connection.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Not logged in']);
    exit;
}

$user_id = intval($_SESSION['user_id']);
$payment_method = isset($_POST['payment_method']) ? trim($_POST['payment_method']) : 'Cash';

// Find pending order
$resOrder = $conn->prepare("SELECT id FROM orders WHERE user_id=? AND status='pending' LIMIT 1");
$resOrder->bind_param('i', $user_id);
$resOrder->execute();
$result = $resOrder->get_result();
if (!$result || $result->num_rows === 0) {
    echo json_encode(['status' => 'error', 'message' => 'No active order']);
    exit;
}
$order_id = intval($result->fetch_assoc()['id']);

// Compute total
$sqlTotal = "SELECT IFNULL(SUM(oi.quantity * m.price),0) AS total
             FROM order_items oi JOIN menu m ON m.id=oi.menu_id
             WHERE oi.order_id=?";
$stmtTotal = $conn->prepare($sqlTotal);
$stmtTotal->bind_param('i', $order_id);
$stmtTotal->execute();
$totRes = $stmtTotal->get_result();
$total = $totRes ? floatval($totRes->fetch_assoc()['total'] ?? 0) : 0.0;

if ($total <= 0) {
    echo json_encode(['status' => 'error', 'message' => 'Order has no items']);
    exit;
}


$conn->begin_transaction();
try {
    // Idempotency: ensure a single profit record per order
    $chk = $conn->prepare("SELECT id FROM profits WHERE order_id=? LIMIT 1");
    $chk->bind_param('i', $order_id);
    $chk->execute();
    $exists = $chk->get_result();
    $hasProfit = $exists && $exists->num_rows > 0;

    if (!$hasProfit) {
        // Insert revenue into profits
        $ins = $conn->prepare("INSERT INTO profits (order_id, cashier_id, total_amount, payment_method) VALUES (?, ?, ?, ?)");
        $ins->bind_param('iids', $order_id, $user_id, $total, $payment_method);
        if (!$ins->execute()) {
            throw new Exception('Failed to record revenue');
        }
    }

    // Check stock availability first
    $resCheckItems = $conn->query("SELECT oi.menu_id, oi.quantity, m.name as menu_name
        FROM order_items oi 
        JOIN menu m ON m.id = oi.menu_id
        WHERE oi.order_id = $order_id");
    
    if ($resCheckItems) {
        while ($item = $resCheckItems->fetch_assoc()) {
            $menu_id = $item['menu_id'];
            $order_qty = $item['quantity'];
            $menu_name = $item['menu_name'];
            
            // Check ingredients availability
            $resCheckIng = $conn->query("SELECT mi.ingredient_id, mi.quantity_required, 
                cis.ingredient_name, cis.current_quantity
                FROM menu_ingredients mi
                JOIN current_ingredients_stock cis ON cis.id = mi.ingredient_id
                WHERE mi.menu_id = $menu_id");
            
            if ($resCheckIng) {
                while ($ing = $resCheckIng->fetch_assoc()) {
                    $needed = $ing['quantity_required'] * $order_qty;
                    $available = $ing['current_quantity'];
                    
                    if ($available < $needed) {
                        throw new Exception('Insufficient stock: ' . $ing['ingredient_name'] . 
                            ' for ' . $menu_name . '. Need: ' . $needed . ', Available: ' . $available);
                    }
                }
            }
        }
    }
    
    // Deduct ingredients from stock
    $resOrderItems = $conn->query("SELECT oi.menu_id, oi.quantity 
        FROM order_items oi 
        WHERE oi.order_id = $order_id");
    
    if ($resOrderItems) {
        while ($item = $resOrderItems->fetch_assoc()) {
            $menu_id = $item['menu_id'];
            $quantity = $item['quantity'];
            
            // Get ingredients for this menu item
            $resIngredients = $conn->query("SELECT mi.ingredient_id, mi.quantity_required, cis.ingredient_name
                FROM menu_ingredients mi
                JOIN current_ingredients_stock cis ON cis.id = mi.ingredient_id
                WHERE mi.menu_id = $menu_id");
            
            if ($resIngredients) {
                while ($ing = $resIngredients->fetch_assoc()) {
                    $ingredient_id = $ing['ingredient_id'];
                    $quantity_used = $ing['quantity_required'] * $quantity;
                    
                    // Update stock (prevent negative)
                    $updateStmt = $conn->prepare("UPDATE current_ingredients_stock 
                        SET current_quantity = GREATEST(0, current_quantity - ?) 
                        WHERE id = ?");
                    $updateStmt->bind_param('di', $quantity_used, $ingredient_id);
                    $updateStmt->execute();
                    
                    // Check if stock reached 0 and disable related menu items
                    $checkStock = $conn->query("SELECT current_quantity FROM current_ingredients_stock WHERE id = $ingredient_id");
                    if ($checkStock) {
                        $stockRow = $checkStock->fetch_assoc();
                        if ($stockRow['current_quantity'] <= 0) {
                            // Disable menu items that use this depleted ingredient
                            $conn->query("UPDATE menu m 
                                JOIN menu_ingredients mi ON mi.menu_id = m.id 
                                SET m.status = 'unavailable' 
                                WHERE mi.ingredient_id = $ingredient_id");
                        }
                    }
                    
                    // Log usage
                    $logStmt = $conn->prepare("INSERT INTO ingredient_usage_log 
                        (ingredient_id, order_id, quantity_used, notes) 
                        VALUES (?, ?, ?, ?)");
                    $notes = "Used for order #$order_id";
                    $logStmt->bind_param('iids', $ingredient_id, $order_id, $quantity_used, $notes);
                    $logStmt->execute();
                }
            }
        }
    }

    // Complete order and timestamp
    if (!$conn->query("UPDATE orders SET status='completed', order_date=NOW() WHERE id=$order_id")) {
        throw new Exception('Failed to complete order');
    }

    $conn->commit();
    echo json_encode(['status' => 'success', 'order_id' => $order_id, 'total' => $total]);
} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
