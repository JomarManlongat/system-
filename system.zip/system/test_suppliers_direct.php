<?php
// Quick test to see if suppliers database returns data
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_name('INVENTORY_SESSION');
session_start();

// Mock session data for testing
if (!isset($_SESSION['UserID'])) {
    $_SESSION['UserID'] = 'TEST_USER';
    $_SESSION['Role'] = 'staff';
    $_SESSION['user_location'] = 'Restaurant';
}

require(__DIR__ . '/main_inventory_system/admin-page/suppliers/suppliers_database.php');
?>
